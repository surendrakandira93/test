CREATE TABLE [dbo].[Role]
(
	[Id] INT NOT NULL IDENTITY(1,1),
    [Name] VARCHAR(100) NOT NULL,
	[Description] VARCHAR(250) NULL,
    CONSTRAINT [PK_Role_Id] PRIMARY KEY ([Id])
)

CREATE TABLE [dbo].[Institute] (
    [Id]   int identity(1,1) NOT NULL,
    [Name] NVARCHAR (75) NOT  NULL,
	[LogoPath] NVARCHAR (75)   NULL,
    CONSTRAINT [PK_Institute_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Branch] (
    [Id]				INT IDENTITY(1,1) NOT NULL,
    [InstituteId]		INT NOT NULL,
	[RegistrationNo]    NVARCHAR (100)   NULL,
	[PrincipalName]     NVARCHAR (100)  NOT NULL,
	[ACStartYear]       NVARCHAR (100)   NULL,
	[AccreditedBy]      NVARCHAR (100)   NULL,
	[BillingName]       NVARCHAR (100)  NOT NULL,
    [Name]				NVARCHAR (75)   NOT NULL,    
    [Address1]			NVARCHAR (255)  NOT NULL,
    [Address2]			NVARCHAR (155)   NULL,
    [Email]				NVARCHAR (100)  NOT NULL,
    [FaxNo]				NVARCHAR (50)    NULL,
    [Mobile]			NVARCHAR (50)   NOT NULL,
    [PhoneNo]			NVARCHAR (50)    NULL,    
    [StateId]			INT NOT NULL,    
    [District]			NVARCHAR (50)    NULL,
    [Pin]				NVARCHAR (6)    NULL,
    [BranchType]		TINYINT          NULL,    
    CONSTRAINT [PK_Branch_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Branch_Institute_InstituteId]	FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);



CREATE TABLE [dbo].[UserLogin] (
    [Id]                 BIGINT IDENTITY(1,1) NOT NULL,
    [Email]              NVARCHAR (50)    NULL,
    [EmailConfirmed]     BIT              NULL,
    [InstituteId]        INT NOT NULL,
    [BranchId]           INT NOT NULL,
    [FirstName]          NVARCHAR (50)    NULL,
    [MiddleName]         NVARCHAR (50)    NULL,
    [LastName]           NVARCHAR (50)    NULL,
    [Password]           NVARCHAR (50)    NULL,
    [NormalizedUserName] NVARCHAR (255)   NULL,
    [PhoneNumber]        NVARCHAR (255)   NULL,
    [UserName]           NVARCHAR (255)   NULL,
    [AvatarURL]          NVARCHAR (255)   NULL,
    [NickName]           NVARCHAR (255)   NULL,
    [Position]           NVARCHAR (255)   NULL,
    [UserType]           BIT              NULL,
	[RoleId]             INT         NULL,
    CONSTRAINT [PK_UserLogin_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_UserLogin_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_UserLogin_Institute_InstituteI] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id]),
	CONSTRAINT [FK_User_RoleId_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role]([Id])
);


-- A-,O-,A+,B+,AB-,O+,AB+,B-
CREATE TABLE [dbo].[BloodGroup] (
    [Id]          INT NOT NULL,
    [Name]        NVARCHAR (75)    NULL,
    CONSTRAINT [PK_BloodGroup_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
)

-- SC,OBC,Minority,General,ST
CREATE TABLE [dbo].[Category] (
    [Id]          INT IDENTITY(1,1) NOT NULL,
    [Name]        NVARCHAR (75)    NULL,
    CONSTRAINT [PK_Category_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
);

-- Annualy,Manual,Session,II-Innings,I-Innings,Monthly,Seprate,AutoManual,Auto,Contineu,None
-- PDC,TON,PDC,ATD,ATD,PDC,DT,TON,TON,DT,PDC
CREATE TABLE [dbo].[ComboMaster] (
    [Id]          BIGINT IDENTITY(1,1)	NOT NULL,
	[Name]		  NVARCHAR(150)		NOT NULL,
	[CType]		  NVARCHAR(50)		NOT NULL,
    CONSTRAINT [PK_ComboMaster_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
	);

-- INDIA
-- 91
CREATE TABLE [dbo].[Country] (
    [Id]          INT IDENTITY(1,1) NOT NULL,
    [Name]        NVARCHAR (75)    NULL,
    [CountryCode] NVARCHAR (50)    NULL,
    CONSTRAINT [PK_Country_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);


-- WEST BENGAL,KERALA,ARUNACHAL PRADESH,JHARKHAND,MANIPUR,PONDICHERRY,HIMACHAL PRADESH,JAMMU AND KASHMIR,DELHI,CHATTISGARH,GUJARAT,ORISSA,AANDAMAN AND NICOBAR ISLANDS,LAKHSWADEEP,TAMIL NADU,GOA,DADRA AND NAGAR HAVELI,CHANDIGARH,DAMAN AND DIU,BIHAR,ASSAM,UTTARANCHAL,PUNJAB,SIKKIM,MAHARASHTRA,NAGALAND,UTTAR PRADESH,MIZORAM,HARYANA,TRIPURA,ANDHRA PRADESH,KARNATAKA,RAJASTHAN,MADHYA PRADESH,MEGHALAYA
CREATE TABLE [dbo].[State] (
    [Id]        INT IDENTITY(1,1) NOT NULL,
    [Name]      NVARCHAR (50)    NULL,
    [CountryId] INT NULL,
    CONSTRAINT [PK_State_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_State_Country_CountryId] FOREIGN KEY ([CountryId]) REFERENCES [dbo].[Country] ([Id])
);


CREATE TABLE [dbo].[FamilyRelation] (
    [Id]          int identity(1,1) NOT NULL,
    [Name]        NVARCHAR (75)  not  NULL,
    CONSTRAINT [PK_FamilyRelation_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
)

CREATE TABLE [dbo].[Gender] (
    [Id]          int identity(1,1) NOT NULL,
    [Name]        NVARCHAR (75)    NULL,
    CONSTRAINT [PK_Gender_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
);
