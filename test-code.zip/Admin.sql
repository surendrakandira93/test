
CREATE TABLE [dbo].[Caste] (
    [Id]          BIGINT IDENTITY(1,1) NOT NULL,
    [InstituteId] INT NOT NULL,
    [BranchId]    INT NOT NULL,
	[Name]        NVARCHAR (75) NOT NULL,
    CONSTRAINT [PK_Caste_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Caste_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_Caste_Institute_InstituteId] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);

CREATE TABLE [dbo].[ClassList] (
    [Id]          BIGINT IDENTITY(1,1) NOT NULL,
    [InstituteId] INT NOT NULL,
    [BranchId]    INT NOT NULL,
	[Name]        NVARCHAR (50)  NOT  NULL,
    [NextClass]   NVARCHAR (50) NOT   NULL,
    CONSTRAINT [PK_ClassList_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ClassList_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_ClassList_Institute_InstituteId] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);


CREATE TABLE [dbo].[DisabilityType] (
    [Id]          BIGINT IDENTITY(1,1) NOT NULL,
    [InstituteId] INT NOT NULL,
    [BranchId]    INT NOT NULL,
    [Name]        VARCHAR (75)  NOT NULL,
    CONSTRAINT [PK_DisabilityType_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_DisabilityType_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_DisabilityType_Institute_InstituteId] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);


CREATE TABLE [dbo].[Document] (
    [Id]          bigint identity(1,1) NOT NULL,
    [InstituteId] int NOT NULL,
    [BranchId]    int NOT NULL,
    [Name]        NVARCHAR (100) not  NULL,
    CONSTRAINT [PK_Document_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Document_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_Document_Institute_InstituteId] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);


CREATE TABLE [dbo].[House] (
    [Id]          bigint identity(1,1) NOT NULL,
    [InstituteId] int NOT NULL,
    [BranchId]    int NOT NULL,
    [Name]        NVARCHAR (100) not  NULL,
    CONSTRAINT [PK_House_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_House_Branch_BranchId] FOREIGN KEY ([BranchId]) REFERENCES [dbo].[Branch] ([Id]),
    CONSTRAINT [FK_House_Institute_InstituteId] FOREIGN KEY ([InstituteId]) REFERENCES [dbo].[Institute] ([Id])
);














