﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace PaytmApp.Models
{
    public static class SiteKeys
    {
        public static string Domain
        {
            get { return ConfigurationManager.AppSettings["domain"]; }
        }
        public static string MerchantId { get { return ConfigurationManager.AppSettings["MerchantId"]; } }
        public static string MerchantKey { get { return ConfigurationManager.AppSettings["MerchantKey"]; } }
        public static string WebsiteName { get { return ConfigurationManager.AppSettings["WebsiteName"]; } }
        public static string IndustryType { get { return ConfigurationManager.AppSettings["IndustryType"]; } }
        public static string ApiUrl { get { return ConfigurationManager.AppSettings["ApiUrl"]; } }
        public static string IsLive { get { return ConfigurationManager.AppSettings["IsLive"]; } }
    }
}