﻿using PaytmApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PaytmApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            String callbackUrl = $"{SiteKeys.Domain}home/response";
            Dictionary<String, String> paytmParams = new Dictionary<String, String>();
            RemotePost myremotepost = new RemotePost();
            //posting all the parameters required for integration.
            string mKey = SiteKeys.MerchantKey;
            mKey = mKey.Replace("__", "&");
            myremotepost.Url = SiteKeys.ApiUrl;
            paytmParams.Add("MID", SiteKeys.MerchantId);
            paytmParams.Add("CHANNEL_ID", "WEB");
            paytmParams.Add("WEBSITE", SiteKeys.WebsiteName);
            paytmParams.Add("CALLBACK_URL", callbackUrl);
            paytmParams.Add("CUST_ID", $"cust{DateTime.Now.TimeOfDay.Ticks}");
            paytmParams.Add("MOBILE_NO", "7976910368");
            paytmParams.Add("EMAIL", "sk@gmail.com");
            paytmParams.Add("ORDER_ID", DateTime.Now.ToString("ddMMyyyhhmmss"));
            paytmParams.Add("INDUSTRY_TYPE_ID", SiteKeys.IndustryType);//Change the failure url here depending upon the port number of your local system.
            paytmParams.Add("TXN_AMOUNT", "100.53");
            string paytmChecksum = paytm.CheckSum.generateCheckSum(mKey, paytmParams);
            foreach (string key in paytmParams.Keys)
            {
                myremotepost.Add(key, paytmParams[key]);
            }
            myremotepost.Add("CHECKSUMHASH", paytmChecksum);
            
            myremotepost.Post();
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}