﻿using System;
using System.Data.Entity;
using EngineerPark.Data.Mapping;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data
{
    public partial class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
              : base("Name=ProjectDbContext")
        {
        }
        public virtual DbSet<AnnualCpmbudget> AnnualCpmbudget { get; set; }
        public virtual DbSet<AstbconveningOrder> AstbconveningOrder { get; set; }
        public virtual DbSet<AstbconveningOrderApproval> AstbconveningOrderApproval { get; set; }
        public virtual DbSet<AstbsalvageTemp> AstbsalvageTemp { get; set; }
        public virtual DbSet<Astbstore> Astbstore { get; set; }
        public virtual DbSet<AstbstoreDetail> AstbstoreDetail { get; set; }
        public virtual DbSet<AuthorityLetter> AuthorityLetter { get; set; }
        public virtual DbSet<AuthorityLetterApproval> AuthorityLetterApproval { get; set; }
        public virtual DbSet<AuthorityLetterVechileDetail> AuthorityLetterVechileDetail { get; set; }
        public virtual DbSet<AvailabilityCertIssue> AvailabilityCertIssue { get; set; }
        public virtual DbSet<AvailabilityCertIssueApproval> AvailabilityCertIssueApproval { get; set; }
        public virtual DbSet<AvailabilityCertIssueDetail> AvailabilityCertIssueDetail { get; set; }
        public virtual DbSet<AvailabilityCertRequest> AvailabilityCertRequest { get; set; }
        public virtual DbSet<AvailabilityCertRequestApproval> AvailabilityCertRequestApproval { get; set; }
        public virtual DbSet<AvailabilityCertRequestDetail> AvailabilityCertRequestDetail { get; set; }
        public virtual DbSet<BasicCategory> BasicCategory { get; set; }
        public virtual DbSet<Bdofficer> Bdofficer { get; set; }
        public virtual DbSet<CarePrice> CarePrice { get; set; }
        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<ConveningOrder> ConveningOrder { get; set; }
        public virtual DbSet<ConveningOrderApproval> ConveningOrderApproval { get; set; }
        public virtual DbSet<ConveningOrderIssue> ConveningOrderIssue { get; set; }
        public virtual DbSet<ConveningOrderItem> ConveningOrderItem { get; set; }
        public virtual DbSet<ConveningOrderItemSurvey> ConveningOrderItemSurvey { get; set; }
        public virtual DbSet<ConveningOrderItemSurveyMain> ConveningOrderItemSurveyMain { get; set; }
        public virtual DbSet<ConveningOrderMember> ConveningOrderMember { get; set; }
        public virtual DbSet<ConveningOrderSurveySalvageTemp> ConveningOrderSurveySalvageTemp { get; set; }
        public virtual DbSet<ConveyNote> ConveyNote { get; set; }
        public virtual DbSet<ConveyNoteApproval> ConveyNoteApproval { get; set; }
       // public virtual DbSet<ConveyNoteDetail> ConveyNoteDetail { get; set; }
        public virtual DbSet<Country> Country { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Designation> Designation { get; set; }
        public virtual DbSet<Equipment> Equipment { get; set; }
        public virtual DbSet<EquipmentType> EquipmentType { get; set; }
        public virtual DbSet<GatePass> GatePass { get; set; }
        public virtual DbSet<GatePassApproval> GatePassApproval { get; set; }
        public virtual DbSet<GatePassDetail> GatePassDetail { get; set; }
        public virtual DbSet<GroupItem> GroupItem { get; set; }
        public virtual DbSet<GroupItemBasicCategory> GroupItemBasicCategory { get; set; }
        public virtual DbSet<GroupItemDetail> GroupItemDetail { get; set; }
        public virtual DbSet<Item> Item { get; set; }
        public virtual DbSet<ItemBasicCategory> ItemBasicCategory { get; set; }
        public virtual DbSet<ItemEquipment> ItemEquipment { get; set; }
        public virtual DbSet<ItemEquipmentType> ItemEquipmentType { get; set; }
        public virtual DbSet<ItemPart> ItemPart { get; set; }
        public virtual DbSet<ItemSetNumber> ItemSetNumber { get; set; }
        public virtual DbSet<ItemStatus> ItemStatus { get; set; }
        public virtual DbSet<JobOrder> JobOrder { get; set; }
        public virtual DbSet<JobOrderApproval> JobOrderApproval { get; set; }
        public virtual DbSet<JobOrderDetail> JobOrderDetail { get; set; }
        public virtual DbSet<JobOrderDetailsGroupItem> JobOrderDetailsGroupItem { get; set; }
        public virtual DbSet<JobOrderDetailsItem> JobOrderDetailsItem { get; set; }
        public virtual DbSet<JobOrderTemp> JobOrderTemp { get; set; }
        public virtual DbSet<Level> Level { get; set; }
        public virtual DbSet<LoadTrolley> LoadTrolley { get; set; }
        public virtual DbSet<LoadTrolleyItem> LoadTrolleyItem { get; set; }
        public virtual DbSet<LoanExtension> LoanExtension { get; set; }
        public virtual DbSet<LoanExtensionApproval> LoanExtensionApproval { get; set; }
        public virtual DbSet<LoanExtensionDetail> LoanExtensionDetail { get; set; }
        public virtual DbSet<LoanIssueVoucher> LoanIssueVoucher { get; set; }
        public virtual DbSet<LoanIssueVoucherDetail> LoanIssueVoucherDetail { get; set; }
        public virtual DbSet<LoanReceiptVoucher> LoanReceiptVoucher { get; set; }
        public virtual DbSet<LoanReceiptVoucherDetail> LoanReceiptVoucherDetail { get; set; }
        public virtual DbSet<LoanRenewal> LoanRenewal { get; set; }
        public virtual DbSet<LoanRenewalApproval> LoanRenewalApproval { get; set; }
        public virtual DbSet<LoanRenewalDetail> LoanRenewalDetail { get; set; }
        public virtual DbSet<LoanRequest> LoanRequest { get; set; }
        public virtual DbSet<LoanRequestAssign> LoanRequestAssign { get; set; }
        public virtual DbSet<LoanRequestDetail> LoanRequestDetail { get; set; }
        public virtual DbSet<Loginhistory> Loginhistory { get; set; }
        public virtual DbSet<MaintenancePlan> MaintenancePlan { get; set; }
        public virtual DbSet<MaintenancePlanApproval> MaintenancePlanApproval { get; set; }
        public virtual DbSet<MaintenancePlanDetail> MaintenancePlanDetail { get; set; }
        public virtual DbSet<MaintenancePlanDetailsGroupItem> MaintenancePlanDetailsGroupItem { get; set; }
        public virtual DbSet<MaintenancePlanDetailsItem> MaintenancePlanDetailsItem { get; set; }
        public virtual DbSet<MaintenanceSchedulePlan> MaintenanceSchedulePlan { get; set; }
        public virtual DbSet<MaintenanceSchedulePlanApproval> MaintenanceSchedulePlanApproval { get; set; }
        public virtual DbSet<MaterialType> MaterialType { get; set; }
        public virtual DbSet<Menu> Menu { get; set; }
        public virtual DbSet<MenuPermission> MenuPermission { get; set; }
        public virtual DbSet<Organization> Organization { get; set; }
        public virtual DbSet<OrganizationType> OrganizationType { get; set; }
        public virtual DbSet<Origin> Origin { get; set; }
        public virtual DbSet<Periodicity> Periodicity { get; set; }
        public virtual DbSet<Permission> Permission { get; set; }
        public virtual DbSet<QuarterlyMaintenancePlan> QuarterlyMaintenancePlan { get; set; }
        public virtual DbSet<QuarterlyMaintenancePlanApproval> QuarterlyMaintenancePlanApproval { get; set; }
        public virtual DbSet<QuarterlyMaintenancePlanDetail> QuarterlyMaintenancePlanDetail { get; set; }
        public virtual DbSet<QuarterlyMaintenancePlanDetailsGroupItem> QuarterlyMaintenancePlanDetailsGroupItem { get; set; }
        public virtual DbSet<QuarterlyMaintenancePlanDetailsItem> QuarterlyMaintenancePlanDetailsItem { get; set; }
        public virtual DbSet<RefactorLog> RefactorLog { get; set; }
        public virtual DbSet<ReleaseOrder> ReleaseOrder { get; set; }
        public virtual DbSet<ReleaseOrderApproval> ReleaseOrderApproval { get; set; }
        public virtual DbSet<ReleaseOrderDetail> ReleaseOrderDetail { get; set; }
        public virtual DbSet<Report> Report { get; set; }
        public virtual DbSet<ReportPermission> ReportPermission { get; set; }
        public virtual DbSet<ReportUserHistory> ReportUserHistory { get; set; }
        public virtual DbSet<ReportUserPermission> ReportUserPermission { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RoleMenu> RoleMenu { get; set; }
        public virtual DbSet<RoleMenuPermission> RoleMenuPermission { get; set; }
        public virtual DbSet<SalvageIn> SalvageIn { get; set; }
        public virtual DbSet<SalvageOut> SalvageOut { get; set; }
        public virtual DbSet<SenctionOrder> SenctionOrder { get; set; }
        public virtual DbSet<SenctionOrderApproval> SenctionOrderApproval { get; set; }
        public virtual DbSet<ShedType> ShedType { get; set; }
        public virtual DbSet<State> State { get; set; }
        public virtual DbSet<Status> Status { get; set; }
        public virtual DbSet<StockShed> StockShed { get; set; }
        public virtual DbSet<StoreStock> StoreStock { get; set; }
        public virtual DbSet<StoreStockItemAuthority> StoreStockItemAuthority { get; set; }
        public virtual DbSet<StoreStockTransaction> StoreStockTransaction { get; set; }
        public virtual DbSet<StoreStockTransactionQuantity> StoreStockTransactionQuantity { get; set; }
        public virtual DbSet<StoreStockTransactionSetNo> StoreStockTransactionSetNo { get; set; }
        public virtual DbSet<SubOrganizationType> SubOrganizationType { get; set; }
        public virtual DbSet<Task> Task { get; set; }
        public virtual DbSet<TaskWorkFlow> TaskWorkFlow { get; set; }
        public virtual DbSet<TransactionType> TransactionType { get; set; }
        public virtual DbSet<UnitOfMeasure> UnitOfMeasure { get; set; }
        public virtual DbSet<UnitStock> UnitStock { get; set; }
        //public virtual DbSet<UnitStockItemAuthority> UnitStockItemAuthority { get; set; }
       // public virtual DbSet<UnitStockTransaction> UnitStockTransaction { get; set; }
        public virtual DbSet<UnitType> UnitType { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserMack> UserMack { get; set; }
        public virtual DbSet<UserPermission> UserPermission { get; set; }
        public virtual DbSet<UserType> UserType { get; set; }
        public virtual DbSet<Year> Year { get; set; }

        //================[VIEW]================
        public virtual DbSet<MasterDataView> MasterDataDB { get; set; }
        public virtual DbSet<DepositeStatusReportEDB> DepositeStatus { get; set; }
        public virtual DbSet<ETSRStateView> ETSRState { get; set; }
        public virtual DbSet<AuthorizedItemMSLView> AuthorizedItemMSLView { get; set; }
        public virtual DbSet<BlockQuantityView> BlockQuantityView { get; set; }
        public virtual DbSet<BlockQuantitySetWiseView> BlockQuantitySetWiseView { get; set; }
        public virtual DbSet<CurrentStockQuantityView> CurrentStockQuantityView { get; set; }
        public virtual DbSet<CurrentStockQuantitySetWiseView> CurrentStockQuantitySetWiseView { get; set; }
        public virtual DbSet<StockQuantityView> StockQuantityView { get; set; }
        public virtual DbSet<StockQuantitySetWiseView> StockQuantitySetWiseView { get; set; }
        //public virtual DbSet<SP_StockPrint> SP_StockPrint { get; set; }


        public virtual DbSet<LoanDepositedStatusView> LoanDepositedStatusView { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder) {
            modelBuilder.Configurations.Add(new ASTBSalvageTempMap());
            modelBuilder.Configurations.Add(new BasicCategoryMap());
            modelBuilder.Configurations.Add(new CarePriceMap());
            modelBuilder.Configurations.Add(new CategoryMap());
            modelBuilder.Configurations.Add(new ConveningOrderSurveySalvageTempMap());
            modelBuilder.Configurations.Add(new CountryMap());
            modelBuilder.Configurations.Add(new DepartmentMap());
            modelBuilder.Configurations.Add(new DesignationMap());
            modelBuilder.Configurations.Add(new EquipmentMap());
            modelBuilder.Configurations.Add(new EquipmentTypeMap());
            modelBuilder.Configurations.Add(new GroupItemMap());
            modelBuilder.Configurations.Add(new GroupItemBasicCategoryMap());
            modelBuilder.Configurations.Add(new GroupItemDetailMap());
            modelBuilder.Configurations.Add(new ItemMap());
            modelBuilder.Configurations.Add(new ItemBasicCategoryMap());
            modelBuilder.Configurations.Add(new ItemEquipmentMap());
            modelBuilder.Configurations.Add(new ItemEquipmentTypeMap());
            modelBuilder.Configurations.Add(new ItemPartMap());
            modelBuilder.Configurations.Add(new ItemSetNumberMap());
            modelBuilder.Configurations.Add(new ItemStatuMap());
            modelBuilder.Configurations.Add(new JobOrderMap());
            modelBuilder.Configurations.Add(new JobOrderApprovalMap());
            modelBuilder.Configurations.Add(new JobOrderDetailMap());
            modelBuilder.Configurations.Add(new JobOrderDetailsGroupItemMap());
            modelBuilder.Configurations.Add(new JobOrderDetailsItemMap());
            modelBuilder.Configurations.Add(new JobOrderTempMap());
            modelBuilder.Configurations.Add(new LevelMap());
            modelBuilder.Configurations.Add(new LoanExtensionMap());
            modelBuilder.Configurations.Add(new LoanExtensionApprovalMap());
            modelBuilder.Configurations.Add(new LoanExtensionDetailMap());
            modelBuilder.Configurations.Add(new LoanRenewalMap());
            modelBuilder.Configurations.Add(new LoanRenewalApprovalMap());
            modelBuilder.Configurations.Add(new LoanRenewalDetailMap());
            modelBuilder.Configurations.Add(new LoginhistoryMap());
            modelBuilder.Configurations.Add(new MaintenancePlanMap());
            modelBuilder.Configurations.Add(new MaintenancePlanApprovalMap());
            modelBuilder.Configurations.Add(new MaintenancePlanDetailMap());
            modelBuilder.Configurations.Add(new MaintenancePlanDetailsGroupItemMap());
            modelBuilder.Configurations.Add(new MaintenancePlanDetailsItemMap());
            modelBuilder.Configurations.Add(new MaintenanceSchedulePlanMap());
            modelBuilder.Configurations.Add(new MaintenanceSchedulePlanApprovalMap());
            modelBuilder.Configurations.Add(new MaterialTypeMap());
            modelBuilder.Configurations.Add(new MenuMap());
            modelBuilder.Configurations.Add(new MenuPermissionMap());
            modelBuilder.Configurations.Add(new OrganizationMap());
            modelBuilder.Configurations.Add(new OrganizationTypeMap());
            modelBuilder.Configurations.Add(new OriginMap());
            modelBuilder.Configurations.Add(new PeriodicityMap());
            modelBuilder.Configurations.Add(new PermissionMap());
            modelBuilder.Configurations.Add(new QuarterlyMaintenancePlanMap());
            modelBuilder.Configurations.Add(new QuarterlyMaintenancePlanApprovalMap());
            modelBuilder.Configurations.Add(new QuarterlyMaintenancePlanDetailMap());
            modelBuilder.Configurations.Add(new QuarterlyMaintenancePlanDetailsGroupItemMap());
            modelBuilder.Configurations.Add(new QuarterlyMaintenancePlanDetailsItemMap());
            modelBuilder.Configurations.Add(new RefactorLogMap());
            modelBuilder.Configurations.Add(new ReportMap());
            modelBuilder.Configurations.Add(new ReportPermissionMap());
            modelBuilder.Configurations.Add(new ReportUserHistoryMap());
            modelBuilder.Configurations.Add(new ReportUserPermissionMap());
            modelBuilder.Configurations.Add(new RoleMap());
            modelBuilder.Configurations.Add(new RoleMenuMap());
            modelBuilder.Configurations.Add(new RoleMenuPermissionMap());
            modelBuilder.Configurations.Add(new SalvageInMap());
            modelBuilder.Configurations.Add(new SalvageOutMap());
            modelBuilder.Configurations.Add(new ShedTypeMap());
            modelBuilder.Configurations.Add(new StateMap());
            modelBuilder.Configurations.Add(new StatusMap());
            modelBuilder.Configurations.Add(new StockShedMap());
            modelBuilder.Configurations.Add(new SubOrganizationTypeMap());
            modelBuilder.Configurations.Add(new TaskMap());
            modelBuilder.Configurations.Add(new TaskWorkFlowMap());
            modelBuilder.Configurations.Add(new TransactionTypeMap());
            modelBuilder.Configurations.Add(new UnitOfMeasureMap());
            modelBuilder.Configurations.Add(new UnitTypeMap());
            modelBuilder.Configurations.Add(new UserMap());
            modelBuilder.Configurations.Add(new UserMackMap());
            modelBuilder.Configurations.Add(new UserPermissionMap());
            modelBuilder.Configurations.Add(new UserTypeMap());
            modelBuilder.Configurations.Add(new YearMap());
            modelBuilder.Configurations.Add(new ASTBConveningOrderMap());
            modelBuilder.Configurations.Add(new ASTBConveningOrderApprovalMap());
            modelBuilder.Configurations.Add(new ASTBStoreMap());
            modelBuilder.Configurations.Add(new ASTBStoreDetailMap());
            modelBuilder.Configurations.Add(new AuthorityLetterMap());
            modelBuilder.Configurations.Add(new AuthorityLetterApprovalMap());
            modelBuilder.Configurations.Add(new AuthorityLetterVechileDetailMap());
            modelBuilder.Configurations.Add(new AvailabilityCertIssueMap());
            modelBuilder.Configurations.Add(new AvailabilityCertIssueApprovalMap());
            modelBuilder.Configurations.Add(new AvailabilityCertIssueDetailMap());
            modelBuilder.Configurations.Add(new AvailabilityCertRequestMap());
            modelBuilder.Configurations.Add(new AvailabilityCertRequestApprovalMap());
            modelBuilder.Configurations.Add(new AvailabilityCertRequestDetailMap());
            modelBuilder.Configurations.Add(new BDOfficerMap());
            //modelBuilder.Configurations.Add(new ConveningOrderMap());
           // modelBuilder.Configurations.Add(new ConveningOrderApprovalMap());
            modelBuilder.Configurations.Add(new ConveningOrderIssueMap());
            modelBuilder.Configurations.Add(new ConveningOrderItemMap());
            modelBuilder.Configurations.Add(new ConveningOrderItemSurveyMap());
            modelBuilder.Configurations.Add(new ConveningOrderItemSurveyMainMap());
            modelBuilder.Configurations.Add(new ConveningOrderMemberMap());
            modelBuilder.Configurations.Add(new ConveyNoteMap());
            modelBuilder.Configurations.Add(new ConveyNoteApprovalMap());
            //modelBuilder.Configurations.Add(new ConveyNoteDetailMap());
            modelBuilder.Configurations.Add(new GatePassMap());
            modelBuilder.Configurations.Add(new GatePassApprovalMap());
            modelBuilder.Configurations.Add(new GatePassDetailMap());
            modelBuilder.Configurations.Add(new LoadTrolleyMap());
            modelBuilder.Configurations.Add(new LoadTrolleyItemMap());
            modelBuilder.Configurations.Add(new LoanIssueVoucherMap());
            modelBuilder.Configurations.Add(new LoanIssueVoucherDetailMap());
            modelBuilder.Configurations.Add(new LoanReceiptVoucherMap());
            modelBuilder.Configurations.Add(new LoanReceiptVoucherDetailMap());
            modelBuilder.Configurations.Add(new LoanRequestMap());
            modelBuilder.Configurations.Add(new LoanRequestAssignMap());
            modelBuilder.Configurations.Add(new LoanRequestDetailMap());
            modelBuilder.Configurations.Add(new ReleaseOrderMap());
            modelBuilder.Configurations.Add(new ReleaseOrderApprovalMap());
            modelBuilder.Configurations.Add(new ReleaseOrderDetailMap());
            modelBuilder.Configurations.Add(new SenctionOrderMap());
            modelBuilder.Configurations.Add(new SenctionOrderApprovalMap());
            modelBuilder.Configurations.Add(new StoreStockMap());
            modelBuilder.Configurations.Add(new StoreStockItemAuthorityMap());
            modelBuilder.Configurations.Add(new StoreStockTransactionMap());
            modelBuilder.Configurations.Add(new StoreStockTransactionQuantityMap());
            modelBuilder.Configurations.Add(new StoreStockTransactionSetNoMap());
            modelBuilder.Configurations.Add(new UnitStockMap());
           // modelBuilder.Configurations.Add(new UnitStockItemAuthorityMap());
            //modelBuilder.Configurations.Add(new UnitStockTransactionMap());
            modelBuilder.Configurations.Add(new LoanDepositedStatusViewMap());
            //modelBuilder.Configurations.Add(new StateCustomLoanProcessViewMap());
            //modelBuilder.Configurations.Add(new StateCustomStoreViewMap());
            modelBuilder.Configurations.Add(new AuthorizedItemMSLViewMap());
            //modelBuilder.Configurations.Add(new AuthQtyViewMap());
            modelBuilder.Configurations.Add(new BasicCategorySummaryViewMap());
            //modelBuilder.Configurations.Add(new BasicCategoryViewMap());
            modelBuilder.Configurations.Add(new BasicCategoryWiseViewMap());
            //modelBuilder.Configurations.Add(new BlockQtyViewMap());
            modelBuilder.Configurations.Add(new BlockQuantitySetWiseViewMap());
            modelBuilder.Configurations.Add(new BlockQuantityViewMap());
            //modelBuilder.Configurations.Add(new CategoryViewMap());
            modelBuilder.Configurations.Add(new CategoryWiseViewMap());
            modelBuilder.Configurations.Add(new CurrentStockQuantitySetWiseViewMap());
            modelBuilder.Configurations.Add(new CurrentStockQuantityViewMap());
            //modelBuilder.Configurations.Add(new DepositQtyViewMap());
            modelBuilder.Configurations.Add(new ETSRStateViewMap());
            modelBuilder.Configurations.Add(new ETSRSummaryViewMap());
            //modelBuilder.Configurations.Add(new GetConveningAuthMap());
            //modelBuilder.Configurations.Add(new HeldQtyViewMap());
            //modelBuilder.Configurations.Add(new LoanDepositedViewMap());
            //modelBuilder.Configurations.Add(new LoanNotDepositedViewMap());
            modelBuilder.Configurations.Add(new LoanStateViewMap());
            //modelBuilder.Configurations.Add(new OnLoanQtyViewMap());
            //modelBuilder.Configurations.Add(new OnLoanViewMap());
            //modelBuilder.Configurations.Add(new RepairQtyViewMap());
            modelBuilder.Configurations.Add(new StockQuantitySetWiseViewMap());
            modelBuilder.Configurations.Add(new StockQuantityViewMap());
            //modelBuilder.Configurations.Add(new StockStateViewMap());


        }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<AnnualCpmbudget>(entity =>
        //    {
        //        entity.ToTable("AnnualCPMBudget");

        //        entity.Property(e => e.Cpmamount).HasColumnName("CPMAmount");

        //        entity.Property(e => e.Remark).HasMaxLength(500);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.AnnualCpmbudget)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AnnualCPMBudget_Organization_store");
        //    });

        //    modelBuilder.Entity<AstbconveningOrder>(entity =>
        //    {
        //        entity.ToTable("ASTBConveningOrder", "Main");

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.BooComposition).HasMaxLength(256);

        //        entity.Property(e => e.Bpodate).HasColumnName("BPODate");

        //        entity.Property(e => e.FileName).HasMaxLength(250);

        //        entity.Property(e => e.Fyear)
        //            .IsRequired()
        //            .HasColumnName("fyear")
        //            .HasMaxLength(15);

        //        entity.Property(e => e.LetterNo)
        //            .IsRequired()
        //            .HasMaxLength(50);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.CreatedByNavigation)
        //            .WithMany(p => p.AstbconveningOrderCreatedByNavigation)
        //            .HasForeignKey(d => d.CreatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.PresidingOfficer)
        //            .WithMany(p => p.AstbconveningOrderPresidingOfficer)
        //            .HasForeignKey(d => d.PresidingOfficerId)
        //            .HasConstraintName("FK_ASTBConveningOrder_User_PO");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.AstbconveningOrderStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBConveningOrder_Organization_store");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.AstbconveningOrderUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBConveningOrder_Organization_Unit");

        //        entity.HasOne(d => d.UpdatedByNavigation)
        //            .WithMany(p => p.AstbconveningOrderUpdatedByNavigation)
        //            .HasForeignKey(d => d.UpdatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<AstbconveningOrderApproval>(entity =>
        //    {
        //        entity.ToTable("ASTBConveningOrderApproval", "Main");

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AstbconveningOrderId).HasColumnName("ASTBConveningOrderId");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.AstbconveningOrder)
        //            .WithMany(p => p.AstbconveningOrderApproval)
        //            .HasForeignKey(d => d.AstbconveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBConveningOrderApproval_ASTBConveningOrder");

        //        entity.HasOne(d => d.CreatedByNavigation)
        //            .WithMany(p => p.AstbconveningOrderApprovalCreatedByNavigation)
        //            .HasForeignKey(d => d.CreatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.AstbconveningOrderApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBConveningOrderApproval_Designation_FromOrganization");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.AstbconveningOrderApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBConveningOrderApproval_Organization_FromOrganization");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.AstbconveningOrderApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_ASTBConveningOrderApproval_Designation_ToOrganizationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.AstbconveningOrderApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);

        //        entity.HasOne(d => d.UpdatedByNavigation)
        //            .WithMany(p => p.AstbconveningOrderApprovalUpdatedByNavigation)
        //            .HasForeignKey(d => d.UpdatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<AstbsalvageTemp>(entity =>
        //    {
        //        entity.ToTable("ASTBSalvageTemp");

        //        entity.Property(e => e.Astbid).HasColumnName("ASTBId");

        //        entity.Property(e => e.Auth)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Astb)
        //            .WithMany(p => p.AstbsalvageTemp)
        //            .HasForeignKey(d => d.Astbid)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.AstbsalvageTemp)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<Astbstore>(entity =>
        //    {
        //        entity.ToTable("ASTBStore", "Main");

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AstbconveningOrderId).HasColumnName("ASTBConveningOrderId");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.AstbconveningOrder)
        //            .WithMany(p => p.Astbstore)
        //            .HasForeignKey(d => d.AstbconveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStore_ASTBConveningOrderId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.Astbstore)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStore_GroupItem");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.Astbstore)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStore_Item");

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.Astbstore)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStore_ItemSetNumber");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.Astbstore)
        //            .HasForeignKey(d => d.StockShedId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStore_StockShed");
        //    });

        //    modelBuilder.Entity<AstbstoreDetail>(entity =>
        //    {
        //        entity.ToTable("ASTBStoreDetail", "Main");

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AstbstoreId).HasColumnName("ASTBStoreId");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 2)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Astbstore)
        //            .WithMany(p => p.AstbstoreDetail)
        //            .HasForeignKey(d => d.AstbstoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStoreDetail_ASTBStoreId");

        //        entity.HasOne(d => d.ItemStatus)
        //            .WithMany(p => p.AstbstoreDetail)
        //            .HasForeignKey(d => d.ItemStatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ASTBStoreDetail_ItemStatusId");
        //    });

        //    modelBuilder.Entity<AuthorityLetter>(entity =>
        //    {
        //        entity.ToTable("AuthorityLetter", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AuthorityLetter_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.LetterNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.AuthorityLetter)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetter_ReleaseOrderId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.AuthorityLetter)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetter_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.AuthorityLetterStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetter_Sotore");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.AuthorityLetterUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetter_Unit");
        //    });

        //    modelBuilder.Entity<AuthorityLetterApproval>(entity =>
        //    {
        //        entity.ToTable("AuthorityLetterApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AuthorityLetterApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AuthorityLetter)
        //            .WithMany(p => p.AuthorityLetterApproval)
        //            .HasForeignKey(d => d.AuthorityLetterId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetterApproval_AuthorityLetterId");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.AuthorityLetterApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetterApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.AuthorityLetterApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetterApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.AuthorityLetterApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_AuthorityLetterApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.AuthorityLetterApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_AuthorityLetterApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<AuthorityLetterVechileDetail>(entity =>
        //    {
        //        entity.ToTable("AuthorityLetterVechileDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AuthorityLetterVechileDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.DriverCode)
        //            .IsRequired()
        //            .HasMaxLength(25)
        //            .IsUnicode(false);

        //        entity.Property(e => e.DriverName)
        //            .IsRequired()
        //            .HasMaxLength(125)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.VechileNo)
        //            .IsRequired()
        //            .HasMaxLength(25)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.AuthorityLetter)
        //            .WithMany(p => p.AuthorityLetterVechileDetail)
        //            .HasForeignKey(d => d.AuthorityLetterId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AuthorityLetterVechileDetail_LoanRequestId");
        //    });

        //    modelBuilder.Entity<AvailabilityCertIssue>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertIssue", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertIssue_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CertificateNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ApprovedDesignation)
        //            .WithMany(p => p.AvailabilityCertIssueApprovedDesignation)
        //            .HasForeignKey(d => d.ApprovedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_ApprovedDesignationId");

        //        entity.HasOne(d => d.AssignedDesignation)
        //            .WithMany(p => p.AvailabilityCertIssueAssignedDesignation)
        //            .HasForeignKey(d => d.AssignedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_AssignedDesignationId");

        //        entity.HasOne(d => d.AvailabilityCertReqest)
        //            .WithMany(p => p.AvailabilityCertIssue)
        //            .HasForeignKey(d => d.AvailabilityCertReqestId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_AvailabilityCertReqestId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.AvailabilityCertIssue)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.AvailabilityCertIssueStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_Sotore");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.AvailabilityCertIssueUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssue_Unit");
        //    });

        //    modelBuilder.Entity<AvailabilityCertIssueApproval>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertIssueApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertIssueApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AvailabilityCertIssue)
        //            .WithMany(p => p.AvailabilityCertIssueApproval)
        //            .HasForeignKey(d => d.AvailabilityCertIssueId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueApproval_AvailabilityCertIssueId");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.AvailabilityCertIssueApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.AvailabilityCertIssueApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.AvailabilityCertIssueApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_AvailabilityCertIssueApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.AvailabilityCertIssueApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_AvailabilityCertIssueApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<AvailabilityCertIssueDetail>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertIssueDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertIssueDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AvailableQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RequestedQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AvailabilityCertIssue)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.AvailabilityCertIssueId)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_AvailabilityCertReqest");

        //        entity.HasOne(d => d.AvailabilityCertReqestDetail)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.AvailabilityCertReqestDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_AvailabilityCertReqestDetail");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.AvailabilityCertIssueDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertIssueDetail_Item");
        //    });

        //    modelBuilder.Entity<AvailabilityCertRequest>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertRequest", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertRequest_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.Authority)
        //            .IsRequired()
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RequestNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.Task)
        //            .IsRequired()
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ApprovedDesignation)
        //            .WithMany(p => p.AvailabilityCertRequestApprovedDesignation)
        //            .HasForeignKey(d => d.ApprovedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequest_ApprovedDesignationId");

        //        entity.HasOne(d => d.AssignedDesignation)
        //            .WithMany(p => p.AvailabilityCertRequestAssignedDesignation)
        //            .HasForeignKey(d => d.AssignedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequest_AssignedDesignationId");

        //        entity.HasOne(d => d.RequestedStore)
        //            .WithMany(p => p.AvailabilityCertRequestRequestedStore)
        //            .HasForeignKey(d => d.RequestedStoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequest_Sotore");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.AvailabilityCertRequest)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequest_StatusId");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.AvailabilityCertRequestUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequest_Unit");
        //    });

        //    modelBuilder.Entity<AvailabilityCertRequestApproval>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertRequestApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertRequestApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AvailabilityCertRequest)
        //            .WithMany(p => p.AvailabilityCertRequestApproval)
        //            .HasForeignKey(d => d.AvailabilityCertRequestId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequestApproval_AvailabilityCertRequestId");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.AvailabilityCertRequestApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequestApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.AvailabilityCertRequestApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequestApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.AvailabilityCertRequestApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_AvailabilityCertRequestApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.AvailabilityCertRequestApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_AvailabilityCertRequestApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<AvailabilityCertRequestDetail>(entity =>
        //    {
        //        entity.ToTable("AvailabilityCertRequestDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_AvailabilityCertRequestDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Justification)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AvailabilityCertRequest)
        //            .WithMany(p => p.AvailabilityCertRequestDetail)
        //            .HasForeignKey(d => d.AvailabilityCertRequestId)
        //            .HasConstraintName("FK_AvailabilityCertRequestDetail_AvailabilityCertRequest");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.AvailabilityCertRequestDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequestDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.AvailabilityCertRequestDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .HasConstraintName("FK_AvailabilityCertRequestDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.AvailabilityCertRequestDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_AvailabilityCertRequestDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.AvailabilityCertRequestDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_AvailabilityCertRequestDetail_Item");
        //    });

        //    modelBuilder.Entity<BasicCategory>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Bdofficer>(entity =>
        //    {
        //        entity.ToTable("BDOfficer", "Main");

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AstbconveningOrderId).HasColumnName("ASTBConveningOrderId");

        //        entity.Property(e => e.Name).HasMaxLength(50);

        //        entity.Property(e => e.Rank)
        //            .IsRequired()
        //            .HasMaxLength(50);

        //        entity.Property(e => e.Remark).HasMaxLength(50);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.AstbconveningOrder)
        //            .WithMany(p => p.Bdofficer)
        //            .HasForeignKey(d => d.AstbconveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_BDOfficer_ASTBConveningOrder");

        //        entity.HasOne(d => d.CreatedByNavigation)
        //            .WithMany(p => p.BdofficerCreatedByNavigation)
        //            .HasForeignKey(d => d.CreatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Designation)
        //            .WithMany(p => p.Bdofficer)
        //            .HasForeignKey(d => d.DesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_BDOfficer_Designation");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.Bdofficer)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_BDOfficer_Organization");

        //        entity.HasOne(d => d.UpdatedByNavigation)
        //            .WithMany(p => p.BdofficerUpdatedByNavigation)
        //            .HasForeignKey(d => d.UpdatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<CarePrice>(entity =>
        //    {
        //        entity.Property(e => e.Cpmprice)
        //            .HasColumnName("CPMPrice")
        //            .HasColumnType("decimal(8, 2)");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.CarePrice)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<Category>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<ConveningOrder>(entity =>
        //    {
        //        entity.ToTable("ConveningOrder", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrder_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.ConveningOrderNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Poid).HasColumnName("POId");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ApprovedDesignation)
        //            .WithMany(p => p.ConveningOrderApprovedDesignation)
        //            .HasForeignKey(d => d.ApprovedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_ApprovedDesignationId");

        //        entity.HasOne(d => d.AssignedDesignation)
        //            .WithMany(p => p.ConveningOrderAssignedDesignation)
        //            .HasForeignKey(d => d.AssignedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_AssignedDesignationId");

        //        entity.HasOne(d => d.ConveningOrderByNavigation)
        //            .WithMany(p => p.ConveningOrderConveningOrderByNavigation)
        //            .HasForeignKey(d => d.ConveningOrderBy)
        //            .HasConstraintName("FK_ConveningOrder_ConveningOrderBy");

        //        entity.HasOne(d => d.Po)
        //            .WithMany(p => p.ConveningOrderPo)
        //            .HasForeignKey(d => d.Poid)
        //            .HasConstraintName("FK_ConveningOrder_POId");

        //        entity.HasOne(d => d.PresidingOfficer)
        //            .WithMany(p => p.ConveningOrderPresidingOfficer)
        //            .HasForeignKey(d => d.PresidingOfficerId)
        //            .HasConstraintName("FK_ConveningOrder_PresidingOfficerId");

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.ConveningOrder)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_ReleaseOrderId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.ConveningOrder)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.ConveningOrderStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_Sotore");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.ConveningOrderUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrder_Unit");
        //    });

        //    modelBuilder.Entity<ConveningOrderApproval>(entity =>
        //    {
        //        entity.ToTable("ConveningOrderApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.FileName)
        //            .HasMaxLength(500)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.ConveningOrderApproval)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderApproval_ConveningOrderId");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.ConveningOrderApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.ConveningOrderApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.ConveningOrderApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_ConveningOrderApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.ConveningOrderApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_ConveningOrderApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<ConveningOrderIssue>(entity =>
        //    {
        //        entity.HasKey(e => e.ConveningOrderId)
        //            .ForSqlServerIsClustered(false);

        //        entity.ToTable("ConveningOrderIssue", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderIssue_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.ConveningOrderId).ValueGeneratedNever();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.OrderNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithOne(p => p.ConveningOrderIssue)
        //            .HasForeignKey<ConveningOrderIssue>(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderIssue_ConveningOrderId");
        //    });

        //    modelBuilder.Entity<ConveningOrderItem>(entity =>
        //    {
        //        entity.ToTable("ConveningOrderItem", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderItem_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoanQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.ReceivedQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remarks).IsUnicode(false);

        //        entity.Property(e => e.ReturnQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.ConveningOrderItem)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItem_ConveningOrderId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.ConveningOrderItem)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItem_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.ConveningOrderItem)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItem_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.ConveningOrderItem)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_ConveningOrderItem_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ConveningOrderItem)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItem_ItemId");
        //    });

        //    modelBuilder.Entity<ConveningOrderItemSurvey>(entity =>
        //    {
        //        entity.ToTable("ConveningOrderItemSurvey", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderItemSurvey_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrderItem)
        //            .WithMany(p => p.ConveningOrderItemSurvey)
        //            .HasForeignKey(d => d.ConveningOrderItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItemSurvey_ConveningOrderItemId");

        //        entity.HasOne(d => d.ConveningOrderItemSurveyMain)
        //            .WithMany(p => p.ConveningOrderItemSurvey)
        //            .HasForeignKey(d => d.ConveningOrderItemSurveyMainId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItemSurvey_ConveningOrderItemIdMain");

        //        entity.HasOne(d => d.ItemStatus)
        //            .WithMany(p => p.ConveningOrderItemSurvey)
        //            .HasForeignKey(d => d.ItemStatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItemSurvey_ItemStatusId");
        //    });

        //    modelBuilder.Entity<ConveningOrderItemSurveyMain>(entity =>
        //    {
        //        entity.ToTable("ConveningOrderItemSurveyMain", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderItemSurveyMain_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.ApprovedRemark).HasMaxLength(100);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.FileName).HasMaxLength(500);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.ConveningOrderItemSurveyMain)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderItemSurveyMain_ConveningOrdeId");
        //    });

        //    modelBuilder.Entity<ConveningOrderMember>(entity =>
        //    {
        //        entity.ToTable("ConveningOrderMember", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveningOrderMember_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Fmnaddress)
        //            .HasColumnName("FMNAddress")
        //            .HasMaxLength(150)
        //            .IsUnicode(false);

        //        entity.Property(e => e.MemberCode)
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.MemberName)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.ConveningOrderMember)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveningOrderMember_ConveningOrderId");

        //        entity.HasOne(d => d.Member)
        //            .WithMany(p => p.ConveningOrderMember)
        //            .HasForeignKey(d => d.MemberId)
        //            .HasConstraintName("FK_ConveningOrderMember_MemberId");
        //    });

        //    modelBuilder.Entity<ConveningOrderSurveySalvageTemp>(entity =>
        //    {
        //        entity.Property(e => e.Auth)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.ConveningOrderSurveySalvageTemp)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.ConveningOrderSurveySalvageTemp)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<ConveyNote>(entity =>
        //    {
        //        entity.ToTable("ConveyNote", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveyNote_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.NoteNo)
        //            .IsRequired()
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AuthorityLetter)
        //            .WithMany(p => p.ConveyNote)
        //            .HasForeignKey(d => d.AuthorityLetterId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNote_AuthorityLetterId");

        //        entity.HasOne(d => d.AuthorityLetterVechileDetail)
        //            .WithMany(p => p.ConveyNote)
        //            .HasForeignKey(d => d.AuthorityLetterVechileDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNote_AuthorityLetterVechileDetailId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.ConveyNote)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNote_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.ConveyNote)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNote_Sotore");
        //    });

        //    modelBuilder.Entity<ConveyNoteApproval>(entity =>
        //    {
        //        entity.ToTable("ConveyNoteApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveyNoteApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveyNote)
        //            .WithMany(p => p.ConveyNoteApproval)
        //            .HasForeignKey(d => d.ConveyNoteId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteApproval_ConveyNoteId");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.ConveyNoteApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.ConveyNoteApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.ConveyNoteApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_ConveyNoteApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.ConveyNoteApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_ConveyNoteApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<ConveyNoteDetail>(entity =>
        //    {
        //        entity.ToTable("ConveyNoteDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ConveyNoteDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveyNote)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ConveyNoteId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteDetail_ConveyNoteId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .HasConstraintName("FK_ConveyNoteDetail_GroupItemId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_ConveyNoteDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteDetail_ItemId");

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ConveyNoteDetail_ItemSetNumberId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.ConveyNoteDetail)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_ConveyNoteDetail_StockShedId");
        //    });

        //    modelBuilder.Entity<Country>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.Code)
        //            .IsRequired()
        //            .HasMaxLength(4)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(60)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Department>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.Department)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Department_OrganizationId");
        //    });

        //    modelBuilder.Entity<Designation>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Level)
        //            .WithMany(p => p.Designation)
        //            .HasForeignKey(d => d.LevelId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Desigation_LevelId");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.Designation)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Desigation_OrganizationId");
        //    });

        //    modelBuilder.Entity<Equipment>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<EquipmentType>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<GatePass>(entity =>
        //    {
        //        entity.ToTable("GatePass", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GatePass_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.GatePassNo)
        //            .IsRequired()
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveyNote)
        //            .WithMany(p => p.GatePass)
        //            .HasForeignKey(d => d.ConveyNoteId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePass_ConveyNoteId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.GatePass)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePass_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.GatePass)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePass_Sotore");
        //    });

        //    modelBuilder.Entity<GatePassApproval>(entity =>
        //    {
        //        entity.ToTable("GatePassApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GatePassApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.GatePassApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePassApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.GatePassApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePassApproval_FromOrganizationId");

        //        entity.HasOne(d => d.GatePass)
        //            .WithMany(p => p.GatePassApproval)
        //            .HasForeignKey(d => d.GatePassId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePassApproval_GatePassId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.GatePassApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_GatePassApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.GatePassApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_GatePassApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<GatePassDetail>(entity =>
        //    {
        //        entity.ToTable("GatePassDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GatePassDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.GatePass)
        //            .WithMany(p => p.GatePassDetail)
        //            .HasForeignKey(d => d.GatePassId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GatePassDetail_GatePassId");
        //    });

        //    modelBuilder.Entity<GroupItem>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GroupItem_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(500)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.MinimumStockLevelPercent).HasColumnType("decimal(5, 2)");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Category)
        //            .WithMany(p => p.GroupItem)
        //            .HasForeignKey(d => d.CategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItem_CategoryId");

        //        entity.HasOne(d => d.ItemUom)
        //            .WithMany(p => p.GroupItem)
        //            .HasForeignKey(d => d.ItemUomId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItem_ItemUomId");
        //    });

        //    modelBuilder.Entity<GroupItemBasicCategory>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GroupItemBasicCategory_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.BasicCategory)
        //            .WithMany(p => p.GroupItemBasicCategory)
        //            .HasForeignKey(d => d.BasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItemBasicCategory_BasicCategoryId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.GroupItemBasicCategory)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItemBasicCategory_GroupItemId");
        //    });

        //    modelBuilder.Entity<GroupItemDetail>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_GroupItemDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantity)
        //            .HasColumnType("decimal(10, 5)")
        //            .HasDefaultValueSql("((0))");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.GroupItemDetail)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItemDetail_GroupItemId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.GroupItemDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_GroupItemDetail_ItemId");
        //    });

        //    modelBuilder.Entity<Item>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_Item_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.Area).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Capacity).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.CatPtNo)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Cost).HasDefaultValueSql("((0))");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.IsMaster).HasDefaultValueSql("((0))");

        //        entity.Property(e => e.ItemCritLevel).HasDefaultValueSql("((0))");

        //        entity.Property(e => e.LoadingVehicle)
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Volume).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Weight).HasColumnType("decimal(10, 5)");

        //        entity.HasOne(d => d.AreaUom)
        //            .WithMany(p => p.ItemAreaUom)
        //            .HasForeignKey(d => d.AreaUomId)
        //            .HasConstraintName("FK_Item_AreaUomId");

        //        entity.HasOne(d => d.CapacityUom)
        //            .WithMany(p => p.ItemCapacityUom)
        //            .HasForeignKey(d => d.CapacityUomId)
        //            .HasConstraintName("FK_Item_CapacityUomId");

        //        entity.HasOne(d => d.Category)
        //            .WithMany(p => p.Item)
        //            .HasForeignKey(d => d.CategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Item_CategoryId");

        //        entity.HasOne(d => d.ItemUom)
        //            .WithMany(p => p.ItemItemUom)
        //            .HasForeignKey(d => d.ItemUomId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Item_ItemUomId");

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.Item)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .HasConstraintName("FK_Item_MaterialTypeId");

        //        entity.HasOne(d => d.VolumeUom)
        //            .WithMany(p => p.ItemVolumeUom)
        //            .HasForeignKey(d => d.VolumeUomId)
        //            .HasConstraintName("FK_Item_VolumeUomId");

        //        entity.HasOne(d => d.WeightUom)
        //            .WithMany(p => p.ItemWeightUom)
        //            .HasForeignKey(d => d.WeightUomId)
        //            .HasConstraintName("FK_Item_WeightUomId");
        //    });

        //    modelBuilder.Entity<ItemBasicCategory>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ItemBasicCategory_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.BasicCategory)
        //            .WithMany(p => p.ItemBasicCategory)
        //            .HasForeignKey(d => d.BasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemBasicCategory_BasicCategoryId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ItemBasicCategory)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemBasicCategory_ItemId");
        //    });

        //    modelBuilder.Entity<ItemEquipment>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ItemEquipment_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Equipment)
        //            .WithMany(p => p.ItemEquipment)
        //            .HasForeignKey(d => d.EquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemEquipment_EquipmentId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ItemEquipment)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemEquipment_ItemId");
        //    });

        //    modelBuilder.Entity<ItemEquipmentType>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ItemEquipmentType_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.EquipmentType)
        //            .WithMany(p => p.ItemEquipmentType)
        //            .HasForeignKey(d => d.EquipmentTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemEquipmentType_EquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ItemEquipmentType)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemEquipmentType_ItemId");
        //    });

        //    modelBuilder.Entity<ItemPart>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ItemPart_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantity).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ItemPartItem)
        //            .HasForeignKey(d => d.ItemId)
        //            .HasConstraintName("FK_ItemPart_Item");

        //        entity.HasOne(d => d.ItemPartItem)
        //            .WithMany(p => p.ItemPartItemPartItem)
        //            .HasForeignKey(d => d.ItemPartItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ItemPart_ItemPartItem");
        //    });

        //    modelBuilder.Entity<ItemSetNumber>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(20)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.HeldForOrganization)
        //            .WithMany(p => p.ItemSetNumber)
        //            .HasForeignKey(d => d.HeldForOrganizationId)
        //            .HasConstraintName("FK_ItemSetNumber_HeldForOrganizationId");
        //    });

        //    modelBuilder.Entity<ItemStatus>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<JobOrder>(entity =>
        //    {
        //        entity.Property(e => e.Authority).HasMaxLength(250);

        //        entity.Property(e => e.File).HasMaxLength(250);

        //        entity.Property(e => e.JobOrderNo).HasMaxLength(250);

        //        entity.Property(e => e.Justification).HasMaxLength(250);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.VenderName).HasMaxLength(250);

        //        entity.HasOne(d => d.MaintenancePlan)
        //            .WithMany(p => p.JobOrder)
        //            .HasForeignKey(d => d.MaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterlyMaintenancePlan)
        //            .WithMany(p => p.JobOrder)
        //            .HasForeignKey(d => d.QuarterlyMaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.JobOrderStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.JobOrder)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.JobOrderToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_JobOrder_Organization_OrganizationId");
        //    });

        //    modelBuilder.Entity<JobOrderApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.JobOrderApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_JobOrderApprovall_Designation_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.JobOrderApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.JobOrder)
        //            .WithMany(p => p.JobOrderApproval)
        //            .HasForeignKey(d => d.JobOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.JobOrderApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.JobOrderApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<JobOrderDetail>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Category)
        //            .WithMany(p => p.JobOrderDetail)
        //            .HasForeignKey(d => d.CategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.JobOrder)
        //            .WithMany(p => p.JobOrderDetail)
        //            .HasForeignKey(d => d.JobOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<JobOrderDetailsGroupItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.JobOrderDetail)
        //            .WithMany(p => p.JobOrderDetailsGroupItem)
        //            .HasForeignKey(d => d.JobOrderDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.JobOrderDetailsGroupItem)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<JobOrderDetailsItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.JobOrderDetailsItem)
        //            .HasForeignKey(d => d.GroupItemId);

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.JobOrderDetailsItem)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.JobOrderDetailsItem)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.JobOrderDetailsGroupItem)
        //            .WithMany(p => p.JobOrderDetailsItem)
        //            .HasForeignKey(d => d.JobOrderDetailsGroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.JobOrderDetailsItem)
        //            .HasForeignKey(d => d.StockShedId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<JobOrderTemp>(entity =>
        //    {
        //        entity.HasOne(d => d.JobOrder)
        //            .WithMany(p => p.JobOrderTemp)
        //            .HasForeignKey(d => d.JobOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_JobOrderTemp_JobOrder_JobOrderTempId");
        //    });

        //    modelBuilder.Entity<Level>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<LoadTrolley>(entity =>
        //    {
        //        entity.ToTable("LoadTrolley", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoadTrolley_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoadTrolleyNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.LoadTrolley)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoadTrolley_ConveningOrderId");
        //    });

        //    modelBuilder.Entity<LoadTrolleyItem>(entity =>
        //    {
        //        entity.ToTable("LoadTrolleyItem", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoadTrolleyItem_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrderItem)
        //            .WithMany(p => p.LoadTrolleyItem)
        //            .HasForeignKey(d => d.ConveningOrderItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoadTrolleyItem_ConveningOrderItemId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.LoadTrolleyItem)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoadTrolleyItem_GroupItemId");

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.LoadTrolleyItem)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoadTrolleyItem_ItemSetNumberId");

        //        entity.HasOne(d => d.LoadTrolley)
        //            .WithMany(p => p.LoadTrolleyItem)
        //            .HasForeignKey(d => d.LoadTrolleyId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoadTrolleyItem_LoadTrolleyId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.LoadTrolleyItem)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_LoadTrolleyItem_StockShedId");
        //    });

        //    modelBuilder.Entity<LoanExtension>(entity =>
        //    {
        //        entity.Property(e => e.Authority).HasMaxLength(250);

        //        entity.Property(e => e.BdApproveBy).HasMaxLength(250);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Justification).HasMaxLength(250);

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.LoanIssueVoucher)
        //            .WithMany(p => p.LoanExtension)
        //            .HasForeignKey(d => d.LoanIssueVoucherId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.LoanExtension)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.LoanExtensionStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanExtension_Store_StoreId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.LoanExtension)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.LoanExtensionToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);

        //        entity.HasOne(d => d.UnitFrom)
        //            .WithMany(p => p.LoanExtensionUnitFrom)
        //            .HasForeignKey(d => d.UnitFromId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanExtension_OrganizationFrom_UnitFromId");

        //        entity.HasOne(d => d.UnitTo)
        //            .WithMany(p => p.LoanExtensionUnitTo)
        //            .HasForeignKey(d => d.UnitToId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanExtension_OrganizationTo_UnitToId");
        //    });

        //    modelBuilder.Entity<LoanExtensionApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.LoanExtensionApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.LoanExtensionApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.LoanExtension)
        //            .WithMany(p => p.LoanExtensionApproval)
        //            .HasForeignKey(d => d.LoanExtensionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.LoanExtensionApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.LoanExtensionApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<LoanExtensionDetail>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoanPeriodInMonth).HasColumnType("decimal(5, 2)");

        //        entity.Property(e => e.Quantity).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .HasConstraintName("FK_LoanExtensionDetail_GroupItemId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId);

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanExtensionDetail_ItemSetNumberId");

        //        entity.HasOne(d => d.LoanExtension)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.LoanExtensionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.LoanExtensionDetail)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_LoanExtensionDetail_StockShedId");
        //    });

        //    modelBuilder.Entity<LoanIssueVoucher>(entity =>
        //    {
        //        entity.ToTable("LoanIssueVoucher", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanIssueVoucher_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.VoucherNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.LoanIssueVoucher)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucher_ReleaseOrderId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.LoanIssueVoucher)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucher_SotoreId");
        //    });

        //    modelBuilder.Entity<LoanIssueVoucherDetail>(entity =>
        //    {
        //        entity.ToTable("LoanIssueVoucherDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanIssueVoucherDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.LoanIssueVoucherDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucherDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.LoanIssueVoucherDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucherDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.LoanIssueVoucherDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_LoanIssueVoucherDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.LoanIssueVoucherDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucherDetail_ItemId");

        //        entity.HasOne(d => d.LoanIssueVoucher)
        //            .WithMany(p => p.LoanIssueVoucherDetail)
        //            .HasForeignKey(d => d.LoanIssueVoucherId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanIssueVoucherDetail_LoanIssueVoucherId");
        //    });

        //    modelBuilder.Entity<LoanReceiptVoucher>(entity =>
        //    {
        //        entity.ToTable("LoanReceiptVoucher", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanReceiptVoucher_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.VoucherNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithMany(p => p.LoanReceiptVoucher)
        //            .HasForeignKey(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucher_ConveningOrderId");

        //        entity.HasOne(d => d.ReceiptdByNavigation)
        //            .WithMany(p => p.LoanReceiptVoucher)
        //            .HasForeignKey(d => d.ReceiptdBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucher_ReceiptdBy");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.LoanReceiptVoucherStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucher_SotoreId");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.LoanReceiptVoucherUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucher_UnitId");
        //    });

        //    modelBuilder.Entity<LoanReceiptVoucherDetail>(entity =>
        //    {
        //        entity.ToTable("LoanReceiptVoucherDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanReceiptVoucherDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrderItem)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.ConveningOrderItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_ConveningOrderItemId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_ItemId");

        //        entity.HasOne(d => d.LoanReceiptVoucher)
        //            .WithMany(p => p.LoanReceiptVoucherDetail)
        //            .HasForeignKey(d => d.LoanReceiptVoucherId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanReceiptVoucherDetail_LoanReceiptVoucherId");
        //    });

        //    modelBuilder.Entity<LoanRenewal>(entity =>
        //    {
        //        entity.Property(e => e.Authority).HasMaxLength(250);

        //        entity.Property(e => e.BdApproveBy).HasMaxLength(250);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Justification).HasMaxLength(250);

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.LoanIssueVoucher)
        //            .WithMany(p => p.LoanRenewal)
        //            .HasForeignKey(d => d.LoanIssueVoucherId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.LoanRenewal)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.LoanRenewalStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRenewal_Store_StoreId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.LoanRenewal)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.LoanRenewalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.LoanRenewalUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRenewal_OrganizationFrom_UnitId");
        //    });

        //    modelBuilder.Entity<LoanRenewalApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.LoanRenewalApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.LoanRenewalApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.LoanRenewal)
        //            .WithMany(p => p.LoanRenewalApproval)
        //            .HasForeignKey(d => d.LoanRenewalId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.LoanRenewalApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.LoanRenewalApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<LoanRenewalDetail>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoanPeriodInMonth).HasColumnType("decimal(5, 2)");

        //        entity.Property(e => e.Quantity).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .HasConstraintName("FK_LoanRenewalDetail_GroupItemId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId);

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRenewalDetail_ItemSetNumberId");

        //        entity.HasOne(d => d.LoanRenewal)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.LoanRenewalId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.LoanRenewalDetail)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_LoanRenewalDetail_StockShedId");
        //    });

        //    modelBuilder.Entity<LoanRequest>(entity =>
        //    {
        //        entity.ToTable("LoanRequest", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanRequest_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.LoanRequestNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ApprovedDesignation)
        //            .WithMany(p => p.LoanRequestApprovedDesignation)
        //            .HasForeignKey(d => d.ApprovedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_ApprovedDesignationId");

        //        entity.HasOne(d => d.AssignedDesignation)
        //            .WithMany(p => p.LoanRequestAssignedDesignation)
        //            .HasForeignKey(d => d.AssignedDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_AssignedDesignationId");

        //        entity.HasOne(d => d.AvailabilityCertIssue)
        //            .WithMany(p => p.LoanRequest)
        //            .HasForeignKey(d => d.AvailabilityCertIssueId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_AvailabilityCertRequestId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.LoanRequest)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.LoanRequestStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_Sotore");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.LoanRequestUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequest_Unit");
        //    });

        //    modelBuilder.Entity<LoanRequestAssign>(entity =>
        //    {
        //        entity.ToTable("LoanRequestAssign", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanRequestAssign_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.LoanRequestAssignFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequestAssign_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.LoanRequestAssignFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequestAssign_FromOrganizationId");

        //        entity.HasOne(d => d.LoanRequest)
        //            .WithMany(p => p.LoanRequestAssign)
        //            .HasForeignKey(d => d.LoanRequestId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequestAssign_LoanRequestId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.LoanRequestAssignToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_LoanRequestAssign_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.LoanRequestAssignToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_LoanRequestAssign_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<LoanRequestDetail>(entity =>
        //    {
        //        entity.ToTable("LoanRequestDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_LoanRequestDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoanPeriodInMonth).HasColumnType("decimal(5, 2)");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Reason).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AvailabilityCertIssueDetail)
        //            .WithMany(p => p.LoanRequestDetail)
        //            .HasForeignKey(d => d.AvailabilityCertIssueDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequestDetail_AvailabilityCertIssueDetailId");

        //        entity.HasOne(d => d.LoanReqestAssign)
        //            .WithMany(p => p.LoanRequestDetail)
        //            .HasForeignKey(d => d.LoanReqestAssignId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_LoanRequestDetail_LoanRequestAssignId");
        //    });

        //    modelBuilder.Entity<Loginhistory>(entity =>
        //    {
        //        entity.Property(e => e.IpAddress)
        //            .IsRequired()
        //            .HasMaxLength(256);

        //        entity.HasOne(d => d.User)
        //            .WithMany(p => p.Loginhistory)
        //            .HasForeignKey(d => d.UserId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<MaintenancePlan>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.MaintenancePlanStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenancePlan_Organization_store");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.MaintenancePlan)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.MaintenancePlanToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<MaintenancePlanApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.MaintenancePlanApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.MaintenancePlanApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenancePlanApproval_Organization_FromOrganization");

        //        entity.HasOne(d => d.MaintenancePlan)
        //            .WithMany(p => p.MaintenancePlanApproval)
        //            .HasForeignKey(d => d.MaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.MaintenancePlanApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.MaintenancePlanApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<MaintenancePlanDetail>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Category)
        //            .WithMany(p => p.MaintenancePlanDetail)
        //            .HasForeignKey(d => d.CategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaintenancePlan)
        //            .WithMany(p => p.MaintenancePlanDetail)
        //            .HasForeignKey(d => d.MaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenancePlanDetails_MaintenancePlan_MaintenancePlanId");
        //    });

        //    modelBuilder.Entity<MaintenancePlanDetailsGroupItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.MaintenancePlanDetailsGroupItem)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaintenancePlanDetail)
        //            .WithMany(p => p.MaintenancePlanDetailsGroupItem)
        //            .HasForeignKey(d => d.MaintenancePlanDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenancePlanDetailsGroupItems_MaintenancePlanDetail_MaintenancePlanDetailId");
        //    });

        //    modelBuilder.Entity<MaintenancePlanDetailsItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.MaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.MaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.MaintenancePlanDetailsGroupItem)
        //            .WithMany(p => p.MaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.MaintenancePlanDetailsGroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenancePlanDetailsItem_MaintenancePlanDetail_MaintenancePlanDetailId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.MaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.StockShedId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<MaintenanceSchedulePlan>(entity =>
        //    {
        //        entity.Property(e => e.Cpmamount).HasColumnName("CPMAmount");

        //        entity.Property(e => e.Qtr1qty).HasColumnName("QTR1Qty");

        //        entity.Property(e => e.Qtr2qty).HasColumnName("QTR2Qty");

        //        entity.Property(e => e.Qtr3qty).HasColumnName("QTR3Qty");

        //        entity.Property(e => e.Qtr4qty).HasColumnName("QTR4Qty");

        //        entity.Property(e => e.Remark).HasMaxLength(500);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.MaintenancePlanDetail)
        //            .WithMany(p => p.MaintenanceSchedulePlan)
        //            .HasForeignKey(d => d.MaintenancePlanDetailsId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenanceSchedulePlan_MaintenancePlanDetails_MaintenancePlanDetailsId");
        //    });

        //    modelBuilder.Entity<MaintenanceSchedulePlanApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.MaintenanceSchedulePlanApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.MaintenanceSchedulePlanApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MaintenanceSchedulePlanApproval_Organization_FromOrganization");

        //        entity.HasOne(d => d.MaintenanceSchedulePlan)
        //            .WithMany(p => p.MaintenanceSchedulePlanApproval)
        //            .HasForeignKey(d => d.MaintenanceSchedulePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.MaintenanceSchedulePlanApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.MaintenanceSchedulePlanApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<MaterialType>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Menu>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.DisplayName)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.PageUrl)
        //            .HasMaxLength(1000)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Parent)
        //            .WithMany(p => p.InverseParent)
        //            .HasForeignKey(d => d.ParentId)
        //            .HasConstraintName("FK_Menu_ParentId");
        //    });

        //    modelBuilder.Entity<MenuPermission>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Menu)
        //            .WithMany(p => p.MenuPermission)
        //            .HasForeignKey(d => d.MenuId)
        //            .HasConstraintName("FK_MenuPermission_MenuId");

        //        entity.HasOne(d => d.Permission)
        //            .WithMany(p => p.MenuPermission)
        //            .HasForeignKey(d => d.PermissionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_MenuPermission_PermissionId");
        //    });

        //    modelBuilder.Entity<Organization>(entity =>
        //    {
        //        entity.Property(e => e.Address)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.City)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.ImagePath)
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.Susno)
        //            .IsRequired()
        //            .HasColumnName("SUSNo")
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.OrganizationType)
        //            .WithMany(p => p.Organization)
        //            .HasForeignKey(d => d.OrganizationTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Organization_OrganizationTypeId");

        //        entity.HasOne(d => d.Parent)
        //            .WithMany(p => p.InverseParent)
        //            .HasForeignKey(d => d.ParentId)
        //            .HasConstraintName("FK_Organization_ParentId");

        //        entity.HasOne(d => d.State)
        //            .WithMany(p => p.Organization)
        //            .HasForeignKey(d => d.StateId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Organization_StateId");
        //    });

        //    modelBuilder.Entity<OrganizationType>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Origin>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Periodicity>(entity =>
        //    {
        //        entity.Property(e => e.Periodicity1).HasColumnName("Periodicity");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.Periodicity)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<Permission>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<QuarterlyMaintenancePlan>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.MaintenancePlan)
        //            .WithMany(p => p.QuarterlyMaintenancePlan)
        //            .HasForeignKey(d => d.MaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.QuarterlyMaintenancePlanStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.QuarterlyMaintenancePlan)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.QuarterlyMaintenancePlanToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_QuarterlyMaintenancePlan_Organization_OrganizationId");
        //    });

        //    modelBuilder.Entity<QuarterlyMaintenancePlanApproval>(entity =>
        //    {
        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.QuarterlyMaintenancePlanApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.QuarterlyMaintenancePlanApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterlyMaintenancePlan)
        //            .WithMany(p => p.QuarterlyMaintenancePlanApproval)
        //            .HasForeignKey(d => d.QuarterlyMaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.QuarterlyMaintenancePlanApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId);

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.QuarterlyMaintenancePlanApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId);
        //    });

        //    modelBuilder.Entity<QuarterlyMaintenancePlanDetail>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Category)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetail)
        //            .HasForeignKey(d => d.CategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterlyMaintenancePlan)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetail)
        //            .HasForeignKey(d => d.QuarterlyMaintenancePlanId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<QuarterlyMaintenancePlanDetailsGroupItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsGroupItem)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterlyMaintenancePlanDetail)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsGroupItem)
        //            .HasForeignKey(d => d.QuarterlyMaintenancePlanDetailId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<QuarterlyMaintenancePlanDetailsItem>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.GroupItemId);

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterlyMaintenancePlanDetailsGroupItem)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.QuarterlyMaintenancePlanDetailsGroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.QuarterlyMaintenancePlanDetailsItem)
        //            .HasForeignKey(d => d.StockShedId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<RefactorLog>(entity =>
        //    {
        //        entity.HasKey(e => e.ScriptNo);

        //        entity.Property(e => e.ScriptNo).ValueGeneratedNever();
        //    });

        //    modelBuilder.Entity<ReleaseOrder>(entity =>
        //    {
        //        entity.ToTable("ReleaseOrder", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ReleaseOrder_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.ReleaseOrderNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.LoanRequest)
        //            .WithMany(p => p.ReleaseOrder)
        //            .HasForeignKey(d => d.LoanRequestId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrder_LoanRequestId");

        //        entity.HasOne(d => d.Status)
        //            .WithMany(p => p.ReleaseOrder)
        //            .HasForeignKey(d => d.StatusId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrder_StatusId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.ReleaseOrderStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrder_Sotore");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.ReleaseOrderUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrder_Unit");
        //    });

        //    modelBuilder.Entity<ReleaseOrderApproval>(entity =>
        //    {
        //        entity.ToTable("ReleaseOrderApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ReleaseOrderApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.ReleaseOrderApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.ReleaseOrderApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderApproval_FromOrganizationId");

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.ReleaseOrderApproval)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderApproval_ReleaseOrderId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.ReleaseOrderApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_ReleaseOrderApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.ReleaseOrderApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_ReleaseOrderApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<ReleaseOrderDetail>(entity =>
        //    {
        //        entity.ToTable("ReleaseOrderDetail", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_ReleaseOrderDetail_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LoanPeriodInMonth).HasColumnType("decimal(5, 2)");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Reason).IsUnicode(false);

        //        entity.Property(e => e.ReleaseNote)
        //            .IsRequired()
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.ReleaseOrderDetail)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderDetail_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.ReleaseOrderDetail)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderDetail_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.ReleaseOrderDetail)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_ReleaseOrderDetail_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.ReleaseOrderDetail)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderDetail_ItemId");

        //        entity.HasOne(d => d.ReleaseOrder)
        //            .WithMany(p => p.ReleaseOrderDetail)
        //            .HasForeignKey(d => d.ReleaseOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_ReleaseOrderDetail_ReleaseOrderId");
        //    });

        //    modelBuilder.Entity<Report>(entity =>
        //    {
        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(256);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.Url).HasMaxLength(256);

        //        entity.HasOne(d => d.CreatedByNavigation)
        //            .WithMany(p => p.Report)
        //            .HasForeignKey(d => d.CreatedBy)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<ReportPermission>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Report)
        //            .WithMany(p => p.ReportPermission)
        //            .HasForeignKey(d => d.ReportId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Role)
        //            .WithMany(p => p.ReportPermission)
        //            .HasForeignKey(d => d.RoleId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<ReportUserHistory>(entity =>
        //    {
        //        entity.Property(e => e.IpAddress)
        //            .IsRequired()
        //            .HasMaxLength(50);

        //        entity.Property(e => e.MackAddress)
        //            .IsRequired()
        //            .HasMaxLength(50);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.Report)
        //            .WithMany(p => p.ReportUserHistory)
        //            .HasForeignKey(d => d.ReportId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.User)
        //            .WithMany(p => p.ReportUserHistory)
        //            .HasForeignKey(d => d.UserId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<ReportUserPermission>(entity =>
        //    {
        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.HasOne(d => d.ReportPermission)
        //            .WithMany(p => p.ReportUserPermission)
        //            .HasForeignKey(d => d.ReportPermissionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.User)
        //            .WithMany(p => p.ReportUserPermission)
        //            .HasForeignKey(d => d.UserId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<Role>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.PermissionMask).IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<RoleMenu>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Menu)
        //            .WithMany(p => p.RoleMenu)
        //            .HasForeignKey(d => d.MenuId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_RoleMenu_MenuId");

        //        entity.HasOne(d => d.Role)
        //            .WithMany(p => p.RoleMenu)
        //            .HasForeignKey(d => d.RoleId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_RoleMenu_RoleId");
        //    });

        //    modelBuilder.Entity<RoleMenuPermission>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Permission)
        //            .WithMany(p => p.RoleMenuPermission)
        //            .HasForeignKey(d => d.PermissionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_RoleMenuPermission_PermissionId");

        //        entity.HasOne(d => d.RoleMenu)
        //            .WithMany(p => p.RoleMenuPermission)
        //            .HasForeignKey(d => d.RoleMenuId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_RoleMenuPermission_RoleMenuId");
        //    });

        //    modelBuilder.Entity<SalvageIn>(entity =>
        //    {
        //        entity.Property(e => e.Auth)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.SalvageIn)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.SalvageInOrganization)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.SalvageInStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SalvageIn_Store_StoreId");
        //    });

        //    modelBuilder.Entity<SalvageOut>(entity =>
        //    {
        //        entity.Property(e => e.Auth)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark).HasMaxLength(250);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.VendarName)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.HasOne(d => d.MaterialType)
        //            .WithMany(p => p.SalvageOut)
        //            .HasForeignKey(d => d.MaterialTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.SalvageOut)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SalvageOut_Store_StoreId");
        //    });

        //    modelBuilder.Entity<SenctionOrder>(entity =>
        //    {
        //        entity.HasKey(e => e.ConveningOrderId)
        //            .ForSqlServerIsClustered(false);

        //        entity.ToTable("SenctionOrder", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_SenctionOrder_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.ConveningOrderId).ValueGeneratedNever();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.SenctionOrderNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ConveningOrder)
        //            .WithOne(p => p.SenctionOrder)
        //            .HasForeignKey<SenctionOrder>(d => d.ConveningOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SenctionOrder_ConveningOrderId");
        //    });

        //    modelBuilder.Entity<SenctionOrderApproval>(entity =>
        //    {
        //        entity.ToTable("SenctionOrderApproval", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_SenctionOrderApproval_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Note).IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.SenctionOrderApprovalFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SenctionOrderApproval_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.SenctionOrderApprovalFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SenctionOrderApproval_FromOrganizationId");

        //        entity.HasOne(d => d.SenctionOrder)
        //            .WithMany(p => p.SenctionOrderApproval)
        //            .HasForeignKey(d => d.SenctionOrderId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SenctionOrderApproval_SenctionOrderId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.SenctionOrderApprovalToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_SenctionOrderApproval_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.SenctionOrderApprovalToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_SenctionOrderApproval_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<ShedType>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<State>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.Code)
        //            .IsRequired()
        //            .HasMaxLength(4)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CountryId).HasDefaultValueSql("((91))");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(60)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Country)
        //            .WithMany(p => p.State)
        //            .HasForeignKey(d => d.CountryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_State_CountryId");
        //    });

        //    modelBuilder.Entity<Status>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<StockShed>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.StockShed)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StockShed_OrganizationId");

        //        entity.HasOne(d => d.ShedType)
        //            .WithMany(p => p.StockShed)
        //            .HasForeignKey(d => d.ShedTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StockShed_ShedTypeId");
        //    });

        //    modelBuilder.Entity<StoreStock>(entity =>
        //    {
        //        entity.ToTable("StoreStock", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_StoreStock_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.GroupItemBasicCategory)
        //            .WithMany(p => p.StoreStock)
        //            .HasForeignKey(d => d.GroupItemBasicCategoryId)
        //            .HasConstraintName("FK_StoreStock_GroupItemBasicCategoryId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.StoreStock)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStock_GroupItemId");

        //        entity.HasOne(d => d.HeldByOrgnaization)
        //            .WithMany(p => p.StoreStockHeldByOrgnaization)
        //            .HasForeignKey(d => d.HeldByOrgnaizationId)
        //            .HasConstraintName("FK_StoreStock_HeldByOrgnaizationId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.StoreStockStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStock_Organization");

        //        entity.HasOne(d => d.TransactionType)
        //            .WithMany(p => p.StoreStock)
        //            .HasForeignKey(d => d.TransactionTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStock_TransactionType");
        //    });

        //    modelBuilder.Entity<StoreStockItemAuthority>(entity =>
        //    {
        //        entity.ToTable("StoreStockItemAuthority", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_StoreStockItemAuthority_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.HasIndex(e => new { e.GroupItemId, e.AuthorizedOrganiztionId, e.StoreId })
        //            .HasName("IX_StoreStockItemAuthority_GroupItemIdAuthorizedOrganiztionId")
        //            .IsUnique();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AuthorizedQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AuthorizedOrganiztion)
        //            .WithMany(p => p.StoreStockItemAuthorityAuthorizedOrganiztion)
        //            .HasForeignKey(d => d.AuthorizedOrganiztionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockItemAuthority_AuthorizedOrganiztionId");

        //        entity.HasOne(d => d.GroupItemBasicCategory)
        //            .WithMany(p => p.StoreStockItemAuthority)
        //            .HasForeignKey(d => d.GroupItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockItemAuthority_GroupItemBasicCategoryId");

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.StoreStockItemAuthority)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockItemAuthority_GroupItemId");

        //        entity.HasOne(d => d.Store)
        //            .WithMany(p => p.StoreStockItemAuthorityStore)
        //            .HasForeignKey(d => d.StoreId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockItemAuthority_StoreId");
        //    });

        //    modelBuilder.Entity<StoreStockTransaction>(entity =>
        //    {
        //        entity.ToTable("StoreStockTransaction", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_StoreStockTransaction_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Mfgdate).HasColumnName("MFGDate");

        //        entity.Property(e => e.PageNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.PrimaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.SecondaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransaction_Item");

        //        entity.HasOne(d => d.ItemSetNumber)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.ItemSetNumberId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransaction_ItemSetNumberId");

        //        entity.HasOne(d => d.ItemUom)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.ItemUomId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransaction_ItemUomId");

        //        entity.HasOne(d => d.Origin)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.OriginId)
        //            .HasConstraintName("FK_StoreStockTransaction_ItemOriginId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_StoreStockTransaction_StockShedId");

        //        entity.HasOne(d => d.StoreStock)
        //            .WithMany(p => p.StoreStockTransaction)
        //            .HasForeignKey(d => d.StoreStockId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransaction_StoreStock");
        //    });

        //    modelBuilder.Entity<StoreStockTransactionQuantity>(entity =>
        //    {
        //        entity.ToTable("StoreStockTransactionQuantity", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_StoreStockTransactionQuantity_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.ItemStatus)
        //            .WithMany(p => p.StoreStockTransactionQuantity)
        //            .HasForeignKey(d => d.ItemStatusId)
        //            .HasConstraintName("FK_StoreStockTransactionQuantity_ItemStatusId");

        //        entity.HasOne(d => d.StoreStockTransaction)
        //            .WithMany(p => p.StoreStockTransactionQuantity)
        //            .HasForeignKey(d => d.StoreStockTransactionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransactionQuantity_StoreStockTransactionId");
        //    });

        //    modelBuilder.Entity<StoreStockTransactionSetNo>(entity =>
        //    {
        //        entity.ToTable("StoreStockTransactionSetNo", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_StoreStockTransactionSetNo_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).ValueGeneratedNever();

        //        entity.Property(e => e.Mfgdate).HasColumnName("MFGDate");

        //        entity.Property(e => e.PageNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.PrimaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.SecondaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.SetNo)
        //            .IsRequired()
        //            .HasMaxLength(11)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.GroupItem)
        //            .WithMany(p => p.StoreStockTransactionSetNo)
        //            .HasForeignKey(d => d.GroupItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransactionSetNo_GroupItemId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.StoreStockTransactionSetNo)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransactionSetNo_Item");

        //        entity.HasOne(d => d.ItemUom)
        //            .WithMany(p => p.StoreStockTransactionSetNo)
        //            .HasForeignKey(d => d.ItemUomId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_StoreStockTransactionSetNo_ItemUomId");

        //        entity.HasOne(d => d.Origin)
        //            .WithMany(p => p.StoreStockTransactionSetNo)
        //            .HasForeignKey(d => d.OriginId)
        //            .HasConstraintName("FK_StoreStockTransactionSetNo_ItemOriginId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.StoreStockTransactionSetNo)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_StoreStockTransactionSetNo_StockShedId");
        //    });

        //    modelBuilder.Entity<SubOrganizationType>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Task>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<TaskWorkFlow>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.FromDesignation)
        //            .WithMany(p => p.TaskWorkFlowFromDesignation)
        //            .HasForeignKey(d => d.FromDesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_TaskWorkFlow_FromDesignationId");

        //        entity.HasOne(d => d.FromOrganization)
        //            .WithMany(p => p.TaskWorkFlowFromOrganization)
        //            .HasForeignKey(d => d.FromOrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_TaskWorkFlow_FromOrganizationId");

        //        entity.HasOne(d => d.Task)
        //            .WithMany(p => p.TaskWorkFlow)
        //            .HasForeignKey(d => d.TaskId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_TaskWorkFlow_TaskId");

        //        entity.HasOne(d => d.ToDesignation)
        //            .WithMany(p => p.TaskWorkFlowToDesignation)
        //            .HasForeignKey(d => d.ToDesignationId)
        //            .HasConstraintName("FK_TaskWorkFlow_ToDesignationId");

        //        entity.HasOne(d => d.ToOrganization)
        //            .WithMany(p => p.TaskWorkFlowToOrganization)
        //            .HasForeignKey(d => d.ToOrganizationId)
        //            .HasConstraintName("FK_TaskWorkFlow_ToOrganizationId");
        //    });

        //    modelBuilder.Entity<TransactionType>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<UnitOfMeasure>(entity =>
        //    {
        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(60)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.UnitType)
        //            .WithMany(p => p.UnitOfMeasure)
        //            .HasForeignKey(d => d.UnitTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitOfMeasure_UnitTypeId");
        //    });

        //    modelBuilder.Entity<UnitStock>(entity =>
        //    {
        //        entity.ToTable("UnitStock", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_UnitStock_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.TransactionType)
        //            .WithMany(p => p.UnitStock)
        //            .HasForeignKey(d => d.TransactionTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStock_TransactionType");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.UnitStock)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStock_Organization");
        //    });

        //    modelBuilder.Entity<UnitStockItemAuthority>(entity =>
        //    {
        //        entity.ToTable("UnitStockItemAuthority", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_UnitStockItemAuthority_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.AuthorizedQuantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.AuthorizedOrganiztion)
        //            .WithMany(p => p.UnitStockItemAuthorityAuthorizedOrganiztion)
        //            .HasForeignKey(d => d.AuthorizedOrganiztionId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockItemAuthority_AuthorizedOrganiztionId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.UnitStockItemAuthority)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockItemAuthority_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.UnitStockItemAuthority)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockItemAuthority_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.UnitStockItemAuthority)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_UnitStockItemAuthority_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.UnitStockItemAuthority)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockItemAuthority_Item");

        //        entity.HasOne(d => d.Unit)
        //            .WithMany(p => p.UnitStockItemAuthorityUnit)
        //            .HasForeignKey(d => d.UnitId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockItemAuthority_UnitId");
        //    });

        //    modelBuilder.Entity<UnitStockTransaction>(entity =>
        //    {
        //        entity.ToTable("UnitStockTransaction", "Main");

        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_UnitStockTransaction_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.LotNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Mfgdate).HasColumnName("MFGDate");

        //        entity.Property(e => e.PageNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.PrimaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Quantiy).HasColumnType("decimal(10, 5)");

        //        entity.Property(e => e.Remark)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.SecondaryLedgerNo)
        //            .HasMaxLength(15)
        //            .IsUnicode(false);

        //        entity.Property(e => e.SetNo)
        //            .IsRequired()
        //            .HasMaxLength(10)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.HeldByOrgnaization)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.HeldByOrgnaizationId)
        //            .HasConstraintName("FK_UnitStockTransaction_HeldByOrgnaizationId");

        //        entity.HasOne(d => d.ItemBasicCategory)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.ItemBasicCategoryId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockTransaction_ItemBasicCategoryId");

        //        entity.HasOne(d => d.ItemEquipment)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.ItemEquipmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockTransaction_ItemEquipmentId");

        //        entity.HasOne(d => d.ItemEquipmentType)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.ItemEquipmentTypeId)
        //            .HasConstraintName("FK_UnitStockTransaction_ItemEquipmentTypeId");

        //        entity.HasOne(d => d.Item)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.ItemId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockTransaction_Item");

        //        entity.HasOne(d => d.Origin)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.OriginId)
        //            .HasConstraintName("FK_UnitStockTransaction_OriginId");

        //        entity.HasOne(d => d.StockShed)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.StockShedId)
        //            .HasConstraintName("FK_UnitStockTransaction_StockShedId");

        //        entity.HasOne(d => d.UnitStock)
        //            .WithMany(p => p.UnitStockTransaction)
        //            .HasForeignKey(d => d.UnitStockId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UnitStockTransaction_UnitStock");
        //    });

        //    modelBuilder.Entity<UnitType>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<User>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_User_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CodePrefix)
        //            .HasMaxLength(20)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.DateOfBirth).HasColumnType("date");

        //        entity.Property(e => e.Email)
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.FirstName)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.LastName)
        //            .IsRequired()
        //            .HasMaxLength(75)
        //            .IsUnicode(false);

        //        entity.Property(e => e.LoginName)
        //            .IsRequired()
        //            .HasMaxLength(20)
        //            .IsUnicode(false);

        //        entity.Property(e => e.MiddleName)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Mobile)
        //            .HasMaxLength(10)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Department)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.DepartmentId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_User_DepartmentId");

        //        entity.HasOne(d => d.Designation)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.DesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_User_DesignationId");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_User_OrganizationId");

        //        entity.HasOne(d => d.Role)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.RoleId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_User_RoleId");

        //        entity.HasOne(d => d.SubOrganizationType)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.SubOrganizationTypeId)
        //            .HasConstraintName("FK_User_SubOrganizationTypeId");

        //        entity.HasOne(d => d.UserType)
        //            .WithMany(p => p.User)
        //            .HasForeignKey(d => d.UserTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_User_UserTypeId");
        //    });

        //    modelBuilder.Entity<UserMack>(entity =>
        //    {
        //        entity.Property(e => e.MackAddress)
        //            .IsRequired()
        //            .HasMaxLength(20);

        //        entity.HasOne(d => d.User)
        //            .WithMany(p => p.UserMack)
        //            .HasForeignKey(d => d.UserId)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<UserPermission>(entity =>
        //    {
        //        entity.HasIndex(e => e.RowId)
        //            .HasName("CIX_UserPermission_RowId")
        //            .IsUnique()
        //            .ForSqlServerIsClustered();

        //        entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.DateOfBirth).HasColumnType("date");

        //        entity.Property(e => e.Email)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.LoginName)
        //            .IsRequired()
        //            .HasMaxLength(20)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Mobile)
        //            .HasMaxLength(10)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.RowId).ValueGeneratedOnAdd();

        //        entity.Property(e => e.RowVersion)
        //            .IsRequired()
        //            .IsRowVersion();

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.HasOne(d => d.Designation)
        //            .WithMany(p => p.UserPermission)
        //            .HasForeignKey(d => d.DesignationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UserPermission_DesignationId");

        //        entity.HasOne(d => d.Organization)
        //            .WithMany(p => p.UserPermission)
        //            .HasForeignKey(d => d.OrganizationId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_UserPermission_OrganizationId");

        //        entity.HasOne(d => d.SubOrganizationType)
        //            .WithMany(p => p.UserPermission)
        //            .HasForeignKey(d => d.SubOrganizationTypeId)
        //            .HasConstraintName("FK_UserPermission_SubOrganizationTypeId");
        //    });

        //    modelBuilder.Entity<UserType>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.Code)
        //            .IsRequired()
        //            .HasColumnType("char(2)");

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(250)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.Name)
        //            .IsRequired()
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");
        //    });

        //    modelBuilder.Entity<Year>(entity =>
        //    {
        //        entity.Property(e => e.Id).ValueGeneratedOnAdd();

        //        entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.FinancialYear)
        //            .IsRequired()
        //            .HasMaxLength(10)
        //            .IsUnicode(false);

        //        entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

        //        entity.Property(e => e.UpdatedDate).HasDefaultValueSql("(getdate())");

        //        entity.Property(e => e.Year1).HasColumnName("Year");
        //    });
        

        //IgnoreColumnWitDB(modelBuilder);
        //}

        //private static void IgnoreColumnWitDB(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<CurrentStockQuantityView>(entity =>
        //    {
        //        entity.ToTable("CurrentStockQuantityView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.ItemId).HasDefaultValueSql("(newid())");
        //        entity.Property(e => e.currentQuantity).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.StoreId).HasDefaultValueSql("(short())");
        //    });

        //    modelBuilder.Entity<CurrentStockQuantitySetWiseView>(entity =>
        //    {
        //        entity.ToTable("CurrentStockQuantitySetWiseView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.ItemId).HasDefaultValueSql("(newid())");

        //        entity.Property(e => e.GroupItemId).HasDefaultValueSql("(newid())");
        //        entity.Property(e => e.StockShedId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.ItemSetNumberId).HasDefaultValueSql("(int())");
        //        entity.Property(e => e.currentQuantity).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.StoreId).HasDefaultValueSql("(short())");
        //    });

        //    modelBuilder.Entity<AuthorizedItemMSLView>(entity =>
        //    {
        //        entity.ToTable("AuthorizedItemMSLView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.StoreStockItemAuthorityId).HasDefaultValueSql("(newid())");
        //        entity.Property(e => e.AuthorizedOrganiztionId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.OrganizationName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.GroupItemId).HasDefaultValueSql("(newid())");
        //        entity.Property(e => e.ItemName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ItemId).HasDefaultValueSql("(newid())");
        //        entity.Property(e => e.PartName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AuthQuantity).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.PartHeldQuantity).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.MinimumStockLevelPercent).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.PartHeldInPercent).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Criticality).HasDefaultValueSql("(string())");
        //    });

        //    modelBuilder.Entity<ETSRStateView>(entity =>
        //    {
        //        entity.ToTable("ETSRStateView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.ItemName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.TypeOfStoreId).HasDefaultValueSql("(short())");                
        //        entity.Property(e => e.StoreId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.AU).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AuthQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.HeldQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.OnLoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.UnderRep).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.ComitOnGround).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.RelCollected).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.NetSerQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Remark).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.CategoryId).HasDefaultValueSql("(short())");
        //    });

        //    modelBuilder.Entity<ETSRSummeryView>(entity =>
        //    {
        //        entity.ToTable("ETSRSummaryView", "Main");
        //        entity.HasIndex(e => e.Id)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.Items).HasDefaultValueSql("(string())");
        //        //entity.Property(e => e.AU).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.Held).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.RepQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.SerQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Salvage).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Remark).HasDefaultValueSql("(string())");
        //    });

        //    modelBuilder.Entity<CategoryWiseView>(entity =>
        //    {
        //        entity.ToTable("CategoryWiseView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.ItemName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AU).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AuthQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.HeldQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.OnLoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.UnderRep).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.ComitOnGround).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.RelCollected).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.NetSerQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Remark).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.CategoryId).HasDefaultValueSql("(short())");
        //    });

        //    modelBuilder.Entity<BasicCategoryWiseView>(entity =>
        //    {
        //        entity.ToTable("BasicCategoryWiseView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.ItemName).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AU).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.AuthQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.HeldQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.OnLoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.UnderRep).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.ComitOnGround).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.RelCollected).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.NetSerQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Remark).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.BasicCatId).HasDefaultValueSql("(short())");
        //    });

        //    modelBuilder.Entity<BasicCategorySummeryView>(entity =>
        //    {
        //        entity.ToTable("BasicCategorySummaryView", "Main");
        //        entity.HasIndex(e => e.Id)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.Items).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.Held).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.RepQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.SerQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Salvage).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.Remark).HasDefaultValueSql("(string())");
        //    });

        //    modelBuilder.Entity<LoanStateView>(entity =>
        //    {
        //        entity.ToTable("LoanStateView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.GID).HasDefaultValueSql("(Guid())");
        //        entity.Property(e => e.Numencluture).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ND_AU).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.StoreId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.ND_CategoryId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.ND_BasiccatId).HasDefaultValueSql("(short())");

        //        entity.Property(e => e.ND_Unit).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ND_Fmn).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ND_LoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.ND_Authority).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ND_Permt).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.ND_Temp).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.ND_LoanExpPeriod).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.ND_PresentStatus).HasDefaultValueSql("(string())");

        //        entity.Property(e => e.D_Unit).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_Fmn).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_LoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.D_Authority).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_Permt).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.D_Temp).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.D_LoanExpPeriod).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_PresentStatus).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.TotQtyOnLoan).HasDefaultValueSql("(decimal())");

        //    });

        //    modelBuilder.Entity<LoanDepositedStatusView>(entity =>
        //    {
        //        entity.ToTable("LoanDepositedStatusView", "Main");
        //        entity.HasIndex(e => e.RowNo)
        //            .IsUnique()
        //            .ForSqlServerIsClustered();
        //        entity.Property(e => e.GID).HasDefaultValueSql("(Guid())");
        //        entity.Property(e => e.StoreId).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.Numencluture).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_Unit).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_Fmn).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_LoanQty).HasDefaultValueSql("(decimal())");
        //        entity.Property(e => e.D_Authority).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_Permt).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.D_Temp).HasDefaultValueSql("(short())");
        //        entity.Property(e => e.D_LoanExpPeriod).HasDefaultValueSql("(string())");
        //        entity.Property(e => e.D_PresentStatus).HasDefaultValueSql("(string())");
                

        //    });



        //    modelBuilder.Entity<ItemPart>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<ItemBasicCategory>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<ItemEquipment>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<ItemEquipmentType>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<GroupItemDetail>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<GroupItemBasicCategory>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<AvailabilityCertRequestDetail>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<AvailabilityCertIssueDetail>().Ignore(e => e.ObjectState);

        //    modelBuilder.Entity<UnitStockTransaction>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<StoreStockTransaction>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<StoreStockTransactionQuantity>().Ignore(e => e.ObjectState);
        //    modelBuilder.Entity<StoreStockTransactionSetNo>().Ignore(e => e.ObjectState);
        //}

        //public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        //{

        //}

        
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {
        //    }
        //}
    }
}
