﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Data
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task<TEntity> FindByIdAsync(object id);
        Task InsertGraphAsync(TEntity entity);
        Task UpdateAsync(TEntity entity);
        TEntity Update(TEntity dbEntity, TEntity entity);
        Task DeleteAsync(object id);
        Task DeleteAsync(TEntity entity);
        Task InsertAsync(TEntity entity);
        RepositoryQuery<TEntity> Query();
        void Dispose();
        void ChangeEntityState<T>(T entity, ObjectState state) where T : class;
        TEntity SetValues(TEntity dbEntity, TEntity entity);
        Task SaveChangesAsync();
    }
}
