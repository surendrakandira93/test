﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Data
{
    public enum ObjectState
    {
        Added,
        Modified,
        Deleted,
        Unchanged,
        Detached
    }
}
