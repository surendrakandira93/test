﻿namespace EngineerPark.Data.IRepositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;

    /// <summary>
    /// Generic IRepository
    /// </summary>
    /// <typeparam name="T">Type of Entity</typeparam>
    public partial interface IGenericRepository<T>
        where T : class
    {
        /// <summary>
        /// Adds the specified t.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        T Add(T t);

        /// <summary>
        /// Adds the asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        Task<T> AddAsyn(T t);

        /// <summary>
        /// Adds the range asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns></returns>
        Task<List<T>> AddRangeAsyn(List<T> t);

        /// <summary>
        /// Counts this instance.
        /// </summary>
        /// <returns>
        /// Integer Value
        /// </returns>
        int Count();
        /// <summary>
        /// Counts the asynchronous.
        /// </summary>
        /// <returns>
        /// Interger Value
        /// </returns>
        Task<int> CountAsync();

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <param name="id">The identifier.</param>
        void Delete(object id);

        /// <summary>
        /// Deletes the entity asyn.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        Task<int> DeleteEntityAsyn(T entity);

        /// <summary>
        /// Deletes the range asyn.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        Task<int> DeleteRangeAsyn(List<T> entity);

        /// <summary>
        /// Deletes the entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        void DeleteEntity(T entity);

        /// <summary>
        /// Deletes the range.
        /// </summary>
        /// <param name="entity">The entity.</param>
        void DeleteRange(List<T> entity);

        /// <summary>
        /// Deletes the asyn.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Integer Value
        /// </returns>
        Task<int> DeleteAsyn(object id);

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        void Dispose();

        /// <summary>
        /// Finds the specified match.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        T Find(Expression<Func<T, bool>> match);

        /// <summary>
        /// Finds all.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        ICollection<T> FindAll(Expression<Func<T, bool>> match);

        /// <summary>
        /// Finds all asynchronous.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        Task<List<T>> FindAllAsync(Expression<Func<T, bool>> match);

        /// <summary>
        /// Finds the asynchronous.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        Task<T> FindAsync(Expression<Func<T, bool>> match);

        /// <summary>
        /// Finds the by.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        IQueryable<T> FindBy(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Finds the by asyn.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        Task<ICollection<T>> FindByAsyn(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Gets the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        T Get(object id);

        /// <summary>
        /// Gets the asynchronous.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        Task<T> GetAsync(object key);

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        IQueryable<T> GetAll();

        /// <summary>
        /// Gets all asyn.
        /// </summary>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        Task<ICollection<T>> GetAllAsync();

        /// <summary>
        /// Gets all including.
        /// </summary>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        IQueryable<T> GetAllIncluding(Func<IQueryable<T>, IQueryable<T>> includeMembers);

        /// <summary>
        /// Gets all including asyn.
        /// </summary>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// List of Collection
        /// </returns>
        Task<ICollection<T>> GetAllIncludingAsyn(Func<IQueryable<T>, IQueryable<T>> includeMembers);
        IQueryable<T> GetAllIncludingIQueryableAsyn(Func<IQueryable<T>, IQueryable<T>> includeMembers);
        IQueryable<T> GetAllIncludingIQueryableAsyn(Expression<Func<T, bool>> predicate, Func<IQueryable<T>, IQueryable<T>> includeMembers);

        /// <summary>
        /// Gets the including by identifier asyn.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// Type of entity
        /// </returns>
        Task<T> GetIncludingByIdAsyn(Expression<Func<T, bool>> match, Func<IQueryable<T>, IQueryable<T>> includeMembers);

        /// <summary>
        /// Saves this instance.
        /// </summary>
        void Save();

        /// <summary>
        /// Saves the asynchronous.
        /// </summary>
        /// <returns>
        /// Integer Value
        /// </returns>
        Task<int> SaveAsync();

        /// <summary>
        /// Updates the specified t.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        T Update(T t, object key);

        /// <summary>
        /// Updates the asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        Task<T> UpdateAsync(T t, object key);

        /// <summary>
        /// Updates the asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <param name="key">The key.</param>
        /// <param name="rowversion">The rowversion.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        Task<T> UpdateAsync(T t, object key, byte[] rowversion);

        Task<T> UpdateAsync(T t);

        /// <summary>
        /// To the paged list asynchronous.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="model">The model.</param>
        /// <returns>
        /// Get Pagging Entites List By Querable Data with search parameters
        /// </returns>
        Task<DataTableResult> ToPagedListAsync(IQueryable<T> query, DataTableParameter model);

        Task<ICollection<T>> GetIncludingFindByAsyn(Expression<Func<T, bool>> predicate, Func<IQueryable<T>, IQueryable<T>> includeMembers);
     
    }
}