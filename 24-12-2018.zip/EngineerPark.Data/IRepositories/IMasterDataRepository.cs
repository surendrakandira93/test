﻿using EngineerPark.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Data.IRepositories
{
  public interface IMasterDataRepository
    {
        Task<List<MasterDataView>> Execute(string sqlQuery);
    }
}
