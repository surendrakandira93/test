﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace EngineerPark.Data.Models
{
    public partial class AvailabilityCertIssueDetail
    {
        public AvailabilityCertIssueDetail()
        {
            LoanRequestDetail = new HashSet<LoanRequestDetail>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertIssueId { get; set; }
        public Guid AvailabilityCertReqestDetailId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal RequestedQuantiy { get; set; }
        public decimal AvailableQuantiy { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public AvailabilityCertIssue AvailabilityCertIssue { get; set; }
        public AvailabilityCertRequestDetail AvailabilityCertReqestDetail { get; set; }
        public Item Item { get; set; }
        public ItemBasicCategory ItemBasicCategory { get; set; }
        public ItemEquipment ItemEquipment { get; set; }
        public ItemEquipmentType ItemEquipmentType { get; set; }
        public EntityState ObjectState { get;  set; }
        public ICollection<LoanRequestDetail> LoanRequestDetail { get; set; }

    }
}
