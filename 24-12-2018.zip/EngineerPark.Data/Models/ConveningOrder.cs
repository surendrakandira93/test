﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveningOrder
    {
        public ConveningOrder()
        {
            ConveningOrderApproval = new HashSet<ConveningOrderApproval>();
            ConveningOrderItem = new HashSet<ConveningOrderItem>();
            ConveningOrderItemSurveyMain = new HashSet<ConveningOrderItemSurveyMain>();
            ConveningOrderMember = new HashSet<ConveningOrderMember>();
            ConveningOrderSurveySalvageTemp = new HashSet<ConveningOrderSurveySalvageTemp>();
            LoadTrolley = new HashSet<LoadTrolley>();
            LoanReceiptVoucher = new HashSet<LoanReceiptVoucher>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ReleaseOrderId { get; set; }
        public byte YearId { get; set; }
        public string ConveningOrderNo { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime? IssueDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public Guid? ConveningOrderBy { get; set; }
        public Guid? PresidingOfficerId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public short ApprovedDesignationId { get; set; }
        public short AssignedDesignationId { get; set; }
        public Guid? Poid { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public Designation ApprovedDesignation { get; set; }
        public Designation AssignedDesignation { get; set; }
        public User ConveningOrderByNavigation { get; set; }
        public User Po { get; set; }
        public User PresidingOfficer { get; set; }
        public ReleaseOrder ReleaseOrder { get; set; }
        public Status Status { get; set; }
        public Organization Store { get; set; }
        public Organization Unit { get; set; }
        public ConveningOrderIssue ConveningOrderIssue { get; set; }
        public SenctionOrder SenctionOrder { get; set; }
        public ICollection<ConveningOrderApproval> ConveningOrderApproval { get; set; }
        public ICollection<ConveningOrderItem> ConveningOrderItem { get; set; }
        public ICollection<ConveningOrderItemSurveyMain> ConveningOrderItemSurveyMain { get; set; }
        public ICollection<ConveningOrderMember> ConveningOrderMember { get; set; }
        public ICollection<ConveningOrderSurveySalvageTemp> ConveningOrderSurveySalvageTemp { get; set; }
        public ICollection<LoadTrolley> LoadTrolley { get; set; }
        public ICollection<LoanReceiptVoucher> LoanReceiptVoucher { get; set; }
    }
}
