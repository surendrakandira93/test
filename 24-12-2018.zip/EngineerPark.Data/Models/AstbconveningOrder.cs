﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AstbconveningOrder
    {
        public AstbconveningOrder()
        {
            AstbconveningOrderApproval = new HashSet<AstbconveningOrderApproval>();
            AstbsalvageTemp = new HashSet<AstbsalvageTemp>();
            Astbstore = new HashSet<Astbstore>();
            Bdofficer = new HashSet<Bdofficer>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public string LetterNo { get; set; }
        public DateTime Date { get; set; }
        public DateTime? IssueDate { get; set; }
        public Guid? PresidingOfficerId { get; set; }
        public short StoreId { get; set; }
        public short UnitId { get; set; }
        public string FileName { get; set; }
        public bool IsApproved { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public string Fyear { get; set; }
        public string BooComposition { get; set; }
        public DateTime? IntercationDate { get; set; }
        public DateTime Bpodate { get; set; }
        public long FilioNo { get; set; }
        public string Scope { get; set; }

        public User CreatedByNavigation { get; set; }
        public User PresidingOfficer { get; set; }
        public Organization Store { get; set; }
        public Organization Unit { get; set; }
        public User UpdatedByNavigation { get; set; }
        public ICollection<AstbconveningOrderApproval> AstbconveningOrderApproval { get; set; }
        public ICollection<AstbsalvageTemp> AstbsalvageTemp { get; set; }
        public ICollection<Astbstore> Astbstore { get; set; }
        public ICollection<Bdofficer> Bdofficer { get; set; }
    }
}
