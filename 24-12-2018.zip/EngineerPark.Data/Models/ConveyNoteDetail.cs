﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveyNoteDetail
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveyNoteId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public Guid GroupItemId { get; set; }
        public short? StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
        public decimal Quantiy { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ConveyNote ConveyNote { get; set; }
        public GroupItem GroupItem { get; set; }
        public Item Item { get; set; }
        public ItemBasicCategory ItemBasicCategory { get; set; }
        public ItemEquipment ItemEquipment { get; set; }
        public ItemEquipmentType ItemEquipmentType { get; set; }
        public ItemSetNumber ItemSetNumber { get; set; }
        public StockShed StockShed { get; set; }
    }
}
