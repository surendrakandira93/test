﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AvailabilityCertRequest
    {
        public AvailabilityCertRequest()
        {
            AvailabilityCertIssue = new HashSet<AvailabilityCertIssue>();
            AvailabilityCertRequestApproval = new HashSet<AvailabilityCertRequestApproval>();
            AvailabilityCertRequestDetail = new HashSet<AvailabilityCertRequestDetail>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public byte YearId { get; set; }
        public string RequestNo { get; set; }
        public DateTime RequestDate { get; set; }
        public short RequestedStoreId { get; set; }
        public short UnitId { get; set; }
        public byte StatusId { get; set; }
        public string Task { get; set; }
        public string Authority { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public short ApprovedDesignationId { get; set; }
        public short AssignedDesignationId { get; set; }
        public bool IsRequestSent { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public Designation ApprovedDesignation { get; set; }
        public Designation AssignedDesignation { get; set; }
        public Organization RequestedStore { get; set; }
        public Status Status { get; set; }
        public Organization Unit { get; set; }
        public ICollection<AvailabilityCertIssue> AvailabilityCertIssue { get; set; }
        public ICollection<AvailabilityCertRequestApproval> AvailabilityCertRequestApproval { get; set; }
        public ICollection<AvailabilityCertRequestDetail> AvailabilityCertRequestDetail { get; set; }

    }
}
