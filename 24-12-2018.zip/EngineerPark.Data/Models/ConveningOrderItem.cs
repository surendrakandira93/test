﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveningOrderItem
    {
        public ConveningOrderItem()
        {
            ConveningOrderItemSurvey = new HashSet<ConveningOrderItemSurvey>();
            LoadTrolleyItem = new HashSet<LoadTrolleyItem>();
            LoanReceiptVoucherDetail = new HashSet<LoanReceiptVoucherDetail>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal LoanQuantiy { get; set; }
        public decimal ReturnQuantiy { get; set; }
        public decimal? ReceivedQuantiy { get; set; }
        public string Remarks { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ConveningOrder ConveningOrder { get; set; }
        public Item Item { get; set; }
        public ItemBasicCategory ItemBasicCategory { get; set; }
        public ItemEquipment ItemEquipment { get; set; }
        public ItemEquipmentType ItemEquipmentType { get; set; }
        public ICollection<ConveningOrderItemSurvey> ConveningOrderItemSurvey { get; set; }
        public ICollection<LoadTrolleyItem> LoadTrolleyItem { get; set; }
        public ICollection<LoanReceiptVoucherDetail> LoanReceiptVoucherDetail { get; set; }
    }
}
