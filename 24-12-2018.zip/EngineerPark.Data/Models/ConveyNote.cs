﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveyNote
    {
        public ConveyNote()
        {
            ConveyNoteApproval = new HashSet<ConveyNoteApproval>();
            ConveyNoteDetail = new HashSet<ConveyNoteDetail>();
            GatePass = new HashSet<GatePass>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AuthorityLetterId { get; set; }
        public Guid AuthorityLetterVechileDetailId { get; set; }
        public byte YearId { get; set; }
        public string NoteNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public AuthorityLetter AuthorityLetter { get; set; }
        public AuthorityLetterVechileDetail AuthorityLetterVechileDetail { get; set; }
        public Status Status { get; set; }
        public Organization Store { get; set; }
        public ICollection<ConveyNoteApproval> ConveyNoteApproval { get; set; }
        public ICollection<ConveyNoteDetail> ConveyNoteDetail { get; set; }
        public ICollection<GatePass> GatePass { get; set; }
    }
}
