﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class Astbstore
    {
        public Astbstore()
        {
            AstbstoreDetail = new HashSet<AstbstoreDetail>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbconveningOrderId { get; set; }
        public Guid GroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public short StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public AstbconveningOrder AstbconveningOrder { get; set; }
        public GroupItem GroupItem { get; set; }
        public Item Item { get; set; }
        public ItemSetNumber ItemSetNumber { get; set; }
        public StockShed StockShed { get; set; }
        public ICollection<AstbstoreDetail> AstbstoreDetail { get; set; }
    }
}
