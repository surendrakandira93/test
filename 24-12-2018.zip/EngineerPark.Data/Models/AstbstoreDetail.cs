﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AstbstoreDetail
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbstoreId { get; set; }
        public byte ItemStatusId { get; set; }
        public decimal Quantiy { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public Astbstore Astbstore { get; set; }
        public ItemStatus ItemStatus { get; set; }
    }
}
