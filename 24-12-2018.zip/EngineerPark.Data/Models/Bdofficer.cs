﻿using System;

namespace EngineerPark.Data.Models
{
    public partial class Bdofficer
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbconveningOrderId { get; set; }
        public string Rank { get; set; }
        public string Name { get; set; }
        public short OrganizationId { get; set; }
        public short DesignationId { get; set; }
        public short MemberTypeId { get; set; }
        public bool IsView { get; set; }
        public DateTime? ViewDate { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public AstbconveningOrder AstbconveningOrder { get; set; }
        public User CreatedByNavigation { get; set; }
        public Designation Designation { get; set; }
        public Organization Organization { get; set; }
        public User UpdatedByNavigation { get; set; }
    }
}
