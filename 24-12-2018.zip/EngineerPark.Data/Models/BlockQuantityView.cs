﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EngineerPark.Data.Models
{
    public class BlockQuantityView
    {
        
        public long RowNo { get; set; }
        public Guid ItemId { get; set; }
        public decimal BlockQuantity { get; set; }
        public string PartName { get; set; }
    }
}
