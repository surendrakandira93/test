﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Data.Models
{
    public partial class AnnualCpmbudget
    {
        public int Id { get; set; }
        public short StoreId { get; set; }
        public int Year { get; set; }
        public decimal Cpmamount { get; set; }
        public decimal RepairAmount { get; set; }
        public decimal Contingency { get; set; }
        public bool IsVerified { get; set; }
        public bool IsApproved { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public Organization Store { get; set; }
    }
}
