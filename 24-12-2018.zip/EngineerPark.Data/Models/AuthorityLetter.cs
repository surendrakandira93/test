﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AuthorityLetter
    {
        public AuthorityLetter()
        {
            AuthorityLetterApproval = new HashSet<AuthorityLetterApproval>();
            AuthorityLetterVechileDetail = new HashSet<AuthorityLetterVechileDetail>();
            ConveyNote = new HashSet<ConveyNote>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ReleaseOrderId { get; set; }
        public byte YearId { get; set; }
        public string LetterNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ReleaseOrder ReleaseOrder { get; set; }
        public Status Status { get; set; }
        public Organization Store { get; set; }
        public Organization Unit { get; set; }
        public ICollection<AuthorityLetterApproval> AuthorityLetterApproval { get; set; }
        public ICollection<AuthorityLetterVechileDetail> AuthorityLetterVechileDetail { get; set; }
        public ICollection<ConveyNote> ConveyNote { get; set; }
    }
}
