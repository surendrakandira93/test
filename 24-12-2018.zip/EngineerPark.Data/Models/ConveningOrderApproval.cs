﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveningOrderApproval
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public bool IsApproved { get; set; }
        public DateTime ApprovedDate { get; set; }
        public short FromOrganizationId { get; set; }
        public short FromDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public string Note { get; set; }
        public string FileName { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ConveningOrder ConveningOrder { get; set; }
        public Designation FromDesignation { get; set; }
        public Organization FromOrganization { get; set; }
        public Designation ToDesignation { get; set; }
        public Organization ToOrganization { get; set; }
    }
}
