﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveningOrderItemSurvey
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderItemSurveyMainId { get; set; }
        public Guid ConveningOrderItemId { get; set; }
        public byte ItemStatusId { get; set; }
        public decimal Quantiy { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ConveningOrderItem ConveningOrderItem { get; set; }
        public ConveningOrderItemSurveyMain ConveningOrderItemSurveyMain { get; set; }
        public ItemStatus ItemStatus { get; set; }
    }
}
