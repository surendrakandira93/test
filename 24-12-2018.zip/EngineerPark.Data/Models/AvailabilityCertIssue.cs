﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AvailabilityCertIssue
    {
        public AvailabilityCertIssue()
        {
            AvailabilityCertIssueApproval = new HashSet<AvailabilityCertIssueApproval>();
            AvailabilityCertIssueDetail = new HashSet<AvailabilityCertIssueDetail>();
            LoanRequest = new HashSet<LoanRequest>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertReqestId { get; set; }
        public byte YearId { get; set; }
        public string CertificateNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public short ApprovedDesignationId { get; set; }
        public short AssignedDesignationId { get; set; }
        public bool IsIssued { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public Designation ApprovedDesignation { get; set; }
        public Designation AssignedDesignation { get; set; }
        public AvailabilityCertRequest AvailabilityCertReqest { get; set; }
        public Status Status { get; set; }
        public Organization Store { get; set; }
        public Organization Unit { get; set; }
        public ICollection<AvailabilityCertIssueApproval> AvailabilityCertIssueApproval { get; set; }
        public ICollection<AvailabilityCertIssueDetail> AvailabilityCertIssueDetail { get; set; }
        public ICollection<LoanRequest> LoanRequest { get; set; }
    }
}
