﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class ConveningOrderSurveySalvageTemp
    {
        public int Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public DateTime Date { get; set; }
        public double Weight { get; set; }
        public string Auth { get; set; }
        public short MaterialTypeId { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public ConveningOrder ConveningOrder { get; set; }
        public MaterialType MaterialType { get; set; }
    }
}
