﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public class ConveningOrderIssue
    {
        public long RowId { get; set; }
        public Guid ConveningOrderId { get; set; }
        public byte YearId { get; set; }
        public string OrderNo { get; set; }
        public DateTime OrderDate { get; set; }
        public bool IsDeleted { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ConveningOrder ConveningOrder { get; set; }

    }
}