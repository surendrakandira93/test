﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class AuthorityLetterVechileDetail
    {
        public AuthorityLetterVechileDetail()
        {
            ConveyNote = new HashSet<ConveyNote>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AuthorityLetterId { get; set; }
        public string DriverCode { get; set; }
        public string DriverName { get; set; }       
        public string VechileNo { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public AuthorityLetter AuthorityLetter { get; set; }
        public ICollection<ConveyNote> ConveyNote { get; set; }
    }
}
