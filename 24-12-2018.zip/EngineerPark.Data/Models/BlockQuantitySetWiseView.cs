﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EngineerPark.Data.Models
{
   public class BlockQuantitySetWiseView
    {
        
        public long RowNo { get; set; }
        public Guid ItemId { get; set; }
        public decimal BlockQuantity { get; set; }
        public string PartName { get; set; }
        public Guid GroupItemId { get; set; }
        public short StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
    }
}
