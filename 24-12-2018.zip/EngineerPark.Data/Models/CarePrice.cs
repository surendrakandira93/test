﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Data.Models
{
    public partial class CarePrice
    {
        public int Id { get; set; }
        public Guid ItemId { get; set; }
        public decimal Cpmprice { get; set; }
        public int Year { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public Item Item { get; set; }
    }
}
