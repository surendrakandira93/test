﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Data.Models
{
    public partial class Category
    {
        public Category()
        {
            GroupItem = new HashSet<GroupItem>();
            Item = new HashSet<Item>();
            JobOrderDetail = new HashSet<JobOrderDetail>();
            MaintenancePlanDetail = new HashSet<MaintenancePlanDetail>();
            QuarterlyMaintenancePlanDetail = new HashSet<QuarterlyMaintenancePlanDetail>();
        }

        public short Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public ICollection<GroupItem> GroupItem { get; set; }
        public ICollection<Item> Item { get; set; }
        public ICollection<JobOrderDetail> JobOrderDetail { get; set; }
        public ICollection<MaintenancePlanDetail> MaintenancePlanDetail { get; set; }
        public ICollection<QuarterlyMaintenancePlanDetail> QuarterlyMaintenancePlanDetail { get; set; }
    }
}
