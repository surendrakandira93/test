using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class JobOrderDetailsItemMap : EntityTypeConfiguration<JobOrderDetailsItem>
    {
        public JobOrderDetailsItemMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("JobOrderDetailsItem");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.JobOrderDetailsGroupItemId).HasColumnName("JobOrderDetailsGroupItemId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.Quantity).HasColumnName("Quantity");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.GroupItem)
                .WithMany(t => t.JobOrderDetailsItem)
                .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.Item)
                .WithMany(t => t.JobOrderDetailsItem)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemSetNumber)
                .WithMany(t => t.JobOrderDetailsItem)
                .HasForeignKey(d => d.ItemSetNumberId);
            this.HasRequired(t => t.JobOrderDetailsGroupItem)
                .WithMany(t => t.JobOrderDetailsItem)
                .HasForeignKey(d => d.JobOrderDetailsGroupItemId);
            this.HasRequired(t => t.StockShed)
                .WithMany(t => t.JobOrderDetailsItem)
                .HasForeignKey(d => d.StockShedId);

        }
    }
}
