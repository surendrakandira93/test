using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class BasicCategoryViewMap : EntityTypeConfiguration<BasicCategoryView>
    {
        public BasicCategoryViewMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.BasicCatName)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("BasicCategoryView", "Main");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.BasicCatName).HasColumnName("BasicCatName");
        }
    }
}
