using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class UserMackMap : EntityTypeConfiguration<UserMack>
    {
        public UserMackMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.MackAddress)
                .IsRequired()
                .HasMaxLength(20);

            // Table & Column Mappings
            this.ToTable("UserMack");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.MackAddress).HasColumnName("MackAddress");

            // Relationships
            this.HasRequired(t => t.User)
                .WithMany(t => t.UserMack)
                .HasForeignKey(d => d.UserId);

        }
    }
}
