using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class AuthorityLetterVechileDetailMap : EntityTypeConfiguration<AuthorityLetterVechileDetail>
    {
        public AuthorityLetterVechileDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.DriverCode)
                .IsRequired()
                .HasMaxLength(25);

            this.Property(t => t.DriverName)
                .IsRequired()
                .HasMaxLength(125);

            this.Property(t => t.VechileNo)
                .IsRequired()
                .HasMaxLength(25);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("AuthorityLetterVechileDetail", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.AuthorityLetterId).HasColumnName("AuthorityLetterId");
            this.Property(t => t.DriverCode).HasColumnName("DriverCode");
            this.Property(t => t.DriverName).HasColumnName("DriverName");
            this.Property(t => t.VechileNo).HasColumnName("VechileNo");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.AuthorityLetter)
                .WithMany(t => t.AuthorityLetterVechileDetail)
                .HasForeignKey(d => d.AuthorityLetterId);

        }
    }
}
