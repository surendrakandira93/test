using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanNotDepositedViewMap : EntityTypeConfiguration<LoanNotDepositedView>
    {
        public LoanNotDepositedViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ND_UnitId, t.ND_Permt, t.ND_Temp, t.ND_LoanExpPeriod, t.ND_PresentStatus });

            // Properties
            this.Property(t => t.Numencluture)
                .HasMaxLength(100);

            this.Property(t => t.ND_AU)
                .HasMaxLength(60);

            this.Property(t => t.ND_UnitId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_FirstName)
                .HasMaxLength(50);

            this.Property(t => t.ND_Unit)
                .HasMaxLength(100);

            this.Property(t => t.ND_Fmn)
                .HasMaxLength(100);

            this.Property(t => t.ND_Authority)
                .HasMaxLength(200);

            this.Property(t => t.ND_Permt)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_Temp)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_LoanExpPeriod)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.ND_PresentStatus)
                .IsRequired()
                .HasMaxLength(13);

            // Table & Column Mappings
            this.ToTable("LoanNotDepositedView", "Main");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GID).HasColumnName("GID");
            this.Property(t => t.Numencluture).HasColumnName("Numencluture");
            this.Property(t => t.ND_AU).HasColumnName("ND_AU");
            this.Property(t => t.ND_BasiccatId).HasColumnName("ND_BasiccatId");
            this.Property(t => t.ND_CategoryId).HasColumnName("ND_CategoryId");
            this.Property(t => t.ND_LoanQty).HasColumnName("ND_LoanQty");
            this.Property(t => t.ND_UnitId).HasColumnName("ND_UnitId");
            this.Property(t => t.ND_FirstName).HasColumnName("ND_FirstName");
            this.Property(t => t.ND_Unit).HasColumnName("ND_Unit");
            this.Property(t => t.ND_Fmn).HasColumnName("ND_Fmn");
            this.Property(t => t.ND_Authority).HasColumnName("ND_Authority");
            this.Property(t => t.ND_Permt).HasColumnName("ND_Permt");
            this.Property(t => t.ND_Temp).HasColumnName("ND_Temp");
            this.Property(t => t.ND_LoanExpPeriod).HasColumnName("ND_LoanExpPeriod");
            this.Property(t => t.ND_PresentStatus).HasColumnName("ND_PresentStatus");
        }
    }
}
