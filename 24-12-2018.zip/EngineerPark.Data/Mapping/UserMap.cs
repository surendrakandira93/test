﻿using EngineerPark.Data.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace EngineerPark.Data.Mapping
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.CodePrefix)
                .HasMaxLength(20);

            this.Property(t => t.FirstName)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.MiddleName)
                .HasMaxLength(50);

            this.Property(t => t.LastName)
                .IsRequired()
                .HasMaxLength(75);

            this.Property(t => t.Mobile)
                .HasMaxLength(10);

            this.Property(t => t.Email)
                .HasMaxLength(100);

            this.Property(t => t.LoginName)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("User");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.OrganizationId).HasColumnName("OrganizationId");
            this.Property(t => t.SubOrganizationTypeId).HasColumnName("SubOrganizationTypeId");
            this.Property(t => t.UserTypeId).HasColumnName("UserTypeId");
            this.Property(t => t.RoleId).HasColumnName("RoleId");
            this.Property(t => t.DepartmentId).HasColumnName("DepartmentId");
            this.Property(t => t.DesignationId).HasColumnName("DesignationId");
            this.Property(t => t.CodePrefix).HasColumnName("CodePrefix");
            this.Property(t => t.Code).HasColumnName("Code");
            this.Property(t => t.FirstName).HasColumnName("FirstName");
            this.Property(t => t.MiddleName).HasColumnName("MiddleName");
            this.Property(t => t.LastName).HasColumnName("LastName");
            this.Property(t => t.DateOfBirth).HasColumnName("DateOfBirth");
            this.Property(t => t.Mobile).HasColumnName("Mobile");
            this.Property(t => t.Email).HasColumnName("Email");
            this.Property(t => t.LoginName).HasColumnName("LoginName");
            this.Property(t => t.PasswordHash).HasColumnName("PasswordHash");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.ExpiryDate).HasColumnName("ExpiryDate");
            this.Property(t => t.IsLock).HasColumnName("IsLock");
            this.Property(t => t.LastLogin).HasColumnName("LastLogin");
            this.Property(t => t.LoginAttemp).HasColumnName("LoginAttemp");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Department)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.DepartmentId);
            this.HasRequired(t => t.Designation)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.DesignationId);
            this.HasRequired(t => t.Organization)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.OrganizationId);
            this.HasRequired(t => t.Role)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.RoleId);
            this.HasOptional(t => t.SubOrganizationType)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.SubOrganizationTypeId);
            this.HasRequired(t => t.UserType)
                .WithMany(t => t.User)
                .HasForeignKey(d => d.UserTypeId);

        }
    }
}