using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanExtensionMap : EntityTypeConfiguration<LoanExtension>
    {
        public LoanExtensionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Remark)
                .HasMaxLength(250);

            this.Property(t => t.BdApproveBy)
                .HasMaxLength(250);

            this.Property(t => t.Authority)
                .HasMaxLength(250);

            this.Property(t => t.Justification)
                .HasMaxLength(250);

            // Table & Column Mappings
            this.ToTable("LoanExtension");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.UnitFromId).HasColumnName("UnitFromId");
            this.Property(t => t.UnitToId).HasColumnName("UnitToId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.ReleaseOrderId).HasColumnName("ReleaseOrderId");
            this.Property(t => t.LoanIssueVoucherId).HasColumnName("LoanIssueVoucherId");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.DateFrom).HasColumnName("DateFrom");
            this.Property(t => t.DateTo).HasColumnName("DateTo");
            this.Property(t => t.BdDate).HasColumnName("BdDate");
            this.Property(t => t.BdApproveBy).HasColumnName("BdApproveBy");
            this.Property(t => t.Authority).HasColumnName("Authority");
            this.Property(t => t.Justification).HasColumnName("Justification");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.LoanExtension)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.LoanIssueVoucher)
                .WithMany(t => t.LoanExtension)
                .HasForeignKey(d => d.LoanIssueVoucherId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.LoanExtensionToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.UnitFrom)
                .WithMany(t => t.LoanExtensionUnitFrom)
                .HasForeignKey(d => d.UnitFromId);
            this.HasRequired(t => t.UnitTo)
                .WithMany(t => t.LoanExtensionUnitTo)
                .HasForeignKey(d => d.UnitToId);
            this.HasRequired(t => t.ReleaseOrder)
                .WithMany(t => t.LoanExtension)
                .HasForeignKey(d => d.ReleaseOrderId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.LoanExtensionStore)
                .HasForeignKey(d => d.StoreId);

        }
    }
}
