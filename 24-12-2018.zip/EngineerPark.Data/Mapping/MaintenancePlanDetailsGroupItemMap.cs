using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class MaintenancePlanDetailsGroupItemMap : EntityTypeConfiguration<MaintenancePlanDetailsGroupItem>
    {
        public MaintenancePlanDetailsGroupItemMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("MaintenancePlanDetailsGroupItem");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.MaintenancePlanDetailId).HasColumnName("MaintenancePlanDetailId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.GroupItem)
                .WithMany(t => t.MaintenancePlanDetailsGroupItem)
                .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.MaintenancePlanDetail)
                .WithMany(t => t.MaintenancePlanDetailsGroupItem)
                .HasForeignKey(d => d.MaintenancePlanDetailId);

        }
    }
}
