using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class AvailabilityCertRequestMap : EntityTypeConfiguration<AvailabilityCertRequest>
    {
        public AvailabilityCertRequestMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.RequestNo)
                .IsRequired()
                .HasMaxLength(11);

            this.Property(t => t.Task)
                .IsRequired()
                .HasMaxLength(200);

            this.Property(t => t.Authority)
                .IsRequired()
                .HasMaxLength(200);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("AvailabilityCertRequest", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.YearId).HasColumnName("YearId");
            this.Property(t => t.RequestNo).HasColumnName("RequestNo");
            this.Property(t => t.RequestDate).HasColumnName("RequestDate");
            this.Property(t => t.RequestedStoreId).HasColumnName("RequestedStoreId");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.StatusId).HasColumnName("StatusId");
            this.Property(t => t.Task).HasColumnName("Task");
            this.Property(t => t.Authority).HasColumnName("Authority");
            this.Property(t => t.FromDate).HasColumnName("FromDate");
            this.Property(t => t.ToDate).HasColumnName("ToDate");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.IsDeleted).HasColumnName("IsDeleted");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.ApprovedDesignationId).HasColumnName("ApprovedDesignationId");
            this.Property(t => t.AssignedDesignationId).HasColumnName("AssignedDesignationId");
            this.Property(t => t.IsRequestSent).HasColumnName("IsRequestSent");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.ApprovedDesignation)
                .WithMany(t => t.AvailabilityCertRequestApprovedDesignation)
                .HasForeignKey(d => d.ApprovedDesignationId);
            this.HasRequired(t => t.AssignedDesignation)
                .WithMany(t => t.AvailabilityCertRequestAssignedDesignation)
                .HasForeignKey(d => d.AssignedDesignationId);
            this.HasRequired(t => t.RequestedStore)
                .WithMany(t => t.AvailabilityCertRequestRequestedStore)
                .HasForeignKey(d => d.RequestedStoreId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.AvailabilityCertRequestUnit)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.Status)
                .WithMany(t => t.AvailabilityCertRequest)
                .HasForeignKey(d => d.StatusId);

        }
    }
}
