using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StockQuantityViewMap : EntityTypeConfiguration<StockQuantityView>
    {
        public StockQuantityViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ItemId });

            // Properties
            //this.Property(t => t.StoreId)
            //    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("StockQuantityView", "Main");
           // this.Property(t => t.StoreId).HasColumnName("StoreId");
           // this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
           // this.Property(t => t.PartHeldQuantity).HasColumnName("PartHeldQuantity");
        }
    }
}
