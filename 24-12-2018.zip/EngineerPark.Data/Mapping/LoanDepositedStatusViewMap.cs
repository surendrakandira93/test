﻿using EngineerPark.Data.Models.ReportView;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace EngineerPark.Data.Mapping
{
    public class LoanDepositedStatusViewMap : EntityTypeConfiguration<LoanDepositedStatusView>
    {
        public LoanDepositedStatusViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.RowNo, t.GID, t.StoreId});

            // Properties
            this.Property(t => t.RowNo)
               .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.GID)
                .IsRequired()
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);



            // Table & Column Mappings
            this.ToTable("LoanDepositedStatusView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GID).HasColumnName("GID");
            this.Property(t => t.Numencluture).HasColumnName("Numencluture");            
            this.Property(t => t.D_Unit).HasColumnName("D_Unit");
            this.Property(t => t.D_Fmn).HasColumnName("D_Fmn");
            this.Property(t => t.D_LoanQty).HasColumnName("D_LoanQty");
            this.Property(t => t.D_Authority).HasColumnName("D_Authority");
            this.Property(t => t.D_Permt).HasColumnName("D_Permt");
            this.Property(t => t.D_Temp).HasColumnName("D_Temp");
            this.Property(t => t.D_LoanExpPeriod).HasColumnName("D_LoanExpPeriod");
            this.Property(t => t.D_PresentStatus).HasColumnName("D_PresentStatus");
        }
    }
}
