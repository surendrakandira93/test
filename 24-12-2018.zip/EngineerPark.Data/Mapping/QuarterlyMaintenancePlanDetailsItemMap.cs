using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class QuarterlyMaintenancePlanDetailsItemMap : EntityTypeConfiguration<QuarterlyMaintenancePlanDetailsItem>
    {
        public QuarterlyMaintenancePlanDetailsItemMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("QuarterlyMaintenancePlanDetailsItem");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.QuarterlyMaintenancePlanDetailsGroupItemId).HasColumnName("QuarterlyMaintenancePlanDetailsGroupItemId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.Quantity).HasColumnName("Quantity");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.GroupItem)
                .WithMany(t => t.QuarterlyMaintenancePlanDetailsItem)
                .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.Item)
                .WithMany(t => t.QuarterlyMaintenancePlanDetailsItem)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemSetNumber)
                .WithMany(t => t.QuarterlyMaintenancePlanDetailsItem)
                .HasForeignKey(d => d.ItemSetNumberId);
            this.HasRequired(t => t.QuarterlyMaintenancePlanDetailsGroupItem)
                .WithMany(t => t.QuarterlyMaintenancePlanDetailsItem)
                .HasForeignKey(d => d.QuarterlyMaintenancePlanDetailsGroupItemId);
            this.HasRequired(t => t.StockShed)
                .WithMany(t => t.QuarterlyMaintenancePlanDetailsItem)
                .HasForeignKey(d => d.StockShedId);

        }
    }
}
