using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class SalvageInMap : EntityTypeConfiguration<SalvageIn>
    {
        public SalvageInMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Auth)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Remark)
                .HasMaxLength(250);

            // Table & Column Mappings
            this.ToTable("SalvageIn");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.OrganizationId).HasColumnName("OrganizationId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.Date).HasColumnName("Date");
            this.Property(t => t.Weight).HasColumnName("Weight");
            this.Property(t => t.Auth).HasColumnName("Auth");
            this.Property(t => t.MaterialTypeId).HasColumnName("MaterialTypeId");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");

            // Relationships
            this.HasRequired(t => t.MaterialType)
                .WithMany(t => t.SalvageIn)
                .HasForeignKey(d => d.MaterialTypeId);
            this.HasRequired(t => t.Organization)
                .WithMany(t => t.SalvageInOrganization)
                .HasForeignKey(d => d.OrganizationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.SalvageInStore)
                .HasForeignKey(d => d.StoreId);

        }
    }
}
