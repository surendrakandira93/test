using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class BlockQuantityViewMap : EntityTypeConfiguration<BlockQuantityView>
    {
        public BlockQuantityViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ItemId });

            // Properties
            //this.Property(t => t.StoreId)
            //    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.PartName)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("BlockQuantityView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            //this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.BlockQuantity).HasColumnName("BlockQuantity");
            this.Property(t => t.PartName).HasColumnName("PartName");
        }
    }
}
