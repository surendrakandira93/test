using EngineerPark.Data.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace EngineerPark.Data.Mapping
{
    public class ASTBConveningOrderMap : EntityTypeConfiguration<AstbconveningOrder>
    {
        public ASTBConveningOrderMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.LetterNo)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.FileName)
                .HasMaxLength(250);

            this.Property(t => t.Fyear)
                .HasMaxLength(15);

            this.Property(t => t.BooComposition)
                .HasMaxLength(256);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ASTBConveningOrder", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.LetterNo).HasColumnName("LetterNo");
            this.Property(t => t.Date).HasColumnName("Date");
            this.Property(t => t.IssueDate).HasColumnName("IssueDate");
            this.Property(t => t.PresidingOfficerId).HasColumnName("PresidingOfficerId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.FileName).HasColumnName("FileName");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.Fyear).HasColumnName("fyear");
            this.Property(t => t.BooComposition).HasColumnName("BooComposition");
            this.Property(t => t.IntercationDate).HasColumnName("IntercationDate");
            this.Property(t => t.FilioNo).HasColumnName("FilioNo");
            this.Property(t => t.Bpodate).HasColumnName("BPODate");
            this.Property(t => t.Scope).HasColumnName("Scope");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Store)
                .WithMany(t => t.AstbconveningOrderStore)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.AstbconveningOrderUnit)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.CreatedByNavigation)
                .WithMany(t => t.AstbconveningOrderCreatedByNavigation)
                .HasForeignKey(d => d.CreatedBy);
            this.HasOptional(t => t.UpdatedByNavigation)
                .WithMany(t => t.AstbconveningOrderCreatedByNavigation)
                .HasForeignKey(d => d.PresidingOfficerId);
            this.HasRequired(t => t.UpdatedByNavigation)
                .WithMany(t => t.AstbconveningOrderUpdatedByNavigation)
                .HasForeignKey(d => d.UpdatedBy);

        }
    }
}
