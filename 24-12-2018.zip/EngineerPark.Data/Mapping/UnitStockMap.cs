using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class UnitStockMap : EntityTypeConfiguration<UnitStock>
    {
        public UnitStockMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("UnitStock", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.TransactionTypeId).HasColumnName("TransactionTypeId");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.IsStockOut).HasColumnName("IsStockOut");
            this.Property(t => t.TransactionDate).HasColumnName("TransactionDate");
            this.Property(t => t.TransactionRefId).HasColumnName("TransactionRefId");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.UnitStock)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.TransactionType)
                .WithMany(t => t.UnitStock)
                .HasForeignKey(d => d.TransactionTypeId);

        }
    }
}
