using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ConveningOrderItemSurveyMap : EntityTypeConfiguration<ConveningOrderItemSurvey>
    {
        public ConveningOrderItemSurveyMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ConveningOrderItemSurvey", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ConveningOrderItemSurveyMainId).HasColumnName("ConveningOrderItemSurveyMainId");
            this.Property(t => t.ConveningOrderItemId).HasColumnName("ConveningOrderItemId");
            this.Property(t => t.ItemStatusId).HasColumnName("ItemStatusId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.ItemStatus)
                .WithMany(t => t.ConveningOrderItemSurvey)
                .HasForeignKey(d => d.ItemStatusId);
            this.HasRequired(t => t.ConveningOrderItem)
                .WithMany(t => t.ConveningOrderItemSurvey)
                .HasForeignKey(d => d.ConveningOrderItemId);
            this.HasRequired(t => t.ConveningOrderItemSurveyMain)
                .WithMany(t => t.ConveningOrderItemSurvey)
                .HasForeignKey(d => d.ConveningOrderItemSurveyMainId);

        }
    }
}
