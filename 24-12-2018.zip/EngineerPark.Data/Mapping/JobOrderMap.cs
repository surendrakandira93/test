using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class JobOrderMap : EntityTypeConfiguration<JobOrder>
    {
        public JobOrderMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Authority)
                .HasMaxLength(250);

            this.Property(t => t.VenderName)
                .HasMaxLength(250);

            this.Property(t => t.JobOrderNo)
                .HasMaxLength(250);

            this.Property(t => t.Justification)
                .HasMaxLength(250);

            this.Property(t => t.File)
                .HasMaxLength(250);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("JobOrder");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.MaintenancePlanId).HasColumnName("MaintenancePlanId");
            this.Property(t => t.QuarterlyMaintenancePlanId).HasColumnName("QuarterlyMaintenancePlanId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.JobOrderTypeId).HasColumnName("JobOrderTypeId");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.Authority).HasColumnName("Authority");
            this.Property(t => t.VenderName).HasColumnName("VenderName");
            this.Property(t => t.FromDate).HasColumnName("FromDate");
            this.Property(t => t.ToDate).HasColumnName("ToDate");
            this.Property(t => t.JobOrderNo).HasColumnName("JobOrderNo");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CompletionDate).HasColumnName("CompletionDate");
            this.Property(t => t.CancellationDate).HasColumnName("CancellationDate");
            this.Property(t => t.Justification).HasColumnName("Justification");
            this.Property(t => t.File).HasColumnName("File");
            this.Property(t => t.Status).HasColumnName("Status");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.JobOrder)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.MaintenancePlan)
                .WithMany(t => t.JobOrder)
                .HasForeignKey(d => d.MaintenancePlanId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.JobOrderToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.JobOrderStore)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.QuarterlyMaintenancePlan)
                .WithMany(t => t.JobOrder)
                .HasForeignKey(d => d.QuarterlyMaintenancePlanId);

        }
    }
}
