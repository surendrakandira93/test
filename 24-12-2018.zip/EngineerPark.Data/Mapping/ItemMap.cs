using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ItemMap : EntityTypeConfiguration<Item>
    {
        public ItemMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.CatPtNo)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Description)
                .HasMaxLength(100);

            this.Property(t => t.LoadingVehicle)
                .HasMaxLength(100);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("Item");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.CatPtNo).HasColumnName("CatPtNo");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            this.Property(t => t.Description).HasColumnName("Description");
            this.Property(t => t.MaterialTypeId).HasColumnName("MaterialTypeId");
            this.Property(t => t.WeightUomId).HasColumnName("WeightUomId");
            this.Property(t => t.Weight).HasColumnName("Weight");
            this.Property(t => t.Area).HasColumnName("Area");
            this.Property(t => t.AreaUomId).HasColumnName("AreaUomId");
            this.Property(t => t.VolumeUomId).HasColumnName("VolumeUomId");
            this.Property(t => t.Volume).HasColumnName("Volume");
            this.Property(t => t.CapacityUomId).HasColumnName("CapacityUomId");
            this.Property(t => t.Capacity).HasColumnName("Capacity");
            this.Property(t => t.ItemUomId).HasColumnName("ItemUomId");
            this.Property(t => t.LoadingVehicle).HasColumnName("LoadingVehicle");
            this.Property(t => t.ManCarry).HasColumnName("ManCarry");
            this.Property(t => t.Cost).HasColumnName("Cost");
            this.Property(t => t.ItemCritLevel).HasColumnName("ItemCritLevel");
            this.Property(t => t.IsMaster).HasColumnName("IsMaster");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");
            this.Property(t => t.RequiredManpower).HasColumnName("RequiredManpower");

            // Relationships
            this.HasRequired(t => t.Category)
                .WithMany(t => t.Item)
                .HasForeignKey(d => d.CategoryId);
            this.HasOptional(t => t.AreaUom)
                .WithMany(t => t.ItemAreaUom)
                .HasForeignKey(d => d.AreaUomId);
            this.HasOptional(t => t.CapacityUom)
                .WithMany(t => t.ItemCapacityUom)
                .HasForeignKey(d => d.CapacityUomId);
            this.HasRequired(t => t.ItemUom)
                .WithMany(t => t.ItemItemUom)
                .HasForeignKey(d => d.ItemUomId);
            this.HasOptional(t => t.MaterialType)
                .WithMany(t => t.Item)
                .HasForeignKey(d => d.MaterialTypeId);
            this.HasOptional(t => t.VolumeUom)
                .WithMany(t => t.ItemVolumeUom)
                .HasForeignKey(d => d.VolumeUomId);
            this.HasOptional(t => t.WeightUom)
                .WithMany(t => t.ItemWeightUom)
                .HasForeignKey(d => d.WeightUomId);

        }
    }
}
