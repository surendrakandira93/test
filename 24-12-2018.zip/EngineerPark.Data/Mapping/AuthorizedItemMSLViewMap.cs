using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data.Mapping
{
    public class AuthorizedItemMSLViewMap : EntityTypeConfiguration<AuthorizedItemMSLView>
    {
        public AuthorizedItemMSLViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreStockItemAuthorityId, t.AuthorizedOrganiztionId, t.GroupItemId, t.ItemName, t.ItemId, t.PartHeldQuantity, t.Criticality });

            // Properties
            this.Property(t => t.AuthorizedOrganiztionId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.OrganizationName)
                .HasMaxLength(100);

            this.Property(t => t.ItemName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PartName)
                .HasMaxLength(100);

            this.Property(t => t.PartHeldQuantity)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Criticality)
                .IsRequired()
                .HasMaxLength(25);

            // Table & Column Mappings
            this.ToTable("AuthorizedItemMSLView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.StoreStockItemAuthorityId).HasColumnName("StoreStockItemAuthorityId");
            this.Property(t => t.AuthorizedOrganiztionId).HasColumnName("AuthorizedOrganiztionId");
            this.Property(t => t.OrganizationName).HasColumnName("OrganizationName");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemName).HasColumnName("ItemName");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.PartName).HasColumnName("PartName");
            this.Property(t => t.AuthQuantity).HasColumnName("AuthQuantity");
            this.Property(t => t.PartHeldQuantity).HasColumnName("PartHeldQuantity");
            this.Property(t => t.MinimumStockLevelPercent).HasColumnName("MinimumStockLevelPercent");
            this.Property(t => t.PartHeldInPercent).HasColumnName("PartHeldInPercent");
            this.Property(t => t.Criticality).HasColumnName("Criticality");
        }
    }
}
