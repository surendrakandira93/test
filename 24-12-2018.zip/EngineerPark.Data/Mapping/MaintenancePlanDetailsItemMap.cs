using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class MaintenancePlanDetailsItemMap : EntityTypeConfiguration<MaintenancePlanDetailsItem>
    {
        public MaintenancePlanDetailsItemMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("MaintenancePlanDetailsItem");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.MaintenancePlanDetailsGroupItemId).HasColumnName("MaintenancePlanDetailsGroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Item)
                .WithMany(t => t.MaintenancePlanDetailsItem)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemSetNumber)
                .WithMany(t => t.MaintenancePlanDetailsItem)
                .HasForeignKey(d => d.ItemSetNumberId);
            this.HasRequired(t => t.MaintenancePlanDetailsGroupItem)
                .WithMany(t => t.MaintenancePlanDetailsItem)
                .HasForeignKey(d => d.MaintenancePlanDetailsGroupItemId);
            this.HasRequired(t => t.StockShed)
                .WithMany(t => t.MaintenancePlanDetailsItem)
                .HasForeignKey(d => d.StockShedId);

        }
    }
}
