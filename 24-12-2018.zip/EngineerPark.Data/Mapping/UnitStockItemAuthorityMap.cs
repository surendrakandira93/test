using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class UnitStockItemAuthorityMap : EntityTypeConfiguration<UnitStockItemAuthority>
    {
        public UnitStockItemAuthorityMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("UnitStockItemAuthority", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.AuthorizedOrganiztionId).HasColumnName("AuthorizedOrganiztionId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemBasicCategoryId).HasColumnName("ItemBasicCategoryId");
            this.Property(t => t.ItemEquipmentTypeId).HasColumnName("ItemEquipmentTypeId");
            this.Property(t => t.ItemEquipmentId).HasColumnName("ItemEquipmentId");
            this.Property(t => t.AuthorizedQuantiy).HasColumnName("AuthorizedQuantiy");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Item)
                .WithMany(t => t.UnitStockItemAuthority)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemBasicCategory)
                .WithMany(t => t.UnitStockItemAuthority)
                .HasForeignKey(d => d.ItemBasicCategoryId);
            this.HasRequired(t => t.ItemEquipment)
                .WithMany(t => t.UnitStockItemAuthority)
                .HasForeignKey(d => d.ItemEquipmentId);
            this.HasOptional(t => t.ItemEquipmentType)
                .WithMany(t => t.UnitStockItemAuthority)
                .HasForeignKey(d => d.ItemEquipmentTypeId);
            this.HasRequired(t => t.AuthorizedOrganiztion)
                .WithMany(t => t.UnitStockItemAuthorityAuthorizedOrganiztion)
                .HasForeignKey(d => d.AuthorizedOrganiztionId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.UnitStockItemAuthorityUnit)
                .HasForeignKey(d => d.UnitId);

        }
    }
}
