using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ConveningOrderItemSurveyMainMap : EntityTypeConfiguration<ConveningOrderItemSurveyMain>
    {
        public ConveningOrderItemSurveyMainMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.FileName)
                .HasMaxLength(500);

            this.Property(t => t.ApprovedRemark)
                .HasMaxLength(100);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ConveningOrderItemSurveyMain", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ConveningOrderId).HasColumnName("ConveningOrderId");
            this.Property(t => t.IsVerified).HasColumnName("IsVerified");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.FileName).HasColumnName("FileName");
            this.Property(t => t.ApprovedRemark).HasColumnName("ApprovedRemark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.ConveningOrder)
                .WithMany(t => t.ConveningOrderItemSurveyMain)
                .HasForeignKey(d => d.ConveningOrderId);

        }
    }
}
