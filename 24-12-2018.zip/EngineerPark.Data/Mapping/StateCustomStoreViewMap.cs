using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StateCustomStoreViewMap : EntityTypeConfiguration<StateCustomStoreView>
    {
        public StateCustomStoreViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreId, t.GroupItemId, t.ItemName, t.ItemId, t.PartName, t.MaterialType, t.EP, t.CatPtNo, t.AU });

            // Properties
            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ItemName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PartName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.MaterialType)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.EP)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.CatPtNo)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.AU)
                .IsRequired()
                .HasMaxLength(60);

            // Table & Column Mappings
            this.ToTable("StateCustomStoreView");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemName).HasColumnName("ItemName");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.PartName).HasColumnName("PartName");
            this.Property(t => t.MaterialType).HasColumnName("MaterialType");
            this.Property(t => t.EP).HasColumnName("EP");
            this.Property(t => t.CatPtNo).HasColumnName("CatPtNo");
            this.Property(t => t.AU).HasColumnName("AU");
            this.Property(t => t.Serviceable).HasColumnName("Serviceable");
            this.Property(t => t.Repairable).HasColumnName("Repairable");
            this.Property(t => t.Salvage).HasColumnName("Salvage");
            this.Property(t => t.Issue).HasColumnName("Issue");
            this.Property(t => t.Deposit).HasColumnName("Deposit");
            this.Property(t => t.Authorized).HasColumnName("Authorized");
            this.Property(t => t.Held).HasColumnName("Held");
        }
    }
}
