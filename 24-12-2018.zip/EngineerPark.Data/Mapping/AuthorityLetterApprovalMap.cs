using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;

namespace EngineerPark.Data.Mapping
{
    public class AuthorityLetterApprovalMap : EntityTypeConfiguration<AuthorityLetterApproval>
    {
        public AuthorityLetterApprovalMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("AuthorityLetterApproval", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.AuthorityLetterId).HasColumnName("AuthorityLetterId");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.ApprovedDate).HasColumnName("ApprovedDate");
            this.Property(t => t.FromOrganizationId).HasColumnName("FromOrganizationId");
            this.Property(t => t.FromDesignationId).HasColumnName("FromDesignationId");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.Note).HasColumnName("Note");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.FromDesignation)
                .WithMany(t => t.AuthorityLetterApprovalFromDesignation)
                .HasForeignKey(d => d.FromDesignationId);
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.AuthorityLetterApprovalToDesignation)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.FromOrganization)
                .WithMany(t => t.AuthorityLetterApprovalFromOrganization)
                .HasForeignKey(d => d.FromOrganizationId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.AuthorityLetterApprovalToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.AuthorityLetter)
                .WithMany(t => t.AuthorityLetterApproval)
                .HasForeignKey(d => d.AuthorityLetterId);

        }
    }
}
