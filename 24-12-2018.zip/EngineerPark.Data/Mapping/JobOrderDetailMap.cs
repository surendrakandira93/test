using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class JobOrderDetailMap : EntityTypeConfiguration<JobOrderDetail>
    {
        public JobOrderDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("JobOrderDetail");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.JobOrderId).HasColumnName("JobOrderId");
            this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            this.Property(t => t.Quantity).HasColumnName("Quantity");
            this.Property(t => t.Amount).HasColumnName("Amount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Category)
                .WithMany(t => t.JobOrderDetail)
                .HasForeignKey(d => d.CategoryId);
            this.HasRequired(t => t.JobOrder)
                .WithMany(t => t.JobOrderDetail)
                .HasForeignKey(d => d.JobOrderId);

        }
    }
}
