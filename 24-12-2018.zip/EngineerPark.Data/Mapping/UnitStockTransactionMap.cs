using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class UnitStockTransactionMap : EntityTypeConfiguration<UnitStockTransaction>
    {
        public UnitStockTransactionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.PrimaryLedgerNo)
                .HasMaxLength(15);

            this.Property(t => t.SecondaryLedgerNo)
                .HasMaxLength(15);

            this.Property(t => t.PageNo)
                .HasMaxLength(15);

            this.Property(t => t.SetNo)
                .IsRequired()
                .HasMaxLength(10);

            this.Property(t => t.LotNo)
                .HasMaxLength(15);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("UnitStockTransaction", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.UnitStockId).HasColumnName("UnitStockId");
            this.Property(t => t.PrimaryLedgerNo).HasColumnName("PrimaryLedgerNo");
            this.Property(t => t.SecondaryLedgerNo).HasColumnName("SecondaryLedgerNo");
            this.Property(t => t.PageNo).HasColumnName("PageNo");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemBasicCategoryId).HasColumnName("ItemBasicCategoryId");
            this.Property(t => t.ItemEquipmentTypeId).HasColumnName("ItemEquipmentTypeId");
            this.Property(t => t.ItemEquipmentId).HasColumnName("ItemEquipmentId");
            this.Property(t => t.OriginId).HasColumnName("OriginId");
            this.Property(t => t.Mfgdate).HasColumnName("MFGDate");
            this.Property(t => t.ExpiryDate).HasColumnName("ExpiryDate");
            this.Property(t => t.SetNo).HasColumnName("SetNo");
            this.Property(t => t.LotNo).HasColumnName("LotNo");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.HeldByOrgnaizationId).HasColumnName("HeldByOrgnaizationId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Item)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemBasicCategory)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.ItemBasicCategoryId);
            this.HasRequired(t => t.ItemEquipment)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.ItemEquipmentId);
            this.HasOptional(t => t.ItemEquipmentType)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.ItemEquipmentTypeId);
            this.HasOptional(t => t.HeldByOrgnaization)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.HeldByOrgnaizationId);
            this.HasOptional(t => t.Origin)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.OriginId);
            this.HasOptional(t => t.StockShed)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.StockShedId);
            this.HasRequired(t => t.UnitStock)
                .WithMany(t => t.UnitStockTransaction)
                .HasForeignKey(d => d.UnitStockId);

        }
    }
}
