using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class QuarterlyMaintenancePlanMap : EntityTypeConfiguration<QuarterlyMaintenancePlan>
    {
        public QuarterlyMaintenancePlanMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("QuarterlyMaintenancePlan");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.MaintenancePlanId).HasColumnName("MaintenancePlanId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.QuarterId).HasColumnName("QuarterId");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.QuarterlyMaintenancePlan)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.MaintenancePlan)
                .WithMany(t => t.QuarterlyMaintenancePlan)
                .HasForeignKey(d => d.MaintenancePlanId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.QuarterlyMaintenancePlanToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.QuarterlyMaintenancePlanStore)
                .HasForeignKey(d => d.StoreId);

        }
    }
}
