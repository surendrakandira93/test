using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class MaintenanceSchedulePlanMap : EntityTypeConfiguration<MaintenanceSchedulePlan>
    {
        public MaintenanceSchedulePlanMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Remark)
                .HasMaxLength(500);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("MaintenanceSchedulePlan");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.MaintenancePlanDetailsId).HasColumnName("MaintenancePlanDetailId");
            this.Property(t => t.Qtr1qty).HasColumnName("QTR1Qty");
            this.Property(t => t.Qtr2qty).HasColumnName("QTR2Qty");
            this.Property(t => t.Qtr3qty).HasColumnName("QTR3Qty");
            this.Property(t => t.Qtr4qty).HasColumnName("QTR4Qty");
            this.Property(t => t.Cpmamount).HasColumnName("CPMAmount");
            this.Property(t => t.RepairAmount).HasColumnName("RepairAmount");
            this.Property(t => t.Contingency).HasColumnName("Contingency");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.IsVerified).HasColumnName("IsVerified");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.MaintenancePlanDetail)
                .WithMany(t => t.MaintenanceSchedulePlan)
                .HasForeignKey(d => d.MaintenancePlanDetailsId);

        }
    }
}
