using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class JobOrderApprovalMap : EntityTypeConfiguration<JobOrderApproval>
    {
        public JobOrderApprovalMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("JobOrderApproval");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.JobOrderId).HasColumnName("JobOrderId");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.ApprovedDate).HasColumnName("ApprovedDate");
            this.Property(t => t.FromOrganizationId).HasColumnName("FromOrganizationId");
            this.Property(t => t.FromDesignationId).HasColumnName("FromDesignationId");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.Note).HasColumnName("Note");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.JobOrderApprovalToDesignation)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.FromDesignation)
                .WithMany(t => t.JobOrderApprovalFromDesignation)
                .HasForeignKey(d => d.FromDesignationId);
            this.HasRequired(t => t.JobOrder)
                .WithMany(t => t.JobOrderApproval)
                .HasForeignKey(d => d.JobOrderId);
            this.HasRequired(t => t.FromOrganization)
                .WithMany(t => t.JobOrderApprovalFromOrganization)
                .HasForeignKey(d => d.FromOrganizationId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.JobOrderApprovalToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);

        }
    }
}
