using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanIssueVoucherDetailMap : EntityTypeConfiguration<LoanIssueVoucherDetail>
    {
        public LoanIssueVoucherDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("LoanIssueVoucherDetail", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.LoanIssueVoucherId).HasColumnName("LoanIssueVoucherId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemBasicCategoryId).HasColumnName("ItemBasicCategoryId");
            this.Property(t => t.ItemEquipmentTypeId).HasColumnName("ItemEquipmentTypeId");
            this.Property(t => t.ItemEquipmentId).HasColumnName("ItemEquipmentId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Item)
                .WithMany(t => t.LoanIssueVoucherDetail)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemBasicCategory)
                .WithMany(t => t.LoanIssueVoucherDetail)
                .HasForeignKey(d => d.ItemBasicCategoryId);
            this.HasRequired(t => t.ItemEquipment)
                .WithMany(t => t.LoanIssueVoucherDetail)
                .HasForeignKey(d => d.ItemEquipmentId);
            this.HasOptional(t => t.ItemEquipmentType)
                .WithMany(t => t.LoanIssueVoucherDetail)
                .HasForeignKey(d => d.ItemEquipmentTypeId);
            this.HasRequired(t => t.LoanIssueVoucher)
                .WithMany(t => t.LoanIssueVoucherDetail)
                .HasForeignKey(d => d.LoanIssueVoucherId);

        }
    }
}
