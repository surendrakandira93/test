using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StoreStockTransactionSetNoMap : EntityTypeConfiguration<StoreStockTransactionSetNo>
    {
        public StoreStockTransactionSetNoMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.SetNo)
                .IsRequired()
                .HasMaxLength(11);

            this.Property(t => t.PrimaryLedgerNo)
                .HasMaxLength(15);

            this.Property(t => t.SecondaryLedgerNo)
                .HasMaxLength(15);

            this.Property(t => t.PageNo)
                .HasMaxLength(15);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("StoreStockTransactionSetNo", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.StoreStockId).HasColumnName("StoreStockId");
            this.Property(t => t.SetNo).HasColumnName("SetNo");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemUomId).HasColumnName("ItemUomId");
            this.Property(t => t.PrimaryLedgerNo).HasColumnName("PrimaryLedgerNo");
            this.Property(t => t.SecondaryLedgerNo).HasColumnName("SecondaryLedgerNo");
            this.Property(t => t.PageNo).HasColumnName("PageNo");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.OriginId).HasColumnName("OriginId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Mfgdate).HasColumnName("MFGDate");
            this.Property(t => t.ExpiryDate).HasColumnName("ExpiryDate");
            this.Property(t => t.HeldByOrgnaizationId).HasColumnName("HeldByOrgnaizationId");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.GroupItem)
                .WithMany(t => t.StoreStockTransactionSetNo)
                .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.Item)
                .WithMany(t => t.StoreStockTransactionSetNo)
                .HasForeignKey(d => d.ItemId);
            this.HasOptional(t => t.Origin)
                .WithMany(t => t.StoreStockTransactionSetNo)
                .HasForeignKey(d => d.OriginId);
            this.HasOptional(t => t.StockShed)
                .WithMany(t => t.StoreStockTransactionSetNo)
                .HasForeignKey(d => d.StockShedId);
            this.HasRequired(t => t.ItemUom)
                .WithMany(t => t.StoreStockTransactionSetNo)
                .HasForeignKey(d => d.ItemUomId);

        }
    }
}
