using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanRenewalDetailMap : EntityTypeConfiguration<LoanRenewalDetail>
    {
        public LoanRenewalDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            // Table & Column Mappings
            this.ToTable("LoanRenewalDetail");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.LoanRenewalId).HasColumnName("LoanRenewalId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemBasicCategoryId).HasColumnName("ItemBasicCategoryId");
            this.Property(t => t.ItemEquipmentTypeId).HasColumnName("ItemEquipmentTypeId");
            this.Property(t => t.ItemEquipmentId).HasColumnName("ItemEquipmentId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
            this.Property(t => t.Quantity).HasColumnName("Quantity");
            this.Property(t => t.LoanPeriodInMonth).HasColumnName("LoanPeriodInMonth");
            //this.Property(t => t.Reason).HasColumnName("Reason");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");

            // Relationships
            this.HasOptional(t => t.GroupItem)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.Item)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemBasicCategory)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.ItemBasicCategoryId);
            this.HasRequired(t => t.ItemEquipment)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.ItemEquipmentId);
            this.HasOptional(t => t.ItemEquipmentType)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.ItemEquipmentTypeId);
            this.HasRequired(t => t.ItemSetNumber)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.ItemSetNumberId);
            this.HasRequired(t => t.LoanRenewal)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.LoanRenewalId);
            this.HasOptional(t => t.StockShed)
                .WithMany(t => t.LoanRenewalDetail)
                .HasForeignKey(d => d.StockShedId);

        }
    }
}
