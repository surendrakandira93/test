using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StateCustomLoanProcessViewMap : EntityTypeConfiguration<StateCustomLoanProcessView>
    {
        public StateCustomLoanProcessViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreId, t.IssueDate });

            // Properties
            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Unit)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("StateCustomLoanProcessView");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.Unit).HasColumnName("Unit");
            this.Property(t => t.IssueDate).HasColumnName("IssueDate");
            this.Property(t => t.DueDate).HasColumnName("DueDate");
            this.Property(t => t.LoanPeriod).HasColumnName("LoanPeriod");
            this.Property(t => t.DepositDate).HasColumnName("DepositDate");
        }
    }
}
