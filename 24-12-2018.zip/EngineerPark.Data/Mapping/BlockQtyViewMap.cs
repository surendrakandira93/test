using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class BlockQtyViewMap : EntityTypeConfiguration<BlockQtyView>
    {
        public BlockQtyViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreId, t.BlockQty });

            // Properties
            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.GroupName)
                .HasMaxLength(100);

            this.Property(t => t.BlockQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("BlockQtyView", "Main");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.GroupName).HasColumnName("GroupName");
            this.Property(t => t.BasiccatId).HasColumnName("BasiccatId");
            this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            this.Property(t => t.ItemUomId).HasColumnName("ItemUomId");
            this.Property(t => t.BlockQty).HasColumnName("BlockQty");
            this.Property(t => t.BlockQty1).HasColumnName("BlockQty1");
        }
    }
}
