using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class CategoryViewMap : EntityTypeConfiguration<CategoryView>
    {
        public CategoryViewMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.CatName)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("CategoryView", "Main");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.CatName).HasColumnName("CatName");
        }
    }
}
