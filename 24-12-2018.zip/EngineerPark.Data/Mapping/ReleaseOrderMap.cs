using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ReleaseOrderMap : EntityTypeConfiguration<ReleaseOrder>
    {
        public ReleaseOrderMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.ReleaseOrderNo)
                .IsRequired()
                .HasMaxLength(11);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ReleaseOrder", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.LoanRequestId).HasColumnName("LoanRequestId");
            this.Property(t => t.YearId).HasColumnName("YearId");
            this.Property(t => t.ReleaseOrderNo).HasColumnName("ReleaseOrderNo");
            this.Property(t => t.ReleaseDate).HasColumnName("ReleaseDate");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.StatusId).HasColumnName("StatusId");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.IsDeleted).HasColumnName("IsDeleted");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Store)
                .WithMany(t => t.ReleaseOrderStore)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.ReleaseOrderUnit)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.Status)
                .WithMany(t => t.ReleaseOrder)
                .HasForeignKey(d => d.StatusId);
            this.HasRequired(t => t.LoanRequest)
                .WithMany(t => t.ReleaseOrder)
                .HasForeignKey(d => d.LoanRequestId);

        }
    }
}
