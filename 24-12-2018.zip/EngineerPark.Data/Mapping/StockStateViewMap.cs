using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StockStateViewMap : EntityTypeConfiguration<StockStateView>
    {
        public StockStateViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreStockItemAuthorityId, t.AuthorizedOrganiztionId, t.GroupItemId, t.ItemName, t.OnLoanQty, t.UnderRep, t.ComitOnGround, t.RelCollected, t.NetSerQty, t.Remark });

            // Properties
            this.Property(t => t.AuthorizedOrganiztionId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.OrganizationName)
                .HasMaxLength(100);

            this.Property(t => t.ItemName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.OnLoanQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.UnderRep)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ComitOnGround)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.RelCollected)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.NetSerQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Remark)
                .IsRequired()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("StockStateView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.StoreStockItemAuthorityId).HasColumnName("StoreStockItemAuthorityId");
            this.Property(t => t.AuthorizedOrganiztionId).HasColumnName("AuthorizedOrganiztionId");
            this.Property(t => t.OrganizationName).HasColumnName("OrganizationName");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemName).HasColumnName("ItemName");
            this.Property(t => t.AuthQuantity).HasColumnName("AuthQuantity");
            this.Property(t => t.PartHeldQuantity).HasColumnName("PartHeldQuantity");
            this.Property(t => t.OnLoanQty).HasColumnName("OnLoanQty");
            this.Property(t => t.UnderRep).HasColumnName("UnderRep");
            this.Property(t => t.ComitOnGround).HasColumnName("ComitOnGround");
            this.Property(t => t.RelCollected).HasColumnName("RelCollected");
            this.Property(t => t.NetSerQty).HasColumnName("NetSerQty");
            this.Property(t => t.Remark).HasColumnName("Remark");
        }
    }
}
