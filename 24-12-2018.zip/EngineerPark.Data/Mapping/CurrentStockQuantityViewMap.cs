using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class CurrentStockQuantityViewMap : EntityTypeConfiguration<CurrentStockQuantityView>
    {
        public CurrentStockQuantityViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ItemId, t.StoreId });

            // Properties
            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("CurrentStockQuantityView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.currentQuantity).HasColumnName("currentQuantity");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
        }
    }
}
