using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ConveyNoteDetailMap : EntityTypeConfiguration<ConveyNoteDetail>
    {
        public ConveyNoteDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ConveyNoteDetail", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ConveyNoteId).HasColumnName("ConveyNoteId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.ItemBasicCategoryId).HasColumnName("ItemBasicCategoryId");
            this.Property(t => t.ItemEquipmentTypeId).HasColumnName("ItemEquipmentTypeId");
            this.Property(t => t.ItemEquipmentId).HasColumnName("ItemEquipmentId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
            this.Property(t => t.Quantiy).HasColumnName("Quantiy");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.GroupItem)
               .WithMany(t => t.ConveyNoteDetail)
               .HasForeignKey(d => d.GroupItemId);
            this.HasRequired(t => t.Item)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ItemId);
            this.HasRequired(t => t.ItemBasicCategory)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ItemBasicCategoryId);
            this.HasRequired(t => t.ItemEquipment)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ItemEquipmentId);
            this.HasOptional(t => t.ItemEquipmentType)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ItemEquipmentTypeId);
            this.HasRequired(t => t.ItemSetNumber)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ItemSetNumberId);
            this.HasOptional(t => t.StockShed)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.StockShedId);
            this.HasRequired(t => t.ConveyNote)
                .WithMany(t => t.ConveyNoteDetail)
                .HasForeignKey(d => d.ConveyNoteId);

        }
    }
}
