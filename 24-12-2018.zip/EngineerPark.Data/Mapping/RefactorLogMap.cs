using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class RefactorLogMap : EntityTypeConfiguration<RefactorLog>
    {
        public RefactorLogMap()
        {
            // Primary Key
            this.HasKey(t => t.ScriptNo);

            // Properties
            this.Property(t => t.ScriptNo)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("RefactorLog");
            this.Property(t => t.ScriptNo).HasColumnName("ScriptNo");
        }
    }
}
