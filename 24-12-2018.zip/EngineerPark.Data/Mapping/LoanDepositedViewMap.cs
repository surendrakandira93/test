using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanDepositedViewMap : EntityTypeConfiguration<LoanDepositedView>
    {
        public LoanDepositedViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.D_UnitId, t.D_Permt, t.D_Temp, t.D_LoanExpPeriod, t.D_PresentStatus });

            // Properties
            this.Property(t => t.Numencluture)
                .HasMaxLength(100);

            this.Property(t => t.D_AU)
                .HasMaxLength(60);

            this.Property(t => t.D_UnitId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_FirstName)
                .HasMaxLength(50);

            this.Property(t => t.D_Unit)
                .HasMaxLength(100);

            this.Property(t => t.D_Fmn)
                .HasMaxLength(100);

            this.Property(t => t.D_Authority)
                .HasMaxLength(200);

            this.Property(t => t.D_Permt)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_Temp)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_LoanExpPeriod)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.D_PresentStatus)
                .IsRequired()
                .HasMaxLength(9);

            // Table & Column Mappings
            this.ToTable("LoanDepositedView", "Main");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GID).HasColumnName("GID");
            this.Property(t => t.Numencluture).HasColumnName("Numencluture");
            this.Property(t => t.D_AU).HasColumnName("D_AU");
            this.Property(t => t.D_BasiccatId).HasColumnName("D_BasiccatId");
            this.Property(t => t.D_CategoryId).HasColumnName("D_CategoryId");
            this.Property(t => t.D_LoanQty).HasColumnName("D_LoanQty");
            this.Property(t => t.D_UnitId).HasColumnName("D_UnitId");
            this.Property(t => t.D_FirstName).HasColumnName("D_FirstName");
            this.Property(t => t.D_Unit).HasColumnName("D_Unit");
            this.Property(t => t.D_Fmn).HasColumnName("D_Fmn");
            this.Property(t => t.D_Authority).HasColumnName("D_Authority");
            this.Property(t => t.D_Permt).HasColumnName("D_Permt");
            this.Property(t => t.D_Temp).HasColumnName("D_Temp");
            this.Property(t => t.D_LoanExpPeriod).HasColumnName("D_LoanExpPeriod");
            this.Property(t => t.D_PresentStatus).HasColumnName("D_PresentStatus");
        }
    }
}
