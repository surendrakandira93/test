using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ConveningOrderMemberMap : EntityTypeConfiguration<ConveningOrderMember>
    {
        public ConveningOrderMemberMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.MemberCode)
                .HasMaxLength(11);

            this.Property(t => t.MemberName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Fmnaddress)
                .HasMaxLength(150);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ConveningOrderMember", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ConveningOrderId).HasColumnName("ConveningOrderId");
            this.Property(t => t.MemberCode).HasColumnName("MemberCode");
            this.Property(t => t.MemberName).HasColumnName("MemberName");
            this.Property(t => t.MemberId).HasColumnName("MemberId");
            this.Property(t => t.IsPresidingOfficer).HasColumnName("IsPresidingOfficer");
            this.Property(t => t.Fmnaddress).HasColumnName("FMNAddress");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.Member)
                .WithMany(t => t.ConveningOrderMember)
                .HasForeignKey(d => d.MemberId);
            this.HasRequired(t => t.ConveningOrder)
                .WithMany(t => t.ConveningOrderMember)
                .HasForeignKey(d => d.ConveningOrderId);

        }
    }
}
