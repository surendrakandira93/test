using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class BlockQuantitySetWiseViewMap : EntityTypeConfiguration<BlockQuantitySetWiseView>
    {
        public BlockQuantitySetWiseViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ItemId, t.ItemSetNumberId });

            

            this.Property(t => t.PartName)
                .HasMaxLength(100);

            this.Property(t => t.ItemSetNumberId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("BlockQuantitySetWiseView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");            
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.BlockQuantity).HasColumnName("BlockQuantity");
            this.Property(t => t.PartName).HasColumnName("PartName");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.StockShedId).HasColumnName("StockShedId");
            this.Property(t => t.ItemSetNumberId).HasColumnName("ItemSetNumberId");
        }
    }
}
