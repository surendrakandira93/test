using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StateCustomLoanExtensionViewMap : EntityTypeConfiguration<StateCustomLoanExtensionView>
    {
        public StateCustomLoanExtensionViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.StoreId, t.Unit, t.IssueDate, t.DueDate });

            // Properties
            this.Property(t => t.StoreId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Unit)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("StateCustomLoanExtensionView");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.ItemId).HasColumnName("ItemId");
            this.Property(t => t.Unit).HasColumnName("Unit");
            this.Property(t => t.IssueDate).HasColumnName("IssueDate");
            this.Property(t => t.DueDate).HasColumnName("DueDate");
            this.Property(t => t.LoanPeriod).HasColumnName("LoanPeriod");
            this.Property(t => t.DepositDate).HasColumnName("DepositDate");
        }
    }
}
