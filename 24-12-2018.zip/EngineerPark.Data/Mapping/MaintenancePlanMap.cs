using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class MaintenancePlanMap : EntityTypeConfiguration<MaintenancePlan>
    {
        public MaintenancePlanMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("MaintenancePlan");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.PlanType).HasColumnName("PlanType");
            this.Property(t => t.Year).HasColumnName("Year");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");
            this.Property(t => t.IsVerified).HasColumnName("IsVerified");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.MaintenancePlan)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.MaintenancePlanStore)
                .HasForeignKey(d => d.StoreId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.MaintenancePlanToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);

        }
    }
}
