using EngineerPark.Data.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace EngineerPark.Data.Mapping
{
    public class BDOfficerMap : EntityTypeConfiguration<Bdofficer>
    {
        public BDOfficerMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Rank)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Name)
                .HasMaxLength(50);

            this.Property(t => t.Remark)
                .HasMaxLength(50);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("BDOfficer", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.AstbconveningOrderId).HasColumnName("ASTBConveningOrderId");
            this.Property(t => t.Rank).HasColumnName("Rank");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.OrganizationId).HasColumnName("OrganizationId");
            this.Property(t => t.DesignationId).HasColumnName("DesignationId");
            this.Property(t => t.MemberTypeId).HasColumnName("MemberTypeId");
            this.Property(t => t.IsView).HasColumnName("IsView");
            this.Property(t => t.ViewDate).HasColumnName("ViewDate");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Designation)
                .WithMany(t => t.Bdofficer)
                .HasForeignKey(d => d.DesignationId);
            this.HasRequired(t => t.Organization)
                .WithMany(t => t.Bdofficer)
                .HasForeignKey(d => d.OrganizationId);
            this.HasRequired(t => t.CreatedByNavigation)
                .WithMany(t => t.BdofficerCreatedByNavigation)
                .HasForeignKey(d => d.CreatedBy);
            this.HasRequired(t => t.UpdatedByNavigation)
                .WithMany(t => t.BdofficerUpdatedByNavigation)
                .HasForeignKey(d => d.UpdatedBy);
            this.HasRequired(t => t.AstbconveningOrder)
                .WithMany(t => t.Bdofficer)
                .HasForeignKey(d => d.AstbconveningOrderId);

        }
    }
}
