using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanIssueVoucherMap : EntityTypeConfiguration<LoanIssueVoucher>
    {
        public LoanIssueVoucherMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.VoucherNo)
                .IsRequired()
                .HasMaxLength(11);

            this.Property(t => t.Remark)
                .HasMaxLength(200);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("LoanIssueVoucher", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.YearId).HasColumnName("YearId");
            this.Property(t => t.ReleaseOrderId).HasColumnName("ReleaseOrderId");
            this.Property(t => t.VoucherNo).HasColumnName("VoucherNo");
            this.Property(t => t.VoucherDate).HasColumnName("VoucherDate");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.IssuedBy).HasColumnName("IssuedBy");
            this.Property(t => t.IsCancelled).HasColumnName("IsCancelled");
            this.Property(t => t.IsDeleted).HasColumnName("IsDeleted");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Store)
                .WithMany(t => t.LoanIssueVoucher)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.ReleaseOrder)
                .WithMany(t => t.LoanIssueVoucher)
                .HasForeignKey(d => d.ReleaseOrderId);

        }
    }
}
