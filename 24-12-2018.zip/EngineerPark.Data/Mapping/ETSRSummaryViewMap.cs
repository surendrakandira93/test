using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data.Mapping
{
    public class ETSRSummaryViewMap : EntityTypeConfiguration<ETSRSummeryView>
    {
        public ETSRSummaryViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.Id, t.Held, t.RepQty, t.SerQty, t.Salvage, t.Remark });

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Items)
                .HasMaxLength(100);

            this.Property(t => t.Held)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.RepQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.SerQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Salvage)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Remark)
                .IsRequired()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("ETSRSummaryView", "Main");
            this.Property(t => t.Id).HasColumnName("ID");
            this.Property(t => t.Items).HasColumnName("Items");
            this.Property(t => t.Held).HasColumnName("Held");
            this.Property(t => t.RepQty).HasColumnName("RepQty");
            this.Property(t => t.SerQty).HasColumnName("SerQty");
            this.Property(t => t.Salvage).HasColumnName("Salvage");
            this.Property(t => t.Remark).HasColumnName("Remark");
        }
    }
}
