using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data.Mapping
{
    public class LoanStateViewMap : EntityTypeConfiguration<LoanStateView>
    {
        public LoanStateViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ND_Unit, t.ND_Fmn, t.ND_LoanQty, t.ND_Authority, t.ND_Permt, t.ND_Temp, t.ND_LoanExpPeriod, t.ND_PresentStatus, t.D_Unit, t.D_Fmn, t.D_LoanQty, t.D_Authority, t.D_Permt, t.D_Temp, t.D_LoanExpPeriod, t.D_PresentStatus, t.TotQtyOnLoan });

            // Properties
            this.Property(t => t.Numencluture)
                .HasMaxLength(100);

            this.Property(t => t.ND_AU)
                .HasMaxLength(60);

            this.Property(t => t.ND_Unit)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.ND_Fmn)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.ND_LoanQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_Authority)
                .IsRequired()
                .HasMaxLength(200);

            this.Property(t => t.ND_Permt)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_Temp)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ND_LoanExpPeriod)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.ND_PresentStatus)
                .IsRequired()
                .HasMaxLength(13);

            this.Property(t => t.D_Unit)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.D_Fmn)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.D_LoanQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_Authority)
                .IsRequired()
                .HasMaxLength(200);

            this.Property(t => t.D_Permt)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_Temp)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.D_LoanExpPeriod)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.D_PresentStatus)
                .IsRequired()
                .HasMaxLength(9);

            this.Property(t => t.TotQtyOnLoan)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("LoanStateView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.GID).HasColumnName("GID");
            this.Property(t => t.Numencluture).HasColumnName("Numencluture");
            this.Property(t => t.ND_AU).HasColumnName("ND_AU");
            this.Property(t => t.ND_CategoryId).HasColumnName("ND_CategoryId");
            this.Property(t => t.ND_BasiccatId).HasColumnName("ND_BasiccatId");
            this.Property(t => t.ND_Unit).HasColumnName("ND_Unit");
            this.Property(t => t.ND_Fmn).HasColumnName("ND_Fmn");
            this.Property(t => t.ND_LoanQty).HasColumnName("ND_LoanQty");
            this.Property(t => t.ND_Authority).HasColumnName("ND_Authority");
            this.Property(t => t.ND_Permt).HasColumnName("ND_Permt");
            this.Property(t => t.ND_Temp).HasColumnName("ND_Temp");
            this.Property(t => t.ND_LoanExpPeriod).HasColumnName("ND_LoanExpPeriod");
            this.Property(t => t.ND_PresentStatus).HasColumnName("ND_PresentStatus");
            this.Property(t => t.D_Unit).HasColumnName("D_Unit");
            this.Property(t => t.D_Fmn).HasColumnName("D_Fmn");
            this.Property(t => t.D_LoanQty).HasColumnName("D_LoanQty");
            this.Property(t => t.D_Authority).HasColumnName("D_Authority");
            this.Property(t => t.D_Permt).HasColumnName("D_Permt");
            this.Property(t => t.D_Temp).HasColumnName("D_Temp");
            this.Property(t => t.D_LoanExpPeriod).HasColumnName("D_LoanExpPeriod");
            this.Property(t => t.D_PresentStatus).HasColumnName("D_PresentStatus");
            this.Property(t => t.TotQtyOnLoan).HasColumnName("TotQtyOnLoan");
        }
    }
}
