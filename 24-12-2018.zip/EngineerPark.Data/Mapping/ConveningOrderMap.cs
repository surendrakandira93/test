using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ConveningOrderMap : EntityTypeConfiguration<ConveningOrder>
    {
        public ConveningOrderMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.ConveningOrderNo)
                .IsRequired()
                .HasMaxLength(11);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ConveningOrder", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ReleaseOrderId).HasColumnName("ReleaseOrderId");
            this.Property(t => t.YearId).HasColumnName("YearId");
            this.Property(t => t.ConveningOrderNo).HasColumnName("ConveningOrderNo");
            this.Property(t => t.RequestDate).HasColumnName("RequestDate");
            this.Property(t => t.IssueDate).HasColumnName("IssueDate");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.StatusId).HasColumnName("StatusId");
            this.Property(t => t.ConveningOrderBy).HasColumnName("ConveningOrderBy");
            this.Property(t => t.PresidingOfficerId).HasColumnName("PresidingOfficerId");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.IsDeleted).HasColumnName("IsDeleted");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.ApprovedDesignationId).HasColumnName("ApprovedDesignationId");
            this.Property(t => t.AssignedDesignationId).HasColumnName("AssignedDesignationId");
            this.Property(t => t.Poid).HasColumnName("POId");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.ApprovedDesignation)
                .WithMany(t => t.ConveningOrderApprovedDesignation)
                .HasForeignKey(d => d.ApprovedDesignationId);
            this.HasRequired(t => t.AssignedDesignation)
                .WithMany(t => t.ConveningOrderAssignedDesignation)
                .HasForeignKey(d => d.AssignedDesignationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.ConveningOrderStore)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.ConveningOrderUnit)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.Status)
                .WithMany(t => t.ConveningOrder)
                .HasForeignKey(d => d.StatusId);
            this.HasOptional(t => t.ConveningOrderByNavigation)
                .WithMany(t => t.ConveningOrderConveningOrderByNavigation)
                .HasForeignKey(d => d.ConveningOrderBy);
            this.HasOptional(t => t.Po)
                .WithMany(t => t.ConveningOrderPresidingOfficer)
                .HasForeignKey(d => d.Poid);
            this.HasOptional(t => t.PresidingOfficer)
                .WithMany(t => t.ConveningOrderPresidingOfficer)
                .HasForeignKey(d => d.PresidingOfficerId);
            this.HasRequired(t => t.ReleaseOrder)
                .WithMany(t => t.ConveningOrder)
                .HasForeignKey(d => d.ReleaseOrderId);

        }
    }
}
