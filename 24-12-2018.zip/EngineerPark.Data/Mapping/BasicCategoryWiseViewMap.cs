using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data.Mapping
{
    public class BasicCategoryWiseViewMap : EntityTypeConfiguration<BasicCategoryWiseView>
    {
        public BasicCategoryWiseViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.Id, t.ItemName, t.AuthQty, t.HeldQty, t.OnLoanQty,
                t.UnderRep, t.ComitOnGround, t.RelCollected, t.Remark, t.BasicCatId, t.AU,t.NetSerQty });

            // Properties
            this.Property(t => t.ItemName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.AU)
                .HasMaxLength(60);

            this.Property(t => t.AuthQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.HeldQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.OnLoanQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.UnderRep)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ComitOnGround)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.RelCollected)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Remark)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.BasicCatId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.NetSerQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.BasicCatId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("BasicCategoryWiseView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ItemName).HasColumnName("ItemName");
            this.Property(t => t.AU).HasColumnName("AU");
            this.Property(t => t.AuthQty).HasColumnName("AuthQty");
            this.Property(t => t.HeldQty).HasColumnName("HeldQty");
            this.Property(t => t.OnLoanQty).HasColumnName("OnLoanQty");
            this.Property(t => t.UnderRep).HasColumnName("UnderRep");
            this.Property(t => t.ComitOnGround).HasColumnName("ComitOnGround");
            this.Property(t => t.RelCollected).HasColumnName("RelCollected");
            this.Property(t => t.NetSerQty).HasColumnName("NetSerQty");
            this.Property(t => t.Remark).HasColumnName("Remark");
            //this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            //this.Property(t => t.ItemUomId).HasColumnName("ItemUomId");
            this.Property(t => t.BasicCatId).HasColumnName("BasicCatId");
        }
    }
}
