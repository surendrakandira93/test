using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class DepositQtyViewMap : EntityTypeConfiguration<DepositQtyView>
    {
        public DepositQtyViewMap()
        {
            // Primary Key
            this.HasKey(t => t.GroupItemId);

            // Properties
            this.Property(t => t.Name)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("DepositQtyView", "Main");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.BasiccatId).HasColumnName("BasiccatId");
            this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            this.Property(t => t.DepositQty).HasColumnName("DepositQty");
        }
    }
}
