using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class StoreStockMap : EntityTypeConfiguration<StoreStock>
    {
        public StoreStockMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("StoreStock", "Main");
            this.Property(t => t.RowId).HasColumnName("RowId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.TransactionTypeId).HasColumnName("TransactionTypeId");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.IsStockOut).HasColumnName("IsStockOut");
            this.Property(t => t.TransactionDate).HasColumnName("TransactionDate");
            this.Property(t => t.TransactionRefId).HasColumnName("TransactionRefId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.HeldByOrgnaizationId).HasColumnName("HeldByOrgnaizationId");
            this.Property(t => t.GroupItemBasicCategoryId).HasColumnName("GroupItemBasicCategoryId");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasOptional(t => t.GroupItemBasicCategory)
                .WithMany(t => t.StoreStock)
                .HasForeignKey(d => d.GroupItemBasicCategoryId);
            this.HasRequired(t => t.GroupItem)
                .WithMany(t => t.StoreStock)
                .HasForeignKey(d => d.GroupItemId);
            this.HasOptional(t => t.HeldByOrgnaization)
                .WithMany(t => t.StoreStockHeldByOrgnaization)
                .HasForeignKey(d => d.HeldByOrgnaizationId);
            this.HasRequired(t => t.Store)
                .WithMany(t => t.StoreStockStore)
                .HasForeignKey(d => d.StoreId);
            this.HasRequired(t => t.TransactionType)
                .WithMany(t => t.StoreStock)
                .HasForeignKey(d => d.TransactionTypeId);

        }
    }
}
