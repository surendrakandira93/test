using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models.ReportView;

namespace EngineerPark.Data.Mapping
{
    public class AuthQtyViewMap : EntityTypeConfiguration<auth>
    {
        public AuthQtyViewMap()
        {
            // Primary Key
            this.HasKey(t => new { t.Id, t.ItemName, t.BasicCatId, t.AuthQty, t.ItemUomId, t.CategoryId });

            // Properties
            this.Property(t => t.ItemName)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.BasicCatId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.BasicCatName)
                .HasMaxLength(100);

            this.Property(t => t.AuthQty)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ItemUomId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.AU)
                .HasMaxLength(60);

            this.Property(t => t.CategoryId)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.CatName)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("AuthQtyView", "Main");
            this.Property(t => t.RowNo).HasColumnName("RowNo");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.TypeOfStoreId).HasColumnName("TypeOfStoreId");
            this.Property(t => t.ItemName).HasColumnName("ItemName");
            this.Property(t => t.BasicCatId).HasColumnName("BasicCatId");
            this.Property(t => t.BasicCatName).HasColumnName("BasicCatName");
            this.Property(t => t.AuthQty).HasColumnName("AuthQty");
            this.Property(t => t.ItemUomId).HasColumnName("ItemUomId");
            this.Property(t => t.AU).HasColumnName("AU");
            this.Property(t => t.CategoryId).HasColumnName("CategoryId");
            this.Property(t => t.CatName).HasColumnName("CatName");
        }
    }
}
