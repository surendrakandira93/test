using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class LoanRenewalMap : EntityTypeConfiguration<LoanRenewal>
    {
        public LoanRenewalMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Remark)
                .HasMaxLength(250);

            this.Property(t => t.BdApproveBy)
                .HasMaxLength(250);

            this.Property(t => t.Authority)
                .HasMaxLength(250);

            this.Property(t => t.Justification)
                .HasMaxLength(250);

            // Table & Column Mappings
            this.ToTable("LoanRenewal");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.LoanRenewalDate).HasColumnName("LoanRenewalDate");
            this.Property(t => t.StoreId).HasColumnName("StoreId");
            this.Property(t => t.UnitId).HasColumnName("UnitId");
            this.Property(t => t.ReleaseOrderId).HasColumnName("ReleaseOrderId");
            this.Property(t => t.LoanIssueVoucherId).HasColumnName("LoanIssueVoucherId");
            this.Property(t => t.Remark).HasColumnName("Remark");
            this.Property(t => t.DateFrom).HasColumnName("DateFrom");
            this.Property(t => t.DateTo).HasColumnName("DateTo");
            this.Property(t => t.BdDate).HasColumnName("BdDate");
            this.Property(t => t.BdApproveBy).HasColumnName("BdApproveBy");
            this.Property(t => t.Authority).HasColumnName("Authority");
            this.Property(t => t.Justification).HasColumnName("Justification");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.IsApproved).HasColumnName("IsApproved");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");

            // Relationships
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.LoanRenewal)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.LoanIssueVoucher)
                .WithMany(t => t.LoanRenewal)
                .HasForeignKey(d => d.LoanIssueVoucherId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.LoanRenewalUnit)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.Unit)
                .WithMany(t => t.LoanRenewalUnit)
                .HasForeignKey(d => d.UnitId);
            this.HasRequired(t => t.ReleaseOrder)
                .WithMany(t => t.LoanRenewal)
                .HasForeignKey(d => d.ReleaseOrderId);
            this.HasRequired(t => t.ToOrganization)
                .WithMany(t => t.LoanRenewalStore)
                .HasForeignKey(d => d.StoreId);

        }
    }
}
