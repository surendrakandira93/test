using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class ReportPermissionMap : EntityTypeConfiguration<ReportPermission>
    {
        public ReportPermissionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("ReportPermission");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ReportId).HasColumnName("ReportId");
            this.Property(t => t.RoleId).HasColumnName("RoleId");
            this.Property(t => t.PermissionCount).HasColumnName("PermissionCount");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.Report)
                .WithMany(t => t.ReportPermission)
                .HasForeignKey(d => d.ReportId);
            this.HasRequired(t => t.Role)
                .WithMany(t => t.ReportPermission)
                .HasForeignKey(d => d.RoleId);

        }
    }
}
