using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class TaskWorkFlowMap : EntityTypeConfiguration<TaskWorkFlow>
    {
        public TaskWorkFlowMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.RowVersion)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8)
                .IsRowVersion();

            // Table & Column Mappings
            this.ToTable("TaskWorkFlow");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.TaskId).HasColumnName("TaskId");
            this.Property(t => t.FromOrganizationId).HasColumnName("FromOrganizationId");
            this.Property(t => t.FromDesignationId).HasColumnName("FromDesignationId");
            this.Property(t => t.ToOrganizationId).HasColumnName("ToOrganizationId");
            this.Property(t => t.ToDesignationId).HasColumnName("ToDesignationId");
            this.Property(t => t.IsActive).HasColumnName("IsActive");
            this.Property(t => t.CreatedBy).HasColumnName("CreatedBy");
            this.Property(t => t.CreatedDate).HasColumnName("CreatedDate");
            this.Property(t => t.UpdatedBy).HasColumnName("UpdatedBy");
            this.Property(t => t.UpdatedDate).HasColumnName("UpdatedDate");
            this.Property(t => t.RowVersion).HasColumnName("RowVersion");

            // Relationships
            this.HasRequired(t => t.FromDesignation)
                .WithMany(t => t.TaskWorkFlowFromDesignation)
                .HasForeignKey(d => d.FromDesignationId);
            this.HasOptional(t => t.ToDesignation)
                .WithMany(t => t.TaskWorkFlowToDesignation)
                .HasForeignKey(d => d.ToDesignationId);
            this.HasRequired(t => t.FromOrganization)
                .WithMany(t => t.TaskWorkFlowFromOrganization)
                .HasForeignKey(d => d.FromOrganizationId);
            this.HasOptional(t => t.ToOrganization)
                .WithMany(t => t.TaskWorkFlowToOrganization)
                .HasForeignKey(d => d.ToOrganizationId);
            this.HasRequired(t => t.Task)
                .WithMany(t => t.TaskWorkFlow)
                .HasForeignKey(d => d.TaskId);

        }
    }
}
