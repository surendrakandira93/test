using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class JobOrderTempMap : EntityTypeConfiguration<JobOrderTemp>
    {
        public JobOrderTempMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            // Table & Column Mappings
            this.ToTable("JobOrderTemp");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.JobOrderId).HasColumnName("JobOrderId");
            this.Property(t => t.GroupItemId).HasColumnName("GroupItemId");
            this.Property(t => t.TransactionDate).HasColumnName("TransactionDate");

            // Relationships
            this.HasRequired(t => t.JobOrder)
                .WithMany(t => t.JobOrderTemp)
                .HasForeignKey(d => d.JobOrderId);

        }
    }
}
