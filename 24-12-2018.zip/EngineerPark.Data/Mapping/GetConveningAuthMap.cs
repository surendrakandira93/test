using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using EngineerPark.Data.Models;
namespace EngineerPark.Data.Mapping
{
    public class GetConveningAuthMap : EntityTypeConfiguration<GetConveningAuth>
    {
        public GetConveningAuthMap()
        {
            // Primary Key
            this.HasKey(t => new { t.ConveningOrderId, t.Name });

            // Properties
            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("GetConveningAuth", "Main");
            this.Property(t => t.ConveningOrderId).HasColumnName("ConveningOrderId");
            this.Property(t => t.Name).HasColumnName("Name");
        }
    }
}
