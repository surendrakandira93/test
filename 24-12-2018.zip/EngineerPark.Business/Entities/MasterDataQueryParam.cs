﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class MasterDataQueryParam
    {
        
        public List<QueryFilter> WhereFilters { get; set; }
        
        public string Key { get; set; }
               
        public string TableName { get; set; }

        public string KeyFieldName { get; set; }

        public string ValueFieldName { get; set; }
              
        public string OrderByColumnName { get; set; }
               
        public bool IsOrderDescending { get; set; }
                
        public string AdditionalFieldName { get; set; }
                
        public bool IsSelectValueRequired { get; set; }

        public string DBSqlQuery { get; set; }
    }
}
