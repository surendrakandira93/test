﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class UserMacEntity
    {
        public int Id { get; set; }
        public Guid UserId { get; set; }
        public string MackAddress { get; set; }
    }

    public class UserMacList
    {
        public string UserName { get; set; }
        public List<UserMacEntity> MackAddressList { get; set; }

    }
}
