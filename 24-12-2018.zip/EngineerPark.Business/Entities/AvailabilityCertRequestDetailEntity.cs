﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;

    public class AvailabilityCertRequestDetailEntity : BaseEntity
    {

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertRequestId { get; set; }
        public string ItemName { get; set; }
        public string CategoryName { get; set; }
        public string EquipmentTypeName { get; set; }
        public string EquipmentName { get; set; }
        public decimal? RequestQuantiy { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid? ItemEquipmentId { get; set; }
        public decimal Quantiy { get; set; }
        public decimal? CurrentStockQuantity { get; set; }
        public int? Place { get; set; }
        public string Justification { get; set; }
        public List<MasterDataEntity> BasicCategoryList { get; set; }
        public List<MasterDataEntity> EquipmentList { get; set; }
        public List<MasterDataEntity> EquipmentTypeList { get; set; }
        public short ItemUomId { get; set; }
        public string ItemUomName { get; set; }
    }
}
