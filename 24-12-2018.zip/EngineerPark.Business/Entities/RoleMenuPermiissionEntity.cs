﻿namespace EngineerPark.Business.Entities
{
    public class RoleMenuPermiissionEntity
    {
        public int Id { get; set; }
        public int ParentId { get; set; }

        public string Name { get; set; }
        public bool IsApply { get; set; }
    }
}
