﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
   public class BdofficerEntity: BaseEntity
    {
        public BdofficerEntity()
        {
            this.DesignationList = new List<MasterDataEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbconveningOrderId { get; set; }
        public string Rank { get; set; }
        public string Name { get; set; }
        public short OrganizationId { get; set; }
        public short DesignationId { get; set; }
        public string OrganizationName { get; set; }
        public string DesignationName { get; set; }
        public short MemberTypeId { get; set; }        
        public string Remark { get; set; }
        public string Authority { get; set; }
        public List<MasterDataEntity> DesignationList { get; set; }
    }
}
