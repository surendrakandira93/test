﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ConveyNoteModelPrintEntity
   {
        public ConveyNoteModelPrintEntity()
        {
            this.ConveyNoteDetailPrint = new List<ConveyNoteDetailPrintEntity>();
        }

        public string ConveyNoteNo { get; set; }
        public DateTime IssueDate { get; set; }
        public string StoreName { get; set; }

        public string AuthLetterNo { get; set; }
        public DateTime AuthLetterDate { get; set; }

        public string GetPassNo { get; set; }
        public DateTime GetPassDate { get; set; }


        public string ReportType { get; set; }
        public string ReportNumberHeading { get; set; }


        public string CollectedBy { get; set; }
        public string VehicleNo { get; set; }

        public ConveyNoteEntity ConveyNoteModel { get; set; }
        public AuthorityLetterEntity AuthorityLetterModel { get; set; }
        public UserEntity userDetail { get; set; }
        public OrganizationEntity OrganizationModelFrom { get; set; }
        public OrganizationEntity OrganizationModelTo { get; set; }

        public List<ConveyNoteDetailPrintEntity> ConveyNoteDetailPrint { get; set; }

    }
}
