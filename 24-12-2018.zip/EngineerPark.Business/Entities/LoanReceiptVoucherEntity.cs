﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanReceiptVoucherEntity : BaseEntity
    {
        public LoanReceiptVoucherEntity()
        {
            LoanReceiptVoucherDetail = new List<LoanReceiptVoucherDetailEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public byte YearId { get; set; }
        public Guid ConveningOrderId { get; set; }
        public byte VoucherType { get; set; }
        public string VoucherNo { get; set; }
        public DateTime VoucherDate { get; set; }
        public short StoreId { get; set; }
        public short UnitId { get; set; }
        public Guid ReceiptdBy { get; set; }
        public bool IsCancelled { get; set; }
        public bool IsDeleted { get; set; }
        public string Remark { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public string StoreName { get; set; }


        public List<LoanReceiptVoucherDetailEntity> LoanReceiptVoucherDetail { get; set; }
        
    }
}
