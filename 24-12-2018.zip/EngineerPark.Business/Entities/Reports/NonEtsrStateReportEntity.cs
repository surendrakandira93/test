﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Reports
{
    public class NonEtsrStateReportEntity
    {
        public int SRNo { get; set; }

        public string ItemName { get; set; }

        public string AUName { get; set; }

        public decimal Auth { get; set; }

        public decimal Held { get; set; }

        public decimal OnLoanQty { get; set; }

        public decimal UnderRepairQty { get; set; }

        public decimal CommittedOnGround { get; set; }

        public decimal RelCollected { get; set; }

        public decimal NetServiceableQty { get; set; }

        public long Remarks { get; set; }

        public string CategoryName { get; set; }
        public string OrganizationName { get; set; }

    }
}
