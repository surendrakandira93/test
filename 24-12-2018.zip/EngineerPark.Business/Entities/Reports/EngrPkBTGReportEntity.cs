﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Reports
{
    public class EngrPkBTGReportEntity
    {
        public long? SRNo { get; set; }
       
        public string ItemName { get; set; }
        
        public string AUName { get; set; }
      
        public string AuthName { get; set; }

        public long Held { get; set; }
      
        public long OnLoanQty { get; set; }

        public long UnderRepairQty { get; set; }
      
        public long CommittedOnGround { get; set; }
       
        public long RelCollected { get; set; }
       
        public long NetServiceableQty { get; set; }
        public long Remarks { get; set; }
    }
}
