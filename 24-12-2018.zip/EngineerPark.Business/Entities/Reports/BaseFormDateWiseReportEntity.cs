﻿using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EngineerPark.Business.Entities.Reports
{
    public class BaseFormDateWiseReportEntity
    {
        //[DisplayName("From Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime? DateFrom { get; set; }

        //[DisplayName("To Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MMM/yyyy}")]
        public DateTime? DateTo { get; set; }

        public int StoreId { get; set; }

                                           // public List<QuaterlyReportEntity> QuaterlyPartialViewRpt { get; set; }

    }
}
