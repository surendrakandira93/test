﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ReportsEntity
    {
        public int Id { get; set; }
        public int SectioId { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public bool IsApply { get; set; }
    }
}
