﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Reports
{
    public class LoanComparisonReportEntity
    {
        public string column { get; set; }
        public string column1 { get; set; }
        public string column2 { get; set; }
        public string where { get; set; }
        public string where2 { get; set; }
        public string groupby { get; set; }
        public string groupby2 { get; set; }
        public string join { get; set; }
    }
}