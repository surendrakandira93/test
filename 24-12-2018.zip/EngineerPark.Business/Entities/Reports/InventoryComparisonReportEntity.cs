﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Reports
{
    public class InventoryComparisonReportEntity
    {
        public string column { get; set; }
        public string column1 { get; set; }
        public string where { get; set; }
        public string groupby { get; set; }
        public string groupby1 { get; set; }
    }
}
