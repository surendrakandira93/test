﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Reports
{
   public class StateCustomEntity
    {
        public string Col { get; set; }
        public string Wh { get; set; }
        public string groupBy { get; set; }
        public string Col1 { get; set; }
        public string groupBy1 { get; set; }
    }
}
