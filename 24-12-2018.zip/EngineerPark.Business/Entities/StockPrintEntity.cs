﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class StockPrintEntity
    {
        public string CategoryName { get; set; }
        public List<StockDataEntity> StoreData { get; set; }
    }
    public class StockDataEntity
    {
        public Guid GroupItemId { get; set; }
        public string GroupItemName { get; set; }
        public string AU { get; set; }
        public Guid ItemId { get; set; }
        public string ItemName { get; set; }
        public short StockShedId { get; set; }
        public string StockShedName { get; set; }
        public int ItemSetNumberId { get; set; }
        public string Setnumber { get; set; }
        public decimal OP_Quantiy { get; set; }
        public decimal ISS_Quantiy { get; set; }
        public decimal DEP_Quantiy { get; set; }
        public decimal Auth_Quantiy { get; set; }
        public decimal heldQty { get; set; }
    }
}
