﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanIssueVoucherEntity:BaseEntity
    {
        public LoanIssueVoucherEntity()
        {
            LoanIssueVoucherDetail = new List<LoanIssueVoucherDetailEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public byte YearId { get; set; }
        public Guid ReleaseOrderId { get; set; }
        public string VoucherNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public DateTime VoucherDate { get; set; }
        public short StoreId { get; set; }
        public short UnitId { get; set; }
        public Guid IssuedBy { get; set; }
        public bool IsCancelled { get; set; }
        public bool IsDeleted { get; set; }
        public string Remark { get; set; }
        public List<LoanIssueVoucherDetailEntity> LoanIssueVoucherDetail { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string StoreName { get; set; }
        public short DesignationId { get; set; }
    }
}
