﻿using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
  public  class RoleEntity:BaseEntity
    {
        public short Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PermissionMask { get; set; }
        public bool? IsActive { get; set; }
        public List<RoleParentMenuEntity> RoleMenu { get; set; }
        public List<ReportsEntity> Report { get; set; }


    }
}
