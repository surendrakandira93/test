﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanIssueVoucherPrintEntity
    {
        public LoanIssueVoucherPrintEntity()
        {
            this.LoanIssueVoucherPrintDetail = new List<LoanIssueVoucherPrintDetailEntity>();
        }

        public string VoucherNumber { get; set; }
        public DateTime IssueDate { get; set; }
        public string StoreName { get; set; }

        public string AuthLetterNo { get; set; }
        public DateTime AuthLetterDate { get; set; }

        public string GetPassNo { get; set; }
        public DateTime GetPassDate { get; set; }


        //public string ReportType { get; set; }
        //public string ReportNumberHeading { get; set; }

        public ConveyNoteModelPrintEntity ConveyNoteModel { get; set; }
        public AuthorityLetterEntity AuthorityLetterModel { get; set; }
        public UserEntity userDetail { get; set; }
        public OrganizationEntity OrganizationModelFrom { get; set; }
        public OrganizationEntity OrganizationModelTo { get; set; }

        public List<LoanIssueVoucherPrintDetailEntity> LoanIssueVoucherPrintDetail { get; set; }
    }
}
