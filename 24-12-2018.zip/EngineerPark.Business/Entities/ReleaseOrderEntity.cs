﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ReleaseOrderEntity: BaseEntity
    {
        public ReleaseOrderEntity()
        {
            this.ReleaseOrderDetail = new List<ReleaseOrderDetailEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid LoanRequestId { get; set; }
        public byte YearId { get; set; }
        public string ReleaseOrderNo { get; set; }
        public DateTime ReleaseDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public int IssuedBy { get; set; }
        public int ApprovedBy { get; set; }
        public string ReleaseNote { get; set; }      

        public List<ReleaseOrderDetailEntity> ReleaseOrderDetail { get; set; }
        public string LoanRequestNo { get;  set; }
        public DateTime RequestDate { get; set; }
        public string StoreName { get;  set; }
        public short DesignationId { get;  set; }
        public string Note { get;  set; }
    }
}
