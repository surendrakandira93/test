﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AnnualCPMBudgetEntity:BaseEntity
    {
        public int Id { get; set; }
        public short StoreId { get; set; }
        public int Year { get; set; }
        public decimal Cpmamount { get; set; }
        public decimal RepairAmount { get; set; }
        public decimal Contingency { get; set; }
        public string Remark { get; set; }
    }
}
