﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class MaintenancePlanDetailsEntity
    {
        public Guid ItemId { get; set; }
        public string Name { get; set; }
        public int ItemSetNumberId { get; set; }
        public string SetNo { get; set; }
        public int StockShedId { get; set; }
        public string ShedNo { get; set; }
        public double Quantiy { get; set; }
        public float PerItemQuantity { get; set; }
        public decimal Cost { get; set; }
        public string DueFrom { get; set; }
    }

    public class MaintenancePlanResponseEntity
    {
        public Guid Id { get; set; }
        public int MaintenancePlanId { get; set; }
        public string Name { get; set; }
        public int PlanType { get; set; }
        public int Year { get; set; }
        public short StoreId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public List<MaintenancePlanDetailsEntity> ItemList { get; set; }
        public List<MaintenancePlanDetailEntity> MaintenancePlanDetail { get; set; }

    }
}
