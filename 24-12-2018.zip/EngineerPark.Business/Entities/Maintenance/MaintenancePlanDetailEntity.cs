﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class MaintenancePlanDetailEntity:BaseEntity
    {
        public MaintenancePlanDetailEntity()
        {
            MaintenancePlanDetailsGroupItem = new List<MaintenancePlanDetailsGroupItemEntity>();
        }

        public int Id { get; set; }
        public int MaintenancePlanId { get; set; }
        public short CategoryId { get; set; }
        public  string CategoryName { get; set; }
        public double Quantiy { get; set; }
        public decimal Amount { get; set; }

        public List<MaintenancePlanDetailsGroupItemEntity> MaintenancePlanDetailsGroupItem { get; set; }
    }
}
