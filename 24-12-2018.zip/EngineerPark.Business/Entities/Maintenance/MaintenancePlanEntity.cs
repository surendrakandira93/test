﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public class MaintenancePlanEntity:BaseEntity
    {
        public MaintenancePlanEntity()
        {
            MaintenancePlanDetail = new List<MaintenancePlanDetailEntity>();
        }

        public int Id { get; set; }
        public int PlanType { get; set; }
        public int Year { get; set; }
        public short StoreId { get; set; }
        public short DesignationId { get; set; }

        public List<MaintenancePlanDetailEntity> MaintenancePlanDetail { get; set; }
    }
}
