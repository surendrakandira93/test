﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class MaintenancePlanGroupDetails
    {
        public Guid GroupItemId { get; set; }
        public string Name { get; set; }       
        public float Quantity { get; set; }        
        public decimal Cost { get; set; }
        public List<GroupItemPartEntity> PartList { get; set; }

    }
    public class GroupItemPartEntity
    {
        public Guid Id { get; set; }
        public float Quantity { get; set; }
    }

    public class MaintenancePlanGroupDetailsReponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<MaintenancePlanGroupDetails> Result { get; set; }

    }
}
