﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class MaintenancePlanDetailsItemEntity:BaseEntity
    {
        public int Id { get; set; }
        public int MaintenancePlanDetailsGroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public int ItemSetNumberId { get; set; }
        public short StockShedId { get; set; }
        public double Quantiy { get; set; }
        public decimal Amount { get; set; }
    }
}
