﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class MaintenancePlanDetailsGroupItemEntity:BaseEntity
    {
        public MaintenancePlanDetailsGroupItemEntity()
        {
            this.MaintenancePlanDetailsItem = new List<MaintenancePlanDetailsItemEntity>();
        }
        public int Id { get; set; }
        public int MaintenancePlanDetailId { get; set; }
        public Guid GroupItemId { get; set; }
        public double Quantiy { get; set; }
        public decimal Amount { get; set; }
        public List<MaintenancePlanDetailsItemEntity> MaintenancePlanDetailsItem { get; set; }
    }
}
