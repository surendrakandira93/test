﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class CarePriceEntity:BaseEntity
    {
        public int Id { get; set; }
        public Guid ItemId { get; set; }
        public string ItemName { get; set; }
        public string AU { get; set; }
        public decimal? Cpmprice { get; set; }
        public int Year { get; set; }
    }
}
