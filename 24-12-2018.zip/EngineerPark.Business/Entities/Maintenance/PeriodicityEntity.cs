﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class PeriodicityEntity:BaseEntity
    {
        public int Id { get; set; }
        public Guid ItemId { get; set; }
        public int? Periodicity1 { get; set; }
        public string ItemName { get; set; }
        public string AU { get; set; }
        public decimal Qty { get; set; }

    }
}
