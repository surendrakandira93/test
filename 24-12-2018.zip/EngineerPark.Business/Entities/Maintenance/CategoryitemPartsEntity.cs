﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.Maintenance
{
    public class CategoryitemPartsDetails
    {
        public Guid GroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public string GroupItemName { get; set; }
        public string ItemName { get; set; }
        public string Cost { get; set; }
        public DateTime DueFrom { get; }
        public string SetNo { get; set; }
        public int SetId { get; set; }
        public string ShedNo { get; set; }
        public string ShedId { get; set; }
    }
}




