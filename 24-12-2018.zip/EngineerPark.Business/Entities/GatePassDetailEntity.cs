﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class GatePassDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid GatePassId { get; set; }
        public int ApprovedBy { get; set; }        
    }
}
