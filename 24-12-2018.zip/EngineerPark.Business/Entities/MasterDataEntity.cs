﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class MasterDataEntity
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string AdditionalValue { get; set; }
    }
}
