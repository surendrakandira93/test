﻿namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class StoreStockEntity:BaseEntity
    {
        public StoreStockEntity()
        {
            StoreStockTransaction = new List<StoreStockTransactionEntity>();
        }

        public long RowId { get; set; }

        public Guid Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public byte TransactionTypeId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short StoreId { get; set; }

        public bool IsStockOut { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public DateTime TransactionDate { get; set; }

        public Guid? TransactionRefId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid GroupItemId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short HeldByOrgnaizationId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short GroupItemBasicCategoryId { get; set; }

        public List<StoreStockTransactionEntity> StoreStockTransaction { get; set; }
        //public List<StoreStockTransactionSetNoEntity> StoreStockTransactionSetNo { get; set; }
    }
}
