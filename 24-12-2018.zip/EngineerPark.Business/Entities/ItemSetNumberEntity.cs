﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using EngineerPark.CrossCutting;
using System.Text;
namespace EngineerPark.Business.Entities
{
    public class ItemSetNumberEntity : BaseEntity
    {
        
        public int Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        [StringLength(100, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string Name { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short HeldForOrganizationId { get; set; }

       
        [StringLength(250, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string Description { get; set; }

        public bool? IsActive { get; set; }

       // public OrganizationEntity HeldForOrganization { get; set; }
       


    }
}
