﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class LoanExtensionDetailEntity:BaseEntity
    {
        public int Id { get; set; }
        public int LoanExtensionId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public Guid? GroupItemId { get; set; }
        public short? StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
        public DateTime? OutDate { get; set; }
        public decimal Quantity { get; set; }
        public decimal? LoanPeriodInMonth { get; set; }
        public string Reason { get; set; }
        public string ReleaseNote { get; set; }
        public string ItemBasicCategoryName { get; set; }
        public string ItemEquipmentName { get; set; }
        public string ItemName { get; set; }
        public string GroupItemName { get; set; }
        public string StockShedNo { get; set; }
        public string ItemSetNumberNo { get; set; }
        public byte Place { get; set; }
    }
}
