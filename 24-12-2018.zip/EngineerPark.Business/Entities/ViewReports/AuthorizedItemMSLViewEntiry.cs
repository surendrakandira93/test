﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.ViewReports
{
    public class AuthorizedItemMSLViewEntity
    {
        public long RowNo { get; set; }
        public Guid StoreStockItemAuthorityId { get; set; }
        public short AuthorizedOrganiztionId { get; set; }
        public string OrganizationName { get; set; }
        public Guid GroupItemId { get; set; }
        public string ItemName { get; set; }
        public Guid ItemId { get; set; }
        public string PartName { get; set; }
        public decimal AuthQuantity { get; set; }
        public decimal PartHeldQuantity { get; set; }
        public decimal MinimumStockLevelPercent { get; set; }
        public decimal PartHeldInPercent { get; set; }
        public string Criticality { get; set; }
    }
}
