﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.ViewReports
{
    public class LoanStateViewEntity
    {
        public long RowNo { get; set; }
        public Guid GID { get; set; }
        public string Numencluture { get; set; }
        public string ND_AU { get; set; }
        public short ND_CategoryId { get; set; }
        public short ND_BasiccatId { get; set; }

        public string ND_Unit { get; set; }
        public string ND_Fmn { get; set; }
        public decimal ND_LoanQty { get; set; }
        public string ND_Authority { get; set; }
        public long ND_Permt { get; set; }
        public long ND_Temp { get; set; }
        public string ND_LoanExpPeriod { get; set; }
        public string ND_PresentStatus { get; set; }

        public string D_Unit { get; set; }
        public string D_Fmn { get; set; }
        public decimal? D_LoanQty { get; set; }
        public string D_Authority { get; set; }
        public long? D_Permt { get; set; }
        public long? D_Temp { get; set; }
        public string D_LoanExpPeriod { get; set; }
        public string D_PresentStatus { get; set; }

        public decimal TotQtyOnLoan { get; set; }


        public string CategoryName { get; set; }
        public string OrganizationName { get; set; }
    }
}
