﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.ViewReports
{
    public class ETSRSummeryViewEntity
    {
        //public long RowNo { get; set; }
        public short Id { get; set; }
        public string Items { get; set; }
        //public string AU { get; set; }
        public decimal Held { get; set; }
        public decimal RepQty { get; set; }
        public decimal SerQty { get; set; }
        public decimal Salvage { get; set; }
        public string Remark { get; set; }
    }
}
