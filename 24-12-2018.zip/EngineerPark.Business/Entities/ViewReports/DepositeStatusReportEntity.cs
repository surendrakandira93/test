﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.ViewReports
{
    public class DepositeStatusReportEntity
    {
        public long? SRNo { get; set; }
        public string ItemName { get; set; }
        public string AUName { get; set; }

        public string UnitName { get; set; }
        public string Fmn { get; set; }
        public decimal Qty { get; set; }
        public string RVNo { get; set; }
        public DateTime Date { get; set; }
        public decimal Serviceable { get; set; }
        public decimal Repairable { get; set; }
        public long FWT { get; set; }

        public decimal AmountReqd { get; set; }
        public string ConveningOrderLettleNo { get; set; }
        public DateTime ConveningOrderLetterDate { get; set; }
        public string Authority { get; set; }
        public DateTime ApproveDate { get; set; }


        public string CategoryName { get; set; }
        public string OrganizationName { get; set; }
    }
}
