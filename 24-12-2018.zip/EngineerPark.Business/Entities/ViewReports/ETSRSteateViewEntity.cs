﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.ViewReports
{
    public class ETSRStateViewEntity
    {       
        public long RowNo { get; set; }
        public Guid Id { get; set; }       
        public string ItemName { get; set; }
        public string AU { get; set; }
        public decimal AuthQty { get; set; }
        public decimal HeldQty { get; set; }
        public decimal OnLoanQty { get; set; }
        public decimal UnderRep { get; set; }
        public decimal ComitOnGround { get; set; }
        public decimal RelCollected { get; set; }
        public decimal NetSerQty { get; set; }
        public string Remark { get; set; }
        public short CategoryId { get; set; }

        public string CategoryName { get; set; }
        public string OrganizationName { get; set; }
    }
}
