﻿namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public  class UnitStockEntity:BaseEntity
    {
        public UnitStockEntity()
        {
            UnitStockTransaction = new List<UnitStockTransactionEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public byte TransactionTypeId { get; set; }
        public short UnitId { get; set; }
        public bool IsStockOut { get; set; }
        public DateTime TransactionDate { get; set; }
        public Guid? TransactionRefId { get; set; }      
        public List<UnitStockTransactionEntity> UnitStockTransaction { get; set; }
    }
}
