﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoadTrollyPrintEntity
    {
        public LoadTrollyPrintEntity()
        {
            this.LoadTrollyDetailPrint = new List<LoadTrollyDetailPrintEntity>();
        }

        public string TrollyNumber { get; set; }
        public DateTime TrollyDate { get; set; }
        public string ConveningOrderNo { get; set; }

        public string StoreName { get; set; }

        

        public string AuthorityName { get; set; }

        public string DepositedBy { get; set; }

        public string  LoadedinVehicle { get; set; }

        public string Note { get; set; }

        public UserEntity userDetail { get; set; }
        public OrganizationEntity OrganizationModelFrom { get; set; }
        public OrganizationEntity OrganizationModelTo { get; set; }
        public ConveningOrderEntity ConveningOrder { get; set; }
        public List<LoadTrollyDetailPrintEntity> LoadTrollyDetailPrint { get; set; }

    }
}
