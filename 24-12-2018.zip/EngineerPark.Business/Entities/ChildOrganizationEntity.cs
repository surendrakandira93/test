﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ChildOrganizationEntity
    {
        public short? ParentId { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public int OrganizationTypeId { get; set; }
        public List<ChildOrganizationEntity> Child { get; set; }
    }

    public class TreeEntity
    {
        public int id { get; set; }
        public string text { get; set; }
        public string parent { get; set; }
        public string description { get; set; }
        public int organizationtypeid { get; set; }
        public object li_attr { get; set; }

    }
}
