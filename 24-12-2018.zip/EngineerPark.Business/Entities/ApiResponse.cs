﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ApiResponse<T>
    {
        public ApiResponse()
        {
            Code = HttpStatusCode.OK;
        }
        public bool Status { get; set; }
        public bool IsLocked { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public HttpStatusCode Code { get; set; }
        public string[] Errors { get; set; }
    }
}
