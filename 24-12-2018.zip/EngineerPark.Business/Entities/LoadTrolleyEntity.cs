﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
    public class LoadTrolleyEntity : BaseEntity
    {
        public LoadTrolleyEntity()
        {
            LoadTrolleyItem = new HashSet<LoadTrolleyItemEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public byte YearId { get; set; }
        public string LoadTrolleyNo { get; set; }
        public DateTime LoadTrolleyDate { get; set; }
        public ICollection<LoadTrolleyItemEntity> LoadTrolleyItem { get; set; }
        public short StoreId { get; set; }
    }
}
