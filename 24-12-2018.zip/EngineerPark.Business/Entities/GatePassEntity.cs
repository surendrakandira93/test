﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class GatePassEntity:BaseEntity
    {
        public GatePassEntity()
        {
            GatePassDetail = new List<GatePassDetailEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveyNoteId { get; set; }
        public byte YearId { get; set; }
        public string GatePassNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short StoreId { get; set; }
        public int IssueTo { get; set; }
        public int IssuedBy { get; set; }
        public DateTime ExpiryDate { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsIssued { get; set; }
        public string Remark { get; set; }       
        public List<GatePassDetailEntity> GatePassDetail { get; set; }
        public short DesignationId { get; set; }
        public short UnitId { get; set; }
        public string Note { get; set; }
    }
}
