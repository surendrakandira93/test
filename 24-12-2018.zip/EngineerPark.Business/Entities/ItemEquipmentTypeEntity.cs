﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ItemEquipmentTypeEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ItemId { get; set; }
        public short EquipmentTypeId { get; set; }
       
    }
}
