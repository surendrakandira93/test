﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;

    public class AvailabilityCertRequestEntity
    {
        public AvailabilityCertRequestEntity()
        {
            this.AvailabilityCertRequestDetail = new List<AvailabilityCertRequestDetailEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public byte YearId { get; set; }
        public string RequestNo { get; set; }
        public DateTime RequestDate { get; set; }
        public short RequestedStoreId { get; set; }
        public short UnitId { get; set; }
        public byte StatusId { get; set; }
        public string Task { get; set; }
        public string Authority { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        //public short? CategoryId { get; set; }
        //public short? BasicCategoryId { get; set; }
        //public Guid GroupItemId { get; set; }        
        public short DesignationId { get; set; }
        public bool IsApproved { get; set; }
        public string Note { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsRequestSent { get; set; }
        public string Remark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }
       


        public List<AvailabilityCertRequestDetailEntity> AvailabilityCertRequestDetail { get; set; }


    }
}
