﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class LoanIssueVoucherConveyNoteEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveyNoteId { get; set; }        
    }
}
