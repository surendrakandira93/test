﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;

    public class AvailabilityCertIssueDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertIssueId { get; set; }
        public Guid AvailabilityCertReqestDetailId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal RequestedQuantiy { get; set; }
        public decimal AvailableQuantiy { get; set; }

        public string ItemName { get; set; }
        public string CategoryName { get; set; }
        public string EquipmentTypeName { get; set; }
        public string EquipmentName { get; set; }
        public int? Place { get; set; }
        public string ItemUomName { get; set; }

        public List<MasterDataEntity> BasicCategoryList { get; set; }
        public List<MasterDataEntity> EquipmentList { get; set; }
        public List<MasterDataEntity> EquipmentTypeList { get; set; }
    }
}
