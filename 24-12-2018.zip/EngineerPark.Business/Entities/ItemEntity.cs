﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;

    public class ItemEntity: BaseEntity
    {
        public ItemEntity()
        {
            this.ItemPartItem = new List<ItemPartsEntity>();
            //this.ItemUom = new List<UnitOfMeasureEntity>();
        }
        
        public long RowId { get; set; }
        public Guid Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        [StringLength(15, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string CatPtNo { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        [StringLength(100, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string Name { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short CategoryId { get; set; }

        public string Description { get; set; }
        public short? MaterialTypeId { get; set; }
        public short WeightUomId { get; set; }
        public decimal Weight { get; set; }
        public decimal? Area { get; set; }
        public short? AreaUomId { get; set; }
        public short? VolumeUomId { get; set; }
        public decimal? Volume { get; set; }
        public short? CapacityUomId { get; set; }
        public decimal? Capacity { get; set; }
        public short ItemUomId { get; set; }

        public string ItemUomName { get; set; }
        public string ItemBasicCatName { get; set; }
        public string ItemEqptTypeName { get; set; }
        public string ItemEqptName { get; set; }
        //public byte? ItemStatusId { get; set; }

        public string LoadingVehicle { get; set; }
        public short? ManCarry { get; set; }
        public decimal Cost { get; set; }
        public decimal ItemCritLevel { get; set; }


        public short IsMaster { get; set; }
        public bool? IsActive { get; set; }

        public List<short> BasicCategoryId { get; set; }
        public List<short> EquipmentId { get; set; }
        public List<short> EquipmentTypeId { get; set; }
              

        public List<ItemPartsEntity> ItemPartItem { get; set; }
    }
}
