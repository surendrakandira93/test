﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ResponseEntity<T>
    {
        public ResponseEntity()
        {
            Code = HttpStatusCode.OK;
        }
        public ResponseEntity(HttpStatusCode statusCode)
        {
            Code = statusCode;
        }
        public bool Status { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public HttpStatusCode Code { get; set; }
        public string[] Errors { get; set; }

        
    }
}
