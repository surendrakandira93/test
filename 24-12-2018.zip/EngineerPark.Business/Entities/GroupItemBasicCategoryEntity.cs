﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class GroupItemBasicCategoryEntity : BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid GroupItemId { get; set; }
        public short BasicCategoryId { get; set; }

    }
}
