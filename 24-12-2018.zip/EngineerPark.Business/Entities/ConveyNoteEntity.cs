﻿using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ConveyNoteEntity: BaseEntity
    {
        public ConveyNoteEntity()
        {
            this.ConveyNoteDetail = new List<ConveyNoteDetailEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid AuthorityLetterId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid AuthorityLetterVechileDetailId { get; set; }
        public byte YearId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string NoteNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public int ApprovedBy { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }       
        public string Remark { get; set; }
        public string DriverDetails { get; set; }
        public string StoreName { get; set; }
        public List<ConveyNoteDetailEntity> ConveyNoteDetail { get; set; }

    }
}
