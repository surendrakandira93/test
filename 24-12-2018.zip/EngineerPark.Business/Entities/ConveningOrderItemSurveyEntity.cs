﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderItemSurveyMainEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public bool IsVerified { get; set; }
        public bool IsApproved { get; set; }
        public string FileName { get; set; }
        public string ApprovedRemark { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public List<ConveningOrderItemSurvey_Entity> ConveningOrderItemSurvey { get; set; }
    }
    public class ConveningOrderItemSurveyEntity : BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderItemId { get; set; }
        public byte ItemStatusId { get; set; }
        public decimal? Quantiy { get; set; }
        public string ItemStatusName { get; set; }

    }
    public class ConveningOrderSurveyEntity
    {
        public ConveningOrderSurveyEntity()
        {
            this.ConveningOrderItem = new List<ConveningOrderItemSurvey_Entity>();
        }

        public string ReleaseOrderNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public Guid? ConveningOrderId { get; set; }
        public string StoreName { get; set; }
        public string FileName { get; set; }
        public List<ConveningOrderItemSurvey_Entity> ConveningOrderItem { get; set; }

    }

    public class ConveningOrderItemSurvey_Entity
    {
        public ConveningOrderItemSurvey_Entity()
        {
            this.SurveryModel = new List<ConveningOrderItemSurveyEntity>();
        }

        public Guid Id { get; set; }
        public Guid? ConveningOrderItemSurveyMainId { get; set; }
        public Guid? ConveningOrderItemId { get; set; }
        public decimal? LoanQuantiy { get; set; }
        public decimal? ReturnQuantiy { get; set; }
        public decimal? ReceivedQuantiy { get; set; }
        public string Remarks { get; set; }
        public string ItemBasicCategoryName { get; set; }
        public string ItemEquipmentName { get; set; }
        public string ItemEquipmentTypeName { get; set; }
        public string ItemName { get; set; }
        public List<ConveningOrderItemSurveyEntity> SurveryModel { get; set; }
    }
}
