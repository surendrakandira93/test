﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;
    using System.Text;

    public class GroupItemMslEntity : BaseEntity
    {
        public long? RowId { get; set; }
        public Guid Id { get; set; }

        [Display(Name = "Name")]
        [MaxLength(100, ErrorMessage = "Group Item Name should be max length 100 character")]
        [Required(ErrorMessage = "Please enter Group Item Name")]
        public string Name { get; set; }

        public string CategoryName { get; set; }

        public string ItemUomName { get; set; }

        [Display(Name = "Minimum StockLevel Percent")]
        //[MaxLength(100, ErrorMessage = "Group Item Name should be max length 100 character")]
        [Required(ErrorMessage = "Please Enter Minimum StockLevel Percent")]
        public decimal? MinimumStockLevelPercent { get; set; }

    }
}
