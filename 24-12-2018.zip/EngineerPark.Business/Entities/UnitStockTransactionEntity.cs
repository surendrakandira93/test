﻿namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class UnitStockTransactionEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid UnitStockId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public DateTime Mfgdate { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public DateTime ExpiryDate { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string SetNo { get; set; }
        public string LotNo { get; set; }
        public decimal Quantiy { get; set; }
        public string Remark { get; set; }
        
    }
}
