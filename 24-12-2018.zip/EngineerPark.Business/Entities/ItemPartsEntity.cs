﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;
    using System.Text;
    public class ItemPartsEntity : BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
       // [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemId { get; set; }

        public Guid ItemPartItemId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public decimal Quantity { get; set; }


    }
}
