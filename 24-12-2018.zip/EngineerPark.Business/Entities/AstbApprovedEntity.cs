﻿using System;

namespace EngineerPark.Business.Entities
{
    public class AstbApprovedEntity
    {
        public Guid AstbconveningId { get; set; }
        public short OrgId { get; set; }
        public short DestId { get; set; }
        public bool IsApproved { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public short? ToDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? FromDesignationId { get; set; }
        public short? FromOrganizationId { get; set; }
        public string Fyear { get; set; }
        public string BooComposition { get; set; }
        public DateTime? IntercationDate { get; set; }
        public string Scope { get; set; }
        public long FilioNo { get; set; }
        public DateTime Bpodate { get; set; }
    }
}
