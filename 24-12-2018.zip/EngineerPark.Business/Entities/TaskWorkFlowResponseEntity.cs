﻿using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
  public  class TaskWorkFlowResponseEntity
    {
        public TaskWorkFlowResponseEntity()
        {
            this.TaskWorkFlow = new List<TaskWorkFlowEntity>();
            this.ToOrganization = new List<MasterDataEntity>();
            this.ToDesignation = new List<MasterDataEntity>();
            this.FromDesignation = new List<MasterDataEntity>();
        }
        public List<TaskWorkFlowEntity> TaskWorkFlow { get; set; }
        public List<MasterDataEntity> ToOrganization { get; set; }
        public List<MasterDataEntity> ToDesignation { get; set; }
        public List<MasterDataEntity> FromDesignation { get; set; }
        public string FromOrganizationName { get; set; }
        public short FromOrganizationId { get; set; }
        public string TaskName { get; set; }
        public byte TaskId { get; set; }



    }
}
