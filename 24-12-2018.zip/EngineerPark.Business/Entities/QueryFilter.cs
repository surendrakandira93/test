﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class QueryFilter
    {
       
        public QueryFilter(string fieldName, string fieldValue)
        {
            this.FieldName = fieldName;
            this.FieldValue = fieldValue;
            this.FilterOperator = " And ";
        }

       
        public QueryFilter(string fieldName, string fieldValue, string filterOperator)
        {
            this.FieldName = fieldName;
            this.FieldValue = fieldValue;
            this.FilterOperator = filterOperator;
        }

        
        private QueryFilter()
        {
        }

      
        public string FieldName { get; set; }

        
        public string FieldValue { get; set; }

        public string FilterOperator { get; set; }
    }
}
