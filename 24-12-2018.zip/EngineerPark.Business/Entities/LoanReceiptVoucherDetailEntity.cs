﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class LoanReceiptVoucherDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid LoanReceiptVoucherId { get; set; }
        public Guid ConveningOrderItemId { get; set; }
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal Quantiy { get; set; }
        public string Remark { get; set; }

        public string ItemName { get; set; }
        public string ItemBasicCategoryName { get; set; }
        public string ItemEquipmentTypeName { get; set; }
        public string ItemEquipmentName { get; set; }
        public decimal LoanQuantiy { get; set; }
        public decimal? AvailableQuantiy { get;  set; }
    }
}
