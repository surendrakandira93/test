﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class LoanRequestPrintEntity
    {
        public LoanRequestPrintEntity()
        {
            this.LoanRequestDetailPrint = new List<LoanRequestDetailPrintEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertRequestId { get; set; }
        public Guid AvailabilityCertIssueId { get; set; }
        public short DesignationId { get; set; }
        public byte YearId { get; set; }
        public string LoanRequestNo { get; set; }
        public string RequestNo { get; set; }
        public string IssuetNo { get; set; }
        public DateTime RequestDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public string StoreName { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public string Remark { get; set; }
        public string Note { get; set; }

        public DateTime CreatedDate { get; set; }
        // public LoanRequestEntity LoanRequestModel { get; set; }
        //public AvailabilityCertRequestEntity AvailabilityCertRequestModel { get; set; }
        //public AvailabilityCertIssueEntity AvailabilityCertIssueModel { get; set; }
        public UserEntity userDetail { get; set; }
         public OrganizationEntity OrganizationModelFrom { get; set; }
        //public OrganizationModel OrganizationModelTo { get; set; }

        public List<LoanRequestDetailPrintEntity> LoanRequestDetailPrint { get; set; }

    }
}
