﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AvailabilityCertIssuePrintEntity
    {
        public AvailabilityCertRequestEntity AvailabilityCertRequestModel { get; set; }
        public AvailabilityCertIssueEntity AvailabilityCertIssueModel { get; set; }
        public UserEntity userDetail { get; set; }
        public OrganizationEntity OrganizationModelFrom { get; set; }
        public OrganizationEntity OrganizationModelTo { get; set; }
    }
}
