﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderItemSurveyPrintEntity
    {
        public ConveningOrderItemSurveyPrintEntity()
        {
            this.ConveningOrderItemList = new List<ConveningOrderItemSurveyDetailPrintEntity>();
            this.ConveningOrderMemberList = new List<ConveningOrderMemberEntity>();
        }

        public string ReleaseOrderNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public string StoreName { get; set; }
        public string Task { get; set; }
        public UserEntity userDetail { get; set; }
        public OrganizationEntity organization { get; set; }
        public ConveningOrderEntity ConveningOrder { get; set; }
        public List<ConveningOrderMemberEntity> ConveningOrderMemberList { get; set; }
        public List<ConveningOrderItemSurveyDetailPrintEntity> ConveningOrderItemList { get; set; }
    }
}
