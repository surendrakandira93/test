﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderItemEntity:BaseEntity
    {
        public ConveningOrderItemEntity()
        {
            this.Survey = new List<ConveningOrderItemSurvey_SectionOrder_Entity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public Guid ItemId { get; set; }
        //public short ? ItemUomId { get; set; } //Not in DB
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal LoanQuantiy { get; set; }
        public decimal ReturnQuantiy { get; set; }
        public decimal? ReceivedQuantiy { get; set; }
        public decimal? AvailableQuantiy { get; set; }
        public string Remarks { get; set; }
        public string ItemBasicCategoryName { get;  set; }
        public string ItemEquipmentName { get;  set; }
        public string ItemEquipmentTypeName { get;  set; }
        public string ItemName { get;  set; }
        public int? Place { get; set; }
        public List<MasterDataEntity> GroupItemList { get; set; }
        public List<ConveningOrderItemSurvey_SectionOrder_Entity> Survey { get; set; }
    }

    public class ConveningOrderItemSurvey_SectionOrder_Entity
    {
        public byte ItemStatusId { get; set; }
        public decimal? Quantiy { get; set; }
        public string ItemStatusName { get; set; }
    }
}
