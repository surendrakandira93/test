﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class LoanIssueVoucherDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid LoanIssueVoucherId { get; set; }       
        public Guid ItemId { get; set; }
        public Guid ItemBasicCategoryId { get; set; }
        public Guid? ItemEquipmentTypeId { get; set; }
        public Guid ItemEquipmentId { get; set; }
        public decimal Quantiy { get; set; }
        public string Remark { get; set; }
        public string ItemName { get; set; }
        public string ItemBasicCategoryName { get; set; }
        public string ItemEquipmentTypeName { get; set; }
        public string ItemEquipmentName { get; set; }
        public string ItemUomName { get; set; }
        public int? Place { get; set; }
    }
}
