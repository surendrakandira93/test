﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ItemBasicCategoryEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ItemId { get; set; }
        public short BasicCategoryId { get; set; }

    }
}
