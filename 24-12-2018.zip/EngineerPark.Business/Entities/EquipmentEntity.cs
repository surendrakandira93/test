﻿namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System.ComponentModel.DataAnnotations;

    public class EquipmentEntity:BaseEntity
    {
        public short Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        [StringLength(100, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string Name { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "StringLength")]
        public string Description { get; set; }
        public bool? IsActive { get; set; }
    }
}
