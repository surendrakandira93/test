﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
    public class DashboardNotificationEntity
    {
        public DashboardNotificationEntity()
        {
            this.Result = new List<NotificationDetailEntity>();
        }
        public List<NotificationDetailEntity> Result { get; set; }       
    }
    
    public class NotificationDetailEntity
    {
        public string Heading { get; set; }
        public string ColorClass { get; set; }
        public string ModelId { get; set; }
        public string ActionUrl { get; set; }
        public string ActionTitle { get; set; }
        public List<string> ColumnName { get; set; }
        public List<List<string>> Rows { get; set; }
    }

    public class NotificationPostEntity
    {
        public string Heading { get; set; }
        public string ColorClass { get; set; }
        public string MethodName { get; set; }
        public string ActionUrl { get; set; }
        public string ActionTitle { get; set; }
        public List<string> ColumnName { get; set; }

    }

    public class NotificationMainEntity
    {
        public NotificationMainEntity()
        {
            this.Methods = new List<NotificationPostEntity>();
        }

        public short DesignationId { get; set; }
        public short OrganizationId { get; set; }
        public List<NotificationPostEntity> Methods { get; set; }
    }
}
