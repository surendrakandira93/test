﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class LoanRequestDetailEntity:BaseEntity
    {
       
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid LoanReqestId { get; set; }
        public Guid LoanReqestAssignId { get; set; }
        public Guid AvailabilityCertIssueDetailId { get; set; }
        public string ItemName { get; set; }
        public short? Place { get; set; }
        public string CategoryName { get; set; }
        public string EquipmentTypeName { get; set; }
        public string EquipmentName { get; set; }
        public decimal Quantiy { get; set; }
        public decimal IssueQuantiy { get; set; }
        public decimal RequestQuantiy { get; set; }
        public decimal? LoanPeriodInMonth { get; set; }
        public string Reason { get; set; }
       
    }
}
