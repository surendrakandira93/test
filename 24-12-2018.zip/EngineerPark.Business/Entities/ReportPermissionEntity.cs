﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ReportPermissionEntity:BaseEntity
    {
        public int Id { get; set; }
        public int ReportId { get; set; }
        public short RoleId { get; set; }
        public int PermissionCount { get; set; }        
    }
}
