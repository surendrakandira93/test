﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class ItemDetailEntity
    {
        public Guid ItemId { get; set; }
        public string CatPtNo { get; set; }
        public int Place { get; set; }
        public string ItemUom { get; set; }
        public short ItemUomId { get; set; }
        public List<MasterDataEntity> BasicCategoryList { get; set; }
        public List<MasterDataEntity> EquipmentTypeList { get; set; }
        public List<MasterDataEntity> EquipmentList { get; set; }
        public List<MasterDataEntity> ItemUomList { get; set; }

    }
}
