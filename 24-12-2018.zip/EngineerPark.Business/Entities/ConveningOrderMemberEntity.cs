﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderMemberEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveningOrderId { get; set; }
        public string MemberCode { get; set; }
        public string MemberName { get; set; }
        public Guid? MemberId { get; set; }
        public ConveningOrderEntity ConveningOrder { get; set; }
    }

    public class ConveningOrderMainMember
    {
        public Guid? Poid { get; set; }

        public List<ConveningOrderMemberEntity> OrderMember { get; set; }
    }
}
