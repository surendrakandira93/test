﻿using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
    public class RoleParentMenuEntity
    {
        public RoleParentMenuEntity()
        {
            this.Menu = new List<RoleMenuEntity>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsApply { get; set; }
        public List<RoleMenuEntity> Menu { get; set; }
    }
}
