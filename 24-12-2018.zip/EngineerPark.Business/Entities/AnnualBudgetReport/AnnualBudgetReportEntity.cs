﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AnnualBudgetReportEntity
    {
        public AnnualBudgetReportEntity(DataRow row)
        {
            CategoryId = int.Parse(row["CategoryId"].ToString());
            Name = (string)row["Name"];
            MaintenancePlanDetailsId = int.Parse(row["MaintenancePlanDetailsId"].ToString());
            Name = (string)row["Name"];
            GroundQty = decimal.Parse(row["GroundQty"].ToString());
            LoanQty = decimal.Parse(row["LoanQty"].ToString());
            DepositQty = decimal.Parse(row["DepositQty"].ToString());
            HeldQty = decimal.Parse(row["HeldQty"].ToString());
            AuthQty = decimal.Parse(row["AuthQty"].ToString());
            CpmQty = decimal.Parse(row["CpmQty"].ToString());
            CpmAmount = decimal.Parse(row["CPMAmount"].ToString());

            
        }
        public int MaintenancePlanDetailsId { get; set; }
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public string AU { get; set; }
        public decimal GroundQty { get; set; }
        public decimal LoanQty { get; set; }
        public decimal DepositQty { get; set; }
        public decimal HeldQty { get; set; }
        public decimal AuthQty { get; set; }
        public decimal CpmQty { get; set; }
        public decimal CpmAmount { get; set; }
    }   
}
