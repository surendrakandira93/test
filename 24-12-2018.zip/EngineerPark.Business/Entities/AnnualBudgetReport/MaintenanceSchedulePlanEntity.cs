﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class MaintenanceSchedulePlanEntity:BaseEntity
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public double CPMQty { get; set; }
        public int MaintenancePlanDetailsId { get; set; }
        public double Qtr1qty { get; set; }
        public double Qtr2qty { get; set; }
        public double Qtr3qty { get; set; }
        public double Qtr4qty { get; set; }
        public decimal Cpmamount { get; set; }
        public decimal RepairAmount { get; set; }
        public decimal Contingency { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public string Remark { get; set; }
    }
}
