﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class SalvageInEntity:BaseEntity
    {
        public int Id { get; set; }
        public short OrganizationId { get; set; }
        public short StoreId { get; set; }
        public DateTime Date { get; set; }
        public double Weight { get; set; }
        public string Auth { get; set; }
        public short MaterialTypeId { get; set; }
        public string Remark { get; set; }
    }
}
