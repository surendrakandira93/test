﻿using System;

namespace EngineerPark.Business.Entities
{
    public class LoadTrolleyItemEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid LoadTrolleyId { get; set; }
        public Guid ConveningOrderItemId { get; set; }
        public decimal Quantiy { get; set; }
        public Guid GroupItemId { get; set; }
        public short? StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
        public short ItemUomId { get; set; }
        public Guid ItemId { get; set; }
    }
}
