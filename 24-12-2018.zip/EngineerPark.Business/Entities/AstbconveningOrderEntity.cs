﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AstbconveningOrderEntity: BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public string LetterNo { get; set; }
        public DateTime Date { get; set; }
        public Guid? PresidingOfficerId { get; set; }
        public short StoreId { get; set; }
        public short UnitId { get; set; }
        public string StoreName { get; set; }
        public string UnitName { get; set; }
        public List<BdofficerEntity> BdOfficer { get; set; }
        public short DesignationId { get; set; }
        public string Note { get; set; }
        public bool IsApproved { get; set; }
        public string Fyear { get; set; }
        public string BooComposition { get; set; }
        public DateTime? IntercationDate { get; set; }
        public string Scope { get; set; }
        public long? FilioNo { get; set; }
        public DateTime? Bpodate { get; set; }
    }
    
}
