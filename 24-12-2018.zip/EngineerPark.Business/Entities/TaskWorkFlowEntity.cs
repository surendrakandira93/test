﻿namespace EngineerPark.Business.Entities
{
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;

    public class TaskWorkFlowEntity : BaseEntity
    {
        public int Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public byte TaskId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short FromOrganizationId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short FromDesignationId { get; set; }

        public short? ToOrganizationId { get; set; }

        public short? ToDesignationId { get; set; }

        public bool? IsActive { get; set; }
    }
}