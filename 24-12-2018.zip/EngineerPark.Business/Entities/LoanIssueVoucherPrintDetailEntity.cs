﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanIssueVoucherPrintDetailEntity
    {
        public string ItemName { get; set; }
        public string UOMName { get; set; }
        public int Place { get; set; }
        public decimal quantity { get; set; }
        public string Remark { get; set; }
    }
}
