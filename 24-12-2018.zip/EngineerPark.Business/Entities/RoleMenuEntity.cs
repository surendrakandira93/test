﻿namespace EngineerPark.Business.Entities
{
    using System.Collections.Generic;

    public class RoleMenuEntity
    {
        public RoleMenuEntity()
        {
            this.MenuPermiission = new List<RoleMenuPermiissionEntity>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsApply { get; set; }

        public List<RoleMenuPermiissionEntity> MenuPermiission { get; set; }
    }
}
