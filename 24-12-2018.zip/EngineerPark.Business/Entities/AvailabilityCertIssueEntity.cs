﻿

namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class AvailabilityCertIssueEntity:BaseEntity
    {
        public AvailabilityCertIssueEntity()
        {
            this.AvailabilityCertIssueDetail = new List<AvailabilityCertIssueDetailEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertReqestId { get; set; }
        public byte YearId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string ReqestNo { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string CertificateNo { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public DateTime IssueDate { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short UnitId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsIssued { get; set; }
        public string Remark { get; set; }
        public List<AvailabilityCertIssueDetailEntity> AvailabilityCertIssueDetail { get; set; }
        public bool IsApproved { get; set; }
        public short DesignationId { get; set; }
        public string Note { get; set; }
        
    }
}
