﻿using System;
using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
    public class JobOrderEntity : BaseEntity
    {
        public JobOrderEntity()
        {
            JobOrderDetail = new List<JobOrderDetailEntity>();
        }

        public int Id { get; set; }
        public short StoreId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }      
        public bool IsApproved { get; set; }       
        public short DesignationId { get;  set; }
        public int MaintenancePlanId { get; set; }
        public int QuarterlyMaintenancePlanId { get; set; }
        public int JobOrderTypeId { get; set; }
        public string Authority { get; set; }
        public string VenderName { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string JobOrderNo { get; set; }
        public double? Amount { get; set; }
        public DateTime? CompletionDate { get; set; }
        public DateTime? CancellationDate { get; set; }
        public string Justification { get; set; }
        public string File { get; set; }
        public byte? Status { get; set; }
        public List<JobOrderDetailEntity> JobOrderDetail { get; set; }
    }
}
