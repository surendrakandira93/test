﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class JobOrderDetailsReponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<JobOrderGroupDetails> Result { get; set; }
    }

    public class JobOrderGroupDetails
    {
        
        public short MaterialTypeId { get; set; }
        public string Name { get; set; }
        public float Quantity { get; set; }
        public decimal Cost { get; set; }
        public List<JobOrderGroupItemPartEntity> PartList { get; set; }

    }
    public class JobOrderGroupItemPartEntity
    {
        public Guid Id { get; set; }
        public Guid GroupItemId { get; set; }
        public float Quantity { get; set; }
    }
}
