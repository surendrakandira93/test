﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class JobOrderDetailEntity : BaseEntity
    {
        public JobOrderDetailEntity()
        {
            JobOrderDetailsGroupItem = new List<JobOrderDetailsGroupItemEntity>();
        }

        public int Id { get; set; }
        public int JobOrderId { get; set; }
        public short CategoryId { get; set; }
        public string CategoryName { get; set; }
        public double Quantity { get; set; }
        public decimal Amount { get; set; }
        public List<JobOrderDetailsGroupItemEntity> JobOrderDetailsGroupItem { get; set; }
    }
}
