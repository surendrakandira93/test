﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class JobOrderApprovalEntity
    {
        public int JobOrderId { get; set; }
        public string JobOrderType { get; set; }
        public short OrgId { get; set; }
        public short DestId { get; set; }
        public bool IsApproved { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public short? ToDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? FromDesignationId { get; set; }
        public short? FromOrganizationId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string JobOrderNo { get; set; }
        public double? Amount { get; set; }
        public DateTime? CompletionDate { get; set; }
        public DateTime? CancellationDate { get; set; }
        public byte? Status { get; set; }
    }
}
