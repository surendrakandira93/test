﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class JobOrderDetailsGroupItemEntity : BaseEntity
    {
        public JobOrderDetailsGroupItemEntity()
        {
            JobOrderDetailsItem = new List<JobOrderDetailsItemEntity>();
        }

        public int Id { get; set; }
        public int JobOrderDetailId { get; set; }
        public short MaterialTypeId { get; set; }
        public double Quantity { get; set; }
        public decimal Amount { get; set; }
        public List<JobOrderDetailsItemEntity> JobOrderDetailsItem { get; set; }
    }
}
