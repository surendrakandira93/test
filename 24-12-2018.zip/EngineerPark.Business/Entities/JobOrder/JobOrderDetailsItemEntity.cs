﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class JobOrderDetailsItemEntity : BaseEntity
    {
        public int Id { get; set; }
        public int JobOrderDetailsGroupItemId { get; set; }
        public Guid? GroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public int ItemSetNumberId { get; set; }
        public short StockShedId { get; set; }
        public double Quantity { get; set; }
        public decimal Amount { get; set; }
    }
}
