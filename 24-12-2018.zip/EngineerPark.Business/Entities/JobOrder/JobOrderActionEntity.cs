﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class JobOrderActionEntity:BaseEntity
    {
        public int Id { get; set; }
        public DateTime? CompletionDate { get; set; }
        public DateTime? CancellationDate { get; set; }
        public string Justification { get; set; }        
        public byte? Status { get; set; }
    }
}
