﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class SalvageOutEntity:BaseEntity
    {
        public int Id { get; set; }
        public short StoreId { get; set; }
        public DateTime Date { get; set; }
        public double Weight { get; set; }
        public decimal Amount { get; set; }
        public string Auth { get; set; }
        public string VendarName { get; set; }
        public short MaterialTypeId { get; set; }
        public string Remark { get; set; }
    }
}
