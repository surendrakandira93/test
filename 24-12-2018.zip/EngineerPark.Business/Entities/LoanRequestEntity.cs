﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class LoanRequestEntity:BaseEntity
    {
        public LoanRequestEntity()
        {
            this.LoanRequestDetail = new List<LoanRequestDetailEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AvailabilityCertRequestId { get; set; }
        public Guid AvailabilityCertIssueId { get; set; }
        public short DesignationId { get; set; }
        public byte YearId { get; set; }
        public string LoanRequestNo { get; set; }
        public string RequestNo { get; set; }
        public string IssuetNo { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime IssuetDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public string StoreName { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public string Remark { get; set; }
        public string Note { get; set; }
        public short? ToDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? FromDesignationId { get; set; }
        public short? FromOrganizationId { get; set; }

        public List<LoanRequestDetailEntity> LoanRequestDetail { get; set; }

    }
}
