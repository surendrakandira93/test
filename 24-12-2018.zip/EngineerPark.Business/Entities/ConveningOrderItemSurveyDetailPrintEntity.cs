﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderItemSurveyDetailPrintEntity
    {
        public long? RowId { get; set; }
        public Guid? Id { get; set; }
        

        [Display(Name = "Loan Quantiy")]
        public decimal LoanQuantiy { get; set; }
        [Display(Name = "Return Quantiy")]
        public decimal ReturnQuantiy { get; set; }
        [Display(Name = "Received Quantiy")]
        public decimal? ReceivedQuantiy { get; set; }

        public decimal? ServiceQuantiy { get; set; }

        public decimal? RepairQuantiy { get; set; }

      
        public string Remarks { get; set; }
      
        public string ItemName { get; set; }

        public string UomName { get; set; }

        public int Place { get; set; }
       

    }
}
