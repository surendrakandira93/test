﻿using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EngineerPark.Business.Entities
{
    public class ConveyNoteDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ConveyNoteId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemBasicCategoryId { get; set; }
        //[Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid? ItemEquipmentTypeId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemEquipmentId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public decimal Quantiy { get; set; }
        public string Remark { get; set; }
        public Guid GroupItemId { get; set; }
        public short? StockShedId { get; set; }
        public int ItemSetNumberId { get; set; }
        public short ItemUomId { get; set; }
        public decimal? AvailableQuantity { get; set; }

        public string ItemName { get; set; }
        public string BasicCategoryName { get; set; }
        public string EquipmentName { get; set; }
        [NotMapped]
        public string GroupItemName { get; set; }
        public string StockShedName { get; set; }
        public string ItemSetNumberName { get; set; }
        public string ItemUomName { get; set; }
        public int? Place { get; set; }

        public List<MasterDataEntity> GroupItemList { get; set; }
        public List<MasterDataEntity> ItemList { get; set; }       
        public List<MasterDataEntity> BasicCategoryList { get; set; }
        public List<MasterDataEntity> EquipmentTypeList { get; set; }
        public List<MasterDataEntity> EquipmentList { get; set; }
    }
}
