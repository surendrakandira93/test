﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class StateEntity
    {
        public StateEntity()
        {
            Organization = new List<OrganizationEntity>();
        }

        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public short CountryId { get; set; }
        public short Order { get; set; }
        public bool? IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public CountryEntity Country { get; set; }
        public List<OrganizationEntity> Organization { get; set; }
    }
}
