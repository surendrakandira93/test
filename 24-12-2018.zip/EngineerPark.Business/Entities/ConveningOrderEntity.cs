﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class ConveningOrderEntity : BaseEntity
    {
        public ConveningOrderEntity()
        {
            this.ConveningOrderItem = new List<ConveningOrderItemEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid ReleaseOrderId { get; set; }
        public string ReleaseOrderNo { get; set; }
        public byte YearId { get; set; }
        public string ConveningOrderNo { get; set; }
        public string SenctionNo { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? IssueDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public byte StatusId { get; set; }
        public Guid? ConveningOrderBy { get; set; }
        public Guid? PresidingOfficerId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string StoreName { get; set; }
        public string FileName { get; set; }

        public short? ToDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? FromDesignationId { get; set; }
        public short? FromOrganizationId { get; set; }

        public List<ConveningOrderItemEntity> ConveningOrderItem { get; set; }
        public short DesignationId { get; set; }
        public string Note { get; set; }
        public bool IsApproved { get; set; }
    }
}
