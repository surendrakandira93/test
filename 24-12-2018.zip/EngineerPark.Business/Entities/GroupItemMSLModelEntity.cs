﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;
    using System.Text;

    public class GroupItemMslModelEntity
    {
        public GroupItemMslModelEntity()
        {
            this.GroupItemMsl = new List<GroupItemMslEntity>();
        }
        public string CategoryName { get; set; }
        public List<GroupItemMslEntity> GroupItemMsl { get; set; }

    }
}
