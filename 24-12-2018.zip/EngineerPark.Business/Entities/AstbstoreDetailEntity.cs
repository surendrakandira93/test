﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AstbstoreDetailEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbstoreId { get; set; }
        public byte ItemStatusId { get; set; }
        public string Name { get; set; }
        public decimal Quantiy { get; set; }        
    }
}
