﻿namespace EngineerPark.Business.Entities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using EngineerPark.CrossCutting;
    using System.Text;
    using System.ComponentModel.DataAnnotations.Schema;

    public class GroupItemDetailEntity : BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }

        public Guid GroupItemId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemId { get; set; }
        public string ItemName { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public decimal Quantity { get; set; }

        [NotMapped]
        public string CategoryName { get; set; }
        [NotMapped]
        public string NameUnitOfMeasure { get; set; }
        [NotMapped]
        public byte? DigitAfterDecimal { get; set; }

    }
}
