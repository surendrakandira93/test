﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class SenctionOrderEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid ConveningOrderId { get; set; }
        public byte YearId { get; set; }
        public string SenctionOrderNo { get; set; }
        public DateTime SenctionDate { get; set; }
        public byte StatusId { get; set; }
        public bool IsApproved { get; set; }
        public bool IsDeleted { get; set; }
        public short DesignationId { get; set; }
        public short UnitId { get; set; }
        public string Note { get;  set; }
    }
}
