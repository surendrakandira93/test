﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanRenewalEntity:BaseEntity
    {
        public LoanRenewalEntity()
        {
            this.LoanRenewalDetail = new List<LoanRenewalDetailEntity>();
        }
        public int Id { get; set; }
        public DateTime? LoanRenewalDate { get; set; }
        public short StoreId { get; set; }
        public Guid ReleaseOrderId { get; set; }
        public Guid LoanIssueVoucherId { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string LoanIssueVoucherNo { get; set; }
        public string Remark { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public DateTime? BdDate { get; set; }
        public string BdApproveBy { get; set; }
        public string Authority { get; set; }
        public string Justification { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public bool IsApproved { get; set; }
        public List<LoanRenewalDetailEntity> LoanRenewalDetail { get; set; }
        public string UnitName { get; set; }
        public short UnitId { get; set; }
        public short LoanUnitId { get; set; }
        public short DesignationId { get; set; }
        public string StoreName { get; set; }
    }
}
