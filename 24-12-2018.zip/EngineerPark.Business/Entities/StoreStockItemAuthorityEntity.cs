﻿namespace EngineerPark.Business.Entities
{

    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Text;


    public class StoreStockItemAuthorityEntity:BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short StoreId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short AuthorizedOrganiztionId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid GroupItemId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short GroupItemBasicCategoryId { get; set; }
                
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public decimal AuthorizedQuantiy { get; set; }

        public string Remark { get; set; }


        //[NotMapped]
        //public CategoryEntity GroupItemCategory { get; set; }
        //[NotMapped]
        //public UnitOfMeasureEntity GroupItemItemUom { get; set; }

        [NotMapped]
        public string CategoryName { get; set; }
        [NotMapped]
        public string NameUnitOfMeasure { get; set; }
        [NotMapped]
        public byte? DigitAfterDecimal { get; set; }

    }
}
