﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class QuarterlyMaintenancePlanGroupDetailsReponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<QuarterlyMaintenancePlanGroupDetails> Result { get; set; }
    }

    public class QuarterlyMaintenancePlanGroupDetails
    {
        public short MaterialTypeId { get; set; }
        public string Name { get; set; }
        public float Quantity { get; set; }
        public decimal Cost { get; set; }
        public List<QuarterlyGroupItemPartEntity> PartList { get; set; }

    }
    public class QuarterlyGroupItemPartEntity
    {
        public Guid Id { get; set; }
        public Guid GroupItemId { get; set; }
        public float Quantity { get; set; }
    }
}
