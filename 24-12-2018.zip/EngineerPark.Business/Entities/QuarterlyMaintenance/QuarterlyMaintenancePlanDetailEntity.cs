﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class QuarterlyMaintenancePlanDetailEntity:BaseEntity
    {
        public QuarterlyMaintenancePlanDetailEntity()
        {
            QuarterlyMaintenancePlanDetailsGroupItem = new List<QuarterlyMaintenancePlanDetailsGroupItemEntity>();
        }

        public int Id { get; set; }
        public int QuarterlyMaintenancePlanId { get; set; }
        public short CategoryId { get; set; }
        public string CategoryName { get; set; }
        public double Quantity { get; set; }
        public double MaxQuantity { get; set; }
        public decimal Amount { get; set; }
        public List<QuarterlyMaintenancePlanDetailsGroupItemEntity> QuarterlyMaintenancePlanDetailsGroupItem { get; set; }
    }
}
