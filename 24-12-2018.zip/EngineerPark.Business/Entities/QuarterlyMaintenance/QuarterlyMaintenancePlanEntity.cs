﻿using System.Collections.Generic;

namespace EngineerPark.Business.Entities
{
    public class QuarterlyMaintenancePlanEntity:BaseEntity
    {
        public QuarterlyMaintenancePlanEntity()
        {
            QuarterlyMaintenancePlanDetail = new List<QuarterlyMaintenancePlanDetailEntity>();
        }

        public int Id { get; set; }
        public short StoreId { get; set; }
        public int QuarterId { get; set; }
        public int MaintenancePlanId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }      
        public bool IsApproved { get; set; }
        public List<QuarterlyMaintenancePlanDetailEntity> QuarterlyMaintenancePlanDetail { get; set; }
        public short DesignationId { get;  set; }
    }
}
