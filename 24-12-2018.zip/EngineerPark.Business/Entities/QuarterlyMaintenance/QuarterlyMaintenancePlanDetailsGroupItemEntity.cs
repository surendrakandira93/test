﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class QuarterlyMaintenancePlanDetailsGroupItemEntity:BaseEntity
    {
        public QuarterlyMaintenancePlanDetailsGroupItemEntity()
        {
            QuarterlyMaintenancePlanDetailsItem = new List<QuarterlyMaintenancePlanDetailsItemEntity>();
        }

        public int Id { get; set; }
        public int QuarterlyMaintenancePlanDetailId { get; set; }
        public short MaterialTypeId { get; set; }
        public double Quantity { get; set; }
        public decimal Amount { get; set; }
        public List<QuarterlyMaintenancePlanDetailsItemEntity> QuarterlyMaintenancePlanDetailsItem { get; set; }
    }
}
