﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class QuarterlyMaintenancePlanResponseEntity
    {
        public short Id { get; set; }
        public int QuarterlyMaintenancePlanId { get; set; }
        public string Name { get; set; }
        public int QuarterId { get; set; }
        public int MaintenancePlanId { get; set; }
        public short StoreId { get; set; }
        public short? ToOrganizationId { get; set; }
        public short? ToDesignationId { get; set; }
        public List<QuarterlyMaintenancePlanDetailsEntity> ItemList { get; set; }
        public List<QuarterlyMaintenancePlanDetailEntity> QuarterlyMaintenancePlanDetail { get; set; }
    }

    public class QuarterlyMaintenancePlanDetailsEntity
    {
        public Guid GroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public string GroupName { get; set; }
        public string Name { get; set; }
        public int ItemSetNumberId { get; set; }
        public string SetNo { get; set; }
        public int StockShedId { get; set; }
        public string ShedNo { get; set; }
        public double Quantiy { get; set; }
        public float PerItemQuantity { get; set; }
        public decimal Cost { get; set; }
        public string DueFrom { get; set; }
    }
}
