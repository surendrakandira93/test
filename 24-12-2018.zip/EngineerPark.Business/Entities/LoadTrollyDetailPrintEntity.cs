﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoadTrollyDetailPrintEntity
    {
        public long? RowId { get; set; }
        public Guid? Id { get; set; }
       
        public decimal LoanQuantiy { get; set; }
       
        public decimal ReturnQuantiy { get; set; }
       
        public decimal? ReceivedQuantiy { get; set; }

        public decimal? ServiceQuantiy { get; set; }

        public decimal? RepairQuantiy { get; set; }

        public string StockShadName { get; set; }

        public string Remarks { get; set; }

        public string ItemName { get; set; }

        public string UomName { get; set; }

        public int Place { get; set; }

    }

}
