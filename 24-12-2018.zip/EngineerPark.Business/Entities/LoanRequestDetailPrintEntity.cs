﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class LoanRequestDetailPrintEntity
    {
        public long? RowId { get; set; }
        public Guid? Id { get; set; }
        public Guid? LoanReqestAssignId { get; set; }
        public Guid AvailabilityCertIssueDetailId { get; set; }
        
        public string ItemName { get; set; }
      
        public string CategoryName { get; set; }
        //[Display(Name = "Eqpt Type")]
        //public string EquipmentTypeName { get; set; }
       
        public string EquipmentName { get; set; }
      

        public decimal Quantiy { get; set; }
        public short? Place { get; set; }
       
        public decimal IssueQuantiy { get; set; }
     
        public decimal RequestQuantiy { get; set; }
      
        public decimal? LoanPeriodInMonth { get; set; }
        public string Reason { get; set; }

        //As per Report
        public string OriginalSenctioningAuth { get; set; }
        public string LoanPerionFromTo { get; set; }
        public string LoanPerionMomthDays { get; set; }
        public string Task { get; set; }
        public string RequestedEP { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}
