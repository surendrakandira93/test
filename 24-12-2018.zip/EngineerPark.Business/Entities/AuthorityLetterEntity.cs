﻿using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class AuthorityLetterEntity: BaseEntity
    {
        public AuthorityLetterEntity()
        {
            this.AuthorityLetterVechileDetail = new List<AuthorityLetterVechileDetailEntity>();
        }
        public long RowId { get; set; }
        public Guid Id { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ReleaseOrderId { get; set; }
        public byte YearId { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string LetterNo { get; set; }
        public DateTime IssueDate { get; set; }
        public short UnitId { get; set; }
        public short StoreId { get; set; }
        public int IssueTo { get; set; }
        public int IssuedBy { get; set; }
        public DateTime ExpiryDate { get; set; }
        public byte StatusId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsIssued { get; set; }
        public string Remark { get; set; }

        public List<AuthorityLetterVechileDetailEntity> AuthorityLetterVechileDetail { get; set; }
        public short DesignationId { get; set; }
        public string Note { get; set; }
        public string StoreName { get;  set; }
        public string ReleaseOrderNo { get; set; }
    }
}
