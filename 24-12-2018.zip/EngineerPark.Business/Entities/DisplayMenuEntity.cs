﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class DisplayRoleMenuEntity
    {
        public DisplayRoleMenuEntity()
        {
            this.menu = new List<DisplayMenuEntity>();
        }
        public string Name { get; set; }
        public List<DisplayMenuEntity> menu { get; set; }
    }
   public class DisplayMenuEntity
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public List<byte> PermissionId { get; set; }
    }
}
