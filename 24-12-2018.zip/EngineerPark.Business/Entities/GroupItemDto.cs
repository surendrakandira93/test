﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
   public class GroupItemDto
    {
        public Guid GroupItemId { get; set; }

        public Guid ItemId { get; set; }
        public string ItemName { get; set; }
        public decimal Quantity { get; set; }
        public string AU { get; set; }

    }
}
