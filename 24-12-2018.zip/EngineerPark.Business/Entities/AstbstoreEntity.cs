﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities
{
    public class AstbstoreEntity : BaseEntity
    {
        public AstbstoreEntity()
        {
            AstbstoreDetail = new List<AstbstoreDetailEntity>();
        }

        public long RowId { get; set; }
        public Guid Id { get; set; }
        public Guid AstbconveningOrderId { get; set; }
        public Guid GroupItemId { get; set; }
        public Guid ItemId { get; set; }
        public string GroupItemName { get; set; }
        public string AU { get; set; }
        public string ItemName { get; set; }
        public short StockShedId { get; set; }
        public string StockShedName { get; set; }
        public int ItemSetNumberId { get; set; }
        public string Setnumber { get; set; }
        public decimal OP_Quantiy { get; set; }
        public decimal ISS_Quantiy { get; set; }
        public decimal DEP_Quantiy { get; set; }
        public decimal Auth_Quantiy { get; set; }
        public decimal heldQty { get; set; }
        public List<AstbstoreDetailEntity> AstbstoreDetail { get; set; }
    }

    public class Astbstoredetails
    {
        public Astbstoredetails()
        {
            this.Store = new List<AstbstoreEntity>();
        }

        public Guid AstbconveningId { get; set; }
        public short StoreId { get; set; }
        public string FileName { get; set; }
        public string StoreName { get; set; }
        public short  CategoryId { get; set; }
        public string LetterNo { get; set; }
        public short? ToDesignationId { get; set; }
        public short? ToOrganizationId { get; set; }
        public List<AstbstoreEntity> Store { get; set; }
    }
}
