﻿namespace EngineerPark.Business.Entities
{
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class StoreStockTransactionSetNoEntity : BaseEntity
    {
        public long RowId { get; set; }
        public Guid Id { get; set; }
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid StoreStockId { get; set; }

        public string SetNo { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid GroupItemId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public Guid ItemId { get; set; }
        
        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short ItemUomId { get; set; }
        public string ItemUomName { get; set; }

        public string PrimaryLedgerNo { get; set; }
        public string SecondaryLedgerNo { get; set; }
        public string PageNo { get; set; }
        public short? StockShedId { get; set; }
        public short? OriginId { get; set; }
        public decimal Quantiy { get; set; }
        public DateTime Mfgdate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public short? HeldByOrgnaizationId { get; set; }
        public string Remark { get; set; }

        public List<MasterDataEntity> GroupItemList { get; set; }
        public List<MasterDataEntity> ItemList { get; set; }
        public List<MasterDataEntity> ItemUomList { get; set; }
        public List<MasterDataEntity> OriginList { get; set; }
        public List<MasterDataEntity> StockShedList { get; set; }
        public List<MasterDataEntity> HeldByOrgnaizationList { get; set; }

    }
}
