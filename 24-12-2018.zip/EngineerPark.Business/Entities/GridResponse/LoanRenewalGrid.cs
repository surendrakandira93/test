﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
    public class LoanRenewalGrid
    {
        public int Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string LoanIssueVoucher { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public bool IsApproved { get; set; }
    }
}
