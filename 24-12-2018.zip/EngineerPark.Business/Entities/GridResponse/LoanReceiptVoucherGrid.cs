﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
    public class LoanReceiptVoucherGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string LoanReceiptVoucherNo { get; set; }
        public string SenctionNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public DateTime LoanReceiptVoucherDate { get; set; }
        public DateTime OrderDate { get; set; }
        public bool IsApproved { get; set; }
    }
}
