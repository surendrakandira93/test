﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class AvailabilityCertRequestGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string RequestNo { get; set; }
        public DateTime RequestDate { get; set; }
        public string Remark { get; set; }
        public bool IsApprove { get; set; }
        public bool IsEditAble { get; set; }
        public bool IsIssued { get; set; }
        public bool IsCreateAvbIssue { get; set; }
        public string Status { get;  set; }
        public string ApprovedDesignation { get; set; }
        public string AssignedDesignation { get; set; }
        public Guid IssueId { get; set; }

    }
}
