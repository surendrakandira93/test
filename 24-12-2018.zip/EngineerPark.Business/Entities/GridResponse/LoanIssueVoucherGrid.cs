﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
    public class LoanIssueVoucherGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string LoanIssueVoucherNo { get; set; }
        public string SenctionNo { get; set; }
        public string ReleaseOrderNo { get; set; }
        public DateTime LoanIssueVoucherDate { get; set; }
        public DateTime ReleaseDate { get; set; }
        public bool IsApproved { get; set; }
    }
}
