﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class LoanRequestGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string RequestNo { get; set; }
        public string LoanRequestNo { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime LoanDate { get; set; }
        public string Remark { get; set; }
        public bool IsApproved { get; set; }
        public bool IsReasenote { get; set; }
        public string Status { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string ApprovedDesignation { get; set; }
        public string AssignedDesignation { get; set; }
    }
}
