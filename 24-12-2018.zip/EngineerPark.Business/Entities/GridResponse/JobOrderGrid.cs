﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class JobOrderGrid
    {
        public int Id { get; set; }
        public string Authority { get; set; }
        public string StoreName { get; set; }
        public string JobOrderType { get; set; }
        public string VenderName { get; set; }
        public decimal Amount { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public bool IsApproved { get; set; }
        public bool IsEditable { get; set; }
        public bool IsComplete { get; set; }
    }
}
