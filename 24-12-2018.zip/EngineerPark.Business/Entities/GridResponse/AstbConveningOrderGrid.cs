﻿using System;

namespace EngineerPark.Business.Entities.GridResponse
{
  public  class AstbConveningOrderGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string LetterNo { get; set; }       
        public DateTime Date { get; set; }
        public bool approvedByStore { get; set; }
        public bool IsDbcomposition { get; set; }
        public bool IsApproved { get; set; }
    }
}
