﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class ReleaseOrderGrid
    {
        public Guid Id { get; set; }
        public string ConveyNoteNo { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string LoanRequestNo { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime LoanRequestDate { get; set; }

        public DateTime RequestFromDate { get; set; }
        public DateTime RequestToDate { get; set; }

        public string Note { get; set; }
        public bool IsApproved { get; set; }
    }
}
