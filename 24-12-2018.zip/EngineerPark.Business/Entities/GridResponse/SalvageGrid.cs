﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class SalvageGrid
    {
        public int Id { get; set; }
        public string OrganizationName { get; set; }
        public string StoreName { get; set; }
        public DateTime Date { get; set; }
        public double Weight { get; set; }
        public string Auth { get; set; }
        public string MaterialTypeName { get; set; }
        public string Remark { get; set; }
        public decimal Amount { get; set; }
        public string VanderName { get; set; }
        public bool IsEditable { get; set; }
    }
}
