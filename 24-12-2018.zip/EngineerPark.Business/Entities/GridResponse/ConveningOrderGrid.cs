﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
    public class ConveningOrderGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string senctionNo { get; set; }
        public string LoadTrolley { get; set; }
        public DateTime senctionDate { get; set; }
        public string ConveningOrderNo { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime? IssueDate { get; set; }
        public DateTime RequestDate { get; set; }
        public bool IsApproved { get; set; }
        public bool IsIssueOrder { get; set; }
        public bool IsMakeMember { get; set; }
        public string ApprovedDesignation { get; set; }
        public string AssignedDesignation { get; set; }
        public string Status { get; set; }
        public bool IsVerified { get; set; }
        public string FileName { get; set; }
        public bool IsEditable { get; set; }
    }
}
