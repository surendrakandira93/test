﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
  public  class ConveyNoteGrid
    {
        public string NoteNo { get; set; }
        public DateTime IssueDate { get; set; }
        public Guid Id { get; set; }
        public string StoreName { get; set; }
        public string UnitName { get; set; }
        public bool IsApprove { get; set; }
        public string LetterNo { get; set; }
        public DateTime LetterDate { get; set; }
    }
}
