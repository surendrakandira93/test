﻿namespace EngineerPark.Business.Entities.GridResponse
{
    using System;

    public class LoadTrolleyGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string LoadTrolleyNo { get; set; }
        public string senctionNo { get; set; }
        public string ConveningOrderNo { get; set; }
        public DateTime LoadTrolleyDate { get; set; }
        public DateTime OrderDate { get; set; }
        public bool IsApproved { get; set; }
    }
}
