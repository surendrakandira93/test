﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
    public class LoanExtensionGrid
    {
        public int Id { get; set; }
        public string UnitFromName { get; set; }
        public string UnitToName { get; set; }
        public string StoreName { get; set; }
        public string ReleaseOrderNo { get; set; }
        public string LoanIssueVoucher { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public string Note { get; set; }
        public bool IsApproved { get; set; }
    }
}
