﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
   public class QuarterlyMaintenancePlanGrid
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public string StoreName { get; set; }
        public string QuarterId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public bool IsApproved { get; set; }
    }
}
