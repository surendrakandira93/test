﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.Business.Entities.GridResponse
{
  public  class AvailabilityCertIssueGrid
    {
        public Guid Id { get; set; }
        public string UnitName { get; set; }
        public string StoreName { get; set; }
        public string IssueNo { get; set; }
        public string RequestNo { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime RequestDate { get; set; }
        public string Remark { get; set; }
        public bool IsApprove { get; set; }
        public bool IsLoanRequest { get; set; }
        public bool IsReject { get; set; }
        public string Status { get; set; }
    }
}
