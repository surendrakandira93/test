﻿using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EngineerPark.Business.Entities
{
  public  class UserEntity:BaseEntity
    {
        public int RowId { get; set; }
        public Guid Id { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short OrganizationId { get; set; }

        public byte? SubOrganizationTypeId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public byte UserTypeId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short RoleId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short DepartmentId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public short DesignationId { get; set; }

        public string CodePrefix { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public int Code { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string LoginName { get; set; }

        [Required(ErrorMessageResourceType = typeof(ValidationMessages), ErrorMessageResourceName = "IsRequired")]
        public string PasswordHash { get; set; }

        
        public bool IsActive { get; set; }
        public DateTime? ExpiryDate { get; set; }


        [NotMapped]
        public short OrganizationTypeId { get; set; }
        [NotMapped]
        public string OrganizationName { get; set; }
        [NotMapped]
        public string OrganizationImg { get; set; }
        [NotMapped]
        public string ParentOrganizationImg { get; set; }
        [NotMapped]
        public string DepartmentName { get; set; }
        [NotMapped]
        public string DesignationName { get; set; }
        [NotMapped]
        public DateTime ActiveDate { get; set; }
        public byte LoginAttemp { get; set; }
        public bool IsLock { get; set; }
        public DateTime? LastLogin { get; set; }

        // public DepartmentEntity Department { get; set; }
        // public DesignationEntity Designation { get; set; }
        //// public OrganizationEntity Organization { get; set; }
        // public SubOrganizationTypeEntity SubOrganizationType { get; set; }
        // public UserTypeEntity UserType { get; set; }
    }
}
