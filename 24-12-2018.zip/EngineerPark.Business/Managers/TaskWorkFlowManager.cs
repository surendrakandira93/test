﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class TaskWorkFlowManager : ITaskWorkFlowManager
    {
        private readonly IGenericRepository<TaskWorkFlow> repository;
        private readonly IGenericRepository<Data.Models.Task> taskrepository;

        private readonly IGenericRepository<Organization> orgRepository;
        private readonly IGenericRepository<Designation> degisRepository;

        private IMapper mapper;

        public TaskWorkFlowManager(IMapper mapper, IGenericRepository<TaskWorkFlow> repository, IGenericRepository<Organization> orgRepository, IGenericRepository<Designation> degisRepository, IGenericRepository<Data.Models.Task> taskrepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.orgRepository = orgRepository;
            this.degisRepository = degisRepository;
            this.taskrepository = taskrepository;
        }

        public async Task<int> DeleteAsync(short fromOrganizationId)
        {

            var existingRecords = await this.repository.FindAllAsync(x => x.FromOrganizationId == fromOrganizationId);
            if (existingRecords != null)
            {
                if (existingRecords.Any())
                {
                    this.repository.DeleteRange(existingRecords.ToList());
                    var result = await this.repository.SaveAsync();
                    return result;
                }
            }

            return 0;
        }

        public async Task<TaskWorkFlowResponseEntity> GetAsync(short fromOrganizationId, short taskId)
        {
            try
            {

                List<short> toOrgIds = new List<short>();
                TaskWorkFlowResponseEntity response = new TaskWorkFlowResponseEntity();

                if (taskId == (int)TaskTypeEnum.Issue || taskId == (int)TaskTypeEnum.Request)
                {
                    var organizations = await this.orgRepository.GetIncludingFindByAsyn(x => x.Parent != null,x => x.Include(m => m.Parent));
                    foreach (var item in organizations)
                    {
                        //toOrgIds.Add(item.Parent.Id);
                        toOrgIds.Add(item.Id);
                        response.ToOrganization.Add(new MasterDataEntity { Id = item.Id.ToString(), Name = item.Name });
                    }
                }
                else
                {
                    var organizations = await this.orgRepository.GetIncludingFindByAsyn(x => x.Id == fromOrganizationId || x.ParentId == fromOrganizationId, x => x.Include(m => m.Parent));
                    foreach (var item in organizations)
                    {
                        toOrgIds.Add(item.Id);
                        response.ToOrganization.Add(new MasterDataEntity { Id = item.Id.ToString(), Name = item.Name });
                        if (item.Id == fromOrganizationId && item.Parent != null)
                        {
                            toOrgIds.Add(item.Parent.Id);
                            response.ToOrganization.Add(new MasterDataEntity { Id = item.Parent.Id.ToString(), Name = item.Parent.Name });
                        }

                    }
                }

                


                Organization fromOrg = await orgRepository.GetAsync(fromOrganizationId);
                response.FromOrganizationName = fromOrg.Name;
                response.FromOrganizationId = fromOrganizationId;
                Data.Models.Task task = await this.taskrepository.GetAsync(byte.Parse(taskId.ToString()));
                response.TaskName = task.Name;
                response.TaskId = (byte)taskId;

                var fromdesg = await this.degisRepository.FindAllAsync(x => x.OrganizationId == fromOrganizationId);
                foreach (var item in fromdesg)
                {
                    response.FromDesignation.Add(new MasterDataEntity { Id = item.Id.ToString(), Name = item.Name });
                    TaskWorkFlow taskWorkFlow = await this.repository.FindAsync(x => x.FromOrganizationId == fromOrganizationId && x.FromDesignationId == item.Id && x.TaskId == taskId);
                    if (taskWorkFlow != null)
                    {
                        response.TaskWorkFlow.Add(this.mapper.Map<TaskWorkFlowEntity>(taskWorkFlow));
                    }
                    else
                    {
                        response.TaskWorkFlow.Add(new TaskWorkFlowEntity { FromDesignationId = item.Id, FromOrganizationId = fromOrganizationId, TaskId = (byte)taskId });

                    }
                }


                var todesg = await this.degisRepository.FindByAsyn(x => toOrgIds.Contains(x.OrganizationId));                
                foreach (var item in todesg)
                {
                    response.ToDesignation.Add(new MasterDataEntity { Id = item.Id.ToString(), Name = item.Name });
                }

                return response;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<TaskWorkFlowEntity>> InsertAsync(TaskWorkFlowResponseEntity entity)
        {
            try
            {
                var existingRecord = await this.repository.FindAllAsync(x => x.FromOrganizationId == entity.FromOrganizationId && x.TaskId == entity.TaskId);

                var existingTaskFlow = existingRecord.Where(x => entity.TaskWorkFlow.Any(scdet => scdet.Id == x.Id)).ToList();
                var deletedTaskFlow = existingRecord.Where(x => !entity.TaskWorkFlow.Any(scdet => scdet.Id == x.Id)).ToList();
                var InsertedTaskFlow = entity.TaskWorkFlow.Where(x => !existingRecord.Any(m => m.Id == x.Id)).ToList();
                if (InsertedTaskFlow.Count > 0)
                {
                    var mapped = this.mapper.Map<List<TaskWorkFlow>>(InsertedTaskFlow);
                    var result = await this.repository.AddRangeAsyn(mapped);

                }

                if (existingTaskFlow.Count > 0)
                {
                    //this.UpdateTaskFlow(existingTaskFlow, entity.TaskWorkFlow);
                    foreach (var item in existingTaskFlow)
                    {
                        var taskWork = await this.repository.GetAsync(item.Id);
                        var UpdatedItemPart = entity.TaskWorkFlow.FirstOrDefault(x => x.Id == taskWork.Id);
                        taskWork.ToDesignationId = UpdatedItemPart.ToDesignationId;
                        taskWork.FromOrganizationId = UpdatedItemPart.FromOrganizationId;
                        taskWork.FromDesignationId = UpdatedItemPart.FromDesignationId;
                        taskWork.ToOrganizationId = UpdatedItemPart.ToOrganizationId;
                        taskWork.UpdatedBy = UpdatedItemPart.UpdatedBy;
                        taskWork.CreatedDate = UpdatedItemPart.CreatedDate; await this.repository.UpdateAsync(item);
                    };
                }

                if (deletedTaskFlow.Any())
                {
                    this.repository.DeleteRange(deletedTaskFlow);
                }

                return entity.TaskWorkFlow; ;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<List<TaskWorkFlowEntity>> UpdateAsync(List<TaskWorkFlowEntity> entities)
        {
            var mapped = this.mapper.Map<List<TaskWorkFlow>>(entities);
            mapped.ForEach(x =>
            {
                this.repository.Update(x, x.Id);
            });

            var result = await this.repository.SaveAsync();

            return this.mapper.Map<List<TaskWorkFlowEntity>>(mapped);
        }

        private void UpdateTaskFlow(List<TaskWorkFlow> existingTaskflow, List<TaskWorkFlowEntity> entity)
        {
            if (existingTaskflow != null)
            {
                existingTaskflow.ForEach(taskWork =>
                {
                    var UpdatedItemPart = entity.FirstOrDefault(x => x.Id == taskWork.Id);
                    taskWork.ToDesignationId = UpdatedItemPart.ToDesignationId;
                    taskWork.FromOrganizationId = UpdatedItemPart.FromOrganizationId;
                    taskWork.FromDesignationId = UpdatedItemPart.FromDesignationId;
                    taskWork.ToOrganizationId = UpdatedItemPart.ToOrganizationId;
                    taskWork.UpdatedBy = UpdatedItemPart.UpdatedBy;
                    taskWork.CreatedDate = UpdatedItemPart.CreatedDate;


                });
            }
        }
    }
}