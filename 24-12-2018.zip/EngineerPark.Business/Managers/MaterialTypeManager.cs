﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;

    public  class MaterialTypeManager: IMaterialTypeManager
    {
        private IGenericRepository<MaterialType> repository;
        private IMapper mapper;
        public MaterialTypeManager(IMapper mapper, IGenericRepository<MaterialType> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<MaterialTypeEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<MaterialTypeEntity>>(result);
            return mapped;
        }

        public async Task<MaterialTypeEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<MaterialTypeEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<MaterialTypeEntity> InsertAsync(MaterialTypeEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<MaterialType>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<MaterialTypeEntity>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<MaterialTypeEntity> UpdateAsync(MaterialTypeEntity entity)
        {
            var mapped = this.mapper.Map<MaterialType>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id);

            return this.mapper.Map<MaterialTypeEntity>(result);
        }
    }
}