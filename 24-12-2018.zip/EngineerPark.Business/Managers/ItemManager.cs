﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class ItemManager : IItemManager
    {
        private IGenericRepository<Item> repository;
        private IGenericRepository<ItemPart> itemPartRepository;
        private IGenericRepository<ItemBasicCategory> itemBasicCategoryRepository;
        private IGenericRepository<ItemEquipment> itemEquipmentRepository;
        private IGenericRepository<ItemEquipmentType> itemEquipmentTypeRepository;
        private IMapper mapper;

        public ItemManager(IMapper mapper, IGenericRepository<Item> repository,
            IGenericRepository<ItemPart> itemPartRepository,
            IGenericRepository<ItemBasicCategory> itemBasicCategoryRepository,
            IGenericRepository<ItemEquipment> itemEquipmentRepository,
            IGenericRepository<ItemEquipmentType> itemEquipmentTypeRepository
            )
        {
            this.mapper = mapper;
            this.repository = repository;
            this.itemPartRepository = itemPartRepository;
            this.itemBasicCategoryRepository = itemBasicCategoryRepository;
            this.itemEquipmentRepository = itemEquipmentRepository;
            this.itemEquipmentTypeRepository = itemEquipmentTypeRepository;
        }

        /// <summary>
        /// Deletes the asynchronous.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(Guid id)
        {
            int result = 0;
            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, (x => x.Include(m => m.ItemPartItem).Include(y => y.ItemBasicCategory).Include(y => y.ItemEquipment).Include(y => y.ItemEquipmentType)));
            if (existingRecord != null)
            {
                if (existingRecord.ItemBasicCategory.Any())
                {
                    this.itemBasicCategoryRepository.DeleteRange(existingRecord.ItemBasicCategory.ToList());
                }
                if (existingRecord.ItemPartItem.Any())
                {
                    this.itemPartRepository.DeleteRange(existingRecord.ItemPartItem.ToList());
                }
                if (existingRecord.ItemEquipment.Any())
                {
                    this.itemEquipmentRepository.DeleteRange(existingRecord.ItemEquipment.ToList());
                }
                if (existingRecord.ItemEquipmentType.Any())
                {
                    this.itemEquipmentTypeRepository.DeleteRange(existingRecord.ItemEquipmentType.ToList());
                }
                this.repository.DeleteEntity(existingRecord);
                result = await this.repository.SaveAsync();
            }
            return result;
        }

        public async Task<IList<ItemEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<ItemEntity>>(result);
            return mapped;
        }

        public async Task<IList<ItemEntity>> GetUOMListAsync()
        {
            var result = await this.repository.GetAllIncludingAsyn(x => x.Include(m => m.ItemUom).Where(y => y.IsMaster == 0));
            var mapped = this.mapper.Map<List<ItemEntity>>(result.ToList());
            mapped.ForEach(x =>
            {
                x.ItemUomName = result.FirstOrDefault(s => s.ItemUomId == x.ItemUomId).ItemUom.Name;
            });
            return mapped;
        }
        
        public async Task<IList<ItemDetailEntity>> GetItemChildListAsync()
        {
            try
            {
                List<ItemDetailEntity> responseList = new List<ItemDetailEntity>();               
                var result = await this.repository.GetAllIncludingAsyn(x => x.Include(m => m.ItemUom).Include(y => y.ItemBasicCategory).Include("ItemBasicCategory.BasicCategory").Include(y => y.ItemEquipment).Include("ItemEquipment.Equipment").Include(y => y.ItemEquipmentType).Include("ItemEquipmentType.EquipmentType").Where(y => y.IsMaster == 0));                
                foreach(var r in result)
                {
                    ItemDetailEntity response = new ItemDetailEntity();
                    response.ItemId = r.Id;                    
                    response.BasicCategoryList = r.ItemBasicCategory.Any() ? r.ItemBasicCategory.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.BasicCategory.Name }).ToList() : new List<MasterDataEntity>();
                    response.EquipmentList = r.ItemEquipment.Any() ? r.ItemEquipment.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.Equipment.Name }).ToList() : new List<MasterDataEntity>();
                    response.EquipmentTypeList = r.ItemEquipmentType.Any() ? r.ItemEquipmentType.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.EquipmentType.Name }).ToList() : new List<MasterDataEntity>();                    
                    responseList.Add(response);
                }                
                return responseList;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
                
        public async Task<ItemDetailEntity> ItemDetailAsync(Guid id)
        {           
            ItemDetailEntity response = new ItemDetailEntity();
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(y => y.ItemBasicCategory).Include("ItemBasicCategory.BasicCategory").Include(y => y.ItemEquipment).Include("ItemEquipment.Equipment").Include(y => y.ItemEquipmentType).Include("ItemEquipmentType.EquipmentType").Include(m=>m.ItemUom));
            response.ItemId = result.Id;
            response.CatPtNo = result.CatPtNo;
            response.ItemUom = result.ItemUom.Name;
            response.ItemUomId = result.ItemUomId;
            response.Place = result.ItemUom.DigitAfterDecimal;
            response.BasicCategoryList = result.ItemBasicCategory.Any() ? result.ItemBasicCategory.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.BasicCategory.Name }).ToList() : new List<MasterDataEntity>();
            response.EquipmentList = result.ItemEquipment.Any() ? result.ItemEquipment.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.Equipment.Name }).ToList() : new List<MasterDataEntity>();
            response.EquipmentTypeList = result.ItemEquipmentType.Any() ? result.ItemEquipmentType.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.EquipmentType.Name }).ToList() : new List<MasterDataEntity>();
            return response;
        }
               
        public async Task<ItemEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id ==id, (x => x.Include(m => m.ItemPartItem).Include(y => y.ItemBasicCategory).Include(y => y.ItemEquipment).Include(y => y.ItemEquipmentType)));

            var mapped = this.mapper.Map<ItemEntity>(result);
            mapped.BasicCategoryId = result.ItemBasicCategory.Select(x => x.BasicCategoryId).ToList();
            mapped.EquipmentId = result.ItemEquipment.Select(x => x.EquipmentId).ToList();
            mapped.EquipmentTypeId = result.ItemEquipmentType.Select(x => x.EquipmentTypeId).ToList();
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters,int? isMaster)
        {
            var predicate = CustomPredicate.BuildPredicate<Item>(parameters);
            predicate = predicate.Or(x => x.MaterialType.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.ItemUom.Name.Contains(parameters.Search.Value));

            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.MaterialType).Include(m => m.ItemUom).Where(y => y.IsMaster == isMaster));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);

            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (Item)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    CatPtNo = y.CatPtNo,
                    MaterialTypeId = y.MaterialType.Name,
                    ItemUomId = y.ItemUom.Name,
                    Description = y.Description,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }
        
        public async Task<ItemEntity> InsertAsync(ItemEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Item>(entity);
                if (entity.IsMaster == 0)
                {
                    this.GetItemBasicCategory(mapped, entity.BasicCategoryId);
                    this.GetItemEquipment(mapped, entity.EquipmentId);
                    //this.GetItemItemEquipmentType(mapped, entity.EquipmentTypeId);  //Not required as per capt. sameer
                }
                
                var result = await this.repository.AddAsyn(mapped);
                return this.mapper.Map<ItemEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, Guid id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<ItemEntity> UpdateAsync(ItemEntity entity)
        {
            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, (x => x.Include(m => m.ItemPartItem).Include(y => y.ItemBasicCategory).Include(y => y.ItemEquipment).Include(y => y.ItemEquipmentType)));

            if (existingRecord != null)
            {
                #region ItemPart Updation

                if (entity.ItemPartItem != null)
                {
                    var existingItemParts = existingRecord.ItemPartItem.Where(x => entity.ItemPartItem.Any(scdet => scdet.Id == x.Id)).ToList();
                    var deletedItemParts = existingRecord.ItemPartItem.Where(x => !entity.ItemPartItem.Any(scdet => scdet.Id == x.Id)).ToList();
                    var InsertedItemParts = entity.ItemPartItem.Where(x => !existingRecord.ItemPartItem.Any(m => m.Id == x.Id)).ToList();
                    UpdateItemPart(existingItemParts, entity);

                    if (deletedItemParts.Any())
                    {
                        this.itemPartRepository.DeleteRange(deletedItemParts);
                    }

                    if (InsertedItemParts.Any())
                    {
                        AddItemPart(InsertedItemParts, existingRecord);
                    }
                }
                else if (existingRecord.ItemPartItem.Any())
                {
                    this.itemPartRepository.DeleteRange(existingRecord.ItemPartItem.ToList());
                }

                #endregion ItemPart Updation
                
                #region ItemBasicCategory Updation

                if (entity.BasicCategoryId != null)
                {
                    var existingItemBasicCategoryItem = existingRecord.ItemBasicCategory.Where(x => entity.BasicCategoryId.Any(scdet => scdet == x.BasicCategoryId)).ToList();

                    var deletedItemBasicCategoryItem = existingRecord.ItemBasicCategory.Where(x => !entity.BasicCategoryId.Any(scdet => scdet == x.BasicCategoryId)).ToList();

                    var InsertedItemBasicCategoryItem = entity.BasicCategoryId.Where(x => !existingRecord.ItemBasicCategory.Any(m => m.BasicCategoryId == x)).ToList();

                    UpdateItemBasicCategory(existingItemBasicCategoryItem, entity);

                    if (deletedItemBasicCategoryItem.Any())
                    {
                        this.itemBasicCategoryRepository.DeleteRange(deletedItemBasicCategoryItem);
                    }

                    if (InsertedItemBasicCategoryItem.Any())
                    {
                        AddItemBasicCategory(InsertedItemBasicCategoryItem, existingRecord, entity.CreatedBy);
                    }
                }
                else if (existingRecord.ItemBasicCategory.Any())
                {
                    this.itemBasicCategoryRepository.DeleteRange(existingRecord.ItemBasicCategory.ToList());
                }

                #endregion ItemBasicCategory Updation

                #region ItemEquipment Updation

                if (entity.EquipmentId != null)
                {
                    var existingItemEquipmentItem = existingRecord.ItemEquipment.Where(x => entity.EquipmentId.Any(scdet => scdet == x.EquipmentId)).ToList();

                    var deletedItemEquipmentItem = existingRecord.ItemEquipment.Where(x => !entity.EquipmentId.Any(scdet => scdet == x.EquipmentId)).ToList();

                    var InsertedItemEquipmentItem = entity.EquipmentId.Where(x => !existingRecord.ItemEquipment.Any(m => m.EquipmentId == x)).ToList();

                    UpdateItemEquipment(existingItemEquipmentItem, entity);

                    if (deletedItemEquipmentItem.Any())
                    {
                        this.itemEquipmentRepository.DeleteRange(deletedItemEquipmentItem);
                    }

                    if (InsertedItemEquipmentItem.Any())
                    {
                        AddItemEquipment(InsertedItemEquipmentItem, existingRecord, entity.CreatedBy);
                    }
                }
                else if (existingRecord.ItemEquipment.Any())
                {
                    this.itemEquipmentRepository.DeleteRange(existingRecord.ItemEquipment.ToList());
                }

                #endregion ItemEquipment Updation

                #region ItemEquipmentType Updation

                if (entity.EquipmentTypeId != null)
                {
                    var existingItemEquipmentTypeItem = existingRecord.ItemEquipmentType.Where(x => entity.EquipmentTypeId.Any(scdet => scdet == x.EquipmentTypeId)).ToList();

                    var deletedItemEquipmentTypeItem = existingRecord.ItemEquipmentType.Where(x => !entity.EquipmentTypeId.Any(scdet => scdet == x.EquipmentTypeId)).ToList();

                    var InsertedItemEquipmentTypeItem = entity.EquipmentTypeId.Where(x => !existingRecord.ItemEquipmentType.Any(m => m.EquipmentTypeId == x)).ToList();

                    UpdateItemEquipmentType(existingItemEquipmentTypeItem, entity);

                    if (deletedItemEquipmentTypeItem.Any())
                    {
                        this.itemEquipmentTypeRepository.DeleteRange(deletedItemEquipmentTypeItem);
                    }

                    if (InsertedItemEquipmentTypeItem.Any())
                    {
                        AddItemEquipmentType(InsertedItemEquipmentTypeItem, existingRecord, entity.CreatedBy);
                    }
                }
                else if (existingRecord.ItemEquipmentType.Any())
                {
                    this.itemEquipmentTypeRepository.DeleteRange(existingRecord.ItemEquipmentType.ToList());
                }

                #endregion ItemEquipmentType Updation

                UpdateItem(existingRecord, entity);
            }
            
            var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);
            return this.mapper.Map<ItemEntity>(result);                      
        }
        
        private void UpdateItem(Item existingRecord, ItemEntity entity)
        {
            existingRecord.CategoryId = entity.CategoryId;
            existingRecord.Name = entity.Name;
            existingRecord.Description = entity.Description;
            existingRecord.ItemUomId = entity.ItemUomId;
            existingRecord.Area = entity.Area;
            existingRecord.AreaUomId = entity.AreaUomId;
            existingRecord.Capacity = entity.Capacity;
            existingRecord.CapacityUomId = entity.CapacityUomId;
            existingRecord.Volume = entity.Volume;
            existingRecord.VolumeUomId = entity.VolumeUomId;
            existingRecord.Weight = entity.Weight;
            existingRecord.WeightUomId = entity.WeightUomId;
            existingRecord.MaterialTypeId = entity.MaterialTypeId;

            existingRecord.ManCarry = entity.ManCarry;
            existingRecord.Cost = entity.Cost;
            existingRecord.LoadingVehicle = entity.LoadingVehicle;
            existingRecord.ItemCritLevel = entity.ItemCritLevel;

            //existingRecord.ItemStatusId = entity.ItemStatusId.Value;
            existingRecord.CatPtNo = entity.CatPtNo;
        }
        

        private void AddItemPart(List<ItemPartsEntity> insertedItemParts, Item existingRecord)
        {
            if (insertedItemParts != null)
            {
                insertedItemParts.ForEach(x =>
                {
                    existingRecord.ItemPartItem.Add(new ItemPart()
                    {
                        ItemId = x.ItemId,
                        Quantity = x.Quantity,
                        UpdatedBy = x.UpdatedBy,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        UpdatedDate = x.UpdatedDate,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }

        private void UpdateItemPart(List<ItemPart> existingItemParts, ItemEntity entity)
        {
            if (existingItemParts != null)
            {
                existingItemParts.ForEach(ItemPart =>
                {
                    var UpdatedItemPart = entity.ItemPartItem.FirstOrDefault(x => x.Id == ItemPart.Id);

                    ItemPart.ObjectState = EntityState.Modified;
                    ItemPart.ItemId = UpdatedItemPart.ItemId;
                    ItemPart.Quantity = UpdatedItemPart.Quantity;
                });
            }
        }
        

        private void AddItemEquipment(List<short> inserted, Item existingRecord, Guid createdBy)
        {
            if (inserted != null)
            {
                inserted.ForEach(x =>
                {
                    existingRecord.ItemEquipment.Add(new ItemEquipment()
                    {
                        EquipmentId = x,
                        UpdatedBy = createdBy,
                        CreatedBy = createdBy,
                        CreatedDate = DateTime.UtcNow,
                        UpdatedDate = DateTime.UtcNow,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }

        private void UpdateItemEquipment(List<ItemEquipment> existing, ItemEntity entity)
        {
            if (existing != null)
            {
                existing.ForEach(existRecord =>
                {
                    var UpdatedRecord = entity.EquipmentId.FirstOrDefault(x => x == existRecord.EquipmentId);

                    existRecord.ObjectState = EntityState.Modified;
                    existRecord.EquipmentId = UpdatedRecord;
                });
            }
        }

        private void GetItemEquipment(Item item, List<short> equipmentId)
        {
            foreach (var id in equipmentId)
            {
                item.ItemEquipment.Add(new ItemEquipment
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ItemId = item.Id,
                    EquipmentId = id,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    ObjectState = EntityState.Added
                });
            }
        }


        private void AddItemBasicCategory(List<short> inserted, Item existingRecord, Guid createdBy)
        {
            if (inserted != null)
            {
                inserted.ForEach(x =>
                {
                    existingRecord.ItemBasicCategory.Add(new ItemBasicCategory()
                    {
                        BasicCategoryId = x,
                        UpdatedBy = createdBy,
                        CreatedBy = createdBy,
                        CreatedDate = DateTime.UtcNow,
                        UpdatedDate = DateTime.UtcNow,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }

        private void UpdateItemBasicCategory(List<ItemBasicCategory> existing, ItemEntity entity)
        {
            if (existing != null)
            {
                existing.ForEach(existRecord =>
                {
                    var UpdatedRecord = entity.BasicCategoryId.FirstOrDefault(x => x == existRecord.BasicCategoryId);

                    existRecord.ObjectState = EntityState.Modified;
                    existRecord.BasicCategoryId = UpdatedRecord;
                });
            }
        }

        private void GetItemBasicCategory(Item item, List<short> basicCategoriesId)
        {
            foreach (var id in basicCategoriesId)
            {
                item.ItemBasicCategory.Add(new ItemBasicCategory
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    BasicCategoryId = id,
                    ItemId = item.Id,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    ObjectState = EntityState.Added
                });
            }
        }


        private void AddItemEquipmentType(List<short> inserted, Item existingRecord, Guid createdBy)
        {
            if (inserted != null)
            {
                inserted.ForEach(x =>
                {
                    existingRecord.ItemEquipmentType.Add(new ItemEquipmentType()
                    {
                        EquipmentTypeId = x,
                        UpdatedBy = createdBy,
                        CreatedBy = createdBy,
                        CreatedDate = DateTime.UtcNow,
                        UpdatedDate = DateTime.UtcNow,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }
        
        private void UpdateItemEquipmentType(List<ItemEquipmentType> existing, ItemEntity entity)
        {
            if (existing != null)
            {
                existing.ForEach(existRecord =>
                {
                    var UpdatedRecord = entity.EquipmentTypeId.FirstOrDefault(x => x == existRecord.EquipmentTypeId);

                    existRecord.ObjectState = EntityState.Modified;
                    existRecord.EquipmentTypeId = UpdatedRecord;
                });
            }
        }

        private void GetItemItemEquipmentType(Item item, List<short> equipmentId)
        {
            foreach (var id in equipmentId)
            {
                item.ItemEquipmentType.Add(new ItemEquipmentType
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ItemId = item.Id,
                    EquipmentTypeId = id,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    ObjectState = EntityState.Added
                });
            }
        }
    }
}