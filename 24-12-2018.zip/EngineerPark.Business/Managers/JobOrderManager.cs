﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class JobOrderManager : IJobOrderManager
    {
        private IGenericRepository<GroupItem> repository;
        private readonly IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<GroupItemDetail> groupitemdetailrepository;
        private readonly string Connectionstring;
        private IGenericRepository<Category> repositoryCategory;
        private IGenericRepository<JobOrder> repositoryJobOrder;
        private IGenericRepository<JobOrderDetail> repositoryJobOrderDetail;
        private IGenericRepository<JobOrderDetailsGroupItem> repositoryJobOrderDetailsGroupItem;
        private IGenericRepository<JobOrderDetailsItem> repositoryJobOrderDetailsItem;
        private readonly IGenericRepository<StoreStock> storeStockRepository;
        private readonly IGenericRepository<StoreStockTransaction> stockTransactionRepository;
        private IGenericRepository<JobOrderTemp> repositoryJobOrderTemp;
        private IGenericRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan;
        private IGenericRepository<MaterialType> repositoryMaterialType;
        private IMapper mapper;

        public JobOrderManager(IMapper mapper, IGenericRepository<GroupItem> repository, IGenericRepository<GroupItemDetail> groupitemdetailrepository, IGenericRepository<Category> repositoryCategory, IGenericRepository<JobOrder> repositoryJobOrder, IGenericRepository<JobOrderDetail> repositoryJobOrderDetail, IGenericRepository<JobOrderDetailsGroupItem> repositoryJobOrderDetailsGroupItem, IGenericRepository<JobOrderDetailsItem> repositoryJobOrderDetailsItem, IGenericRepository<TaskWorkFlow> taskworkRepository,
            IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransaction> stockTransactionRepository, IGenericRepository<JobOrderTemp> repositoryJobOrderTemp, IGenericRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan, IGenericRepository<MaterialType> repositoryMaterialType)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.groupitemdetailrepository = groupitemdetailrepository;
            this.repositoryCategory = repositoryCategory;
            this.repositoryJobOrder = repositoryJobOrder;
            this.repositoryJobOrderDetail = repositoryJobOrderDetail;
            this.repositoryJobOrderDetailsGroupItem = repositoryJobOrderDetailsGroupItem;
            this.repositoryJobOrderDetailsItem = repositoryJobOrderDetailsItem;
            this.taskworkRepository = taskworkRepository;
            this.storeStockRepository = storeStockRepository;
            this.stockTransactionRepository = stockTransactionRepository;
            this.repositoryJobOrderTemp = repositoryJobOrderTemp;
            this.repositoryQuarterlyMaintenancePlan = repositoryQuarterlyMaintenancePlan;
            this.repositoryMaterialType = repositoryMaterialType;
        }


        public async Task<JobOrderDetailsReponse> GetJobOrderDetailsAsync(short categoryId, int quarterlyMaintenancePlanId, short organizationId)
        {
            try
            {
                var quarterlyMaintenancePlan =await repositoryQuarterlyMaintenancePlan.GetIncludingByIdAsyn(x => x.Id == quarterlyMaintenancePlanId && x.StoreId == organizationId && x.IsApproved, x => x.Include(m => m.QuarterlyMaintenancePlanDetail).Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem"));

          

                JobOrderDetailsReponse response = new JobOrderDetailsReponse();
                var category = await repositoryCategory.GetAsync(categoryId);
                response.Id = categoryId;
                response.Name = category.Name;
                response.Result = this.repositoryMaterialType.GetAllIncludingIQueryableAsyn(x => x.IsActive == true && x.Item.Any(y => y.GroupItemDetail.Any()), x => x.Include(m => m.Item).Include("Item.GroupItemDetail")).Select(x => new JobOrderGroupDetails { MaterialTypeId = x.Id, Name = x.Name, PartList = x.Item.Select(y => new JobOrderGroupItemPartEntity { Id = y.Id, Quantity = 0 }).ToList() }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<JobOrderResponseEntity> GetJobOrderItemDetailsAsync(short materialTypeId, int quarterlyMaintenancePlanId, short organizationId,short categoryId)
        {
            try
            {
                JobOrderResponseEntity response = new JobOrderResponseEntity();
              //  var category = await repository.GetAsync(groupId);
                response.Id = materialTypeId;
               // response.Name = category.Name;
                var ds = SqlHelper.ExecuteDataset(this.Connectionstring, "GetJobOrderDetails", new SqlParameter("@MaterialTypeId", materialTypeId), new SqlParameter("@CategoryId", categoryId), new SqlParameter("@StoreId", organizationId), new SqlParameter("@QuarterlyMaintenancePlanId", quarterlyMaintenancePlanId));
                List<QuarterlyMaintenancePlanItemDetailsModel> result = new List<QuarterlyMaintenancePlanItemDetailsModel>();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        result.Add(new QuarterlyMaintenancePlanItemDetailsModel(row));

                    }
                }
                response.ItemList = result.Select(x => new JobOrderDetailsEntity { GroupItemId= x.GroupItemId, Cost = x.Cost, DueFrom = x.DueFrom.ToString("dd/MM/yyyy"), ItemId = x.ItemId,GroupName=x.GroupName, ItemSetNumberId = x.ItemSetNumberId, Name = x.Name, Quantiy = x.Quantity, SetNo = x.SetNo, ShedNo = x.ShedNo, StockShedId = x.StockShedId, PerItemQuantity = x.PerItemQuantity }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<JobOrderEntity> InsertJobOrderAsync(JobOrderEntity entity)
        {
            JobOrder dataEntity = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.StoreId == entity.StoreId && !x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));

            if (dataEntity == null)
            {
                dataEntity = new JobOrder();
                dataEntity.CreatedBy = entity.CreatedBy;
                dataEntity.CreatedDate = entity.CreatedDate;
                dataEntity.JobOrderTypeId = entity.JobOrderTypeId;
                dataEntity.FromDate = entity.FromDate;
                dataEntity.ToDate = entity.ToDate;


                dataEntity.Amount = entity.Amount;
                dataEntity.Authority = entity.Authority;
                dataEntity.File = entity.File;
                dataEntity.JobOrderNo = entity.JobOrderNo;
                dataEntity.MaintenancePlanId = entity.MaintenancePlanId;
                dataEntity.QuarterlyMaintenancePlanId = entity.QuarterlyMaintenancePlanId;
                dataEntity.VenderName = entity.VenderName;

                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;
            }
            else
            {
                dataEntity.JobOrderTypeId = entity.JobOrderTypeId;
                dataEntity.FromDate = entity.FromDate;
                dataEntity.ToDate = entity.ToDate;


                dataEntity.Amount = entity.Amount;
                dataEntity.Authority = entity.Authority;
                dataEntity.File = entity.File;
                dataEntity.JobOrderNo = entity.JobOrderNo;
                dataEntity.MaintenancePlanId = entity.MaintenancePlanId;
                dataEntity.QuarterlyMaintenancePlanId = entity.QuarterlyMaintenancePlanId;
                dataEntity.VenderName = entity.VenderName;

                dataEntity.JobOrderTypeId = entity.JobOrderTypeId;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;

                foreach (var item in dataEntity.JobOrderDetail.ToList())
                {

                    foreach (var group in item.JobOrderDetailsGroupItem.ToList())
                    {
                        foreach (var items in group.JobOrderDetailsItem.ToList())
                        {
                            await repositoryJobOrderDetailsItem.DeleteAsyn(items.Id);
                        }


                        await repositoryJobOrderDetailsGroupItem.DeleteAsyn(group.Id);
                    }

                    await repositoryJobOrderDetail.DeleteAsyn(item.Id);

                }                
            }

            var task = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.JobOrder && x.FromOrganizationId == entity.StoreId && x.FromDesignationId == entity.DesignationId);
            if (task != null && task.ToDesignationId.HasValue)
            {
                dataEntity.ToDesignationId = task.ToDesignationId;
                dataEntity.ToOrganizationId = task.ToOrganizationId;
            }

            foreach (var item in entity.JobOrderDetail)
            {
                JobOrderDetail detail = new JobOrderDetail();
                detail.JobOrderId = dataEntity.Id;
                detail.Quantity = item.Quantity;
                detail.Amount = item.Amount;
                detail.CategoryId = item.CategoryId;
                detail.CreatedBy = item.CreatedBy;
                detail.CreatedDate = item.CreatedDate;
                detail.UpdatedBy = item.UpdatedBy;
                detail.UpdatedDate = item.UpdatedDate;
                item.JobOrderDetailsGroupItem.ForEach(x =>
                {
                    detail.JobOrderDetailsGroupItem.Add(new JobOrderDetailsGroupItem
                    {
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        MaterialTypeId = x.MaterialTypeId,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        Amount = x.Amount,
                        Quantity = x.Quantity,
                        JobOrderDetailsItem = x.JobOrderDetailsItem.Select(y => new JobOrderDetailsItem
                        {
                            CreatedBy = y.CreatedBy,
                            CreatedDate = y.CreatedDate,
                            GroupItemId=y.GroupItemId,
                            ItemId = y.ItemId,
                            ItemSetNumberId = y.ItemSetNumberId,
                            StockShedId = y.StockShedId,
                            UpdatedBy = y.UpdatedBy,
                            UpdatedDate = y.UpdatedDate,
                            Amount = y.Amount,
                            Quantity = y.Quantity
                        }).ToList()


                    });
                });

                if (dataEntity.Id > 0)
                {
                    await repositoryJobOrderDetail.AddAsyn(detail);
                }
                else
                {
                    dataEntity.JobOrderDetail.Add(detail);
                }
            }

            if (dataEntity.Id > 0)
            {
                await this.repositoryJobOrder.UpdateAsync(dataEntity, dataEntity.Id);

            }
            else
            {
                await this.repositoryJobOrder.AddAsyn(dataEntity);
            }

            return entity;
        }

        public async Task<JobOrderResponseEntity> GetApprovedAsync(int id, short orgId, short desId)
        {

            JobOrderResponseEntity response = new JobOrderResponseEntity();
            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.JobOrder && x.FromOrganizationId == orgId && x.FromDesignationId == desId && x.ToOrganizationId != null && x.ToDesignationId != null);

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }

            var result = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id == id && !x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));
            if (result != null)
            {
           
                response.JobOrderId = result.Id;
                response.JobOrderTypeId = result.JobOrderTypeId;
                response.Amount = result.Amount;
                response.Authority = result.Authority;
                response.File = result.File;
                response.FromDate = result.FromDate;
                response.JobOrderId = result.Id;
                response.JobOrderNo = result.JobOrderNo;
                response.MaintenancePlanId = result.MaintenancePlanId;
                response.QuarterlyMaintenancePlanId = result.QuarterlyMaintenancePlanId;
                response.ToDate = result.ToDate;
                response.VenderName = result.VenderName;                
                response.StoreId = result.StoreId;
                response.JobOrderDetail = this.mapper.Map<List<JobOrderDetailEntity>>(result.JobOrderDetail);
                response.JobOrderDetail.ForEach(x =>
                {
                    x.CategoryName = result.JobOrderDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                });
            }

            return response;

        }

        public async Task<JobOrderApprovalEntity> InsertApproveAsync(JobOrderApprovalEntity entity)
        {
            try
            {
                bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.JobOrder && x.FromOrganizationId == entity.OrgId && x.FromDesignationId == entity.DestId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

                //var oldResult = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id == entity.JobOrderId, x => x.Include(m => m.JobOrderApproval));

                JobOrder oldResult = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id == entity.JobOrderId && !x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));

                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;
                oldResult.JobOrderApproval.Add(new JobOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DestId,
                    FromOrganizationId = entity.OrgId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    JobOrderId = oldResult.Id
                });

                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IsApproved = entity.IsApproved;
                    List<StoreStock> storeData = new List<StoreStock>();

                    List<JobOrderTemp> jobOrderTemp = new List<JobOrderTemp>();

                    List<Guid> groupList = new List<Guid>();


                    foreach (var item in oldResult.JobOrderDetail.ToList())
                    {



                        foreach (var group in item.JobOrderDetailsGroupItem.ToList())
                        {
                            groupList=group.JobOrderDetailsItem.Select(x => x.GroupItemId.Value).ToList();


                        

                        foreach (var groupId in groupList.Distinct())
                        {

                        
                            var stockStoreQty = storeStockRepository.FindAll(x => x.GroupItemId == groupId && !x.IsStockOut).FirstOrDefault();
                            StoreStock store = new StoreStock();
                            store.CreatedBy = oldResult.CreatedBy;
                            store.CreatedDate = DateTime.Now;
                            store.GroupItemId = groupId;
                            store.IsStockOut = true;
                            store.StoreId = oldResult.StoreId;
                            store.TransactionDate = DateTime.Now;
                            store.TransactionTypeId = (int)TransactionTypeEnum.JobOrderOut;
                            store.UpdatedBy = oldResult.UpdatedBy;
                            store.UpdatedDate = DateTime.Now;
                            foreach (var items in group.JobOrderDetailsItem.Where(g=>g.GroupItemId==groupId).ToList())
                            {
                                var stockQty = stockTransactionRepository.FindAll(x => x.ItemId == items.ItemId).FirstOrDefault();
                                StoreStockTransaction stockTrans = new StoreStockTransaction();
                                stockTrans.CreatedBy = item.CreatedBy;
                                stockTrans.CreatedDate = DateTime.Now;
                                stockTrans.ItemId = items.ItemId;
                                stockTrans.ItemSetNumber = items.ItemSetNumber;
                                stockTrans.ItemSetNumberId = items.ItemSetNumberId;
                                stockTrans.ItemUomId = stockQty.ItemUomId;
                                stockTrans.StockShedId = items.StockShedId;
                                stockTrans.UpdatedBy = items.CreatedBy;
                                stockTrans.CreatedDate = DateTime.Now;
                                stockTrans.StoreStockTransactionQuantity.Add(new StoreStockTransactionQuantity { CreatedBy = items.CreatedBy, CreatedDate = DateTime.Now, ItemStatusId = (int)ItemStatusEnum.Repairable, Quantiy = decimal.Parse(items.Quantity.ToString()), UpdatedBy = items.UpdatedBy, UpdatedDate = DateTime.Now });
                                store.StoreStockTransaction.Add(stockTrans);
                            }

                            storeData.Add(store);

                            jobOrderTemp.Add(new JobOrderTemp { GroupItemId = groupId, JobOrderId = oldResult.Id, TransactionDate = stockStoreQty.TransactionDate });


                        }
                        }

                    }

                    await storeStockRepository.AddRangeAsyn(storeData);
                    await repositoryJobOrderTemp.AddRangeAsyn(jobOrderTemp);
                }

                var result = await this.repositoryJobOrder.UpdateAsync(oldResult, oldResult.Id);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public async Task<JobOrderResponseEntity> GetActionAsync(int id)
        {

            JobOrderResponseEntity response = new JobOrderResponseEntity();
            
            var result = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id == id && x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));
            if (result != null)
            {

                response.JobOrderId = result.Id;
                response.JobOrderTypeId = result.JobOrderTypeId;
                response.Amount = result.Amount;
                response.Authority = result.Authority;
                response.File = result.File;
                response.FromDate = result.FromDate;
                response.JobOrderId = result.Id;
                response.JobOrderNo = result.JobOrderNo;
                response.MaintenancePlanId = result.MaintenancePlanId;
                response.QuarterlyMaintenancePlanId = result.QuarterlyMaintenancePlanId;
                response.ToDate = result.ToDate;
                response.VenderName = result.VenderName;
                response.StoreId = result.StoreId;
                response.JobOrderDetail = this.mapper.Map<List<JobOrderDetailEntity>>(result.JobOrderDetail);
                response.JobOrderDetail.ForEach(x =>
                {
                    x.CategoryName = result.JobOrderDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                });
            }

            return response;

        }

        public async Task<JobOrderActionEntity> InsertActionAsync(JobOrderActionEntity entity)
        {
            try
            {

                List<Guid> groupList = new List<Guid>();
                JobOrder oldResult = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id == entity.Id && x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));

                if (entity.Status.HasValue)
                {
                    if ((JobOrderStatus)entity.Status.Value == JobOrderStatus.Complete)
                    {
                        oldResult.CompletionDate = entity.CompletionDate;
                    }
                    else
                    {
                        oldResult.CancellationDate = entity.CancellationDate;
                        oldResult.Justification = entity.Justification;
                    }
                    oldResult.Status = entity.Status;

                    List<StoreStock> storeData = new List<StoreStock>();                    

                    foreach (var item in oldResult.JobOrderDetail.ToList())
                    {
                        foreach (var group in item.JobOrderDetailsGroupItem.ToList())
                        {
                            groupList = group.JobOrderDetailsItem.Select(x => x.GroupItemId.Value).ToList();
                            
                            foreach (var groupId in groupList.Distinct())
                            {
                                DateTime TransactionDate = DateTime.Now;

                                if ((JobOrderStatus)entity.Status.Value == JobOrderStatus.Cancel)
                                {
                                    var jobOrderTemp = repositoryJobOrderTemp.Find(x => x.JobOrderId == oldResult.Id && x.GroupItemId == groupId);
                                    TransactionDate = jobOrderTemp.TransactionDate;
                                }
                                StoreStock store = new StoreStock();
                                store.CreatedBy = group.CreatedBy;
                                store.CreatedDate = DateTime.Now;
                                store.GroupItemId = groupId;
                                store.IsStockOut = true;
                                store.StoreId = oldResult.StoreId;
                                store.TransactionDate = TransactionDate;
                                store.TransactionTypeId = (int)TransactionTypeEnum.JobOrderOut;
                                store.UpdatedBy = group.UpdatedBy;
                                store.UpdatedDate = DateTime.Now;
                                foreach (var items in group.JobOrderDetailsItem.Where(g => g.GroupItemId == groupId).ToList())
                                {
                                    var stockQty = stockTransactionRepository.FindAll(x => x.ItemId == items.ItemId).FirstOrDefault();
                                    StoreStockTransaction stockTrans = new StoreStockTransaction();
                                    stockTrans.CreatedBy = item.CreatedBy;
                                    stockTrans.CreatedDate = DateTime.Now;
                                    stockTrans.ItemId = items.ItemId;
                                    stockTrans.ItemSetNumber = items.ItemSetNumber;
                                    stockTrans.ItemSetNumberId = items.ItemSetNumberId;
                                    stockTrans.ItemUomId = stockQty.ItemUomId;
                                    stockTrans.StockShedId = items.StockShedId;
                                    stockTrans.UpdatedBy = items.CreatedBy;
                                    stockTrans.CreatedDate = DateTime.Now;
                                    stockTrans.StoreStockTransactionQuantity.Add(new StoreStockTransactionQuantity { CreatedBy = items.CreatedBy, CreatedDate = DateTime.Now, ItemStatusId = (int)ItemStatusEnum.Repairable, Quantiy = decimal.Parse(items.Quantity.ToString()), UpdatedBy = items.UpdatedBy, UpdatedDate = DateTime.Now });
                                    store.StoreStockTransaction.Add(stockTrans);
                                }

                                storeData.Add(store);
                            }
                        }

                    }

                    await storeStockRepository.AddRangeAsyn(storeData);

                    var result = await this.repositoryJobOrder.UpdateAsync(oldResult, oldResult.Id);
                }

                
                
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public async Task<JobOrderEntity> GetJobOrderAsync(int id, short organizationId)
        {
            var response = new JobOrderEntity();
            try
            {

                var result = await this.repositoryJobOrder.GetIncludingByIdAsyn(x => x.Id==id && x.StoreId == organizationId  && !x.IsApproved, x => x.Include(m => m.JobOrderDetail).Include("JobOrderDetail.Category").Include("JobOrderDetail.JobOrderDetailsGroupItem").Include("JobOrderDetail.JobOrderDetailsGroupItem.JobOrderDetailsItem"));
                if (result != null)
                {
                    response = this.mapper.Map<JobOrderEntity>(result);
                    response.JobOrderDetail.ForEach(x =>
                    {
                        x.CategoryName = result.JobOrderDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                    });
                }
                else
                {
                    response = new JobOrderEntity();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


            return response;
        }


        public async Task<DataTableResult> GetJobOrderPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<JobOrder> query = this.repositoryJobOrder.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId || (x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId) || x.JobOrderApproval.Any(a => a.FromOrganizationId == parameters.OrganizationId && a.FromDesignationId == parameters.DesignationId), x => x.Include(m => m.Store).Include(m => m.JobOrderApproval).Include(m => m.ToOrganization).Include(m => m.JobOrderDetail));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (JobOrder)x;

                var fromWork = y.JobOrderApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.JobOrderApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.IsApproved;
                requiredData.Add(new JobOrderGrid
                {
                    StoreName = y.Store.Name,
                    Id = y.Id,
                    FromDate = y.FromDate,
                    ToDate=y.ToDate,
                    JobOrderType = Utilities.GetEnumDescription((JobOrderType)y.JobOrderTypeId),
                    VenderName=y.VenderName,
                    Authority=y.Authority,
                    Amount = y.JobOrderDetail.Sum(s => s.Amount),
                    IsApproved = y.JobOrderApproval.Any(a => a.FromOrganizationId == parameters.OrganizationId && a.FromDesignationId == parameters.DesignationId) || (y.IsApproved && y.ToOrganizationId == parameters.OrganizationId && y.ToDesignationId == parameters.DesignationId) || y.StoreId == parameters.OrganizationId,
                    IsEditable=!y.IsApproved && !y.JobOrderApproval.Any(),
                    IsComplete=y.IsApproved&&!y.Status.HasValue
                });
            }

            response.Data = requiredData;
            return response;
        }

    }
}
