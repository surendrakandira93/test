﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.Business.Entities.GridResponse;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class ConveyNoteManager : IConveyNoteManager
    {
        private IGenericRepository<ConveyNote> repository;
        private IGenericRepository<AuthorityLetter> authorityRepository;
        private IGenericRepository<ReleaseOrderDetail> releaseOrderDetailRepository;
        private IGenericRepository<StoreStock> storeStockRepository;
        private IGenericRepository<StoreStockTransaction> transactionRepository;
        private IGenericRepository<CurrentStockQuantitySetWiseView> CurrentStockQuantitySetWiseRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;

        public ConveyNoteManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<ConveyNote> repository,
            IGenericRepository<AuthorityLetter> authorityRepository, IGenericRepository<ReleaseOrderDetail> releaseOrderDetailRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransaction> transactionRepository, IGenericRepository<CurrentStockQuantitySetWiseView> CurrentStockQuantitySetWiseRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.authorityRepository = authorityRepository;
            this.releaseOrderDetailRepository = releaseOrderDetailRepository;
            this.storeStockRepository = storeStockRepository;
            this.transactionRepository = transactionRepository;
            this.CurrentStockQuantitySetWiseRepository = CurrentStockQuantitySetWiseRepository;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
        }


        public async Task<ConveyNoteEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, (x => x.Include(m => m.ConveyNoteDetail).Include("ConveyNoteDetail.ItemBasicCategory").Include("ConveyNoteDetail.ItemEquipment").Include("ConveyNoteDetail.ItemEquipmentType")));
            var mapped = this.mapper.Map<ConveyNoteEntity>(result);
            return mapped;
        }

        public async Task<ConveyNoteEntity> GetByIdAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
             .Include(m => m.ConveyNoteDetail)
             .Include(m => m.AuthorityLetterVechileDetail)
             .Include("ConveyNoteDetail.ItemBasicCategory")
             .Include("ConveyNoteDetail.ItemBasicCategory.BasicCategory")
             .Include("ConveyNoteDetail.Item")
             .Include("ConveyNoteDetail.Item.ItemUom")
             .Include("ConveyNoteDetail.ItemEquipment")
             .Include("ConveyNoteDetail.ItemEquipment.Equipment")
             .Include("ConveyNoteDetail.ItemSetNumber")
             .Include("ConveyNoteDetail.StockShed")
             .Include("ConveyNoteDetail.GroupItem"));
            var mapped = this.mapper.Map<ConveyNoteEntity>(result);
            mapped.DriverDetails = $"{result.AuthorityLetterVechileDetail.DriverName}({result.AuthorityLetterVechileDetail.VechileNo})";
            mapped.StoreName = result.Store.Name;
            mapped.ConveyNoteDetail.ForEach(x =>
            {
                var detail = result.ConveyNoteDetail.FirstOrDefault(f => f.Id == x.Id);
                x.ItemName = detail.Item.Name;
                x.ItemUomName = detail.Item.ItemUom.Name;
                x.Place = detail.Item.ItemUom.DigitAfterDecimal;
                x.GroupItemName = detail.GroupItem.Name;
                x.BasicCategoryName = detail.ItemBasicCategory.BasicCategory.Name;
                x.EquipmentName = detail.ItemEquipment.Equipment.Name;
                x.StockShedName = detail.StockShed.Name;
                x.ItemSetNumberName = detail.ItemSetNumber.Name;
            });
            return mapped;
        }

        public async Task<ConveyNoteModelPrintEntity> GetAsyncForPrint(Guid id)
        {
            ConveyNoteModelPrintEntity CNPE = new ConveyNoteModelPrintEntity();
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Store).Include(m => m.AuthorityLetter).Include(m => m.AuthorityLetterVechileDetail).Include(m => m.GatePass)
            .Include(m => m.ConveyNoteDetail)
            .Include("ConveyNoteDetail.Item")
            .Include("ConveyNoteDetail.Item.ItemUom")
            ).Where(X => X.Id == id).FirstOrDefault();

            if (query != null)
            {
                CNPE.AuthLetterDate = query.AuthorityLetter.IssueDate;
                CNPE.AuthLetterNo = query.AuthorityLetter.LetterNo;
                CNPE.ConveyNoteNo = query.NoteNo;
                CNPE.IssueDate = query.IssueDate;
                CNPE.StoreName = query.Store.Name;
                CNPE.AuthorityLetterModel = this.mapper.Map<AuthorityLetterEntity>(query.AuthorityLetter);
                CNPE.ConveyNoteModel = this.mapper.Map<ConveyNoteEntity>(query);

                CNPE.CollectedBy = $"{query.AuthorityLetterVechileDetail.DriverName} ({query.AuthorityLetterVechileDetail.DriverCode})";
                CNPE.VehicleNo = query.AuthorityLetterVechileDetail.VechileNo;

                if (query.GatePass.FirstOrDefault() != null)
                {
                    CNPE.GetPassNo = query.GatePass.FirstOrDefault().GatePassNo;
                    CNPE.GetPassDate = query.GatePass.FirstOrDefault().CreatedDate;
                }
                var FromOrg = await Organization.GetAsync(query.StoreId);
                var userReq = Usermgr.Get(query.CreatedBy);
                var ToOrg = await Organization.GetAsync(query.AuthorityLetter.UnitId);
                CNPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(FromOrg);
                CNPE.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(ToOrg);
                var user = Usermgr.Get(query.CreatedBy);
                CNPE.userDetail = this.mapper.Map<UserEntity>(user);

            }
            if (query.ConveyNoteDetail.Count > 0)
            {
                foreach (var Item in query.ConveyNoteDetail)
                {
                    ConveyNoteDetailPrintEntity cn = new ConveyNoteDetailPrintEntity();
                    cn.ItemName = Item.Item.Name;
                    cn.UOMName = Item.Item.ItemUom.Name;
                    cn.quantity = Item.Quantiy;
                    cn.Place = Item.Item.ItemUom.DigitAfterDecimal;
                    cn.Remark = Item.Remark;

                    CNPE.ConveyNoteDetailPrint.Add(cn);
                }
            }


            return CNPE;
        }
        public async Task<DataTableResult> GetAuthorityLetterPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            //IQueryable<AuthorityLetter> query = this.authorityRepository.GetAllIncludingIQueryableAsyn(x => x.ReleaseOrder.LoanRequest.LoanRequestAssign.Where(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId).Count() > 0, x => x.Include(m => m.ReleaseOrder).Include("ReleaseOrder.LoanRequest").Include(m => m.Store).Include(m => m.Unit).Include(m => m.ConveyNote));
            IQueryable<AuthorityLetter> query = this.authorityRepository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ReleaseOrder).Include("ReleaseOrder.LoanRequest").Include(m => m.AuthorityLetterVechileDetail).Include(m => m.Store).Include(m => m.Unit).Include(m => m.ConveyNote));

            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AuthorityLetter)x;
                requiredData.Add(new AuthorityLetterGrid
                {
                    Id = y.Id,
                    LoanRequestDate = y.ReleaseOrder.LoanRequest.RequestDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    LoanRequestNo = y.ReleaseOrder.LoanRequest.LoanRequestNo,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    UnitName = y.Unit.Name,
                    LetterNo = y.LetterNo,
                    IssueDate = y.IssueDate,
                    IsApproved = y.AuthorityLetterVechileDetail.Count != y.ConveyNote.Count()
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            //var query = this.repository.GetAll();
            var query = this.repository.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId,x =>x.Include(m => m.Store).Include(m => m.AuthorityLetter).Include(m => m.AuthorityLetter.Unit).Include(m => m.GatePass));
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            DataTableResult response = new DataTableResult();
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            response.Data.ForEach(x =>
            {
                var y = (ConveyNote)x;
                requiredData.Add(new ConveyNoteGrid
                {
                    Id = y.Id,
                    IssueDate = y.IssueDate,
                    StoreName = y.Store.Name,
                    UnitName=y.AuthorityLetter.Unit.Name,
                    NoteNo = y.NoteNo,
                    LetterNo = y.AuthorityLetter.LetterNo,
                    LetterDate = y.AuthorityLetter.IssueDate,
                    IsApprove = y.GatePass.Count() == 0
                });
            });
            response.Data = requiredData;
            return response;
        }

        public async Task<dynamic> GetVechiList(Guid authorityLetterId)
        {
            try
            {


                AuthorityLetter query = await this.authorityRepository.GetIncludingByIdAsyn(x => x.Id == authorityLetterId, x => x.Include(m => m.AuthorityLetterVechileDetail).Include(m => m.ConveyNote).Include("ConveyNote.ConveyNoteDetail").Include(m => m.Store));
                List<MasterDataEntity> vechialList = query.AuthorityLetterVechileDetail.Where(c => c.ConveyNote.Count() == 0).Select(x => new MasterDataEntity { Name = $"{x.DriverName}({x.VechileNo})", Id = x.Id.ToString() }).ToList();
                IQueryable<ReleaseOrderDetail> orderDetails = this.releaseOrderDetailRepository.GetAllIncludingIQueryableAsyn(x => x.ReleaseOrderId == query.ReleaseOrderId, x => x.Include(m => m.Item).Include(m => m.ItemEquipment).Include("ItemEquipment.Equipment").Include(m => m.ItemBasicCategory).Include("ItemBasicCategory.BasicCategory").Include(m => m.ReleaseOrder));
                List<MasterDataEntity> itemList = new List<MasterDataEntity>();
                List<ConveyNoteDetailEntity> itemDetails = new List<ConveyNoteDetailEntity>();
                var converyNote = this.repository.GetAllIncludingIQueryableAsyn(x => x.AuthorityLetterId == authorityLetterId, x => x.Include(m => m.ConveyNoteDetail));


                foreach (var item in orderDetails)
                {
                    var qty = converyNote.Where(s => s.ConveyNoteDetail.Any(x => x.ItemId == item.ItemId)).Sum(s => s.ConveyNoteDetail.Where(x => x.ItemId == item.ItemId).Sum(x => x.Quantiy));

                    ConveyNoteDetailEntity itemDetail = new ConveyNoteDetailEntity();
                    itemDetail.EquipmentName = item.ItemEquipment.Equipment.Name;
                    itemDetail.ItemEquipmentId = item.ItemEquipmentId;
                    itemDetail.BasicCategoryName = item.ItemBasicCategory.BasicCategory.Name;
                    itemDetail.ItemBasicCategoryId = item.ItemBasicCategoryId;
                    itemDetail.ItemId = item.ItemId;
                    itemDetail.ItemUomId = item.Item.ItemUomId;
                    itemDetail.Quantiy = item.Quantiy;
                    itemDetail.AvailableQuantity = item.Quantiy - qty;
                    var setNos = this.storeStockRepository.GetAllIncludingIQueryableAsyn(x => x.StoreStockTransaction.Any(a => a.ItemId == item.ItemId), x => x.Include(m => m.GroupItem));
                    itemDetail.GroupItemList = setNos.Select(x => new MasterDataEntity { Id = x.GroupItemId.ToString(), Name = x.GroupItem.Name }).Distinct().ToList();
                    itemList.Add(new MasterDataEntity
                    {
                        Name = item.Item.Name,
                        Id = item.ItemId.ToString(),
                        AdditionalValue = (item.Quantiy - qty).ToString()

                    });
                    if (itemDetail.AvailableQuantity.HasValue && itemDetail.AvailableQuantity.Value > 0.0M)
                    {
                        itemDetails.Add(itemDetail);
                    }
                }
                return new { vechialList = vechialList, itemList = itemList, itemDetail = itemDetails, storeId = query.StoreId, storeName = query.Store.Name };
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<dynamic> GetItemCategories(Guid itemId, Guid authorityLetterId)
        {
            AuthorityLetter query = await this.authorityRepository.GetAsync(authorityLetterId);

            IQueryable<ReleaseOrderDetail> orderDetails = this.releaseOrderDetailRepository.GetAllIncludingIQueryableAsyn(x => x.ReleaseOrderId == query.ReleaseOrderId && x.ItemId == itemId, x => x.Include(m => m.ItemBasicCategory).Include(m => m.ItemBasicCategory.BasicCategory).Include(m => m.ItemEquipment).Include(m => m.ItemEquipment.Equipment).Include(m => m.ItemEquipmentType).Include(m => m.ItemEquipmentType.EquipmentType));
            List<MasterDataEntity> BasicCategoryList = orderDetails.Select(x => new MasterDataEntity { Id = x.ItemBasicCategoryId.ToString(), Name = x.ItemBasicCategory.BasicCategory.Name, AdditionalValue = x.Item.ItemUomId.ToString() }).ToList();
            List<MasterDataEntity> EquipmentTypeList = orderDetails.Select(x => new MasterDataEntity { Id = x.ItemEquipmentTypeId.ToString(), Name = x.ItemEquipmentType.EquipmentType.Name }).ToList();
            List<MasterDataEntity> EquipmentList = orderDetails.Select(x => new MasterDataEntity { Id = x.ItemEquipmentId.ToString(), Name = x.ItemEquipment.Equipment.Name }).ToList();

            var groupItem = this.storeStockRepository.GetAllIncludingIQueryableAsyn(x => x.StoreStockTransaction.Any(a => a.ItemId == itemId), x => x.Include(m => m.GroupItem)).Distinct();
            var groupItemList = groupItem.Select(x => new MasterDataEntity { Id = x.GroupItemId.ToString(), Name = x.GroupItem.Name }).Distinct().ToList();


            return new { BasicCategoryList = BasicCategoryList, EquipmentTypeList = EquipmentTypeList, EquipmentList = EquipmentList, GroupItemList = groupItemList };
        }

        public async Task<ConveyNoteEntity> InsertAsync(ConveyNoteEntity entity)
        {
            try
            {
                entity.ConveyNoteDetail.ForEach(x =>
                {
                    x.Id = Guid.NewGuid();
                });
                var mapped = this.mapper.Map<ConveyNote>(entity);
                mapped.Store = null;
                foreach (var item in mapped.ConveyNoteDetail)
                {
                    item.GroupItem = null;
                    item.Item = null;
                    item.ItemSetNumber = null;
                    item.StockShed = null;

                }
                await this.repository.AddAsyn(mapped);

                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(Guid authorityLetterId, Guid authorityLetterVechileDetailId, Guid id)
        {
            var record = await this.repository.FindAllAsync(x => x.AuthorityLetterId == authorityLetterId && x.AuthorityLetterVechileDetailId == authorityLetterVechileDetailId && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public List<MasterDataEntity> GetGroupItems(Guid itemId)
        {
            var setNos = this.storeStockRepository.GetAllIncludingIQueryableAsyn(x => x.StoreStockTransaction.Any(a => a.ItemId == itemId), x => x.Include(m => m.GroupItem));
            return setNos.Select(x => new MasterDataEntity { Id = x.GroupItemId.ToString(), Name = x.GroupItem.Name }).Distinct().ToList();
        }

        public List<MasterDataEntity> GetStockShed(Guid itemId, Guid itemGroupId)
        {
            var stockshed = this.transactionRepository.GetAllIncludingIQueryableAsyn(x => x.ItemId == itemId && x.StoreStock.GroupItemId == itemGroupId, x => x.Include(m => m.StockShed)).Distinct();
            List<MasterDataEntity> response = new List<MasterDataEntity>();
            foreach (var x in stockshed)
            {
                if (!response.Any(a => a.Id.ToLower() == x.StockShedId.ToString().ToLower()))
                    response.Add(new MasterDataEntity { Id = x.StockShedId.ToString(), Name = x.StockShed.Name });
            }
            return response.OrderBy(x => x.Id).ToList();
        }

        public async Task<List<MasterDataEntity>> GetSetNo(Guid itemId, Guid itemGroupId, short stockShedId, short storeId, Guid authorityLetterId)
        {
            try
            {
                var setNos = this.transactionRepository.GetAllIncludingIQueryableAsyn(x => x.ItemId == itemId && x.StoreStock.GroupItemId == itemGroupId && x.StockShedId == stockShedId, x => x.Include(m => m.StockShed).Include(m => m.ItemSetNumber).Include(m => m.StoreStockTransactionQuantity)).ToList();
                List<MasterDataEntity> serNoList = new List<MasterDataEntity>();
                foreach (var item in setNos)
                {
                    //var qty = this.repository.GetAllIncludingIQueryableAsyn(x => x.AuthorityLetterId == authorityLetterId && x.ConveyNoteDetail.Where(w => w.ItemId == itemId).Count() > 0, m => m.Include(c => c.ConveyNoteDetail));
                    var stockQty = await this.CurrentStockQuantitySetWiseRepository.FindAsync(q => q.StoreId == storeId && q.ItemId == itemId && q.ItemSetNumberId == item.ItemSetNumberId && q.GroupItemId == itemGroupId && q.StockShedId == stockShedId);
                    if (!serNoList.Any(a => a.Id.ToLower() == item.ItemSetNumberId.ToString().ToLower()))
                        serNoList.Add(new MasterDataEntity { Id = item.ItemSetNumberId.ToString(), Name = item.ItemSetNumber.Name, AdditionalValue = (stockQty != null ? stockQty.currentQuantity : 0.0M).ToString() });
                }
                return serNoList.OrderBy(x => x.Id).ToList();
            }
            catch (Exception ex)
            {
                throw;
            }
        }


    }
}