﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Data.Entity;

    public class StockShedManager : IStockShedManager
    {
        private IGenericRepository<StockShed> repository;
        private IMapper mapper;
        public StockShedManager(IMapper mapper, IGenericRepository<StockShed> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<StockShedEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<StockShedEntity>>(result);
            return mapped;
        }

        public async Task<StockShedEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<StockShedEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<StockShed>(parameters);
            predicate = predicate.Or(x => x.Organization.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.ShedType.Name.Contains(parameters.Search.Value));
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Organization).Include(m => m.ShedType));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (StockShed)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    Description = y.Description,
                    OrganizationName = y.Organization.Name,
                    ShedTypeName=y.ShedType.Name,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<StockShedEntity> InsertAsync(StockShedEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<StockShed>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<StockShedEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<StockShedEntity> UpdateAsync(StockShedEntity entity)
        {
            var mapped = this.mapper.Map<StockShed>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<StockShedEntity>(result);
        }
    }
}
