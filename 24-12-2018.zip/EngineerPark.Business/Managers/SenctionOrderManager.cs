﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class SenctionOrderManager: ISenctionOrderManager
    {
        private IGenericRepository<ConveningOrder> conveningOrderRepository;
        private IGenericRepository<SenctionOrder> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IMapper mapper;

        public SenctionOrderManager(IMapper mapper, IGenericRepository<SenctionOrder> repository, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<ConveningOrder> conveningOrderRepository)
        {
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.conveningOrderRepository = conveningOrderRepository;
            this.mapper = mapper;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.SenctionOrder && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;
            IQueryable<SenctionOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m =>m.SenctionOrderApproval).Include(m=>m.ConveningOrder).Include(m=>m.ConveningOrder.ReleaseOrder));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (SenctionOrder)x;
                var fromWork = y.SenctionOrderApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.SenctionOrderApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null;
                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.ConveningOrderId,
                    senctionNo=y.SenctionOrderNo,
                    senctionDate=y.SenctionDate,
                    ConveningOrderNo = y.ConveningOrder.ConveningOrderNo,
                    IssueDate=y.ConveningOrder.IssueDate,
                    ReleaseOrderNo = y.ConveningOrder.ReleaseOrder.ReleaseOrderNo,
                    ReleaseDate = y.ConveningOrder.ReleaseOrder.ReleaseDate,
                    IsApproved = isApproved
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            bool isApplicableForSectionOrder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.SenctionOrder && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId != null && x.ToDesignationId != null) != null;
            IQueryable<ConveningOrder> query = this.conveningOrderRepository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.ConveningOrderItemSurvey").Include(m=>m.SenctionOrder).Include(m=>m.AssignedDesignation).Include(m=>m.ApprovedDesignation)
           .Include(m => m.ReleaseOrder).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveningOrder)x;
                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrderNo,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    IssueDate=y.IssueDate,
                    UnitName = y.Unit.Name,
                    IsApproved = y.IsApproved &&  y.ConveningOrderItem.Count()>0 && y.ConveningOrderItemSurveyMain.Count()>0&&y.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved && y.SenctionOrder==null,
                    ApprovedDesignation = y.ApprovedDesignation.Name,
                    AssignedDesignation = y.AssignedDesignation.Name,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId)
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<ConveningOrderEntity> GetAsync(Guid id)
        {
               var result = await this.conveningOrderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m=>m.SenctionOrder).Include(m => m.ReleaseOrder).Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType").Include("ConveningOrderItem.ConveningOrderItemSurvey").Include("ConveningOrderItem.ConveningOrderItemSurvey.ItemStatus"));
            var response = new ConveningOrderEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreId = result.StoreId;
            response.SenctionNo = result.SenctionOrder != null ? result.SenctionOrder.SenctionOrderNo : string.Empty;
            response.StoreName = result.Store.Name;
            foreach (var item in result.ConveningOrderItem)
            {
                List<ConveningOrderItemSurvey_SectionOrder_Entity> itemStatus = new List<ConveningOrderItemSurvey_SectionOrder_Entity>();
                
                response.ConveningOrderItem.Add(new ConveningOrderItemEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                   // ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                    ItemName = item.Item.Name,
                    ItemId = item.ItemId,
                    LoanQuantiy = item.LoanQuantiy,
                    ReceivedQuantiy = item.ReceivedQuantiy,
                    ReturnQuantiy = item.ReturnQuantiy,
                    ConveningOrderId = item.ConveningOrderId,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Id = item.Id,
                    Remarks = item.Remarks,
                    RowId = item.RowId,
                    RowVersion = item.RowVersion,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    Survey= item.ConveningOrderItemSurvey.Select(x=>new ConveningOrderItemSurvey_SectionOrder_Entity {
                        ItemStatusId=x.ItemStatusId,
                        ItemStatusName=x.ItemStatus.Name,
                        Quantiy=x.Quantiy
                    }).ToList()

                });
            }
           
            return response;
        }
        
        public async Task<SenctionOrderEntity> InsertAsync(SenctionOrderEntity entity)
        {
            try
            {
                if (!entity.IsApproved)
                {
                    var oldResult = this.conveningOrderRepository.Find(x => x.Id == entity.ConveningOrderId);
                    oldResult.StatusId = entity.StatusId;
                    oldResult.IsApproved = entity.IsApproved;
                    oldResult.IsActive = entity.IsApproved;
                    oldResult.ApprovedDesignationId = entity.DesignationId;
                    await this.conveningOrderRepository.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);
                    return entity;
                }


                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.SenctionOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<SenctionOrder>(entity);

                if (workFlow != null)
                {
                    mapped.SenctionOrderApproval.Add(new SenctionOrderApproval
                    {
                        Id =Guid.NewGuid(),
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        SenctionOrderId=entity.ConveningOrderId,
                        Note = entity.Note

                    });
                }
                var result = await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<SenctionOrderEntity> ApproveAsync(SenctionOrderEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.ConveningOrderId == entity.ConveningOrderId,x=>x.Include(m=>m.SenctionOrderApproval));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.SenctionOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                if (workFlow != null)
                {
                    oldResult.SenctionOrderApproval.Add(new SenctionOrderApproval
                    {
                        Id = Guid.NewGuid(),
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note = entity.Note,
                        SenctionOrderId=entity.ConveningOrderId
                    });
                }

                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }     


    }
}