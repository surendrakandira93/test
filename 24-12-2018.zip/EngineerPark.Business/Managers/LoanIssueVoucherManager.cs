﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.Business.Entities.GridResponse;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class LoanIssueVoucherManager: ILoanIssueVoucherManager
    {
        private IGenericRepository<LoanIssueVoucher> repository;
        private IGenericRepository<ReleaseOrder> releaseOrderRepository;
        private IGenericRepository<ConveyNote> conveyRepository;
        private IGenericRepository<StoreStock> storeStockRepository;
        private IMapper mapper;
        private IGenericRepository<ConveningOrder> repositoryConvening;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;
        public LoanIssueVoucherManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<LoanIssueVoucher> repository, IGenericRepository<ReleaseOrder> releaseOrderRepository, IGenericRepository<ConveyNote> conveyRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<ConveningOrder> repositoryConvening)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.releaseOrderRepository = releaseOrderRepository;
            this.conveyRepository = conveyRepository;
            this.storeStockRepository = storeStockRepository;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
            this.repositoryConvening = repositoryConvening;
        }

        public async Task<DataTableResult> GetReleaseOrderPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            IQueryable<ReleaseOrder> query = this.releaseOrderRepository.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId && x.AuthorityLetter.Any(a=>a.ConveyNote.Any()),x => x.Include(m => m.Store)
            .Include(m => m.LoanIssueVoucher)
             .Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    ReleaseDate = y.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsApproved = y.LoanIssueVoucher.Count() == 0
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<LoanIssueVoucher> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId,x => x.Include(m => m.ReleaseOrder));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoanIssueVoucher)x;
                requiredData.Add(new LoanIssueVoucherGrid
                {
                    Id = y.Id,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    LoanIssueVoucherNo = y.VoucherNo,
                    LoanIssueVoucherDate = y.VoucherDate,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate
                });
            }

            response.Data = requiredData;
            return response;
        }


        public async Task<LoanIssueVoucherPrintEntity> GetAsyncForPrint(Guid id)
        {
            LoanIssueVoucherPrintEntity CNPE = new LoanIssueVoucherPrintEntity();
           // var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Store).Include(m => m.AuthorityLetter).Include(m => m.GatePass)
             var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ReleaseOrder).Include(m => m.Store).Include("ReleaseOrder.LoanRequest").Include("ReleaseOrder.AuthorityLetter").Include("ReleaseOrder.AuthorityLetter.ConveyNote").Include("ReleaseOrder.AuthorityLetter.ConveyNote.GatePass")
            .Include(m => m.LoanIssueVoucherDetail)
            .Include("LoanIssueVoucherDetail.Item")
            .Include("LoanIssueVoucherDetail.Item.ItemUom")
            ).Where(X => X.Id == id).FirstOrDefault();

            if (query != null)
            {
                CNPE.VoucherNumber = query.VoucherNo;
                //CNPE.AuthLetterDate = query.ReleaseOrder.AuthorityLetter;
                //CNPE.AuthLetterNo = query.AuthorityLetter.LetterNo;
                //CNPE.ConveyNoteNo = query.NoteNo;
                 CNPE.IssueDate = query.CreatedDate;
                 CNPE.StoreName = query.Store.Name;
                CNPE.AuthLetterNo = query.ReleaseOrder.AuthorityLetter.FirstOrDefault().LetterNo;
                CNPE.AuthLetterDate = query.ReleaseOrder.AuthorityLetter.FirstOrDefault().IssueDate;

                CNPE.GetPassNo = query.ReleaseOrder.AuthorityLetter.FirstOrDefault().ConveyNote.FirstOrDefault().GatePass.FirstOrDefault().GatePassNo;
                CNPE.GetPassDate = query.ReleaseOrder.AuthorityLetter.FirstOrDefault().ConveyNote.FirstOrDefault().GatePass.FirstOrDefault().IssueDate;
                //}
                var FromOrg = await Organization.GetAsync(query.StoreId);
                //var userReq = await Usermgr.GetAsync(query.ReleaseOrder.LoanRequest.UnitId);
                var ToOrg = await Organization.GetAsync(query.ReleaseOrder.LoanRequest.UnitId);
                CNPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(FromOrg);
                CNPE.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(ToOrg);
                var user = Usermgr.Get(query.CreatedBy);
                CNPE.userDetail = this.mapper.Map<UserEntity>(user);

            }
            if (query.LoanIssueVoucherDetail.Count > 0)
            {
                foreach (var Item in query.LoanIssueVoucherDetail)
                {
                    LoanIssueVoucherPrintDetailEntity cn = new LoanIssueVoucherPrintDetailEntity();
                    cn.ItemName = Item.Item.Name;
                    cn.UOMName = Item.Item.ItemUom.Name;
                    cn.quantity = Item.Quantiy;
                    cn.Place = Item.Item.ItemUom.DigitAfterDecimal;
                    cn.Remark = Item.Remark;

                    CNPE.LoanIssueVoucherPrintDetail.Add(cn);
                }
            }
            return CNPE;
        }
        public async Task<LoanIssueVoucherEntity> GetAsync(Guid id)
        {
            var result = await this.releaseOrderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
             .Include(m => m.ReleaseOrderDetail)
             .Include("ReleaseOrderDetail.ItemBasicCategory").Include("ReleaseOrderDetail.Item")
             .Include("ReleaseOrderDetail.ItemBasicCategory.BasicCategory").Include("ReleaseOrderDetail.ItemEquipment")
             .Include("ReleaseOrderDetail.ItemEquipment.Equipment"));
            var response = new LoanIssueVoucherEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrderNo;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            foreach (var item in result.ReleaseOrderDetail)
            {
                response.LoanIssueVoucherDetail.Add(new LoanIssueVoucherDetailEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                    ItemName = item.Item.Name,
                    ItemId = item.ItemId,
                    Quantiy=item.Quantiy
                });
            }

            return response;
        }

        public async Task<LoanIssueVoucherEntity> GetByIdAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
             .Include(m => m.ReleaseOrder)
             .Include(m => m.LoanIssueVoucherDetail)
             .Include("LoanIssueVoucherDetail.ItemBasicCategory")
            .Include("LoanIssueVoucherDetail.ItemBasicCategory.BasicCategory")
            .Include("LoanIssueVoucherDetail.Item")
            .Include("LoanIssueVoucherDetail.Item.ItemUom")
            .Include("LoanIssueVoucherDetail.ItemEquipment")
            .Include("LoanIssueVoucherDetail.ItemEquipment.Equipment"));

            var mapped = this.mapper.Map<LoanIssueVoucherEntity>(result);
            mapped.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            mapped.StoreName = result.Store.Name;
            mapped.LoanIssueVoucherDetail.ForEach(x => {
                var detail = result.LoanIssueVoucherDetail.FirstOrDefault(f => f.Id == x.Id);
                x.ItemName = detail.Item.Name;
                x.ItemUomName = detail.Item.ItemUom.Name;
                x.Place = detail.Item.ItemUom.DigitAfterDecimal;
                x.ItemBasicCategoryName = detail.ItemBasicCategory.BasicCategory.Name;
                x.ItemEquipmentName = detail.ItemEquipment.Equipment.Name;
            });
            return mapped;

        }

        public async Task<LoanIssueVoucherEntity> InsertAsync(LoanIssueVoucherEntity entity)
        {
            try
            {
                var releaseOrder = await this.releaseOrderRepository.GetIncludingByIdAsyn(x => x.Id == entity.ReleaseOrderId, x => x.Include(m => m.AuthorityLetter).Include(m=>m.LoanRequest).Include(m => m.LoanRequest.LoanRequestAssign));
                var authorityLetter = releaseOrder.AuthorityLetter.FirstOrDefault();
                var conveyNotes =await this.conveyRepository.GetIncludingFindByAsyn(x=>x.AuthorityLetterId== authorityLetter.Id, x=>x.Include(m=>m.ConveyNoteDetail).Include("ConveyNoteDetail.Item"));
                foreach (var conveyNote in conveyNotes)
                {
                    foreach (var item in conveyNote.ConveyNoteDetail)
                    {
                        List<StoreStockTransactionQuantity> stQuantity = new List<StoreStockTransactionQuantity>();
                        StoreStock storestock = new StoreStock();
                        storestock.CreatedBy = entity.CreatedBy;
                        storestock.CreatedDate = entity.CreatedDate;
                        //storestock.GroupItemId = item.GroupItemId.Value;
                        storestock.GroupItemId = item.GroupItemId;
                        storestock.IsStockOut = true;
                        storestock.StoreId = entity.StoreId;
                        storestock.TransactionDate = DateTime.Now;
                        storestock.TransactionRefId = authorityLetter.Id;
                        storestock.TransactionTypeId = (int)TransactionTypeEnum.Issue;
                        storestock.UpdatedBy = item.UpdatedBy;
                        storestock.UpdatedDate = item.UpdatedDate;
                        stQuantity.Add(new StoreStockTransactionQuantity
                        {
                            CreatedBy = entity.CreatedBy,
                            CreatedDate = entity.CreatedDate,
                            //IsBlockQuantity=true,
                            ItemStatusId = (int)ItemStatusEnum.Serviceable,
                            Quantiy = item.Quantiy,
                            UpdatedBy = item.UpdatedBy,
                            UpdatedDate = item.CreatedDate
                        });
                        storestock.StoreStockTransaction.Add(new StoreStockTransaction
                        {
                            CreatedBy = item.CreatedBy,
                            UpdatedDate = item.UpdatedDate,
                            UpdatedBy = item.UpdatedBy,
                            CreatedDate = item.CreatedDate,
                            ItemId = item.ItemId,
                            ItemUomId = item.Item.ItemUomId,
                            PageNo = string.Empty,
                            PrimaryLedgerNo = string.Empty,
                            StockShedId = item.StockShedId,
                            Remark = item.Remark,
                            SecondaryLedgerNo = string.Empty,
                            StoreStockTransactionQuantity = stQuantity,
                            ItemSetNumberId = item.ItemSetNumberId


                        });

                        await this.storeStockRepository.AddAsyn(storestock);
                    }

                    conveyNote.StatusId = (int)StatusEnum.IssuedReleaseOrder;
                    await this.conveyRepository.UpdateAsync(conveyNote, conveyNote.Id);
                }
                var mapped = this.mapper.Map<LoanIssueVoucher>(entity);

                var conveningModel = new ConveningOrder();
                conveningModel.ApprovedDesignationId = releaseOrder.LoanRequest.LoanRequestAssign.Where(x => x.FromOrganizationId == releaseOrder.LoanRequest.UnitId).FirstOrDefault().FromDesignationId;
                conveningModel.AssignedDesignationId = entity.DesignationId;
                conveningModel.ConveningOrderNo = entity.ConveningOrderNo;
                conveningModel.ReleaseOrderId = releaseOrder.Id;
                conveningModel.StoreId = entity.StoreId;
                conveningModel.IsApproved = true;
                conveningModel.RequestDate = DateTime.Now;
                conveningModel.UnitId = entity.UnitId;
                conveningModel.CreatedBy = entity.CreatedBy;
                conveningModel.CreatedDate = entity.CreatedDate;
                conveningModel.UpdatedBy = entity.UpdatedBy;
                conveningModel.UpdatedDate = entity.UpdatedDate;
                conveningModel.StatusId = (int)StatusEnum.RequestForConveningOrder;
                foreach (var item in entity.LoanIssueVoucherDetail)
                {
                    conveningModel.ConveningOrderItem.Add(new ConveningOrderItem {
                        CreatedBy=entity.CreatedBy,
                        CreatedDate=entity.CreatedDate,
                        ItemBasicCategoryId=item.ItemBasicCategoryId,
                        ItemEquipmentId=item.ItemEquipmentId,
                        ItemId=item.ItemId,
                        LoanQuantiy=item.Quantiy,                        
                        ReturnQuantiy= item.Quantiy,
                        Remarks=item.Remark,
                        UpdatedBy=item.UpdatedBy,
                        UpdatedDate=item.UpdatedDate
                        
                    });
                }
                conveningModel.ConveningOrderApproval.Add(new ConveningOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = releaseOrder.LoanRequest.LoanRequestAssign.Where(x => x.FromOrganizationId == releaseOrder.LoanRequest.UnitId).FirstOrDefault().FromDesignationId,
                    ToOrganizationId = releaseOrder.LoanRequest.UnitId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = string.Empty

                });

                releaseOrder.StatusId = (int)StatusEnum.LoanRecived;
                await  this.releaseOrderRepository.UpdateAsync(releaseOrder, releaseOrder.Id);
                var result = await this.repository.AddAsyn(mapped);
                await this.repositoryConvening.AddAsyn(conveningModel);

                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }        
    }
}