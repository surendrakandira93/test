﻿

namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class SalvageManager : ISalvageManager
    {
        private IGenericRepository<SalvageIn> repositoryIn;
        private IGenericRepository<SalvageOut> repositoryOut;
        private IMapper mapper;
        public SalvageManager(IMapper mapper,IGenericRepository<SalvageIn> repositoryIn, IGenericRepository<SalvageOut> repositoryOut)
        {
            this.repositoryIn = repositoryIn;
            this.repositoryOut = repositoryOut;
            this.mapper = mapper;

        }

        public async Task<DataTableResult> GetPaggedInListAsync(DataTableParameter parameters)
        {


            DataTableResult response = new DataTableResult();

            IQueryable<SalvageIn> query = this.repositoryIn.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.MaterialType).Include(m => m.Store).Include(m => m.Organization));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (SalvageIn)x;
                requiredData.Add(new SalvageGrid
                {
                    Id = y.Id,
                    MaterialTypeName = y.MaterialType.Name,
                    StoreName = y.Store.Name,
                    Weight = y.Weight,
                    Auth = y.Auth,
                    Date = y.Date,
                    OrganizationName = y.Organization.Name,
                    Remark = y.Remark,
                    IsEditable=y.CreatedDate.Date==DateTime.Now.Date
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedOutListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<SalvageOut> query = this.repositoryOut.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.MaterialType).Include(m => m.Store));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (SalvageOut)x;
                requiredData.Add(new SalvageGrid
                {
                    Id = y.Id,
                    MaterialTypeName = y.MaterialType.Name,
                    StoreName = y.Store.Name,
                    Weight = y.Weight,
                    Auth = y.Auth,
                    Date = y.Date,
                    VanderName = y.VendarName,
                    Amount = y.Amount,
                    Remark = y.Remark,
                    IsEditable = y.CreatedDate.Date == DateTime.Now.Date
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<SalvageInEntity> InsertInAsync(SalvageInEntity entity)
        {
            try
            {
                if (entity.Id > 0)
                {
                                       var oldResult = this.repositoryIn.Find(x => x.Id == entity.Id);
                    if (oldResult.CreatedDate.Date == DateTime.Now.Date)
                    {
                        oldResult.OrganizationId = entity.OrganizationId;
                        oldResult.StoreId = entity.StoreId;
                        oldResult.Auth = entity.Auth;
                        oldResult.Weight = entity.Weight;
                        oldResult.Date = entity.Date;
                        oldResult.MaterialTypeId = entity.MaterialTypeId;
                        oldResult.Remark = entity.Remark;
                        oldResult.UpdatedBy = entity.UpdatedBy;
                        oldResult.UpdatedDate = entity.UpdatedDate;
                        await this.repositoryIn.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);
                    }
                    return entity;
                }
                else
                {
                    var newResult = new SalvageIn();
                    newResult.OrganizationId = entity.OrganizationId;
                    newResult.StoreId = entity.StoreId;
                    newResult.Auth = entity.Auth;
                    newResult.Weight = entity.Weight;
                    newResult.Date = entity.Date;
                    newResult.MaterialTypeId = entity.MaterialTypeId;
                    newResult.Remark = entity.Remark;
                    newResult.UpdatedBy = entity.UpdatedBy;
                    newResult.UpdatedDate = entity.UpdatedDate;
                    newResult.CreatedBy = entity.CreatedBy;
                    newResult.CreatedDate = DateTime.Now;
                    await this.repositoryIn.AddAsyn(newResult);
                    return entity;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<SalvageOutEntity> InsertOutAsync(SalvageOutEntity entity)
        {
            try
            {
                if (entity.Id > 0)
                {
                    var oldResult = this.repositoryOut.Find(x => x.Id == entity.Id);
                    if (oldResult.CreatedDate.Date == DateTime.Now.Date)
                    {
                        oldResult.VendarName = entity.VendarName;
                        oldResult.Amount = entity.Amount;
                        oldResult.StoreId = entity.StoreId;
                        oldResult.Auth = entity.Auth;
                        oldResult.Weight = entity.Weight;
                        oldResult.Date = entity.Date;
                        oldResult.MaterialTypeId = entity.MaterialTypeId;
                        oldResult.Remark = entity.Remark;
                        oldResult.UpdatedBy = entity.UpdatedBy;
                        oldResult.UpdatedDate = entity.UpdatedDate;                        
                        await this.repositoryOut.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);
                    }
                    return entity;
                }
                else
                {
                    var newResult = new SalvageOut();
                    newResult.VendarName = entity.VendarName;
                    newResult.Amount = entity.Amount;
                    newResult.StoreId = entity.StoreId;
                    newResult.Auth = entity.Auth;
                    newResult.Weight = entity.Weight;
                    newResult.Date = entity.Date;
                    newResult.MaterialTypeId = entity.MaterialTypeId;
                    newResult.Remark = entity.Remark;
                    newResult.UpdatedBy = entity.UpdatedBy;
                    newResult.UpdatedDate = entity.UpdatedDate;
                    newResult.CreatedBy = entity.CreatedBy;
                    newResult.CreatedDate = DateTime.Now;
                    await this.repositoryOut.AddAsyn(newResult);
                    return entity;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<SalvageInEntity> GetInAsync(int id)
        {
            var result = await this.repositoryIn.GetAsync(id);
            var mapped = this.mapper.Map<SalvageInEntity>(result);
            return mapped;
        }

        public async Task<SalvageOutEntity> GetOutAsync(int id)
        {
            var result = await this.repositoryOut.GetAsync(id);
            var mapped = this.mapper.Map<SalvageOutEntity>(result);
            return mapped;
        }

        public async Task<double> GetAvailableQty(short storeId, short materialTypeId)
        {
            try
            {
                var salInt = repositoryIn.FindAll(x => x.StoreId == storeId && x.MaterialTypeId == materialTypeId).Sum(x => x.Weight);
                var salOut=repositoryOut.FindAll(x => x.StoreId == storeId && x.MaterialTypeId == materialTypeId).Sum(x => x.Weight);
                return salInt - salOut;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return 0.0;
            }
        }
    }
}
