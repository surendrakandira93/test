﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EngineerPark.Business.Managers
{
    public class QuarterlyMaintenancePlanManager : IQuarterlyMaintenancePlanManager
    {
        private IGenericRepository<GroupItem> repository;
        private readonly IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<GroupItemDetail> groupitemdetailrepository;        
        private readonly string Connectionstring;
        private IGenericRepository<Category> repositoryCategory;
        private IGenericRepository<MaterialType> repositoryMaterialType;
        private IGenericRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan;
        private IGenericRepository<QuarterlyMaintenancePlanDetail> repositoryQuarterlyMaintenancePlanDetail;
        private IGenericRepository<QuarterlyMaintenancePlanDetailsGroupItem> repositoryQuarterlyMaintenancePlanDetailsGroupItem;
        private IGenericRepository<QuarterlyMaintenancePlanDetailsItem> repositoryQuarterlyMaintenancePlanDetailsItem;
        private IGenericRepository<MaintenanceSchedulePlan> repositoryMaintenanceSchedulePlan;
        private IMapper mapper;

        public QuarterlyMaintenancePlanManager(IMapper mapper, IGenericRepository<GroupItem> repository, IGenericRepository<GroupItemDetail> groupitemdetailrepository,  IGenericRepository<Category> repositoryCategory, IGenericRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan, IGenericRepository<QuarterlyMaintenancePlanDetail> repositoryQuarterlyMaintenancePlanDetail, IGenericRepository<QuarterlyMaintenancePlanDetailsGroupItem> repositoryQuarterlyMaintenancePlanDetailsGroupItem, IGenericRepository<QuarterlyMaintenancePlanDetailsItem> repositoryQuarterlyMaintenancePlanDetailsItem, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<MaterialType> repositoryMaterialType, IGenericRepository<MaintenanceSchedulePlan> repositoryMaintenanceSchedulePlan)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.groupitemdetailrepository = groupitemdetailrepository;
            this.repositoryCategory = repositoryCategory;
            this.repositoryQuarterlyMaintenancePlan = repositoryQuarterlyMaintenancePlan;
            this.repositoryQuarterlyMaintenancePlanDetail = repositoryQuarterlyMaintenancePlanDetail;
            this.repositoryQuarterlyMaintenancePlanDetailsGroupItem = repositoryQuarterlyMaintenancePlanDetailsGroupItem;
            this.repositoryQuarterlyMaintenancePlanDetailsItem = repositoryQuarterlyMaintenancePlanDetailsItem;
            this.taskworkRepository = taskworkRepository;
            this.repositoryMaterialType = repositoryMaterialType;
            this.repositoryMaintenanceSchedulePlan = repositoryMaintenanceSchedulePlan;
        }


        public async Task<QuarterlyMaintenancePlanGroupDetailsReponse> GetMaintenancePlanDetailsAsync(short categoryId, int maintenancePlanId, short organizationId)
        {
            try
            {
                QuarterlyMaintenancePlanGroupDetailsReponse response = new QuarterlyMaintenancePlanGroupDetailsReponse();

                var category = await repositoryCategory.GetAsync(categoryId);
                response.Id = categoryId;
                response.Name = category.Name;
                response.Result = this.repositoryMaterialType.GetAllIncludingIQueryableAsyn(x => x.IsActive == true && x.Item.Any(y => y.GroupItemDetail.Any()), x => x.Include(m => m.Item).Include("Item.GroupItemDetail")).Select(x => new QuarterlyMaintenancePlanGroupDetails { MaterialTypeId = x.Id, Name = x.Name, PartList = x.Item.Select(y => new QuarterlyGroupItemPartEntity { Id = y.Id, Quantity = 0 }).ToList() }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<QuarterlyMaintenancePlanResponseEntity> GetMaintenancePlanItemDetailsAsync(short materialTypeId, int maintenancePlanId, short organizationId, int quarter, int categoryId)
        {
            try
            {
                QuarterlyMaintenancePlanResponseEntity response = new QuarterlyMaintenancePlanResponseEntity();
                //var category = await repository.GetAsync(groupId);
                response.Id = materialTypeId;
                // response.Name = category.Name;
                var ds = SqlHelper.ExecuteDataset(this.Connectionstring, "GetQuarterlyMaintenancePlanDetails", new SqlParameter("@MaterialTypeId", materialTypeId), new SqlParameter("@StoreId", organizationId), new SqlParameter("@CategoryId", categoryId), new SqlParameter("@MaintenancePlanId", maintenancePlanId), new SqlParameter("@Quarter", quarter));
                List<QuarterlyMaintenancePlanItemDetailsModel> result = new List<QuarterlyMaintenancePlanItemDetailsModel>();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        result.Add(new QuarterlyMaintenancePlanItemDetailsModel(row));

                    }
                }
                response.ItemList = result.Select(x => new QuarterlyMaintenancePlanDetailsEntity { GroupItemId = x.GroupItemId, Cost = x.Cost, DueFrom = x.DueFrom.ToString("dd/MM/yyyy"), GroupName = x.GroupName, ItemId = x.ItemId, ItemSetNumberId = x.ItemSetNumberId, Name = x.Name, Quantiy = x.Quantity, SetNo = x.SetNo, ShedNo = x.ShedNo, StockShedId = x.StockShedId, PerItemQuantity = x.PerItemQuantity }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<QuarterlyMaintenancePlanEntity> InsertMaintenancePlanAsync(QuarterlyMaintenancePlanEntity entity)
        {
            QuarterlyMaintenancePlan dataEntity = await this.repositoryQuarterlyMaintenancePlan.GetIncludingByIdAsyn(x => x.StoreId == entity.StoreId && x.QuarterId == entity.QuarterId && x.MaintenancePlanId == entity.MaintenancePlanId && !x.IsApproved, x => x.Include(m => m.QuarterlyMaintenancePlanDetail).Include("QuarterlyMaintenancePlanDetail.Category").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem.QuarterlyMaintenancePlanDetailsItem"));

            if (dataEntity == null)
            {
                dataEntity = new QuarterlyMaintenancePlan();
                dataEntity.CreatedBy = entity.CreatedBy;
                dataEntity.CreatedDate = entity.CreatedDate;
                dataEntity.QuarterId = entity.QuarterId;
                dataEntity.MaintenancePlanId = entity.MaintenancePlanId;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;
            }
            else
            {
                dataEntity.QuarterId = entity.QuarterId;
                dataEntity.MaintenancePlanId = entity.MaintenancePlanId;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;

                foreach (var item in dataEntity.QuarterlyMaintenancePlanDetail.ToList())
                {

                    foreach (var group in item.QuarterlyMaintenancePlanDetailsGroupItem.ToList())
                    {
                        foreach (var items in group.QuarterlyMaintenancePlanDetailsItem.ToList())
                        {
                            await repositoryQuarterlyMaintenancePlanDetailsItem.DeleteAsyn(items.Id);
                        }


                        await repositoryQuarterlyMaintenancePlanDetailsGroupItem.DeleteAsyn(group.Id);
                    }

                    await repositoryQuarterlyMaintenancePlanDetail.DeleteAsyn(item.Id);

                }
            }

            var task = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.QuarterlyMaintenancePlan && x.FromOrganizationId == entity.StoreId && x.FromDesignationId == entity.DesignationId);
            if (task != null && task.ToDesignationId.HasValue)
            {
                dataEntity.ToDesignationId = task.ToDesignationId;
                dataEntity.ToOrganizationId = task.ToOrganizationId;
            }

            foreach (var item in entity.QuarterlyMaintenancePlanDetail)
            {
                QuarterlyMaintenancePlanDetail detail = new QuarterlyMaintenancePlanDetail();
                detail.QuarterlyMaintenancePlanId = dataEntity.Id;
                detail.Quantity = item.Quantity;
                detail.Amount = item.Amount;
                detail.CategoryId = item.CategoryId;
                detail.CreatedBy = item.CreatedBy;
                detail.CreatedDate = item.CreatedDate;
                detail.UpdatedBy = item.UpdatedBy;
                detail.UpdatedDate = item.UpdatedDate;
                item.QuarterlyMaintenancePlanDetailsGroupItem.ForEach(x =>
                {
                    detail.QuarterlyMaintenancePlanDetailsGroupItem.Add(new QuarterlyMaintenancePlanDetailsGroupItem
                    {
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        MaterialTypeId = x.MaterialTypeId,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        Amount = x.Amount,
                        Quantity = x.Quantity,
                        QuarterlyMaintenancePlanDetailsItem = x.QuarterlyMaintenancePlanDetailsItem.Select(y => new QuarterlyMaintenancePlanDetailsItem
                        {
                            CreatedBy = y.CreatedBy,
                            CreatedDate = y.CreatedDate,
                            GroupItemId = y.GroupItemId,
                            ItemId = y.ItemId,
                            ItemSetNumberId = y.ItemSetNumberId,
                            StockShedId = y.StockShedId,
                            UpdatedBy = y.UpdatedBy,
                            UpdatedDate = y.UpdatedDate,
                            Amount = y.Amount,
                            Quantity = y.Quantity
                        }).ToList()


                    });
                });

                if (dataEntity.Id > 0)
                {
                    await repositoryQuarterlyMaintenancePlanDetail.AddAsyn(detail);
                }
                else
                {
                    dataEntity.QuarterlyMaintenancePlanDetail.Add(detail);
                }
            }

            if (dataEntity.Id > 0)
            {
                await this.repositoryQuarterlyMaintenancePlan.UpdateAsync(dataEntity, dataEntity.Id);

            }
            else
            {
                await this.repositoryQuarterlyMaintenancePlan.AddAsyn(dataEntity);
            }

            return entity;
        }

        public async Task<QuarterlyMaintenancePlanResponseEntity> GetApprovedAsync(int id, short orgId, short desId)
        {

            QuarterlyMaintenancePlanResponseEntity response = new QuarterlyMaintenancePlanResponseEntity();
            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.QuarterlyMaintenancePlan && x.FromOrganizationId == orgId && x.FromDesignationId == desId && x.ToOrganizationId != null && x.ToDesignationId != null);

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }

            var result = await this.repositoryQuarterlyMaintenancePlan.GetIncludingByIdAsyn(x => x.Id == id && !x.IsApproved, x => x.Include(m => m.QuarterlyMaintenancePlanDetail).Include("QuarterlyMaintenancePlanDetail.Category").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem.QuarterlyMaintenancePlanDetailsItem"));
            if (result != null)
            {
                response.MaintenancePlanId = result.MaintenancePlanId;
                response.QuarterlyMaintenancePlanId = result.Id;
                response.QuarterId = result.QuarterId;
                response.StoreId = result.StoreId;
                response.QuarterlyMaintenancePlanDetail = this.mapper.Map<List<QuarterlyMaintenancePlanDetailEntity>>(result.QuarterlyMaintenancePlanDetail);
                response.QuarterlyMaintenancePlanDetail.ForEach(x =>
                {
                    x.CategoryName = result.QuarterlyMaintenancePlanDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                });
            }

            return response;

        }

        public async Task<QuarterlyMaintenancePlanApprovalEntity> InsertApproveAsync(QuarterlyMaintenancePlanApprovalEntity entity)
        {
            try
            {
                bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.QuarterlyMaintenancePlan && x.FromOrganizationId == entity.OrgId && x.FromDesignationId == entity.DestId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

                var oldResult = await this.repositoryQuarterlyMaintenancePlan.GetIncludingByIdAsyn(x => x.Id == entity.QuarterlyMaintenancePlanId, x => x.Include(m => m.QuarterlyMaintenancePlanApproval));

                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;
                oldResult.QuarterlyMaintenancePlanApproval.Add(new QuarterlyMaintenancePlanApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DestId,
                    FromOrganizationId = entity.OrgId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    QuarterlyMaintenancePlanId = oldResult.Id
                });

                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IsApproved = entity.IsApproved;
                }

                var result = await this.repositoryQuarterlyMaintenancePlan.UpdateAsync(oldResult, oldResult.Id);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public async Task<QuarterlyMaintenancePlanEntity> GetMaintenanceAsync(int maintenancePlanId, int quarterType, short organizationId)
        {
            var response = new QuarterlyMaintenancePlanEntity();
            try
            {

                var result = await this.repositoryQuarterlyMaintenancePlan.GetIncludingByIdAsyn(x => x.StoreId == organizationId && x.QuarterId == quarterType && x.MaintenancePlanId == maintenancePlanId && !x.IsApproved, x => x.Include(m => m.QuarterlyMaintenancePlanDetail).Include("QuarterlyMaintenancePlanDetail.Category").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem").Include("QuarterlyMaintenancePlanDetail.QuarterlyMaintenancePlanDetailsGroupItem.QuarterlyMaintenancePlanDetailsItem").Include(m => m.MaintenancePlan.MaintenancePlanDetail));
                if (result != null)
                {
                    response = this.mapper.Map<QuarterlyMaintenancePlanEntity>(result);
                    response.QuarterlyMaintenancePlanDetail.ForEach(async x =>
                    {
                        var plan = repositoryMaintenanceSchedulePlan.FindAllAsync(m => m.MaintenancePlanDetail.MaintenancePlanId == maintenancePlanId && m.MaintenancePlanDetail.CategoryId==x.CategoryId).Result.FirstOrDefault();
                        if (plan != null)
                        {
                            switch ((QuarterType)quarterType)
                            {
                                case QuarterType.Quarter1:
                                    x.MaxQuantity = plan.Qtr1qty;
                                    break;
                                case QuarterType.Quarter2:
                                    x.MaxQuantity = plan.Qtr2qty;
                                    break;
                                case QuarterType.Quarter3:
                                    x.MaxQuantity = plan.Qtr3qty;
                                    break;
                                case QuarterType.Quarter4:
                                    x.MaxQuantity = plan.Qtr4qty;
                                    break;
                            }

                        }
                        else
                        {
                            x.MaxQuantity = 0;
                        }
                        x.CategoryName = result.QuarterlyMaintenancePlanDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                    });
                }
                else
                {
                    response = new QuarterlyMaintenancePlanEntity();
                    var plans = await repositoryMaintenanceSchedulePlan.GetIncludingFindByAsyn(m => m.MaintenancePlanDetail.MaintenancePlanId == maintenancePlanId,x=>x.Include(m=>m.MaintenancePlanDetail).Include(m=>m.MaintenancePlanDetail.Category));
                    if (plans != null && plans.Any())
                    {
                        foreach (var plan in plans)
                        {
                            QuarterlyMaintenancePlanDetailEntity x = new QuarterlyMaintenancePlanDetailEntity();
                            if (plan != null)
                            {
                               
                                switch ((QuarterType)quarterType)
                                {
                                    case QuarterType.Quarter1:
                                        x.MaxQuantity = plan.Qtr1qty;
                                        break;
                                    case QuarterType.Quarter2:
                                        x.MaxQuantity = plan.Qtr2qty;
                                        break;
                                    case QuarterType.Quarter3:
                                        x.MaxQuantity = plan.Qtr3qty;
                                        break;
                                    case QuarterType.Quarter4:
                                        x.MaxQuantity = plan.Qtr4qty;
                                        break;
                                }
                            }
                            else
                            {
                                x.MaxQuantity = 0;
                            }
                            x.CategoryName = plan.MaintenancePlanDetail.Category.Name;
                            x.CategoryId = plan.MaintenancePlanDetail.CategoryId;
                            response.QuarterlyMaintenancePlanDetail.Add(x);
                        }
                       

                    }
                   

                    
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


            return response;
        }


        public async Task<DataTableResult> GetMaintenancePaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<QuarterlyMaintenancePlan> query = this.repositoryQuarterlyMaintenancePlan.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId || (x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId) || x.QuarterlyMaintenancePlanApproval.Any(a => a.FromOrganizationId == parameters.OrganizationId && a.FromDesignationId == parameters.DesignationId), x => x.Include(m => m.ToOrganization).Include(m => m.QuarterlyMaintenancePlanApproval).Include(m => m.Store).Include(m => m.QuarterlyMaintenancePlanDetail).Include(m => m.MaintenancePlan));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (QuarterlyMaintenancePlan)x;

                var fromWork = y.QuarterlyMaintenancePlanApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.QuarterlyMaintenancePlanApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.IsApproved;
                requiredData.Add(new QuarterlyMaintenancePlanGrid
                {
                    StoreName = y.Store.Name,
                    Id = y.Id,
                    Date = y.CreatedDate,
                    Year = y.MaintenancePlan.Year,
                    QuarterId = Utilities.GetEnumDescription((QuarterType)y.QuarterId),
                    Amount = y.QuarterlyMaintenancePlanDetail.Sum(s => s.Amount),
                    IsApproved = y.QuarterlyMaintenancePlanApproval.Any(a => a.FromOrganizationId == parameters.OrganizationId && a.FromDesignationId == parameters.DesignationId) || (y.IsApproved && y.ToOrganizationId == parameters.OrganizationId && y.ToDesignationId == parameters.DesignationId) || y.StoreId == parameters.OrganizationId
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<List<MasterDataEntity>> GetApprovedPlan(int maintenancePlanId)
        {
            var planList = repositoryQuarterlyMaintenancePlan.GetAllIncludingIQueryableAsyn(x => x.IsApproved, x => x.Include(m => m.MaintenancePlan));
            return planList != null && planList.Any() ? planList.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = $"{x.MaintenancePlan.Year}-{((QuarterType)x.QuarterId).ToString()}" }).ToList() : new List<MasterDataEntity>();
        }


    }
}
