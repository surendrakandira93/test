﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class StoreStockItemAuthorityManager: IStoreStockItemAuthorityManager
    {
        private IGenericRepository<StoreStockItemAuthority> repository;
        private IGenericRepository<GroupItem> repositoryGI;
        private IGenericRepository<Organization> repositoryOrg;
        private IGenericRepository<BasicCategory> repositoryBC;
        private IMapper mapper;

        public StoreStockItemAuthorityManager(IMapper mapper, IGenericRepository<StoreStockItemAuthority> repository, IGenericRepository<GroupItem> repositoryGI, IGenericRepository<Organization> repositoryOrg, IGenericRepository<BasicCategory> repositoryBC)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.repositoryGI = repositoryGI;
            this.repositoryOrg = repositoryOrg;
            this.repositoryBC = repositoryBC;
        }

        public async Task<int> DeleteAsync(Guid id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<StoreStockItemAuthorityEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<StoreStockItemAuthorityEntity>>(result);
            return mapped;
        }

        public async Task<StoreStockItemAuthorityEntity> GetAsync(Guid id)
        {
            try
            {
                 var result = await this.repository.GetAsync(id);
                var mapped = this.mapper.Map<StoreStockItemAuthorityEntity>(result);
                return mapped;
            }
            catch (Exception  ex)
            {

                throw ex;
            }
        }

        public async Task<StoreStockItemAuthorityEntity> GetAsyncDetail(Guid id)
        {
            try
            {
                StoreStockItemAuthorityEntity auth = new StoreStockItemAuthorityEntity();
                var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(y => y.GroupItemBasicCategory).Include("GroupItem.Category").Include("GroupItem.ItemUom"));

                var mapped = this.mapper.Map<StoreStockItemAuthorityEntity>(result);
                mapped.CategoryName = result.GroupItem.Category.Name;
                mapped.NameUnitOfMeasure = result.GroupItem.ItemUom.Name;
                mapped.DigitAfterDecimal = result.GroupItem.ItemUom.DigitAfterDecimal;
                return mapped;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            //var query = this.repository.GetAll();
            //var result = await CustomPredicate.BuildPredicate(query, parameters);
            //return result;
            var predicate = CustomPredicate.BuildPredicate<StoreStockItemAuthority>(parameters);
            predicate = predicate.Or(x => x.AuthorizedOrganiztion.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.GroupItem.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.GroupItemBasicCategory.Name.Contains(parameters.Search.Value));
            var query = this.repository.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId,x => x.Include(m => m.AuthorizedOrganiztion).Include(m => m.GroupItem).Include(m => m.GroupItemBasicCategory));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (StoreStockItemAuthority)x;
                requiredData.Add(new
                {
                    AuthorizedQuantiy = y.AuthorizedQuantiy,
                    Remark = y.Remark,
                    AuthorizedOrganiztion = y.AuthorizedOrganiztion.Name,
                    GroupItem = y.GroupItem.Name,
                    GroupItemBasicCategory = y.GroupItemBasicCategory.Name,
                    Id = y.Id
                });

            });
            result.Data = requiredData;
            return result;
        }

        public async Task<List<StoreStockItemAuthorityEntity>> InsertAsync(List<StoreStockItemAuthorityEntity> entity)
        {
            try
            {
                var mapped = this.mapper.Map<List<StoreStockItemAuthority>>(entity);

                var result = await this.repository.AddRangeAsyn(mapped);

                return this.mapper.Map<List<StoreStockItemAuthorityEntity>>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }
                
        public async Task<StoreStockItemAuthorityEntity> UpdateAsync(StoreStockItemAuthorityEntity entity)
        {
            var mapped = this.mapper.Map<StoreStockItemAuthority>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<StoreStockItemAuthorityEntity>(result);
        }

        public async Task<IList<MasterDataEntity>> GetSSIAAuthForAsync()
        {
            List<MasterDataEntity> abc = new List<MasterDataEntity>();
            var StoreStockItemAuth = this.repository.GetAll();
            var OrgName = this.repositoryOrg.GetAll();

            var query = from A in StoreStockItemAuth
                        join B in OrgName
                        on A.AuthorizedOrganiztionId equals B.Id
                        select new
                        {
                            Id = A.AuthorizedOrganiztionId,
                            Name = B.Name
                        };
            var result = query.Distinct().ToList();
            foreach (var item in result)
            {
                MasterDataEntity x = new MasterDataEntity();
                x.Id = item.Id.ToString();
                x.Name = item.Name;
                abc.Add(x);
            }
            var mapped = this.mapper.Map<IList<MasterDataEntity>>(abc);
            return mapped;
        }

        public async Task<IList<MasterDataEntity>> GetSSIABasicCatAsync()
        {
            List<MasterDataEntity> abc = new List<MasterDataEntity>();
            var StoreStockItemAuth = this.repository.GetAll();
            var BCName = this.repositoryBC.GetAll();

            var query = from A in StoreStockItemAuth
                        join B in BCName
                        on A.GroupItemBasicCategoryId equals B.Id
                        select new
                        {
                            Id = A.GroupItemBasicCategoryId,
                            Name = B.Name
                        };
            var result = query.Distinct().ToList();
            foreach (var item in result)
            {
                MasterDataEntity x = new MasterDataEntity();
                x.Id = item.Id.ToString();
                x.Name = item.Name;
                abc.Add(x);
            }
            var mapped = this.mapper.Map<IList<MasterDataEntity>>(abc);
            return mapped;
        }

        public async Task<IList<MasterDataEntity>> GetSSIAGroupItemAsync()
        {
            List<MasterDataEntity> abc = new List<MasterDataEntity>();
            var StoreStockItemAuth = this.repository.GetAll();
            var GIName = this.repositoryGI.GetAll();

            var query = from A in StoreStockItemAuth
                        join B in GIName
                        on A.GroupItemId equals B.Id
                        select new
                        {
                            Id = A.GroupItemId,
                            Name = B.Name
                        };
            var result = query.Distinct().ToList();
            foreach (var item in result)
            {
                MasterDataEntity x = new MasterDataEntity();
                x.Id = item.Id.ToString();
                x.Name = item.Name;
                abc.Add(x);
            }
            var mapped = this.mapper.Map<IList<MasterDataEntity>>(abc);
            return mapped;
        }


    }
}