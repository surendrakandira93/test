﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class LoadTrolleyManager : ILoadTrolleyManager
    {
        private IGenericRepository<ConveningOrder> orderRepository;
        private IGenericRepository<LoadTrolley> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<StoreStock> storeStockRepository;
        private IGenericRepository<StoreStockTransaction> transactionRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;

        public LoadTrolleyManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<LoadTrolley> repository, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<ConveningOrder> orderRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransaction> transactionRepository)
        {
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.orderRepository = orderRepository;
            this.storeStockRepository = storeStockRepository;
            this.transactionRepository = transactionRepository;
            this.mapper = mapper;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
        }

        public async Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            IQueryable<ConveningOrder> query = this.orderRepository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId &&x.IssueDate!=null &&x.ConveningOrderItemSurveyMain.Any()&& x.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved, x => x.Include(m => m.ConveningOrderItem).Include(m => m.LoadTrolley).Include("LoadTrolley.LoadTrolleyItem")
            .Include(m => m.ReleaseOrder).Include(m => m.SenctionOrder).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveningOrder)x;
                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.Id,
                    senctionNo = y.SenctionOrder?.SenctionOrderNo??string.Empty,
                    senctionDate = y.SenctionOrder?.SenctionDate??new DateTime(),
                    ConveningOrderNo = y.ConveningOrderNo,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder?.ReleaseOrderNo??string.Empty,
                    ReleaseDate = y.ReleaseOrder?.ReleaseDate??new DateTime(),
                    UnitName = y.Unit.Name,
                    IsApproved = y.LoadTrolley.Count() > 0 ? y.ConveningOrderItem.Sum(s => s.ReceivedQuantiy) > y.LoadTrolley.Sum(s => s.LoadTrolleyItem.Sum(i => i.Quantiy)) : true
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<LoadTrolley> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.ConveningOrder.StoreId == parameters.OrganizationId, x => x.Include(m => m.LoadTrolleyItem).Include(m => m.ConveningOrder));

            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoadTrolley)x;
                requiredData.Add(new LoadTrolleyGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrder.ConveningOrderNo,
                    LoadTrolleyNo = y.LoadTrolleyNo,
                    LoadTrolleyDate = y.LoadTrolleyDate,
                    OrderDate = y.ConveningOrder.RequestDate
                });
            }

            response.Data = requiredData;
            return response;
        }


        public async Task<LoadTrollyPrintEntity> GetAsyncForPrint(Guid id)
        {
           
            var result1 = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.ConveningOrder));

            var result = await this.orderRepository.GetIncludingByIdAsyn(x => x.Id == result1.ConveningOrderId, x => x.Include(m => m.Store)
             .Include(m => m.LoadTrolley).Include(m => m.ReleaseOrder).Include(m=>m.Unit)
             .Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.LoadTrolleyItem").Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.Item.ItemUom").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new LoadTrollyPrintEntity();
          
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.TrollyNumber =result1.LoadTrolleyNo;
            response.TrollyDate = result1.CreatedDate;

            response.StoreName = result.Store.Name;
            response.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(result.Store);
           
            response.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(result.Unit);
            foreach (var item in result.ConveningOrderItem)
            {
                response.LoadTrollyDetailPrint.Add(new LoadTrollyDetailPrintEntity
                {
                    ItemName = item.Item.Name,
                    UomName=item.Item.ItemUom.Name,
                   
                    LoanQuantiy = item.LoanQuantiy,
                    ReceivedQuantiy =decimal.Round(item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy),item.Item.ItemUom.DigitAfterDecimal),
                    ServiceQuantiy = decimal.Round(item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy), item.Item.ItemUom.DigitAfterDecimal),
                    ReturnQuantiy = decimal.Round(item.ReturnQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    RepairQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Repairable).Sum(s => s.Quantiy),
                    Id = item.Id,
                    Remarks = item.Remarks,
                    RowId = item.RowId,

                });
            }
            return response;
        }


        public async Task<ConveningOrderEntity> GetAsync(Guid id)
        {
            var result = await this.orderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
             .Include(m => m.LoadTrolley).Include(m => m.ReleaseOrder)
             .Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.LoadTrolleyItem").Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new ConveningOrderEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreId = result.StoreId;
            response.SenctionNo = result.SenctionOrder != null ? result.SenctionOrder.SenctionOrderNo : string.Empty;
            response.StoreName = result.Store.Name;
            foreach (var item in result.ConveningOrderItem)
            {
                if (true)
                {
                    response.ConveningOrderItem.Add(new ConveningOrderItemEntity
                    {
                        ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                        ItemBasicCategoryId = item.ItemBasicCategoryId,
                        ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                        ItemEquipmentId = item.ItemEquipmentId,
                        //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                        ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                        ItemName = item.Item.Name,
                        ItemId = item.ItemId,
                        //ItemUomId = item.Item.ItemUomId,
                        LoanQuantiy = item.LoanQuantiy,
                        ReceivedQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy),
                        ReturnQuantiy = item.ReturnQuantiy,
                        AvailableQuantiy = item.ReceivedQuantiy - item.LoadTrolleyItem.Sum(x => x.Quantiy),
                        ConveningOrderId = item.ConveningOrderId,
                        CreatedBy = item.CreatedBy,
                        CreatedDate = item.CreatedDate,
                        Id = item.Id,
                        Remarks = item.Remarks,
                        RowId = item.RowId,
                        RowVersion = item.RowVersion,
                        UpdatedBy = item.UpdatedBy,
                        UpdatedDate = item.UpdatedDate,
                        GroupItemList = this.storeStockRepository.GetAllIncludingIQueryableAsyn(x => x.StoreStockTransaction.Any(a => a.ItemId == item.ItemId), x => x.Include(m => m.GroupItem)).Select(x => new MasterDataEntity { Id = x.GroupItemId.ToString(), Name = x.GroupItem.Name }).Distinct().ToList()

                    });
                }
            }
            return response;
        }

        //public async Task<ConveningOrderEntity> GetViewAsync(Guid id)
        //{
        //    var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.LoadTrolleyItem).Include("LoadTrolleyItem.ConveningOrderItem")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.LoadTrolleyItem")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.ItemBasicCategory")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.Item")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.ItemBasicCategory.BasicCategory")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.ItemEquipment")
        //     .Include("LoadTrolleyItem.ConveningOrderItem.ItemEquipment.Equipment")
             
        //     );
        //    var response = new ConveningOrderEntity();
        //    response.ReleaseOrderId = result.Id;
        //    response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
        //    response.ConveningOrderNo = result.ConveningOrderNo;
        //    response.StoreId = result.StoreId;
        //    response.SenctionNo = result.SenctionOrder != null ? result.SenctionOrder.SenctionOrderNo : string.Empty;
        //    response.StoreName = result.Store.Name;
        //    foreach (var item in result.ConveningOrderItem)
        //    {
        //        response.ConveningOrderItem.Add(new ConveningOrderItemEntity
        //        {
        //            ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
        //            ItemBasicCategoryId = item.ItemBasicCategoryId,
        //            ItemEquipmentName = item.ItemEquipment.Equipment.Name,
        //            ItemEquipmentId = item.ItemEquipmentId,
        //            //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
        //            ItemEquipmentTypeId = item.ItemEquipmentTypeId,
        //            ItemName = item.Item.Name,
        //            ItemId = item.ItemId,
        //            //ItemUomId = item.Item.ItemUomId,
        //            LoanQuantiy = item.LoanQuantiy,
        //            ReceivedQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy),
        //            ReturnQuantiy = item.ReturnQuantiy,
        //            AvailableQuantiy = item.ReceivedQuantiy - item.LoadTrolleyItem.Sum(x => x.Quantiy),
        //            ConveningOrderId = item.ConveningOrderId,
        //            CreatedBy = item.CreatedBy,
        //            CreatedDate = item.CreatedDate,
        //            Id = item.Id,
        //            Remarks = item.Remarks,
        //            RowId = item.RowId,
        //            RowVersion = item.RowVersion,
        //            UpdatedBy = item.UpdatedBy,
        //            UpdatedDate = item.UpdatedDate,
        //            GroupItemList = this.storeStockRepository.GetAllIncludingIQueryableAsyn(x => x.StoreStockTransaction.Any(a => a.ItemId == item.ItemId), x => x.Include(m => m.GroupItem)).Select(x => new MasterDataEntity { Id = x.GroupItemId.ToString(), Name = x.GroupItem.Name }).Distinct().ToList()

        //        });
        //    }
        //    return response;
        //}

        public async Task<LoadTrolleyEntity> InsertAsync(LoadTrolleyEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<LoadTrolley>(entity);
                var result = await this.repository.AddAsyn(mapped);                
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }      
       

        //public List<MasterDataEntity> GetSetNo(Guid itemId, Guid itemGroupId, short stockShedId)
        //{
        //    var setNos = this.transactionSetNoRepository.GetAllIncludingIQueryableAsyn(x => x.ItemId == itemId && x.GroupItemId == itemGroupId && x.StockShedId == stockShedId, x => x.Include(m => m.StockShed));
        //    return setNos.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.SetNo, AdditionalValue = x.Quantiy.ToString() }).ToList();
        //}

        public List<MasterDataEntity> GetStockShed(Guid itemId, Guid itemGroupId)
        {
            var stockshed = this.transactionRepository.GetAllIncludingIQueryableAsyn(x => x.ItemId == itemId && x.StoreStock.GroupItemId == itemGroupId, x => x.Include(m => m.StockShed)).Distinct().ToList();           
            List<MasterDataEntity> response = new List<MasterDataEntity>();
            foreach (var x in stockshed)
            {
                if (!response.Any(a => a.Id.ToLower() != x.Id.ToString().ToLower()))
                    response.Add(new MasterDataEntity { Id = x.StockShedId.ToString(), Name = x.StockShed.Name });
            }
            return response;
        }

        public List<MasterDataEntity> GetSetNo(Guid itemId, Guid itemGroupId, short stockShedId)
        {

            var setNos = this.transactionRepository.GetAllIncludingIQueryableAsyn(x => x.ItemId == itemId && x.StoreStock.GroupItemId == itemGroupId && x.StockShedId == stockShedId, x => x.Include(m => m.StockShed).Include(m => m.ItemSetNumber).Include(m => m.StoreStockTransactionQuantity)).ToList();
          //  return setNos.Select(x => new MasterDataEntity { Id = x.ItemSetNumberId.ToString(), Name = x.ItemSetNumber.Name, AdditionalValue = x.StoreStockTransactionQuantity.Sum(s=>s.Quantiy).ToString() }).ToList();

            List<MasterDataEntity> response = new List<MasterDataEntity>();
            foreach (var x in setNos)
            {
                if (!response.Any(a => int.Parse(a.Id )== x.ItemSetNumberId))
                    response.Add(new MasterDataEntity { Id = x.ItemSetNumberId.ToString(), Name = x.ItemSetNumber.Name , AdditionalValue = x.StoreStockTransactionQuantity.Sum(s => s.Quantiy).ToString() });
            }
            return response.OrderBy(x=>x.Id).ToList();
        }




    }
}