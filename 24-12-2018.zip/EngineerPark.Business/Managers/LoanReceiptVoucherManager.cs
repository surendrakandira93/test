﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class LoanReceiptVoucherManager: ILoanReceiptVoucherManager
    {
        private IGenericRepository<ConveningOrder> orderRepository;
        private IGenericRepository<ConveningOrderItem> orderItemRepository;
        private IGenericRepository<ConveningOrderItemSurvey> conveningOrderItemSurveyrepository;
        private IGenericRepository<LoanReceiptVoucher> repository;        
        private IGenericRepository<StoreStock> storeStockRepository;
        private IGenericRepository<LoadTrolley> loadTrollyRepository;
        private IGenericRepository<ReleaseOrder> releaseOrderRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;


        public LoanReceiptVoucherManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<LoanReceiptVoucher> repository, IGenericRepository<ConveningOrder> orderRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<LoadTrolley> loadTrollyRepository, IGenericRepository<ConveningOrderItem> orderItemRepository, IGenericRepository<ReleaseOrder> releaseOrderRepository, IGenericRepository<ConveningOrderItemSurvey> conveningOrderItemSurveyrepository)
        {
            this.repository = repository;
            this.orderRepository = orderRepository;
            this.mapper = mapper;
            this.storeStockRepository = storeStockRepository;
            this.loadTrollyRepository = loadTrollyRepository;
            this.orderItemRepository = orderItemRepository;
            this.releaseOrderRepository = releaseOrderRepository;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
            this.conveningOrderItemSurveyrepository = conveningOrderItemSurveyrepository;
        }

        public async Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters)
        {
            try
            {
                DataTableResult response = new DataTableResult();
                IQueryable<ConveningOrder> query = this.orderRepository.GetAllIncludingIQueryableAsyn(y => y.StoreId == parameters.OrganizationId && y.LoadTrolley.Count() > 0 ? y.ConveningOrderItem.Sum(s => s.ReceivedQuantiy) <= y.LoadTrolley.Sum(s => s.LoadTrolleyItem.Sum(i => i.Quantiy)) : false, x => x.Include(m => m.ConveningOrderItem).Include(m => m.LoadTrolley)
                 .Include(m => m.ReleaseOrder).Include(m => m.LoanReceiptVoucher).Include(m => m.SenctionOrder).Include(m => m.Store).Include(m => m.Unit));
                response = await CustomPredicate.BuildPredicate(query, parameters);
                var requiredData = new List<object>();
                foreach (var x in response.Data)
                {
                    var y = (ConveningOrder)x;
                    requiredData.Add(new ConveningOrderGrid
                    {
                        Id = y.Id,
                        LoadTrolley = string.Join(",", y.LoadTrolley.Select(s => s.LoadTrolleyNo).ToArray()),
                        //senctionNo = y.SenctionOrder.SenctionOrderNo,
                        //senctionDate = y.SenctionOrder.SenctionDate,
                        ConveningOrderNo = y.ConveningOrderNo,
                        StoreName = y.Store.Name,
                        ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                        ReleaseDate = y.ReleaseOrder.ReleaseDate,
                        UnitName = y.Unit.Name,
                        IsApproved = y.LoanReceiptVoucher.Count() == 0
                    });
                }

                response.Data = requiredData;
                return response;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<LoanReceiptVoucher> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId, x =>x.Include(m => m.ConveningOrder));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoanReceiptVoucher)x;
                requiredData.Add(new LoanReceiptVoucherGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrder.ConveningOrderNo,
                    LoanReceiptVoucherNo = y.VoucherNo,
                    LoanReceiptVoucherDate = y.VoucherDate,
                    OrderDate = y.ConveningOrder.RequestDate
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<LoanReceiptVoucherPrintEntity> GetAsyncForPrint(Guid id)
        {
            var result1 = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.ConveningOrder));
            var Trolly=await this.loadTrollyRepository.GetIncludingByIdAsyn(x => x.ConveningOrderId == result1.ConveningOrderId, x => x.Include(m => m.ConveningOrder).Include(y=>y.ConveningOrder.Unit));


            var result = await this.orderRepository.GetIncludingByIdAsyn(x => x.Id == result1.ConveningOrderId, x => x.Include(m => m.Store)
             .Include(m => m.LoadTrolley).Include(m => m.ReleaseOrder)
             .Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.Item.ItemUom").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new LoanReceiptVoucherPrintEntity();

            response.ConveningOrderNo = result1.ConveningOrder.ConveningOrderNo;

            response.TrollyNumber = Trolly.LoadTrolleyNo;
            response.TrollyDate = Trolly.LoadTrolleyDate;

            response.ReceiptVoucherNo = result1.VoucherNo;
            response.ReceiptVoucherDate = result1.VoucherDate;

            response.StoreName = result.Store.Name;
            response.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(result.Store);
            
            response.OrganizationModelTo= this.mapper.Map<OrganizationEntity>(Trolly.ConveningOrder.Unit);
            //response.ConveningOrder = result1.ConveningOrder;

            foreach (var item in result.ConveningOrderItem)
            {
                response.LoanReceiptVoucherDetailPrint.Add(new LoanReceiptVoucherDetailPrintEntity
                {
                    ItemName = item.Item.Name,
                    UomName = item.Item.ItemUom.Name,

                    LoanQuantiy = item.LoanQuantiy,
                    ReceivedQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy),
                    ServiceQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(s => s.Quantiy),
                    ReturnQuantiy = item.ReturnQuantiy,
                    RepairQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == (int)ItemStatusEnum.Repairable).Sum(s => s.Quantiy),
                    Id = item.Id,
                    Remarks = item.Remarks,
                    RowId = item.RowId,

                });
            }

            return response;
        }


        public async Task<LoanReceiptVoucherEntity> GetAsync(Guid id)
        {
            var result = await this.orderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
             .Include(m => m.LoadTrolley).Include(m => m.ReleaseOrder)
             .Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new LoanReceiptVoucherEntity();
            response.ConveningOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreId = result.StoreId;           
            response.StoreName = result.Store.Name;
            foreach (var item in result.ConveningOrderItem)
            {
                response.LoanReceiptVoucherDetail.Add(new LoanReceiptVoucherDetailEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                    ItemName = item.Item.Name,
                    ItemId = item.ItemId,
                    LoanQuantiy = item.LoanQuantiy,
                    AvailableQuantiy = item.ReceivedQuantiy - item.LoadTrolleyItem.Sum(x => x.Quantiy),
                    ConveningOrderItemId = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate
                   
                });
            }

            return response;
        }

        public async Task<LoanReceiptVoucherEntity> InsertAsync(LoanReceiptVoucherEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<LoanReceiptVoucher>(entity);                
                var loadtrollies = await this.loadTrollyRepository.GetIncludingFindByAsyn(x => x.ConveningOrderId == entity.ConveningOrderId, x => x.Include(m => m.LoadTrolleyItem));
                var conveyNote = await this.orderRepository.FindAsync(x => x.Id == entity.ConveningOrderId);
                var releaseOrder =await this.releaseOrderRepository.FindAsync(x => x.Id ==conveyNote.ReleaseOrderId);
                foreach (var loadTrolly in loadtrollies)
                {

                    foreach (var item in loadTrolly.LoadTrolleyItem)
                    {
                        var itemDetails = await this.orderItemRepository.GetIncludingByIdAsyn(x => x.Id == item.ConveningOrderItemId, x => x.Include(m => m.Item));
                        List<StoreStockTransactionQuantity> stQuantity = new List<StoreStockTransactionQuantity>();
                        StoreStock storestock = new StoreStock();
                        storestock.CreatedBy = entity.CreatedBy;
                        storestock.CreatedDate = entity.CreatedDate;
                        storestock.GroupItemId = item.GroupItemId;
                        storestock.IsStockOut = false;
                        storestock.StoreId = entity.StoreId;
                        storestock.TransactionDate = DateTime.Now;
                        storestock.TransactionRefId = entity.ConveningOrderId;
                        storestock.TransactionTypeId = (int)TransactionTypeEnum.Deposit;
                        storestock.UpdatedBy = item.UpdatedBy;
                        storestock.UpdatedDate = item.UpdatedDate;
                        var survay = conveningOrderItemSurveyrepository.FindAll(x => x.ConveningOrderItemId == item.ConveningOrderItemId && x.ConveningOrderItem.ItemId == itemDetails.ItemId).ToList();

                        if(survay!=null && survay.Any())
                        {
                            foreach (var sur in survay.Where(x=>x.Quantiy>0.0M).ToList())
                            {
                                stQuantity.Add(new StoreStockTransactionQuantity
                                {
                                    CreatedBy = entity.CreatedBy,
                                    CreatedDate = entity.CreatedDate,
                                    //IsBlockQuantity=true,
                                    ItemStatusId = sur.ItemStatusId,
                                    Quantiy = sur.Quantiy,
                                    UpdatedBy = item.UpdatedBy,
                                    UpdatedDate = item.CreatedDate
                                });
                            }
                        }
                        
                        storestock.StoreStockTransaction.Add(new StoreStockTransaction
                        {
                            CreatedBy = item.CreatedBy,
                            UpdatedDate = item.UpdatedDate,
                            UpdatedBy = item.UpdatedBy,
                            CreatedDate = item.CreatedDate,
                            ItemId = itemDetails.ItemId,
                            ItemUomId = itemDetails.Item.ItemUomId,
                            PageNo = string.Empty,
                            PrimaryLedgerNo = string.Empty,
                            StockShedId = item.StockShedId,
                            SecondaryLedgerNo = string.Empty,
                            StoreStockTransactionQuantity = stQuantity,
                            ItemSetNumberId = item.ItemSetNumberId


                        });

                        await this.storeStockRepository.AddAsyn(storestock);
                    }
                }

                var result = await this.repository.AddAsyn(mapped);
                releaseOrder.StatusId = (int)StatusEnum.LoanRecived;
                await this.releaseOrderRepository.UpdateAsync(releaseOrder, releaseOrder.Id);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



    }
}