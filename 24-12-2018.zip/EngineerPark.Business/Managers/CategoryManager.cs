﻿
namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;

    public class CategoryManager: ICategoryManager
    {
       
        private IGenericRepository<Category> repository;
        private IMapper mapper;
        public CategoryManager(IMapper mapper, IGenericRepository<Category> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<CategoryEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<CategoryEntity>>(result);
            return mapped;
        }

        public async Task<CategoryEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<CategoryEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<CategoryEntity> InsertAsync(CategoryEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Category>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<CategoryEntity>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<CategoryEntity> UpdateAsync(CategoryEntity entity)
        {
            var mapped = this.mapper.Map<Category>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<CategoryEntity>(result);
        }
    }
}
