﻿namespace EngineerPark.Business.Managers
{
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.Data.IRepositories;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class MasterDataManager: IMasterDataManager
    {
        private readonly IMapper mapper;
        private readonly IMasterDataRepository masterQuery;
        private readonly string Id = "Id";
        private readonly string Name = "Name";
        private readonly string IsActive = "IsActive";
        private readonly string IsActiveValue = "1";

        public MasterDataManager(IMapper mapper, IMasterDataRepository masterQuery)
        {
            this.mapper = mapper;
            this.masterQuery = masterQuery;
        }

        public async Task<List<MasterDataEntity>> States()
        {
            var masterDataQueryParam = CreateParam("State", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            var data = await this.GetMasterData(masterDataQueryParam);
            return data;
        }

        public async Task<List<MasterDataEntity>> OrganizationType()
        {
            var masterDataQueryParam = CreateParam("OrganizationType", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            var data = await this.GetMasterData(masterDataQueryParam);
            return data;
        }
        
        public async Task<List<MasterDataEntity>> Organization()
        {
            var masterDataQueryParam = CreateParam("Organization", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
           return await this.GetMasterData(masterDataQueryParam);
            
        }

        public async Task<List<MasterDataEntity>> OrganizationEP() //OrgID=7|OrgName=EP
        {
            var masterDataQueryParam = CreateParam("Organization", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));

            masterDataQueryParam.WhereFilters.Add(new QueryFilter("OrganizationTypeId","7"));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> OrganizationUnit() //OrgID=7|OrgName=Unit
        {
            var masterDataQueryParam = CreateParam("Organization", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));

            masterDataQueryParam.WhereFilters.Add(new QueryFilter("OrganizationTypeId", "6"));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> OrganizationAuthFor()// [OrgID=1|OrgName=AHQ] [OrgID=2|OrgName=Cmd] [OrgID=3|OrgName=Corps]
        {
            var masterDataQueryParam = CreateParam("Organization", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));

            masterDataQueryParam.WhereFilters.Add(new QueryFilter("OrganizationTypeId","(1,2,3)"," IN "));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> Category()
        {
            var masterDataQueryParam = CreateParam("Category", this.Id, this.Name, this.Id);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> UnitOfMeasure()
        {
            var masterDataQueryParam = CreateParam("UnitOfMeasure", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            masterDataQueryParam.AdditionalFieldName = "UnitTypeId";
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> MaterialType()
        {
            var masterDataQueryParam = CreateParam("MaterialType", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }
        
        public async Task<List<MasterDataEntity>> Items(short? categoryId, int? isMaster)
        {
            var masterDataQueryParam = CreateParam("Item", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            if(categoryId.HasValue)
                masterDataQueryParam.WhereFilters.Add(new QueryFilter("CategoryId", categoryId.Value.ToString()));
            if(isMaster.HasValue)
                masterDataQueryParam.WhereFilters.Add(new QueryFilter("IsMaster", isMaster.Value.ToString()));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> TransactionType()
        {
            var masterDataQueryParam = CreateParam("TransactionType", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }
        
        public async Task<List<MasterDataEntity>> BasicCategory()
        {
            var masterDataQueryParam = CreateParam("BasicCategory", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }
        
        public async Task<List<MasterDataEntity>> Equipment()
        {
            var masterDataQueryParam = CreateParam("Equipment", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }
        
        public async Task<List<MasterDataEntity>> EquipmentType()
        {
            var masterDataQueryParam = CreateParam("EquipmentType", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> ItemStatus()
        {
            var masterDataQueryParam = CreateParam("ItemStatus", this.Id, this.Name, this.Id);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }
        
        public async Task<List<MasterDataEntity>> Origin()
        {
            var masterDataQueryParam = CreateParam("Origin", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> ShedType()
        {
            var masterDataQueryParam = CreateParam("ShedType", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);
        }

        public async Task<List<MasterDataEntity>> StockShed()
        {
            var masterDataQueryParam = CreateParam("StockShed", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);
        }

        public async Task<List<MasterDataEntity>> Level()
        {
            var masterDataQueryParam = CreateParam("Level", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> GroupItem()
        {
            var masterDataQueryParam = CreateParam("GroupItem", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);
        }

        public async Task<List<MasterDataEntity>> GroupItemCatIdWise(short? categoryId)
        {
            var masterDataQueryParam = CreateParam("GroupItem", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            if (categoryId.HasValue)
                masterDataQueryParam.WhereFilters.Add(new QueryFilter("CategoryId", categoryId.Value.ToString()));            
            return await this.GetMasterData(masterDataQueryParam);
        }

        public async Task<List<MasterDataEntity>> Role()
        {
            var masterDataQueryParam = CreateParam("Role", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> Designation(short? orgId)
        {
            var masterDataQueryParam = CreateParam("Designation", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            if(orgId.HasValue)
            masterDataQueryParam.WhereFilters.Add(new QueryFilter("OrganizationId", orgId.Value.ToString()));

            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> Department()
        {
            var masterDataQueryParam = CreateParam("Department", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);

        }

        public async Task<List<MasterDataEntity>> TaskList()
        {
            var masterDataQueryParam = CreateParam("Task", this.Id, this.Name, this.Id);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);
        }

        public async Task<List<MasterDataEntity>> ItemSetNoList()
        {
            var masterDataQueryParam = CreateParam("ItemSetNumber", this.Id, this.Name, this.Name);
            masterDataQueryParam.WhereFilters.Add(new QueryFilter(this.IsActive, this.IsActiveValue));
            return await this.GetMasterData(masterDataQueryParam);
        }




        private static MasterDataQueryParam CreateParam(string tableName, string keyFieldName, string valueFieldName, string orderByColumnName)
        {
            return new MasterDataQueryParam()
            {
                TableName = tableName,
                KeyFieldName = keyFieldName,
                ValueFieldName = valueFieldName,
                OrderByColumnName = orderByColumnName,
                WhereFilters = new List<QueryFilter>()
            };
        }
        
        private async Task<List<MasterDataEntity>> GetMasterData(MasterDataQueryParam param)
        {
            string sqlQuery = this.GenerateQuery(param);
            var results = await this.masterQuery.Execute(sqlQuery);
            var masterEntity = this.mapper.Map<List<MasterDataEntity>>(results);
            return masterEntity;
        }
                
        private string GenerateQuery(MasterDataQueryParam param)
        {

            string sqlQuery = string.Empty;
            var filters = new StringBuilder();

            if (param.WhereFilters.Any())
            {
                filters.Append(" WHERE ");
                int count = 1;
                foreach (var whereFilter in param.WhereFilters)
                {
                    if (whereFilter.FieldValue == null)
                    {
                        filters.Append(string.Format("{0}{1} IS NULL", count == 1 ? string.Empty : whereFilter.FilterOperator, whereFilter.FieldName));
                    }
                    else if (whereFilter.FilterOperator==" IN ")
                    {
                        filters.Append(string.Format(" AND {0} IN {1}", count == 1 ? string.Empty :  whereFilter.FieldName, whereFilter.FieldValue));
                    }
                    else
                    {
                        filters.Append(string.Format("{0}{1} = '{2}'", count == 1 ? string.Empty : whereFilter.FilterOperator, whereFilter.FieldName, whereFilter.FieldValue));
                    }

                    count += 1;
                }
            }

            if (string.IsNullOrEmpty(param.AdditionalFieldName))
            {
                sqlQuery = $"SELECT CONVERT(NVARCHAR(250),{param.KeyFieldName}) AS Id, CONVERT(NVARCHAR(250),{param.ValueFieldName}) AS Name FROM {param.TableName} {filters.ToString()}";
            }

            if (string.IsNullOrEmpty(param.AdditionalFieldName))
            {
                sqlQuery = $"SELECT CONVERT(NVARCHAR(250),{param.KeyFieldName}) AS Id, CONVERT(NVARCHAR(250),{param.ValueFieldName}) AS Name, '' AS AdditionalValue FROM {param.TableName} {filters.ToString()}";
            }
            else
            {
                if (param.AdditionalFieldName.IndexOf(",") > -1)
                {   
                    sqlQuery = $"SELECT CONVERT(NVARCHAR(250),{param.KeyFieldName}) AS Id, CONVERT(NVARCHAR(250),{param.ValueFieldName}) AS Name, CONVERT(NVARCHAR(250),{param.AdditionalFieldName.Split(',')[0]})  AS AdditionalValue FROM {param.TableName} {filters.ToString()}";
                }
                else
                {
                    sqlQuery = $"SELECT CONVERT(NVARCHAR(250),{param.KeyFieldName}) AS Id, CONVERT(NVARCHAR(250),{param.ValueFieldName}) AS Name, CONVERT(NVARCHAR(250),{param.AdditionalFieldName})  AS AdditionalValue FROM {param.TableName} {filters.ToString()}";
                    
                }
            }


            if (!string.IsNullOrEmpty(param.OrderByColumnName))
            {
                sqlQuery = $"{sqlQuery} order by {param.OrderByColumnName.ToString()} {(param.IsOrderDescending == true ? " desc" : " asc")}";
            }

            return sqlQuery;

        }
              
    }
}
