﻿namespace EngineerPark.Business.Managers
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class AvailabilityCertIssueManager: IAvailabilityCertIssueManager
    {
        private IGenericRepository<AvailabilityCertIssue> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<AvailabilityCertRequest> reqRepository;

        private IOrganizationManager Organization;
        private IUserManager Usermgr;
        private IMapper mapper;
        public AvailabilityCertIssueManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<AvailabilityCertIssue> repository, IGenericRepository<AvailabilityCertRequest> reqRepository, IGenericRepository<TaskWorkFlow> taskworkRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.reqRepository = reqRepository;
            this.taskworkRepository = taskworkRepository;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
        }

        public async Task<int> DeleteAsync(Guid id)
        {
            try
            {
                var result = await this.repository.DeleteAsyn(id);
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<IList<AvailabilityCertIssueEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<AvailabilityCertIssueEntity>>(result);
            return mapped;
        }

        public async Task<AvailabilityCertIssuePrintEntity> GetAsyncForPrint(Guid id)
        {
            try
            {
                 AvailabilityCertIssuePrintEntity ACPE = new AvailabilityCertIssuePrintEntity();

                // var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertIssueDetail).Include("AvailabilityCertIssueDetail.Item").Include
                  var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(y=>y.AvailabilityCertReqest).Include(m => m.AvailabilityCertIssueDetail).Include("AvailabilityCertIssueDetail.Item").Include
                 ("AvailabilityCertIssueDetail.Item.ItemUom").Include
                 ("AvailabilityCertIssueDetail.ItemBasicCategory").Include
                 ("AvailabilityCertIssueDetail.ItemBasicCategory.BasicCategory").Include("AvailabilityCertIssueDetail.ItemEquipment").Include
                 ("AvailabilityCertIssueDetail.ItemEquipment.Equipment"));
                var mapped = this.mapper.Map<AvailabilityCertIssueEntity>(result);
                mapped.ReqestNo = string.IsNullOrEmpty(mapped.ReqestNo) ? this.reqRepository.FindBy(x => x.Id == mapped.AvailabilityCertReqestId).FirstOrDefault().RequestNo : mapped.ReqestNo;
                mapped.AvailabilityCertIssueDetail.ForEach(x => {
                    var details = result.AvailabilityCertIssueDetail.Where(i => i.Id == x.Id).FirstOrDefault();
                    x.Place = details.Item.ItemUom.DigitAfterDecimal;
                    x.ItemUomName = details.Item.ItemUom.Name;
                    x.CategoryName = details.ItemBasicCategory.BasicCategory.Name;
                    x.EquipmentName = details.ItemEquipment.Equipment.Name;
                    x.ItemName = details.Item.Name;
                    x.AvailableQuantiy = decimal.Round(x.AvailableQuantiy, details.Item.ItemUom.DigitAfterDecimal);
                    x.RequestedQuantiy = decimal.Round(x.RequestedQuantiy, details.Item.ItemUom.DigitAfterDecimal);
                    x.AvailabilityCertIssueId = mapped.Id;
                });

                ACPE.AvailabilityCertIssueModel = mapped;






                var FromOrg = await Organization.GetAsync(result.StoreId);
                var userReq = Usermgr.Get(result.AvailabilityCertReqest.CreatedBy);
                var ToOrg = await Organization.GetAsync(userReq.OrganizationId);

                ACPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(ToOrg);
                ACPE.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(FromOrg);
                var user = Usermgr.Get(result.CreatedBy);
                ACPE.userDetail = this.mapper.Map<UserEntity>(user);
                ACPE.AvailabilityCertRequestModel = this.mapper.Map<AvailabilityCertRequestEntity>(result.AvailabilityCertReqest);


                return ACPE;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<AvailabilityCertIssueEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertIssueDetail).Include("AvailabilityCertIssueDetail.Item").Include
             ("AvailabilityCertIssueDetail.Item.ItemUom").Include
             ("AvailabilityCertIssueDetail.ItemBasicCategory").Include
             ("AvailabilityCertIssueDetail.ItemBasicCategory.BasicCategory").Include("AvailabilityCertIssueDetail.ItemEquipment").Include
             ("AvailabilityCertIssueDetail.ItemEquipment.Equipment"));
            var mapped = this.mapper.Map<AvailabilityCertIssueEntity>(result);
            mapped.ReqestNo = string.IsNullOrEmpty(mapped.ReqestNo)? this.reqRepository.FindBy(x => x.Id == mapped.AvailabilityCertReqestId).FirstOrDefault().RequestNo:mapped.ReqestNo;
            mapped.AvailabilityCertIssueDetail.ForEach(x => {
                var details = result.AvailabilityCertIssueDetail.Where(i => i.Id == x.Id).FirstOrDefault();
                x.Place = details.Item.ItemUom.DigitAfterDecimal;                
                x.ItemUomName = details.Item.ItemUom.Name;
                x.CategoryName = details.ItemBasicCategory.BasicCategory.Name;
                x.EquipmentName = details.ItemEquipment.Equipment.Name;
                x.ItemName = details.Item.Name;
                x.AvailableQuantiy = decimal.Round(x.AvailableQuantiy, details.Item.ItemUom.DigitAfterDecimal);
                x.RequestedQuantiy = decimal.Round(x.RequestedQuantiy, details.Item.ItemUom.DigitAfterDecimal);
                x.AvailabilityCertIssueId = mapped.Id;
            });
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isFinelIssue = await this.taskworkRepository.FindAllAsync(x => x.TaskId == (int)TaskTypeEnum.Request && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId) != null;

            DataTableResult response = new DataTableResult();
            var query = this.repository.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId || x.UnitId == parameters.OrganizationId, x=>x.Include(m => m.AvailabilityCertReqest).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AvailabilityCertIssue)x;
                //var fromApproveal = y.AvailabilityCertIssueApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                //var toApproveal = y.AvailabilityCertIssueApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                //bool isApproved = toApproveal == null && fromApproveal != null;
                requiredData.Add(new AvailabilityCertIssueGrid
                {
                    Id = y.Id,
                    IssueDate = y.IssueDate,
                    RequestDate = y.AvailabilityCertReqest.RequestDate,
                    StoreName = y.Store.Name,
                    UnitName = y.Unit.Name,
                    IssueNo = y.CertificateNo.ToString(),
                    RequestNo = y.AvailabilityCertReqest.RequestNo.ToString(),
                    Remark = y.Remark,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId)
                    //IsLoanRequest = isFinelIssue && y.UnitId==parameters.OrganizationId,
                    //IsApprove=false //y.IsApproved && isApproved

                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<AvailabilityCertIssueEntity> InsertAsync(AvailabilityCertIssueEntity entity)
        {
            try
            {
                if (!entity.IsApproved)
                {
                    var oldResult = this.reqRepository.Find(x => x.Id == entity.AvailabilityCertReqestId);
                    oldResult.StatusId = entity.StatusId;
                    oldResult.IsApproved = entity.IsApproved;
                    oldResult.IsActive = entity.IsApproved;
                    oldResult.ApprovedDesignationId = entity.DesignationId;
                    await this.reqRepository.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);
                    return entity;
                }

                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Issue && x.ToDesignationId == entity.DesignationId && x.ToOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<AvailabilityCertIssue>(entity);
                mapped.AvailabilityCertReqestId = mapped.AvailabilityCertReqestId == Guid.Empty ? this.reqRepository.FindBy(x => x.RequestNo == entity.ReqestNo).FirstOrDefault().Id : mapped.AvailabilityCertReqestId;
                mapped.AssignedDesignationId = workFlow?.ToDesignationId?? entity.DesignationId;
                mapped.ApprovedDesignationId = entity.DesignationId;
                //mapped.AvailabilityCertIssueApproval.Add(new AvailabilityCertIssueApproval
                //{
                //    ApprovedDate = DateTime.Now,
                //    CreatedBy = entity.CreatedBy,
                //    CreatedDate = entity.CreatedDate,
                //    FromDesignationId = workFlow.ToDesignationId.Value,
                //    FromOrganizationId = workFlow.ToOrganizationId.Value,
                //    IsApproved = entity.IsApproved,
                //    ToDesignationId = workFlow.FromDesignationId,
                //    ToOrganizationId = workFlow.FromOrganizationId,
                //    UpdatedBy = entity.UpdatedBy,
                //    UpdatedDate = entity.UpdatedDate,
                //    Note = entity.Note

                //});                
                
                var result = await this.repository.AddAsyn(mapped);
                var requestResult = this.reqRepository.Find(x => x.Id == entity.AvailabilityCertReqestId);
                requestResult.StatusId = (int) StatusEnum.Approved;                
                await this.reqRepository.UpdateAsync(requestResult, requestResult.Id, entity.RowVersion);
                return this.mapper.Map<AvailabilityCertIssueEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<AvailabilityCertIssueEntity> ApproveAsync(AvailabilityCertIssueEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertIssueApproval).Include(m => m.AvailabilityCertIssueDetail));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Request && x.ToDesignationId == entity.DesignationId && x.ToOrganizationId == entity.UnitId);
                if (workFlow != null)
                {
                    oldResult.AvailabilityCertIssueApproval.Add(new AvailabilityCertIssueApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = workFlow.ToDesignationId.Value,
                        FromOrganizationId = workFlow.ToOrganizationId.Value,
                        IsApproved = entity.IsApproved,
                        ToDesignationId = workFlow.FromDesignationId,
                        ToOrganizationId = workFlow.FromOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note = entity.Note,
                        AvailabilityCertIssueId = oldResult.Id
                    });
                }
                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<AvailabilityCertIssueEntity> UpdateAsync(AvailabilityCertIssueEntity entity)
        {

            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertIssueDetail));

            if (existingRecord != null)
            {
                var existingTransactions = existingRecord.AvailabilityCertIssueDetail.Where(x => entity.AvailabilityCertIssueDetail.Any(scdet => scdet.Id == x.Id)).ToList();
                var deletedTransactions = existingRecord.AvailabilityCertIssueDetail.Where(x => !entity.AvailabilityCertIssueDetail.Any(scdet => scdet.Id == x.Id)).ToList();

                if (entity.AvailabilityCertIssueDetail.Any())
                {
                    var insertedTransactions = entity.AvailabilityCertIssueDetail.Where(x => !existingRecord.AvailabilityCertIssueDetail.Any(it => it.Id == x.Id)).ToList();
                    AddTransaction(insertedTransactions, existingRecord);
                }


                UpdateStorestock(existingRecord, entity);

                UpdateTransaction(existingTransactions, entity);




                deletedTransactions.ForEach(x =>
                {
                    x.ObjectState = EntityState.Deleted;
                });
            }


            var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);

            return this.mapper.Map<AvailabilityCertIssueEntity>(result);
        }

        private void UpdateStorestock(AvailabilityCertIssue existingRecord, AvailabilityCertIssueEntity entity)
        {
            existingRecord.CertificateNo = entity.CertificateNo;
            existingRecord.StoreId = entity.StoreId;
            existingRecord.IsDeleted = entity.IsDeleted;
            existingRecord.IsIssued = entity.IsIssued;
            existingRecord.IssueDate = entity.IssueDate;
            existingRecord.Remark = entity.Remark;
            existingRecord.StatusId = entity.StatusId;
            existingRecord.UnitId = entity.UnitId;
            existingRecord.YearId = entity.YearId;
        }

        private void UpdateTransaction(List<AvailabilityCertIssueDetail> existingTransactions, AvailabilityCertIssueEntity entity)
        {
            if (existingTransactions != null)
            {


                existingTransactions.ForEach(transaction =>
                {
                    var availabilityCert = entity.AvailabilityCertIssueDetail.FirstOrDefault(x => x.Id == transaction.Id);

                    transaction.ObjectState = EntityState.Modified;
                    transaction.ItemId = availabilityCert.ItemId;
                    transaction.ItemBasicCategoryId = availabilityCert.ItemBasicCategoryId;
                    transaction.ItemEquipmentId = availabilityCert.ItemEquipmentId;
                    transaction.ItemEquipmentTypeId = availabilityCert.ItemEquipmentTypeId;
                    transaction.RequestedQuantiy = availabilityCert.RequestedQuantiy;
                    transaction.AvailableQuantiy = availabilityCert.AvailableQuantiy;
                    transaction.UpdatedBy = availabilityCert.UpdatedBy;
                    transaction.UpdatedDate = availabilityCert.UpdatedDate;
                });
            }
        }

        private void AddTransaction(List<AvailabilityCertIssueDetailEntity> insertedTransactions, AvailabilityCertIssue existingRecord)
        {
            if (insertedTransactions != null)
            {
                insertedTransactions.ForEach(x =>
                {
                    existingRecord.AvailabilityCertIssueDetail.Add(new AvailabilityCertIssueDetail()
                    {
                        ObjectState = EntityState.Added,
                        ItemId = x.ItemId,
                        ItemBasicCategoryId = x.ItemBasicCategoryId,
                        ItemEquipmentId = x.ItemEquipmentId,
                        ItemEquipmentTypeId = x.ItemEquipmentTypeId,
                        RequestedQuantiy = x.RequestedQuantiy,
                        AvailableQuantiy = x.AvailableQuantiy,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        CreatedBy = x.UpdatedBy,
                        CreatedDate = x.CreatedDate,

                    });
                });
            }
        }
    }
}
