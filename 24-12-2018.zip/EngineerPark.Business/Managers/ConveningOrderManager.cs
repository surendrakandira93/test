﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class ConveningOrderManager : IConveningOrderManager
    {
        private IGenericRepository<ConveningOrder> repository;
        private IGenericRepository<ConveningOrderMember> memberRepository;
        private IGenericRepository<ReleaseOrder> releaseOrderRepository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<Organization> organizationRepository;
        private IMapper mapper;
        private IGenericRepository<ConveningOrderSurveySalvageTemp> conveningOrderSurveySalvageTemp;
        private IGenericRepository<SalvageIn> salvageInRepository;

        public ConveningOrderManager(IMapper mapper, IGenericRepository<ConveningOrder> repository, IGenericRepository<ReleaseOrder> releaseOrderRepository, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<ConveningOrderMember> memberRepository, IGenericRepository<Organization> organizationRepository, IGenericRepository<ConveningOrderSurveySalvageTemp> conveningOrderSurveySalvageTemp, IGenericRepository<SalvageIn> salvageInRepository)
        {
            this.mapper = mapper;
            this.releaseOrderRepository = releaseOrderRepository;
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.memberRepository = memberRepository;
            this.organizationRepository = organizationRepository;
            this.conveningOrderSurveySalvageTemp = conveningOrderSurveySalvageTemp;
            this.salvageInRepository = salvageInRepository;
        }

        public async Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            // x=>x.LoanIssueVoucher.Count()>0,
            IQueryable<ReleaseOrder> query = this.releaseOrderRepository.GetAllIncludingIQueryableAsyn(x => x.LoanRequest.StoreId == parameters.OrganizationId && x.LoanIssueVoucher.Count > 0, x => x.Include(m => m.ConveningOrder)
                   .Include(m => m.LoanIssueVoucher).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    LoanRequestDate = y.LoanIssueVoucher.FirstOrDefault().VoucherDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    LoanRequestNo = y.LoanIssueVoucher.FirstOrDefault().VoucherNo,
                    ReleaseDate = y.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsApproved = y.ConveningOrder.Count() == 0
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {


            bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

            var isAccessAble = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId);
            var currentOrg = await this.organizationRepository.FindAsync(x => x.Id == parameters.OrganizationId);
            DataTableResult response = new DataTableResult();
            // x.ConveningOrderApproval.Where(a => (a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId) || (a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId)).Count() > 0
            IQueryable<ConveningOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId || x.ReleaseOrder.LoanRequest.UnitId == parameters.OrganizationId || isAccessAble != null, x => x.Include(m => m.ConveningOrderItem)
                    .Include(m => m.ConveningOrderApproval)
                    .Include(m => m.ConveningOrderMember)
                    .Include(m => m.ConveningOrderItemSurveyMain)
                    .Include(m => m.ReleaseOrder).Include(m => m.Store).Include(m => m.Unit).Include(m => m.ApprovedDesignation).Include(m => m.AssignedDesignation));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveningOrder)x;
                var fromWork = y.ConveningOrderApproval.LastOrDefault();
                bool isApproved = (fromWork.ToDesignationId == parameters.DesignationId && fromWork.ToOrganizationId == parameters.OrganizationId) && !(fromWork.FromDesignationId == parameters.DesignationId && fromWork.FromOrganizationId == parameters.OrganizationId);

               // bool isFinelConveorder = (fromWork.FromDesignationId == parameters.DesignationId && fromWork.FromOrganizationId == parameters.OrganizationId) && (fromWork.ToDesignationId == null && fromWork.ToOrganizationId == null);

                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrderNo,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    RequestDate = y.RequestDate,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    IssueDate = y.IssueDate,
                    UnitName = y.Unit.Name,
                    IsApproved = y.IsApproved && isApproved && y.ConveningOrderItemSurveyMain.Any() && y.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved,// !isFinelConveorder,
                    IsIssueOrder = isApproved && y.IsApproved && isFinelConveorder && y.IssueDate == null,
                    IsMakeMember = y.ConveningOrderMember.Count() == 0 && currentOrg.OrganizationTypeId == (int)OrganizationEnum.EPBTI,
                    ApprovedDesignation = y.ApprovedDesignation.Name,
                    AssignedDesignation = y.AssignedDesignation.Name,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId)
                    //FileName=!string.IsNullOrEmpty(y.ConveningOrderApproval.LastOrDefault().FileName)?y.ConveningOrderApproval.LastOrDefault().FileName:y.ConveningOrderItemSurveyMain.FirstOrDefault().FileName
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<ConveningOrderEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m => m.ReleaseOrder).Include(m => m.ConveningOrderItem).Include(m => m.ConveningOrderApproval).Include(m => m.ConveningOrderItemSurveyMain).Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.Item.ItemUom").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new ConveningOrderEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreId = result.StoreId;
            response.RequestDate = result.RequestDate;
            response.StoreName = result.Store.Name;
            response.FileName = result.ConveningOrderApproval.Any() && !string.IsNullOrEmpty(result.ConveningOrderApproval.LastOrDefault().FileName) ? result.ConveningOrderApproval.LastOrDefault().FileName : (result.ConveningOrderItemSurveyMain.Any() ? result.ConveningOrderItemSurveyMain.FirstOrDefault().FileName : string.Empty);
            var convening = result.ConveningOrderApproval.LastOrDefault();
            var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromDesignationId == convening.ToDesignationId.Value && x.FromOrganizationId == convening.ToOrganizationId);
            response.FromDesignationId = convening.ToDesignationId;
            response.FromOrganizationId = convening.ToOrganizationId;
            if (workFlow != null)
            {
                response.ToDesignationId = workFlow.ToDesignationId;
                response.ToOrganizationId = workFlow.ToOrganizationId;
            }
            

            foreach (var item in result.ConveningOrderItem)
            {
                response.ConveningOrderItem.Add(new ConveningOrderItemEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                    ItemName = item.Item.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    ItemId = item.ItemId,
                    LoanQuantiy = item.LoanQuantiy,
                    ReceivedQuantiy = item.ReceivedQuantiy,
                    ReturnQuantiy = item.ReturnQuantiy,
                    ConveningOrderId = item.ConveningOrderId,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Id = item.Id,
                    Remarks = item.Remarks,
                    RowId = item.RowId,
                    RowVersion = item.RowVersion,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate


                });
            }

            return response;
        }

        public async Task<ConveningOrderEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId, short organizationId, short designationId)
        {
            var result = await this.releaseOrderRepository.GetIncludingByIdAsyn(x => x.Id == releaseOrderId, x => x.Include(m => m.Store).Include(m => m.LoanRequest).Include("ReleaseOrderDetail.ItemBasicCategory").Include("ReleaseOrderDetail.Item").Include("ReleaseOrderDetail.Item.ItemUom").Include("ReleaseOrderDetail.ItemBasicCategory.BasicCategory").Include("ReleaseOrderDetail.ItemEquipment").Include("ReleaseOrderDetail.ItemEquipment.Equipment").Include("ReleaseOrderDetail.ItemEquipmentType").Include("ReleaseOrderDetail.ItemEquipmentType.EquipmentType"));
            var response = new ConveningOrderEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrderNo;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            foreach (var item in result.ReleaseOrderDetail)
            {

                response.ConveningOrderItem.Add(new ConveningOrderItemEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,

                    ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                    ItemName = item.Item.Name,
                    ItemId = item.ItemId,
                    LoanQuantiy = decimal.Round(item.Quantiy, item.Item.ItemUom.DigitAfterDecimal)
                });
            }

            return response;
        }

        public async Task<ConveningOrderEntity> InsertAsync(ConveningOrderEntity entity)
        {
            try
            {
                //var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<ConveningOrder>(entity);
                var release = await this.releaseOrderRepository.GetIncludingFindByAsyn(x => x.Id == entity.ReleaseOrderId, x => x.Include(m => m.LoanRequest).Include(m => m.LoanRequest.LoanRequestAssign));
                mapped.AssignedDesignationId = release.FirstOrDefault().LoanRequest.LoanRequestAssign.Where(x => x.FromOrganizationId == release.FirstOrDefault().LoanRequest.UnitId).FirstOrDefault().FromDesignationId;
                mapped.ApprovedDesignationId = entity.DesignationId;
                mapped.ConveningOrderApproval.Add(new ConveningOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = release.FirstOrDefault().LoanRequest.LoanRequestAssign.Where(x => x.FromOrganizationId == release.FirstOrDefault().LoanRequest.UnitId).FirstOrDefault().FromDesignationId,
                    ToOrganizationId = release.FirstOrDefault().LoanRequest.UnitId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    FileName = entity.FileName

                });
                var result = await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<ConveningOrderEntity> ApproveAsync(ConveningOrderEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.ConveningOrderApproval).Include(m => m.ConveningOrderItem));
                // var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.StatusId = entity.StatusId;
                oldResult.IsApproved = entity.IsApproved;
                if (entity.IsApproved)
                {
                    oldResult.IssueDate = entity.IssueDate;

                    var list = await this.conveningOrderSurveySalvageTemp.FindAllAsync(x => x.ConveningOrderId == oldResult.Id);
                    if (list != null && list.Count > 0)
                    {
                        List<SalvageIn> salvageInList = new List<SalvageIn>();
                        salvageInList = list.Select(x => new SalvageIn { MaterialTypeId = x.MaterialTypeId, OrganizationId = oldResult.StoreId, Auth = x.Auth, CreatedBy = oldResult.CreatedBy, StoreId = oldResult.StoreId = oldResult.StoreId, CreatedDate = DateTime.Now, Remark = x.Remark, Date = DateTime.Now, UpdatedBy = oldResult.UpdatedBy, UpdatedDate = DateTime.Now, Weight = x.Weight }).ToList();
                        await this.salvageInRepository.AddRangeAsyn(salvageInList);
                        await this.conveningOrderSurveySalvageTemp.DeleteRangeAsyn(list);
                    }

                }
                oldResult.IsActive = entity.IsActive;
                oldResult.ApprovedDesignationId = entity.DesignationId;
                oldResult.AssignedDesignationId = entity.ToDesignationId.HasValue ? entity.ToDesignationId.Value : entity.FromDesignationId.Value;

                oldResult.ConveningOrderApproval.Add(new ConveningOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    ConveningOrderId = oldResult.Id,
                    FileName = entity.FileName
                });


                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<bool> SaveOrderMember(ConveningOrderMainMember entity)
        {
            try

            {
                var conveningOrderId = entity.OrderMember.FirstOrDefault().ConveningOrderId;
                var conveningOrder = this.repository.Get(conveningOrderId);
                conveningOrder.Poid = entity.Poid;
                await this.repository.UpdateAsync(conveningOrder, conveningOrderId);

                var mapped = this.mapper.Map<List<ConveningOrderMember>>(entity.OrderMember);
                var result = await this.memberRepository.AddRangeAsyn(mapped);

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return true;
        }


    }
}