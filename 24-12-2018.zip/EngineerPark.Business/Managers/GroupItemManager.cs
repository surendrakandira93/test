﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
   
    public class GroupItemManager : IGroupItemManager
    {
        private IGenericRepository<GroupItem> repository; 
        private IGenericRepository<GroupItemBasicCategory> GroupitemBasicCategoryRepository;
        private IGenericRepository<GroupItemDetail> groupitemdetailrepository;
        private IGenericRepository<GroupItemBasicCategory> groupitembasicrepository;
        private IMapper mapper;

        public GroupItemManager(IMapper mapper, IGenericRepository<GroupItem> repository, IGenericRepository<GroupItemBasicCategory> groupitembasicrepository1, IGenericRepository<GroupItemBasicCategory> GroupitemBasicCategoryRepository, IGenericRepository<GroupItemDetail> groupitemdetailrepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.groupitemdetailrepository = groupitemdetailrepository;
            this.GroupitemBasicCategoryRepository = GroupitemBasicCategoryRepository;
            this.groupitembasicrepository = groupitembasicrepository1;
        }

        public async Task<int> DeleteAsync(Guid id)
        {
            //var result = await this.repository.DeleteAsyn(id);
            //return result;

            try
            {
                int result = 0;
                var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, (x => x.Include(m => m.GroupItemDetail).Include(m=>m.GroupItemBasicCategory)));
                if (existingRecord != null)
                {
                    if (existingRecord.GroupItemDetail.Any())
                    {
                        this.groupitemdetailrepository.DeleteRange(existingRecord.GroupItemDetail.ToList());
                    }
                    if (existingRecord.GroupItemBasicCategory.Any())
                    {
                        this.groupitembasicrepository.DeleteRange(existingRecord.GroupItemBasicCategory.ToList());
                    }
                    this.repository.DeleteEntity(existingRecord);
                    result = await this.repository.SaveAsync();
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<IList<GroupItemEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();
            var mapped = this.mapper.Map<IList<GroupItemEntity>>(result);
            return mapped;
        }

        public async Task<IList<GroupItemDetlEntity>> GetGroupItemChildListAsync()
        {
            try
            {
                List<GroupItemDetlEntity> responseList = new List<GroupItemDetlEntity>();
                var result = await this.repository.GetAllIncludingAsyn(x => x.Include(y => y.GroupItemBasicCategory).Include("GroupItemBasicCategory.BasicCategory"));
                foreach (var r in result)
                {
                    GroupItemDetlEntity response = new GroupItemDetlEntity();
                    response.GroupItemId = r.Id;
                    response.BasicCategoryList = r.GroupItemBasicCategory.Any() ? r.GroupItemBasicCategory.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.BasicCategory.Name }).ToList() : new List<MasterDataEntity>();                    
                    responseList.Add(response);
                }
                return responseList;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<GroupItemEntity> GroupItemDetailAsync(Guid id)
        {
            GroupItemEntity response = new GroupItemEntity();
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(y => y.Category).Include("Category").Include(y => y.ItemUom).Include("ItemUom"));
            var mapped = this.mapper.Map<GroupItemEntity>(result);
            return mapped;
        }

        public async Task<IList<GroupItemMslEntity>> GroupItemsbyCatagoryAsync(short catId)
        {
            // GroupItemEntity response = new GroupItemEntity();
             List<GroupItemMslEntity> en = new List<GroupItemMslEntity>();
             //var result = await this.repository.GetIncludingByIdAsyn(x => x.CategoryId == catId, x => x.Include(y => y.Category).Include("Category").Include(y => y.ItemUom).Include("ItemUom"));
            var result = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ItemUom).Include(m => m.Category)).Where(x=>x.CategoryId==catId);
            if (result!=null)
             {
                foreach (var Item in result)
                {
                    GroupItemMslEntity entity = new GroupItemMslEntity();
                    entity.Id = Item.Id;
                    entity.Name = Item.Name;
                    entity.CategoryName = Item.Category.Name;
                    entity.ItemUomName = Item.ItemUom.Name;
                    entity.MinimumStockLevelPercent = Item.MinimumStockLevelPercent;
                    entity.RowVersion = Item.RowVersion;
                    en.Add(entity);
                }

             }


            var mapped = this.mapper.Map<IList<GroupItemMslEntity>>(en);
            return mapped;
        }

        public async Task<GroupItemEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, (x => x.Include(m => m.GroupItemDetail).Include("GroupItemDetail.Item").Include("GroupItemDetail.Item.ItemUom").Include(y => y.GroupItemBasicCategory)));
            var mapped = this.mapper.Map<GroupItemEntity>(result);
            mapped.BasicCategoryId = result.GroupItemBasicCategory.Select(x => x.BasicCategoryId).ToList();

            foreach (var item in mapped.GroupItemDetail)
            {
                var subItem = result.GroupItemDetail.FirstOrDefault(x => x.ItemId == item.ItemId);
                if(subItem!=null)
                { 
                    item.NameUnitOfMeasure = subItem.Item.ItemUom.Name;
                    item.DigitAfterDecimal = subItem.Item.ItemUom.DigitAfterDecimal;
                    item.Quantity = Math.Round(item.Quantity, Convert.ToInt32(item.DigitAfterDecimal));
                }
            }
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<GroupItem>(parameters);
            predicate = predicate.Or(x => x.ItemUom.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.Category.Name.Contains(parameters.Search.Value));
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ItemUom).Include(m => m.Category));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (GroupItem)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    Description = y.Description,
                    ItemUomId = y.ItemUom.Name,
                    CategoryId = y.Category.Name,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }
        
        public async Task<GroupItemEntity> InsertAsync(GroupItemEntity entity)
        {           
            try
            {
                var mapped = this.mapper.Map<GroupItem>(entity);
                this.GetGroupItemBasicCategory(mapped, entity.BasicCategoryId);
                var result = await this.repository.AddAsyn(mapped);                
                return this.mapper.Map<GroupItemEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }                        
        }
        
        public async Task<bool> IsExistorNot(string name, Guid id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        
        public async Task<GroupItemEntity> UpdateAsync(GroupItemEntity entity)
        {
            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, (x => x.Include(m => m.GroupItemDetail)));

            if (existingRecord != null)
            {
                #region ItemPart Updation

                if (entity.GroupItemDetail != null)
                {
                    var existingItemParts = existingRecord.GroupItemDetail.Where(x => entity.GroupItemDetail.Any(scdet => scdet.Id == x.Id)).ToList();
                    var deletedItemParts = existingRecord.GroupItemDetail.Where(x => !entity.GroupItemDetail.Any(scdet => scdet.Id == x.Id)).ToList();
                    var InsertedItemParts = entity.GroupItemDetail.Where(x => !existingRecord.GroupItemDetail.Any(m => m.Id == x.Id)).ToList();
                    UpdateItemPart(existingItemParts, entity);

                    if (deletedItemParts.Any())
                    {
                        this.groupitemdetailrepository.DeleteRange(deletedItemParts);
                    }

                    if (InsertedItemParts.Any())
                    {
                        AddItemPart(InsertedItemParts, existingRecord);
                    }
                }
                else if (existingRecord.GroupItemDetail.Any())
                {
                    this.groupitemdetailrepository.DeleteRange(existingRecord.GroupItemDetail.ToList());
                }

                #endregion ItemPart Updation

                #region GroupItemBasicCategory Updation

                if (entity.BasicCategoryId != null)
                {
                    var existingItemBasicCategoryItem = existingRecord.GroupItemBasicCategory.Where(x => entity.BasicCategoryId.Any(scdet => scdet == x.BasicCategoryId)).ToList();

                    var deletedItemBasicCategoryItem = existingRecord.GroupItemBasicCategory.Where(x => !entity.BasicCategoryId.Any(scdet => scdet == x.BasicCategoryId)).ToList();

                    var InsertedItemBasicCategoryItem = entity.BasicCategoryId.Where(x => !existingRecord.GroupItemBasicCategory.Any(m => m.BasicCategoryId == x)).ToList();

                    UpdateGroupItemBasicCategory(existingItemBasicCategoryItem, entity);

                    if (deletedItemBasicCategoryItem.Any())
                    {
                        this.GroupitemBasicCategoryRepository.DeleteRange(deletedItemBasicCategoryItem);
                    }

                    if (InsertedItemBasicCategoryItem.Any())
                    {
                        AddGroupItemBasicCategory(InsertedItemBasicCategoryItem, existingRecord, entity.CreatedBy);
                    }
                }
                else if (existingRecord.GroupItemBasicCategory.Any())
                {
                    this.GroupitemBasicCategoryRepository.DeleteRange(existingRecord.GroupItemBasicCategory.ToList());
                }

                #endregion ItemBasicCategory Updation

                UpdateItem(existingRecord, entity);
            }

            var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);

            return this.mapper.Map<GroupItemEntity>(result);
        }

        public async Task<GroupItemEntity> UpdateMslAsync(GroupItemMslModelEntity entityMsl)
        {
            foreach (var entity in entityMsl.GroupItemMsl)
            {
                var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, (x => x.Include(m => m.GroupItemDetail)));
                if (existingRecord != null)
                {
                    UpdateItemMsl(existingRecord, entity);
                }

                var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);
            }
           // return this.mapper.Map<GroupItemEntity>(result);
            return null;
        }

        public async Task<List<GroupItemDto>> GetitemDetails(Guid groupId)
        {
            var list =await this.groupitemdetailrepository.GetIncludingFindByAsyn(x => x.GroupItemId == groupId,x=>x.Include(m=>m.Item).Include(m=>m.Item.ItemUom));
            return list.Select(x => new GroupItemDto { ItemId = x.ItemId, ItemName = x.Item.Name, Quantity = x.Quantity, GroupItemId = x.GroupItemId, AU = x.Item.ItemUom.Name }).ToList();

        }

        private void UpdateItemMsl(GroupItem existingRecord, GroupItemMslEntity entity)
        {
            existingRecord.MinimumStockLevelPercent = entity.MinimumStockLevelPercent;
            existingRecord.UpdatedBy = entity.UpdatedBy;
            existingRecord.UpdatedDate = entity.UpdatedDate;

        }

        private void UpdateItem(GroupItem existingRecord, GroupItemEntity entity)
        {            
            existingRecord.Name = entity.Name;
            existingRecord.Description = entity.Description;
            existingRecord.CategoryId = entity.CategoryId;
            existingRecord.ItemUomId = entity.ItemUomId;
            
        }

        private void UpdateItemPart(List<GroupItemDetail> existingItemParts, GroupItemEntity entity)
        {
            if (existingItemParts != null)
            {
                existingItemParts.ForEach(GroupItemDetail =>
                {
                    var UpdatedItemPart = entity.GroupItemDetail.FirstOrDefault(x => x.Id == GroupItemDetail.Id);

                    GroupItemDetail.ObjectState = EntityState.Modified;
                    GroupItemDetail.ItemId = UpdatedItemPart.ItemId;
                    GroupItemDetail.Quantity = UpdatedItemPart.Quantity;
                });
            }
        }

        private void AddItemPart(List<GroupItemDetailEntity> insertedItemParts, GroupItem existingRecord)
        {
            if (insertedItemParts != null)
            {
                insertedItemParts.ForEach(x =>
                {
                    existingRecord.GroupItemDetail.Add(new GroupItemDetail()
                    {
                        ItemId = x.ItemId,
                        Quantity = x.Quantity,
                        UpdatedBy = x.UpdatedBy,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        UpdatedDate = x.UpdatedDate,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }

        //private void AddItemPart(List<ItemPartsEntity> insertedItemParts, Item existingRecord)
        //{
        //    if (insertedItemParts != null)
        //    {
        //        insertedItemParts.ForEach(x =>
        //        {
        //            existingRecord.ItemPartItem.Add(new ItemPart()
        //            {
        //                ItemId = x.ItemId,
        //                Quantity = x.Quantity,
        //                UpdatedBy = x.UpdatedBy,
        //                CreatedBy = x.CreatedBy,
        //                CreatedDate = x.CreatedDate,
        //                UpdatedDate = x.UpdatedDate,
        //                ObjectState = EntityState.Added
        //            });
        //        });
        //    }
        //}

        private void AddGroupItemBasicCategory(List<short> inserted, GroupItem existingRecord, Guid createdBy)
        {
            if (inserted != null)
            {
                inserted.ForEach(x =>
                {
                    existingRecord.GroupItemBasicCategory.Add(new GroupItemBasicCategory()
                    {
                        BasicCategoryId = x,
                        UpdatedBy = createdBy,
                        CreatedBy = createdBy,
                        CreatedDate = DateTime.UtcNow,
                        UpdatedDate = DateTime.UtcNow,
                        ObjectState = EntityState.Added
                    });
                });
            }
        }

        private void UpdateGroupItemBasicCategory(List<GroupItemBasicCategory> existing, GroupItemEntity entity)
        {
            if (existing != null)
            {
                existing.ForEach(existRecord =>
                {
                    var UpdatedRecord = entity.BasicCategoryId.FirstOrDefault(x => x == existRecord.BasicCategoryId);

                    existRecord.ObjectState = EntityState.Modified;
                    existRecord.BasicCategoryId = UpdatedRecord;
                });
            }
        }

        private void GetGroupItemBasicCategory(GroupItem groupitem, List<short> basicCategoriesId)
        {
            foreach (var id in basicCategoriesId)
            {
                groupitem.GroupItemBasicCategory.Add(new GroupItemBasicCategory
                {
                    CreatedBy = groupitem.CreatedBy,
                    CreatedDate = groupitem.CreatedDate,
                    BasicCategoryId = id,
                    GroupItemId = groupitem.Id,
                    UpdatedBy = groupitem.UpdatedBy,
                    UpdatedDate = groupitem.UpdatedDate,
                    ObjectState = EntityState.Added
                });
            }
        }




    }
}
