﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Data.Entity;

namespace EngineerPark.Business.Managers
{
    public class UserManager : IUserManager
    {

        private IGenericRepository<User> repository;
        private IGenericRepository<UserMack> repositoryUserMack;
        private IGenericRepository<Loginhistory> repositoryLoginhistory;
        private readonly IRoleManager roleManager;
        private readonly IOrganizationManager OrganizationManager;
        private IMapper mapper;
        private IGenericRepository<Report> report;
        public UserManager(IMapper mapper,IGenericRepository<User> repository, IRoleManager roleManager, IOrganizationManager OrganizationManager, IGenericRepository<Loginhistory> repositoryLoginhistory, IGenericRepository<UserMack> repositoryUserMack, IGenericRepository<Report> report)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.repositoryLoginhistory = repositoryLoginhistory;
            this.roleManager = roleManager;
            this.OrganizationManager = OrganizationManager;
            this.repositoryUserMack = repositoryUserMack;
            this.report = report;
        }

        public async Task<bool> InsertAsync(UserEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<User>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return result.Id != Guid.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Tuple<Guid,bool>> LoginAsync(Loginentity entity)
        {
            try
            {
                var userStatus = await this.repository.FindAsync(x => x.LoginName == entity.UserName);
                if (userStatus == null)
                {
                    throw new Exception("User does not exist!");
                }

                //var mackList = this.repositoryUserMack.FindAll(x => x.UserId == userStatus.Id);
                //if ( userStatus.RoleId!= (int)RoleTypeEnum.Admin && !mackList.Any(x=>x.MackAddress.ToLower()== entity.MackAddress.ToLower()))
                //{
                //    throw new Exception("Invalid system Mac address.");
                //}


                    if (userStatus.IsLock) {
                    return new Tuple<Guid, bool>(userStatus.Id, userStatus.IsLock);
                }

                var user = await this.repository.FindAsync(x => x.LoginName == entity.UserName && x.PasswordHash == entity.Password);
                if (user == null)
                {
                    string message = "Invalid login attempt.";
                    var update = await this.repository.FindAsync(x => x.LoginName == entity.UserName);
                    update.LoginAttemp += 1;
                    message = $"You have attempted {update.LoginAttemp} with invalid username and password, after 3rd time you will be locked.";
                    if (update.LoginAttemp == 3)
                    {
                        update.IsLock = true;
                        message = $"You have attempted {update.LoginAttemp} with invalid username and password,So your account have been locked. Please contact to admin";
                    }

                    await this.repository.UpdateAsync(update,update.Id);

                    throw new Exception(message);
                }
                if (!user.IsActive.Value)
                {
                    throw new Exception("Your account is deactive,Please contact to admin.");
                }

                if (user.ExpiryDate.HasValue && user.ExpiryDate.Value < DateTime.Now)
                {
                    throw new Exception("Your account is expire. Please contact to admin.");
                }

                if (user.IsLock)
                {
                    throw new Exception("Your account is locked,Please contact to admin.");
                }

                return new Tuple<Guid, bool>(user != null ? user.Id : Guid.Empty, false);
            }
            catch (Exception ex)
            {
                throw ex; ;
            }
        }

        public async Task<Guid> LoginHistoryAsync(Guid userId, string ip)
        {
            try
            {
                var user = await this.repository.FindAsync(x => x.Id == userId);
                user.LoginAttemp = 0;
                user.LastLogin = DateTime.Now;
                await this.repository.UpdateAsync(user, userId);
                await this.repositoryLoginhistory.AddAsyn(new Loginhistory { IpAddress = ip, LoginDate = DateTime.Now, UserId = userId });
                return userId;

            }
            catch (Exception ex)
            {
                throw ex; 
            }
        }

        public async Task<Guid> LogOutHistoryAsync(Guid userId, string ip)
        {

            try
            {
                var user = this.repositoryLoginhistory.FindAll(x => x.UserId == userId && x.IpAddress == ip).LastOrDefault();
                if (!user.LogoutDate.HasValue)
                {
                    user.LogoutDate = DateTime.Now;
                    await this.repositoryLoginhistory.UpdateAsync(user, user.Id);
                }
                return userId;

            }
            catch (Exception ex)
            {
                throw ex; ;
            }
        }
        
        public async Task<(List<DisplayRoleMenuEntity> menu, UserEntity user,List<ReportsEntity> report)> UserByUserNameAsync(string userName)
        {
            List<DisplayRoleMenuEntity> menus = new List<DisplayRoleMenuEntity>();
            var user = await this.repository.FindAsync(x => x.LoginName == userName);
            menus = await this.roleManager.GetMenuByRoleId(user.RoleId);
            var OrganizationDetail = this.OrganizationManager.GetAsync(user.OrganizationId);
            var mapper = this.mapper.Map<UserEntity>(user);
            if (OrganizationDetail != null)
            {
                mapper.OrganizationTypeId = OrganizationDetail.Result.OrganizationTypeId;
                mapper.OrganizationName = OrganizationDetail.Result.Name;
            }

            var allPermission = this.report.FindAll(x => x.ReportPermission.Any(a => a.RoleId == user.RoleId || user.RoleId==1)).Select(x => new ReportsEntity { Id=x.Id,Name=x.Name,SectioId=x.SectioId,Url=x.Url}).ToList();
            // return (menus, user != null ? this.mapper.Map<UserEntity>(user) : null);
            return (menus, user != null ? mapper : null, allPermission);

        }

        public async Task<int> DeleteAsync(Guid id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<UserEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<UserEntity>>(result);
            return mapped;
        }

        public UserEntity Get(Guid id)
        {
            //var result = await this.repository.GetAsync(id);
            var result = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Organization).Include(m => m.Department).Include(m => m.Designation)).Where(x => x.Id == id);
            var mapped = this.mapper.Map<UserEntity>(result.FirstOrDefault());
            mapped.ActiveDate = result.FirstOrDefault().CreatedDate;
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            //var query = this.repository.GetAll();
            //var result = await CustomPredicate.BuildPredicate(query, parameters);
            //return result;

            var predicate = CustomPredicate.BuildPredicate<User>(parameters);
            predicate = predicate.Or(x => x.Organization.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.Department.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.Designation.Name.Contains(parameters.Search.Value));

            DataTableResult result;
            if (parameters.OrganizationTypeId == (short)OrganizationEnum.EPBTI)
            {
                var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Role.Name.ToLower() == "po" && x.OrganizationId==parameters.OrganizationId, x => x.Include(m => m.Organization).Include(m => m.Department).Include(m => m.Designation));
                result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            }
            else
            {
                var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Organization).Include(m => m.Department).Include(m => m.Designation));
                result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            }




            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (User)x;
                requiredData.Add(new
                {
                    CodePrefix = y.CodePrefix,
                    DepartmentId = y.Department.Name,
                    FirstName = y.FirstName,
                    DesignationId = y.Designation.Name,
                    OrganizationId = y.Organization.Name,
                    LoginName = y.LoginName,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<bool> IsExistorNot(string name, Guid id)
        {
            var record = await this.repository.FindAllAsync(x => x.LoginName == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<UserEntity> UpdateAsync(UserEntity entity)
        {
            var mapped = this.mapper.Map<User>(entity);
            var user = await this.repository.FindAsync(x => x.Id == mapped.Id);
            mapped.LastLogin = user.LastLogin;
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);
            return this.mapper.Map<UserEntity>(result);
        }

        public List<MasterDataEntity> GetPoTypeUser(short orgId)
        {
            return this.repository.FindAll(x =>x.OrganizationId==orgId && x.Role.Name.ToLower() == "po").Select(x => new MasterDataEntity { Name = $"{x.FirstName} {x.LastName} ({x.LoginName})", Id = x.Id.ToString() }).ToList();
        }

        public async Task<UserMacList> GetUsetMacAddressList(Guid userId)
        {
            UserMacList response = new UserMacList();

            var mackList = await this.repositoryUserMack.FindAllAsync(x => x.UserId == userId);
            var user =await this.repository.FindAsync(x=>x.Id== userId);
            response.UserName = $"{user.FirstName} {user.LastName}";
            response.MackAddressList= mackList.Select(x => new UserMacEntity { Id = x.Id, UserId = x.UserId, MackAddress = x.MackAddress }).ToList();
            return response;
        }

        public async Task<bool> InsertMacAddressAsync(UserMacEntity entity)
        {
            try
            {
                var model = new UserMack();
                model.UserId = entity.UserId;
                model.MackAddress = entity.MackAddress;
                var result = await this.repositoryUserMack.AddAsyn(model);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UserMacEntity> UpdateMacAddressAsync(UserMacEntity entity)
        {
           
            var user = await this.repositoryUserMack.FindAsync(x => x.Id == entity.Id);
            user.UserId = entity.UserId;
            user.MackAddress = entity.MackAddress;
            var result = await this.repositoryUserMack.UpdateAsync(user, entity.Id);
            return entity;
        }

        public async Task<int> DeleteMacAddressAsync(int id)
        {
            var result = await this.repositoryUserMack.DeleteAsyn(id);
            return result;
        }

    }
}
