﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;

    public class StoreStockManager : IStoreStockManager
    {
        private IGenericRepository<GroupItem> repositoryGI;
        private IGenericRepository<GroupItemDetail> repositoryGID;
        private IGenericRepository<Organization> repositoryOrg;
        private IGenericRepository<StockShed> repositoryStockShed;
        private IGenericRepository<Origin> repositoryOrigin;
        private IGenericRepository<StoreStockItemAuthority> repositorySSIA;
        private IGenericRepository<ItemStatus> repositorItemStatus;

        private IGenericRepository<StoreStock> repositorySS;
        private IGenericRepository<StoreStockTransaction> repositorySST;
        private IGenericRepository<StoreStockTransactionQuantity> repositorySSTQ;
        private IGenericRepository<StoreStockTransactionSetNo> repositorySSTSN;
        private IMapper mapper;

        public StoreStockManager(IMapper mapper, IGenericRepository<StoreStock> repositorySS,
                                IGenericRepository<StoreStockTransaction> repositorySST,
                                IGenericRepository<StoreStockTransactionQuantity> repositorySSTQ,
                                IGenericRepository<StoreStockTransactionSetNo> repositorySSTSN,
                                IGenericRepository<GroupItem> repositoryGI,
                                IGenericRepository<StoreStockItemAuthority> repositorySSIA,
                                IGenericRepository<GroupItemDetail> repositoryGID,
                                IGenericRepository<Organization> repositoryOrg,
                                IGenericRepository<Origin> repositoryOrigin,
                                IGenericRepository<StockShed> repositoryStockShed,
                                IGenericRepository<ItemStatus> repositorItemStatus)
        {
            this.mapper = mapper;
            this.repositorySS = repositorySS;
            this.repositorySST = repositorySST;
            this.repositorySSTQ = repositorySSTQ;
            this.repositorySSTSN = repositorySSTSN;
            this.repositoryGI = repositoryGI;
            this.repositorySSIA = repositorySSIA;
            this.repositoryGID = repositoryGID;
            this.repositoryOrg = repositoryOrg;
            this.repositoryOrigin = repositoryOrigin;
            this.repositoryStockShed = repositoryStockShed;
            this.repositorItemStatus = repositorItemStatus;
        }
      
        public async Task<int> DeleteAsync(Guid id)
        {
            try
            {
                //var result = await this.repositorySS.DeleteAsyn(id);
                //return result;

                int result = 0;
                var existingRecord = await this.repositorySS.GetIncludingByIdAsyn(x => x.Id == id, (x => x.Include(m => m.StoreStockTransaction).Include("StoreStockTransaction.StoreStockTransactionQuantity")));
                if (existingRecord != null)
                {
                    foreach (var x in existingRecord.StoreStockTransaction)
                    {
                        if (x.StoreStockTransactionQuantity != null)
                        {
                            foreach (var y in x.StoreStockTransactionQuantity)
                            {
                                this.repositorySSTQ.DeleteRange(x.StoreStockTransactionQuantity.ToList());
                            }
                        }

                        this.repositorySST.DeleteRange(existingRecord.StoreStockTransaction.ToList());
                    }
                                        
                    //if (existingRecord.StoreStockTransactionSetNo.Any())
                    //{
                    //    this.repositorySSTSN.DeleteRange(existingRecord.StoreStockTransactionSetNo.ToList());
                    //}
                    
                    this.repositorySS.DeleteEntity(existingRecord);
                    result = await this.repositorySS.SaveAsync();
                }
                return result;

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<List<StoreStockEntity>> GetAllAsync()
        {
            var result = await this.repositorySS.GetAllAsync();

            var mapped = this.mapper.Map<List<StoreStockEntity>>(result);
            return mapped;
        }

        public async Task<StoreStockEntity> GetAsync(Guid id)
        {
            try
            {
                var result = await this.repositorySS.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.StoreStockTransaction).Include("StoreStockTransaction.StoreStockTransactionQuantity").Include("StoreStockTransaction.ItemUom"));
                var mapped = this.mapper.Map<StoreStockEntity>(result);
                var itemList = StoreStockGroupItemDetailList(mapped.GroupItemId);
                var orgList = this.repositoryOrigin.FindAll(x => x.IsActive == true).Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.Name }).ToList();
                var StockShedList = this.repositoryStockShed.FindAll(x => x.IsActive == true).Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.Name }).ToList();
                var itemstatusList = this.repositorItemStatus.FindAll(x => x.IsActive == true).Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = x.Name }).ToList();
                mapped.StoreStockTransaction.ForEach(x =>
                {

                    x.ItemUomName = result.StoreStockTransaction.FirstOrDefault(f => f.ItemUomId == x.ItemUomId).ItemUom.Name;
                    x.ItemList = itemList;
                    x.OriginList = orgList;
                    x.StockShedList = StockShedList;                    
                    //x.StoreStockTransactionQuantity.ForEach(s =>
                    //{
                    //    s.ItemStatusName = itemstatusList.FirstOrDefault(f => f.Id == s.ItemStatusId.Value.ToString()).Name;
                    //});
                });

                //mapped.StoreStockTransactionSetNo.ForEach(x =>
                //{
                //   // x.ItemUomName = result.StoreStockTransactionSetNo.FirstOrDefault(f => f.ItemUomId == x.ItemUomId).ItemUom.Name;
                //    x.ItemList = itemList;
                //    x.OriginList = orgList;
                //    x.StockShedList = StockShedList;
                //});



                return mapped;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<StoreStock>(parameters);
            predicate = predicate.Or(x => x.GroupItem.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.HeldByOrgnaization.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.GroupItemBasicCategory.Name.Contains(parameters.Search.Value));
            var query = this.repositorySS.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId,x => x.Include(m => m.GroupItem).Include(m => m.HeldByOrgnaization).Include(m => m.GroupItemBasicCategory));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (StoreStock)x;
                requiredData.Add(new
                {
                    GroupItemName = y.GroupItem.Name,
                    TransactionTypeId = y.TransactionTypeId,
                    TransactionDate = y.TransactionDate,
                    HeldByOrgnaization = y.HeldByOrgnaization!=null ? y.HeldByOrgnaization.Name:string.Empty,
                    GroupItemBasicCategory = y.GroupItemBasicCategory!=null? y.GroupItemBasicCategory.Name:string.Empty,
                Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<StoreStockEntity> InsertAsync(StoreStockEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<StoreStock>(entity);

                var result = await this.repositorySS.AddAsyn(mapped);

                return this.mapper.Map<StoreStockEntity>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StoreStockEntity> UpdateAsync(StoreStockEntity entity)
        {
            try
            {

                var existingRecord = await this.repositorySS.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.StoreStockTransaction).Include("StoreStockTransaction.StoreStockTransactionQuantity").Include("StoreStockTransaction.ItemUom"));

                if (existingRecord != null)
                {
                    //---------Update StoreStock
                    UpdateStorestock(existingRecord, entity);

                    #region StoreStockTransaction Updation

                    if (entity.StoreStockTransaction != null)
                    {
                        var existingTransactions = existingRecord.StoreStockTransaction.Where(x => entity.StoreStockTransaction.Any(scdet => scdet.Id == x.Id)).ToList();
                        var deletedTransactions = existingRecord.StoreStockTransaction.Where(x => !entity.StoreStockTransaction.Any(scdet => scdet.Id == x.Id)).ToList();
                        var InsertedTransactions = entity.StoreStockTransaction.Where(x => !existingRecord.StoreStockTransaction.Any(m => m.Id == x.Id)).ToList();
                        UpdateTransaction(existingTransactions, entity);

                        if (deletedTransactions.Any())
                        {
                            this.repositorySST.DeleteRange(deletedTransactions);
                        }

                        if (InsertedTransactions.Any())
                        {
                            AddTransaction(InsertedTransactions, existingRecord);
                        }
                    }
                    else if (existingRecord.StoreStockTransaction.Any())
                    {
                        this.repositorySST.DeleteRange(existingRecord.StoreStockTransaction.ToList());
                    }

                    #endregion StoreStockTransaction Updation                                      


                    //#region Update StoreStockTransactionSetNo

                    //if (entity.StoreStockTransactionSetNo != null)
                    //{
                    //    var existingTransactionsSetNo = existingRecord.StoreStockTransactionSetNo.Where(x => entity.StoreStockTransactionSetNo.Any(scdet => scdet.Id == x.Id)).ToList();
                    //    var deletedTransactionsSetNo = existingRecord.StoreStockTransactionSetNo.Where(x => !entity.StoreStockTransactionSetNo.Any(scdet => scdet.Id == x.Id)).ToList();
                    //    var InsertedTransactionsSetNo = entity.StoreStockTransactionSetNo.Where(x => !existingRecord.StoreStockTransactionSetNo.Any(m => m.Id == x.Id)).ToList();
                    //    UpdateTransactionSetNo(existingTransactionsSetNo, entity);

                    //    if (deletedTransactionsSetNo.Any())
                    //    {
                    //        this.repositorySSTSN.DeleteRange(deletedTransactionsSetNo);
                    //    }

                    //    if (InsertedTransactionsSetNo.Any())
                    //    {
                    //        AddTransactionSetNo(InsertedTransactionsSetNo, existingRecord);
                    //    }
                    //}
                    //else if (existingRecord.StoreStockTransactionSetNo.Any())
                    //{
                    //    this.repositorySSTSN.DeleteRange(existingRecord.StoreStockTransactionSetNo.ToList());
                    //}

                    //#endregion Update StoreStockTransactionSetNo                    


                }

                var result = await this.repositorySS.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);
                return this.mapper.Map<StoreStockEntity>(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        private void UpdateStorestock(StoreStock existingRecord, StoreStockEntity entity)
        {
            existingRecord.StoreId = entity.StoreId;
            existingRecord.IsStockOut = entity.IsStockOut;
            existingRecord.GroupItemId = entity.GroupItemId;
            existingRecord.TransactionDate = entity.TransactionDate;
            existingRecord.TransactionRefId = entity.TransactionRefId;
            existingRecord.TransactionTypeId = entity.TransactionTypeId;
            existingRecord.HeldByOrgnaizationId = entity.HeldByOrgnaizationId;
        }

        private void AddTransaction(List<StoreStockTransactionEntity> insertedTransactions, StoreStock existingRecord)
        {
            if (insertedTransactions != null)
            {
                foreach (var x in insertedTransactions)
                {
                    existingRecord.StoreStockTransaction.Add(new StoreStockTransaction()
                    {
                        ObjectState = EntityState.Added,
                        StoreStockId = x.StoreStockId,
                        ItemId = x.ItemId,                      
                        ItemUomId = x.ItemUomId,
                        PrimaryLedgerNo = x.PrimaryLedgerNo,
                        SecondaryLedgerNo = x.SecondaryLedgerNo,
                        PageNo = x.PageNo,
                        StockShedId = x.StockShedId,
                        OriginId = x.OriginId,
                        Mfgdate = x.Mfgdate,
                        ExpiryDate = x.ExpiryDate,
                       // HeldByOrgnaizationId = x.HeldByOrgnaizationId,
                        Remark = x.Remark,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        CreatedBy = x.UpdatedBy,
                        CreatedDate = x.CreatedDate,
                        ItemSetNumberId=x.ItemSetNumberId,
                        StoreStockTransactionQuantity = x.StoreStockTransactionQuantity.Select(s => new StoreStockTransactionQuantity
                        {
                            Id = s.Id,
                            CreatedBy = s.CreatedBy,
                            CreatedDate = s.CreatedDate,
                            //IsBlockQuantity = s.IsBlockQuantity,
                            ItemStatusId = s.ItemStatusId,
                            ObjectState = EntityState.Added,
                            Quantiy = s.Quantiy,
                            RowId = s.RowId,
                            StoreStockTransactionId = s.StoreStockTransactionId,
                            RowVersion = s.RowVersion,
                            UpdatedBy = s.UpdatedBy,
                            UpdatedDate = s.UpdatedDate
                        }).ToList()
                });

                }
                insertedTransactions.ForEach(x =>
                {

                });
            }
        }

        private void UpdateTransaction(List<StoreStockTransaction> existingTransactions, StoreStockEntity entity)
        {
            if (existingTransactions != null)
            {
                foreach (var transaction in existingTransactions)
                {
                    var UpdatedItemPart = entity.StoreStockTransaction.FirstOrDefault(x => x.Id == transaction.Id);
                    transaction.ObjectState = EntityState.Modified;
                    transaction.ItemId = UpdatedItemPart.ItemId;                    
                    transaction.ItemUomId = UpdatedItemPart.ItemUomId;
                    transaction.PrimaryLedgerNo = UpdatedItemPart.PrimaryLedgerNo;
                    transaction.SecondaryLedgerNo = UpdatedItemPart.SecondaryLedgerNo;
                    transaction.PageNo = UpdatedItemPart.PageNo;
                    transaction.StockShedId = UpdatedItemPart.StockShedId;
                    transaction.OriginId = UpdatedItemPart.OriginId;
                    transaction.Mfgdate = UpdatedItemPart.Mfgdate;
                    transaction.ExpiryDate = UpdatedItemPart.ExpiryDate;
                    transaction.ItemSetNumberId = UpdatedItemPart.ItemSetNumberId;
                   // transaction.HeldByOrgnaizationId = UpdatedItemPart.HeldByOrgnaizationId;
                    transaction.Remark = UpdatedItemPart.Remark;
                    transaction.UpdatedBy = UpdatedItemPart.UpdatedBy;
                    transaction.UpdatedDate = UpdatedItemPart.UpdatedDate;

                    UpdateTransactionQuantity(transaction.StoreStockTransactionQuantity.ToList(), UpdatedItemPart);
                }
            }
        }

        //private void AddTransactionSetNo(List<StoreStockTransactionSetNoEntity> insertedTransactionsSetNo, StoreStock existingRecord)
        //{
        //    if (insertedTransactionsSetNo != null)
        //    {
        //        insertedTransactionsSetNo.ForEach(x =>
        //        {
        //            existingRecord.StoreStockTransactionSetNo.Add(new StoreStockTransactionSetNo()
        //            {
        //                ObjectState = EntityState.Added,

        //                StoreStockId = x.StoreStockId,
        //                SetNo = x.SetNo,
        //                GroupItemId = x.GroupItemId,
        //                ItemId = x.ItemId,
        //                ItemUomId = x.ItemUomId,
        //                PrimaryLedgerNo = x.PrimaryLedgerNo,
        //                SecondaryLedgerNo = x.SecondaryLedgerNo,
        //                PageNo = x.PageNo,
        //                StockShedId = x.StockShedId,
        //                OriginId = x.OriginId,
        //                Quantiy = x.Quantiy,
        //                Mfgdate = x.Mfgdate,
        //                ExpiryDate = x.ExpiryDate,
        //                HeldByOrgnaizationId = x.HeldByOrgnaizationId,
        //                Remark = x.Remark,

        //                UpdatedBy = x.UpdatedBy,
        //                UpdatedDate = x.UpdatedDate,
        //                CreatedBy = x.UpdatedBy,
        //                CreatedDate = x.CreatedDate,

        //            });
        //        });
        //    }
        //}

        //private void UpdateTransactionSetNo(List<StoreStockTransactionSetNo> existingTransactionsSetNo, StoreStockEntity entity)
        //{
        //    if (existingTransactionsSetNo != null)
        //    {
        //        existingTransactionsSetNo.ForEach(transaction =>
        //        {
        //            var UpdatedItemPart = entity.StoreStockTransactionSetNo.FirstOrDefault(x => x.Id == transaction.Id);
        //            transaction.ObjectState = EntityState.Modified;
        //            transaction.SetNo = UpdatedItemPart.SetNo;
        //            transaction.GroupItemId = UpdatedItemPart.GroupItemId;
        //            transaction.ItemId = UpdatedItemPart.ItemId;
        //            transaction.ItemUomId = UpdatedItemPart.ItemUomId;
        //            transaction.PrimaryLedgerNo = UpdatedItemPart.PrimaryLedgerNo;
        //            transaction.SecondaryLedgerNo = UpdatedItemPart.SecondaryLedgerNo;
        //            transaction.PageNo = UpdatedItemPart.PageNo;
        //            transaction.StockShedId = UpdatedItemPart.StockShedId;
        //            transaction.OriginId = UpdatedItemPart.OriginId;
        //            transaction.Quantiy = UpdatedItemPart.Quantiy;
        //            transaction.Mfgdate = UpdatedItemPart.Mfgdate;
        //            transaction.ExpiryDate = UpdatedItemPart.ExpiryDate;
        //            transaction.HeldByOrgnaizationId = UpdatedItemPart.HeldByOrgnaizationId;
        //            transaction.Remark = UpdatedItemPart.Remark;
        //            transaction.UpdatedBy = UpdatedItemPart.UpdatedBy;
        //            transaction.UpdatedDate = UpdatedItemPart.UpdatedDate;

        //        });
        //    }
        //}

        private void AddTransactionQuantity(List<StoreStockTransactionQuantityEntity> insertedTransactionsQuantity, StoreStockTransaction existingRecord)
        {
            if (insertedTransactionsQuantity != null)
            {
                insertedTransactionsQuantity.ForEach(x =>
                {
                    existingRecord.StoreStockTransactionQuantity.Add(new StoreStockTransactionQuantity()
                    {
                        ObjectState = EntityState.Added,

                        StoreStockTransactionId = x.StoreStockTransactionId,
                        ItemStatusId = x.ItemStatusId,
                        Quantiy = x.Quantiy,
                        //IsBlockQuantity = x.IsBlockQuantity,

                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,

                    });
                });
            }
        }

        private void UpdateTransactionQuantity(List<StoreStockTransactionQuantity> existingTransactionsQuantity, StoreStockTransactionEntity entity)
        {
            try
            {
                if (existingTransactionsQuantity != null)
                {
                    foreach (var transaction in existingTransactionsQuantity)
                    {
                        var UpdatedItemPart = entity.StoreStockTransactionQuantity.FirstOrDefault(x => x.Id == transaction.Id);

                        transaction.ObjectState = EntityState.Modified;

                        transaction.ItemStatusId = UpdatedItemPart.ItemStatusId;
                        transaction.Quantiy = UpdatedItemPart.Quantiy;
                        //transaction.IsBlockQuantity = UpdatedItemPart.IsBlockQuantity;
                        transaction.UpdatedBy = UpdatedItemPart.UpdatedBy;
                        transaction.UpdatedDate = UpdatedItemPart.UpdatedDate;
                    }
                }
                //if (existingTransactionsQuantity != null)
                //{
                //    existingTransactionsQuantity.ForEach(transaction =>
                //    {
                //        var UpdatedItemPart = entity.StoreStockTransactionQuantity.FirstOrDefault(x => x.Id == transaction.Id);
                //        transaction.ObjectState = EntityState.Modified;

                //        transaction.ItemStatusId = UpdatedItemPart.ItemStatusId;
                //        transaction.Quantiy = UpdatedItemPart.Quantiy;
                //    //transaction.IsBlockQuantity = UpdatedItemPart.IsBlockQuantity;
                //    transaction.UpdatedBy = UpdatedItemPart.UpdatedBy;
                //        transaction.UpdatedDate = UpdatedItemPart.UpdatedDate;
                //    });
                //}
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        //public async Task<IList<MasterDataEntity>> StoreStockGroupItemList()
        //{            
        //    List<MasterDataEntity> abc=new List<MasterDataEntity>();
        //    var StoreStockItemAuth = this.repositorySSIA.GetAll();
        //    var GroupItem = this.repositoryGI.GetAll();

        //    var query = from A in StoreStockItemAuth
        //                join B in GroupItem on A.GroupItemId equals B.Id 
        //                select new {
        //                    Id = A.GroupItemId,
        //                    Name = B.Name,

        //                };
        //    var result = query.ToList();
        //    foreach (var item in result)
        //    {
        //        MasterDataEntity x = new MasterDataEntity();
        //        x.Id = item.Id.ToString();
        //        x.Name = item.Name;

        //        abc.Add(x);
        //    }           
        //    var mapped = this.mapper.Map<IList<MasterDataEntity>>(abc);
        //    return mapped;
        //}

        public List<MasterDataEntity> StoreStockGroupItemDetailList(Guid GID)
        {
            //repositorySSIA
            List<MasterDataEntity> abc = new List<MasterDataEntity>();
            var query = this.repositoryGID.GetAllIncludingIQueryableAsyn(x => x.GroupItemId == GID, x => x.Include(y => y.Item)).ToList();
            var result = query.ToList();
            foreach (var item in result)
            {
                MasterDataEntity x = new MasterDataEntity();
                x.Id = item.ItemId.ToString();
                x.Name = item.Item.Name;
                abc.Add(x);
            }
            var mapped = this.mapper.Map<List<MasterDataEntity>>(abc);
            return mapped;
        }

        //public async Task<IList<MasterDataEntity>> StoreStockOrganizationHeldByList(Guid GID)
        //{
        //    List<MasterDataEntity> abc = new List<MasterDataEntity>();
        //    var StoreStockItemAuth = this.repositorySSIA.GetAll();
        //    var OrgName = this.repositoryOrg.GetAll();

        //    var query = from A in StoreStockItemAuth
        //                join B in OrgName
        //                on A.AuthorizedOrganiztionId  equals B.Id 
        //                select new
        //                {
        //                    Id = A.AuthorizedOrganiztionId,
        //                    Name = B.Name
        //                };
        //    var result = query.ToList();
        //    foreach (var item in result)
        //    {
        //        MasterDataEntity x = new MasterDataEntity();
        //        x.Id = item.Id.ToString();
        //        x.Name = item.Name;
        //        abc.Add(x);
        //    }
        //    var mapped = this.mapper.Map<IList<MasterDataEntity>>(abc);
        //    return mapped;
        //}

    }
}