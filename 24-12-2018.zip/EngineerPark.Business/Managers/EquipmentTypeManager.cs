﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;

    public class EquipmentTypeManager: IEquipmentTypeManager
    {
        private IGenericRepository<EquipmentType> repository;
        private IMapper mapper;
        public EquipmentTypeManager(IMapper mapper, IGenericRepository<EquipmentType> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<EquipmentTypeEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<EquipmentTypeEntity>>(result);
            return mapped;
        }

        public async Task<EquipmentTypeEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<EquipmentTypeEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<EquipmentTypeEntity> InsertAsync(EquipmentTypeEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<EquipmentType>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<EquipmentTypeEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<EquipmentTypeEntity> UpdateAsync(EquipmentTypeEntity entity)
        {
            var mapped = this.mapper.Map<EquipmentType>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<EquipmentTypeEntity>(result);
        }
    }
}