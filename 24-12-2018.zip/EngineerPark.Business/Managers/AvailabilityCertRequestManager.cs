﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class AvailabilityCertRequestManager : IAvailabilityCertRequestManager
    {
        private IGenericRepository<CurrentStockQuantityView> currentStockQuantityRepository;
        private IGenericRepository<AvailabilityCertRequest> repository;
        private IGenericRepository<AvailabilityCertRequestDetail> repository_C;
        private IGenericRepository<GroupItemDetail> repositoryGID;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;
        private IMapper mapper;

        public AvailabilityCertRequestManager(IMapper mapper, IOrganizationManager Organization, IUserManager user, IGenericRepository<GroupItemDetail> repositoryGID, 
            IGenericRepository<AvailabilityCertRequest> repository, IGenericRepository<AvailabilityCertRequestDetail> repository_C, IGenericRepository<TaskWorkFlow> taskworkRepository, 
            IGenericRepository<CurrentStockQuantityView> currentStockQuantityRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.repository_C = repository_C;
            this.repositoryGID = repositoryGID;
            this.taskworkRepository = taskworkRepository;
            this.Organization = Organization;
            this.Usermgr = user;
            this.currentStockQuantityRepository = currentStockQuantityRepository;
        }

        public async Task<int> DeleteAsync(Guid id)
        {
            try
            {
                var result = await this.repository.DeleteAsyn(id);
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<IList<AvailabilityCertRequestEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();
            var mapped = this.mapper.Map<IList<AvailabilityCertRequestEntity>>(result);
            return mapped;
        }

        public async Task<AvailabilityCertRequestPrintEntity> GetAsyncForPrint(Guid id)
        {
            try
            {
                AvailabilityCertRequestPrintEntity ACPE = new AvailabilityCertRequestPrintEntity();

                var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertRequestDetail).Include("AvailabilityCertRequestDetail.Item").Include
                 ("AvailabilityCertRequestDetail.Item.ItemUom").Include
                 ("AvailabilityCertRequestDetail.ItemBasicCategory").Include
                 ("AvailabilityCertRequestDetail.ItemBasicCategory.BasicCategory"));

                var ToOrg = await Organization.GetAsync(result.RequestedStoreId);
                var user = Usermgr.Get(result.CreatedBy);
                var FromOrg = await Organization.GetAsync(user.OrganizationId);

                var mapped = this.mapper.Map<AvailabilityCertRequestEntity>(result);
                mapped.AvailabilityCertRequestDetail.ForEach(x =>
                {
                    var details = result.AvailabilityCertRequestDetail.Where(i => i.Id == x.Id).FirstOrDefault();
                    x.Place = details.Item.ItemUom.DigitAfterDecimal;
                    x.ItemUomId = details.Item.ItemUomId;
                    x.ItemUomName = details.Item.ItemUom.Name;
                    x.CategoryName = details.ItemBasicCategory.BasicCategory.Name;
                    //x.EquipmentName = details.ItemEquipment.Equipment.Name;
                    x.ItemName = details.Item.Name;
                    x.RequestQuantiy = details.Quantiy;
                });

                ACPE.AvailabilityCertRequestModel = mapped;
                ACPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(FromOrg);
                ACPE.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(ToOrg);
                ACPE.userDetail = this.mapper.Map<UserEntity>(user);


                return ACPE;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<AvailabilityCertRequestEntity> GetAsync(Guid id)
        {
            try
            {
                //var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertRequestDetail).Include("AvailabilityCertRequestDetail.Item").Include
                //  ("AvailabilityCertRequestDetail.Item.ItemUom").Include
                //  ("AvailabilityCertRequestDetail.ItemBasicCategory").Include
                //  ("AvailabilityCertRequestDetail.ItemBasicCategory.BasicCategory").Include("AvailabilityCertRequestDetail.ItemEquipment").Include
                //  ("AvailabilityCertRequestDetail.ItemEquipment.Equipment"));

                var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertRequestDetail).Include("AvailabilityCertRequestDetail.Item").Include
                 ("AvailabilityCertRequestDetail.Item.ItemUom").Include
                 ("AvailabilityCertRequestDetail.ItemBasicCategory").Include
                 ("AvailabilityCertRequestDetail.ItemBasicCategory.BasicCategory"));

                var mapped = this.mapper.Map<AvailabilityCertRequestEntity>(result);
                mapped.AvailabilityCertRequestDetail.ForEach(async x =>
                {
                    var details = result.AvailabilityCertRequestDetail.Where(i => i.Id == x.Id).FirstOrDefault();
                    var currentStock =await this.currentStockQuantityRepository.FindAsync(q => q.ItemId == x.ItemId && q.StoreId==mapped.RequestedStoreId);
                    x.Place = details.Item.ItemUom.DigitAfterDecimal;
                    x.ItemUomId = details.Item.ItemUomId;
                    x.ItemUomName = details.Item.ItemUom.Name;
                    x.CategoryName = details.ItemBasicCategory.BasicCategory.Name;
                    //x.EquipmentName = details.ItemEquipment.Equipment.Name;
                    x.CurrentStockQuantity = currentStock!=null? currentStock.currentQuantity:0.0M;
                    x.ItemName = details.Item.Name;
                    x.RequestQuantiy = details.Quantiy;
                });
                return mapped;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isReleaseOrder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Request && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;            
            DataTableResult response = new DataTableResult();
            var query = this.repository.GetAllIncludingIQueryableAsyn(x =>x.UnitId==parameters.OrganizationId || x.RequestedStoreId==parameters.OrganizationId,x=>x.Include(m => m.RequestedStore).Include(m => m.AvailabilityCertIssue).Include(m => m.Unit).Include(m => m.AssignedDesignation).Include(m => m.ApprovedDesignation).Include(m => m.AvailabilityCertRequestApproval));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            response.Data.ForEach(x =>
            {
                var y = (AvailabilityCertRequest)x;
                var fromWork = y.AvailabilityCertRequestApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.AvailabilityCertRequestApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.AvailabilityCertIssue.Count() == 0;
                requiredData.Add(new AvailabilityCertRequestGrid
                {
                    Id = y.Id,
                    RequestDate = y.RequestDate,
                    StoreName = y.RequestedStore.Name,
                    UnitName = y.Unit.Name,
                    RequestNo = y.RequestNo.ToString(),
                    Remark = y.Remark,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId),
                    AssignedDesignation = y.AssignedDesignation.Name,
                    ApprovedDesignation = y.ApprovedDesignation.Name,
                    IsApprove = y.IsApproved && isApproved,
                    //IsEditAble = y.UnitId == parameters.OrganizationId && y.AvailabilityCertRequestApproval.Count == 1 && y.AvailabilityCertIssue.Count()==0,
                    IsEditAble =y.StatusId==(int)StatusEnum.InApprovalProcess && y.UnitId == parameters.OrganizationId && y.AvailabilityCertIssue.Count() == 0,
                    IsIssued = y.IsApproved && y.AvailabilityCertIssue.Count() > 0,
                    IssueId = (y.AvailabilityCertIssue.Count() > 0) ? y.AvailabilityCertIssue.FirstOrDefault().Id : Guid.Empty,
                    //IsCreateAvbIssue =y.IsApproved && isReleaseOrder && y.AvailabilityCertIssue.Count==0
                    IsCreateAvbIssue = y.AvailabilityCertIssue.Count == 0

                });
            });
            response.Data = requiredData;
            return response;
        }

        public async Task<AvailabilityCertRequestEntity> InsertAsync(AvailabilityCertRequestEntity entity)
        {
            try
            {
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Request && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<AvailabilityCertRequest>(entity);
                mapped.AssignedDesignationId = workFlow!=null && workFlow.ToDesignationId.HasValue ? workFlow.ToDesignationId.Value : entity.DesignationId;
                mapped.ApprovedDesignationId = entity.DesignationId;

                if (workFlow != null)
                {
                    mapped.AvailabilityCertRequestApproval.Add(new AvailabilityCertRequestApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = entity.IsApproved,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note = entity.Note

                    });
                }

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<AvailabilityCertRequestEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<AvailabilityCertRequestEntity> UpdateAsync(AvailabilityCertRequestEntity entity)
        {
            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertRequestDetail));
            if (existingRecord != null)
            {
                if (entity.AvailabilityCertRequestDetail != null)
                {
                    var existingTransactions = existingRecord.AvailabilityCertRequestDetail.Where(x => entity.AvailabilityCertRequestDetail.Any(scdet => scdet.Id == x.Id)).ToList();
                    var deletedTransactions = existingRecord.AvailabilityCertRequestDetail.Where(x => !entity.AvailabilityCertRequestDetail.Any(scdet => scdet.Id == x.Id)).ToList();

                    if (entity.AvailabilityCertRequestDetail.Any())
                    {
                        var insertedTransactions = entity.AvailabilityCertRequestDetail.Where(x => !existingRecord.AvailabilityCertRequestDetail.Any(it => it.Id == x.Id)).ToList();
                        AddDetails(insertedTransactions, existingRecord);
                    }

                    UpdateStorestock(existingRecord, entity);

                    if (deletedTransactions.Any())
                    {
                        this.repository_C.DeleteRange(deletedTransactions);
                    }

                    //deletedTransactions.ForEach(x =>
                    //{
                    //    x.ObjectState = EntityState.Deleted;
                    //});
                }
                else if (existingRecord.AvailabilityCertRequestDetail.Any())
                {
                    this.repository_C.DeleteRange(existingRecord.AvailabilityCertRequestDetail.ToList());
                }
            }

            var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);
            return this.mapper.Map<AvailabilityCertRequestEntity>(result);
        }

        public async Task<AvailabilityCertRequestEntity> ApproveAsync(AvailabilityCertRequestEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertIssue).Include(m => m.AvailabilityCertRequestDetail));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Request && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                oldResult.Remark = entity.Remark;
                oldResult.StatusId = entity.StatusId;
                oldResult.IsApproved = entity.IsApproved;
                oldResult.IsActive = entity.IsActive;
                oldResult.ApprovedDesignationId = entity.DesignationId;
                oldResult.AssignedDesignationId = workFlow.ToDesignationId.HasValue ? workFlow.ToDesignationId.Value : workFlow.FromDesignationId;
                oldResult.AvailabilityCertRequestApproval.Add(new AvailabilityCertRequestApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note

                });

                var result = await this.repository.UpdateAsync(oldResult, oldResult.Id);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void UpdateStorestock(AvailabilityCertRequest existingRecord, AvailabilityCertRequestEntity entity)
        {
            existingRecord.RequestNo = entity.RequestNo;
            existingRecord.IsDeleted = entity.IsDeleted;
            existingRecord.RequestDate = entity.RequestDate;
            existingRecord.RequestedStoreId = entity.RequestedStoreId;
            existingRecord.Remark = entity.Remark;
            existingRecord.StatusId = entity.StatusId;
            existingRecord.UnitId = entity.UnitId;
            existingRecord.YearId = entity.YearId;
            existingRecord.IsRequestSent = entity.IsRequestSent;
            UpdateTransaction(existingRecord.AvailabilityCertRequestDetail, entity);



        }

        private void UpdateTransaction(ICollection<AvailabilityCertRequestDetail> existingTransactions, AvailabilityCertRequestEntity entity)
        {
            try
            {
                if (existingTransactions != null)
                {
                    foreach (var transaction in existingTransactions)
                    {
                        var availabilityCert = entity.AvailabilityCertRequestDetail.FirstOrDefault(x => x.Id == transaction.Id);

                        if (availabilityCert != null && transaction.Id != Guid.Empty)
                        {
                            transaction.ObjectState = EntityState.Modified;
                            transaction.ItemId = availabilityCert.ItemId;
                            transaction.ItemBasicCategoryId = availabilityCert.ItemBasicCategoryId;
                            transaction.ItemEquipmentId = availabilityCert.ItemEquipmentId;
                            //transaction.ItemEquipmentTypeId = availabilityCert.ItemEquipmentTypeId;
                            transaction.Quantiy = availabilityCert.Quantiy;
                            transaction.UpdatedBy = availabilityCert.UpdatedBy;
                            transaction.UpdatedDate = availabilityCert.UpdatedDate;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void AddDetails(List<AvailabilityCertRequestDetailEntity> insertedTransactions, AvailabilityCertRequest existingRecord)
        {
            if (insertedTransactions != null)
            {
                insertedTransactions.ForEach(x =>
                {
                    existingRecord.AvailabilityCertRequestDetail.Add(new AvailabilityCertRequestDetail()
                    {
                        ObjectState = EntityState.Added,
                        ItemId = x.ItemId,
                        ItemBasicCategoryId = x.ItemBasicCategoryId,
                        ItemEquipmentId = x.ItemEquipmentId,
                        ItemEquipmentTypeId = x.ItemEquipmentTypeId,
                        Quantiy = x.Quantiy,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        CreatedBy = x.UpdatedBy,
                        CreatedDate = x.CreatedDate,

                    });
                });
            }
        }

        public List<MasterDataEntity> AvlbCertRequestGroupItemDetailList(Guid GID)
            {
                List<MasterDataEntity> abc = new List<MasterDataEntity>();
                var query = this.repositoryGID.GetAllIncludingIQueryableAsyn(x => x.GroupItemId == GID, x => x.Include(y => y.Item)).ToList();
                var result = query.ToList();
                foreach (var item in result)
                {
                    MasterDataEntity x = new MasterDataEntity();
                    x.Id = item.ItemId.ToString();
                    x.Name = item.Item.Name;
                    abc.Add(x);
                }
                var mapped = this.mapper.Map<List<MasterDataEntity>>(abc);
                return mapped;
            }

        }
    }
