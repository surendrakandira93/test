﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;
    public class ConveningOrderItemSurveyManager : IConveningOrderItemSurveyManager
    {
        private IGenericRepository<ConveningOrderItemSurvey> repository;
        private IGenericRepository<ConveningOrderItemSurveyMain> repositoryMain;
        private IGenericRepository<ConveningOrderItem> orderItemRepository;
        private IGenericRepository<ItemStatus> itemstatusRepository;
        private IGenericRepository<ConveningOrder> conveningOrderRepository;
        private IGenericRepository<ConveningOrderApproval> conveningOrderApprovalRepository;
        private IGenericRepository<Role> roleRepository;
        private IGenericRepository<User> userRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;
        private IReleaseOrderManager releaseOrderMngr;
        private ILoanRequestManager LoanRequestMngr;
        private IAvailabilityCertIssueManager AvailabilityCertIssueMngr;
        private IAvailabilityCertRequestManager AvailabilityCertRequestMngr;
        private IGenericRepository<ConveningOrderSurveySalvageTemp> conveningOrderSurveySalvageTemp;
        private IGenericRepository<SalvageIn> salvageInRepository;
        private IGenericRepository<MaterialType> materialTypeRepository;

        public ConveningOrderItemSurveyManager(IReleaseOrderManager releaseOrder, ILoanRequestManager LoanRequest, IAvailabilityCertIssueManager AvailabilityCertIssue, IAvailabilityCertRequestManager AvailabilityCertRequest, IMapper mapper, IOrganizationManager Organization, IUserManager user, IGenericRepository<ConveningOrderItem> orderItemRepository, IGenericRepository<ConveningOrderItemSurvey> repository, IGenericRepository<ConveningOrder> conveningOrderRepository, IGenericRepository<ItemStatus> itemstatusRepository, IGenericRepository<ConveningOrderItemSurveyMain> repositoryMain, IGenericRepository<ConveningOrderApproval> conveningOrderApprovalRepository, IGenericRepository<Role> roleRepository, IGenericRepository<User> userRepository, IGenericRepository<ConveningOrderSurveySalvageTemp> conveningOrderSurveySalvageTemp, IGenericRepository<SalvageIn> salvageInRepository, IGenericRepository<MaterialType> materialTypeRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.conveningOrderRepository = conveningOrderRepository;
            this.itemstatusRepository = itemstatusRepository;
            this.orderItemRepository = orderItemRepository;
            this.Organization = Organization;
            this.Usermgr = user;
            this.releaseOrderMngr = releaseOrder;
            this.LoanRequestMngr = LoanRequest;
            this.AvailabilityCertIssueMngr = AvailabilityCertIssue;
            this.AvailabilityCertRequestMngr = AvailabilityCertRequest;
            this.repositoryMain = repositoryMain;
            this.conveningOrderApprovalRepository = conveningOrderApprovalRepository;
            this.roleRepository = roleRepository;
            this.userRepository = userRepository;
            this.conveningOrderSurveySalvageTemp = conveningOrderSurveySalvageTemp;
            this.salvageInRepository = salvageInRepository;
            this.materialTypeRepository = materialTypeRepository;
        }


        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var roleName = this.roleRepository.Get(parameters.RoleId)?.Name.ToLower() ?? string.Empty;
            DataTableResult response = new DataTableResult();
            IQueryable<ConveningOrder> query = this.conveningOrderRepository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId && x.ConveningOrderItemSurveyMain.Count > 0, x => x.Include(m => m.ConveningOrderItem).Include(m => m.ConveningOrderItemSurveyMain).Include("ConveningOrderItem.ConveningOrderItemSurvey")
                 .Include(m => m.ReleaseOrder).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveningOrder)x;
                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrderNo,
                    IssueDate = y.IssueDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsVerified = y.ConveningOrderItemSurveyMain.Any() && !y.ConveningOrderItemSurveyMain.FirstOrDefault().IsVerified && y.Unit.OrganizationTypeId == (int)OrganizationEnum.EPBTI && roleName != "po",
                    IsEditable = y.ConveningOrderItemSurveyMain.Any() && y.ConveningOrderItemSurveyMain.FirstOrDefault().IsVerified && !y.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved && roleName == "po"
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<ConveningOrder> query = this.conveningOrderRepository.GetAllIncludingIQueryableAsyn(x => x.Poid == parameters.UserId && x.StoreId == parameters.OrganizationId && x.ConveningOrderMember.Count > 0, x => x.Include(m => m.ConveningOrderItem).Include(m => m.ConveningOrderItemSurveyMain).Include("ConveningOrderItem.ConveningOrderItemSurvey")
                    .Include(m => m.ReleaseOrder).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveningOrder)x;
                requiredData.Add(new ConveningOrderGrid
                {
                    Id = y.Id,
                    ConveningOrderNo = y.ConveningOrderNo,
                    IssueDate = y.IssueDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsApproved = !y.ConveningOrderItemSurveyMain.Any()
                });
            }

            response.Data = requiredData;
            return response;
        }
        public async Task<ConveningOrderItemSurveyPrintEntity> GetAsyncForPrint(Guid id)
        {
            ConveningOrderItemSurveyPrintEntity COISP = new ConveningOrderItemSurveyPrintEntity();
            var result = await this.conveningOrderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
            .Include(m => m.ReleaseOrder)
            .Include(m => m.ConveningOrderMember)
            .Include(m => m.ConveningOrderItem)
            .Include("ConveningOrderItem.ItemBasicCategory")
            .Include("ConveningOrderItem.Item")
            .Include("ConveningOrderItem.Item.ItemUom")
            .Include("ConveningOrderItem.ItemBasicCategory.BasicCategory")
            .Include("ConveningOrderItem.ItemEquipment")
            .Include("ConveningOrderItem.ItemEquipment.Equipment")
            .Include("ConveningOrderItem.ItemEquipmentType")
            .Include("ConveningOrderItem.ItemEquipmentType.EquipmentType")
            .Include("ConveningOrderItem.ConveningOrderItemSurvey"));
            COISP.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            COISP.ConveningOrderNo = result.ConveningOrderNo;
            COISP.StoreName = result.Store.Name;
            COISP.ConveningOrderMemberList = this.mapper.Map<List<ConveningOrderMemberEntity>>(result.ConveningOrderMember);
            COISP.ConveningOrder = this.mapper.Map<ConveningOrderEntity>(result);
            var user = Usermgr.Get(result.CreatedBy);
            var FromOrg = await Organization.GetAsync(user.OrganizationId);
            COISP.userDetail = this.mapper.Map<UserEntity>(user);
            COISP.organization = this.mapper.Map<OrganizationEntity>(FromOrg);

            var LReq = await this.LoanRequestMngr.GetAsync(result.ReleaseOrder.LoanRequestId);
            var AvailabilityRequest = await this.AvailabilityCertRequestMngr.GetAsync(LReq.AvailabilityCertRequestId);
            COISP.Task = AvailabilityRequest.Task;

            //Do work hare

            foreach (var item in result.ConveningOrderItem)
            {
                COISP.ConveningOrderItemList.Add(new ConveningOrderItemSurveyDetailPrintEntity
                {
                    Id = item.Id,
                    //ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    //ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemName = item.Item.Name,
                    LoanQuantiy = decimal.Round(item.LoanQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    ReceivedQuantiy = item.ReceivedQuantiy,
                    ReturnQuantiy = decimal.Round(item.ReturnQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    // ConveningOrderId = item.ConveningOrderId,
                    ServiceQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == 1).Sum(s => s.Quantiy),
                    RepairQuantiy = item.ConveningOrderItemSurvey.Where(x => x.ItemStatusId == 2).Sum(s => s.Quantiy),
                    UomName = item.Item.ItemUom.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    Remarks = item.Remarks
                });
            }


            return COISP;
        }

        public async Task<ConveningOrderSurveyEntity> GetAsync(Guid id)
        {

            var result = await this.conveningOrderRepository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store)
            .Include(m => m.ReleaseOrder)
            .Include(m => m.ConveningOrderItemSurveyMain)
            .Include(m => m.ConveningOrderItem)
            .Include("ConveningOrderItem.ItemBasicCategory")
            .Include("ConveningOrderItem.Item")
            .Include("ConveningOrderItem.Item.ItemUom")
            .Include("ConveningOrderItem.ItemBasicCategory.BasicCategory")
            .Include("ConveningOrderItem.ItemEquipment")
            .Include("ConveningOrderItem.ItemEquipment.Equipment")
            .Include("ConveningOrderItem.ItemEquipmentType")
            .Include("ConveningOrderItem.ItemEquipmentType.EquipmentType")
            .Include("ConveningOrderItem.ConveningOrderItemSurvey")
            .Include("ConveningOrderItem.ConveningOrderItemSurvey.ItemStatus"));
            var response = new ConveningOrderSurveyEntity();
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreName = result.Store.Name;
            response.FileName = result.ConveningOrderItemSurveyMain.Any() ? result.ConveningOrderItemSurveyMain.FirstOrDefault().FileName : string.Empty;
            response.ConveningOrderId = result.Id;
            foreach (var item in result.ConveningOrderItem)
            {
                List<ConveningOrderItemSurveyEntity> itemList = new List<ConveningOrderItemSurveyEntity>();
                foreach (var survey in item.ConveningOrderItemSurvey)
                {
                    itemList.Add(new ConveningOrderItemSurveyEntity
                    {
                        ConveningOrderItemId = item.Id,
                        ItemStatusId = survey.ItemStatusId,
                        ItemStatusName = survey.ItemStatus.Name,
                        Quantiy = decimal.Round(survey.Quantiy, item.Item.ItemUom.DigitAfterDecimal)
                    });
                }
                response.ConveningOrderItem.Add(new ConveningOrderItemSurvey_Entity
                {
                    Id = item.Id,
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    //ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemName = item.Item.Name,
                    LoanQuantiy = decimal.Round(item.LoanQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    ReceivedQuantiy = decimal.Round(item.ReceivedQuantiy ?? 0.0M, item.Item.ItemUom.DigitAfterDecimal),
                    ReturnQuantiy = decimal.Round(item.ReturnQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    ConveningOrderItemId = item.Id,
                    Remarks = item.Remarks,
                    SurveryModel = itemList
                });
            }

            return response;
        }

        public async Task<ConveningOrderSurveyEntity> GetByConveningOrderIdAsync(Guid conveningOrderId)
        {
            var itemstatus = this.itemstatusRepository.FindAll(x => x.IsActive == true).ToList();
            var result = await this.conveningOrderRepository.GetIncludingByIdAsyn(x => x.Id == conveningOrderId, x => x.Include(m => m.Store).Include(m => m.ReleaseOrder).Include(m => m.ConveningOrderItem).Include("ConveningOrderItem.ItemBasicCategory").Include("ConveningOrderItem.Item").Include("ConveningOrderItem.Item.ItemUom").Include("ConveningOrderItem.ItemBasicCategory.BasicCategory").Include("ConveningOrderItem.ItemEquipment").Include("ConveningOrderItem.ItemEquipment.Equipment").Include("ConveningOrderItem.ItemEquipmentType").Include("ConveningOrderItem.ItemEquipmentType.EquipmentType"));
            var response = new ConveningOrderSurveyEntity();
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.ConveningOrderNo = result.ConveningOrderNo;
            response.StoreName = result.Store.Name;
            response.ConveningOrderId = result.Id;
            foreach (var item in result.ConveningOrderItem)
            {
                List<ConveningOrderItemSurveyEntity> itemList = new List<ConveningOrderItemSurveyEntity>();
                foreach (var status in itemstatus)
                {
                    itemList.Add(new ConveningOrderItemSurveyEntity
                    {
                        ConveningOrderItemId = item.Id,
                        ItemStatusId = status.Id,
                        ItemStatusName = status.Name,
                        Quantiy = 0
                    });
                }
                response.ConveningOrderItem.Add(new ConveningOrderItemSurvey_Entity
                {
                    Id = item.Id,
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    // ItemEquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemName = item.Item.Name,
                    LoanQuantiy = decimal.Round(item.LoanQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    ReceivedQuantiy = item.ReceivedQuantiy,
                    ReturnQuantiy = decimal.Round(item.ReturnQuantiy, item.Item.ItemUom.DigitAfterDecimal),
                    ConveningOrderItemId = item.Id,
                    Remarks = item.Remarks,
                    SurveryModel = itemList
                });
            }

            return response;
        }

        public async Task<bool> InsertAsync(ConveningOrderItemSurveyMainEntity entity)
        {
            try
            {
                if (entity.IsVerified)
                {
                    var mainrepo = await this.repositoryMain.FindAsync(x => x.ConveningOrderId == entity.ConveningOrderId);
                    mainrepo.IsVerified = entity.IsVerified;
                    mainrepo.IsApproved = entity.IsApproved;
                    mainrepo.ApprovedRemark = entity.ApprovedRemark;
                    await this.repositoryMain.UpdateAsync(mainrepo, mainrepo.Id);
                    if (entity.IsApproved)
                    {
                        var poid = this.conveningOrderRepository.Get(entity.ConveningOrderId).Poid;
                        var poUser = userRepository.Get(poid);
                        poUser.ExpiryDate = DateTime.Now.AddDays(-1);
                        poUser.IsActive = false;
                        await this.userRepository.UpdateAsync(poUser, poUser.Id);
                    }

                    return true;
                }

                var main = await this.repositoryMain.GetIncludingByIdAsyn(x => x.ConveningOrderId == entity.ConveningOrderId, x => x.Include(m => m.ConveningOrderItemSurvey));
                if (main != null)
                {
                    foreach (var item in main.ConveningOrderItemSurvey)
                    {
                        this.repository.DeleteEntity(item);
                    }

                    this.repositoryMain.DeleteEntity(main);

                }

                var mappedMain = new ConveningOrderItemSurveyMain();
                mappedMain.ConveningOrderId = entity.ConveningOrderId;
                mappedMain.FileName = entity.FileName;
                mappedMain.CreatedBy = entity.CreatedBy;
                mappedMain.CreatedDate = entity.CreatedDate;
                mappedMain.UpdatedBy = entity.UpdatedBy;
                mappedMain.UpdatedDate = entity.UpdatedDate;
                List<ConveningOrderItemSurvey> ConveningOrderItemSurveyModel = new List<ConveningOrderItemSurvey>();
                foreach (var item in entity.ConveningOrderItemSurvey)
                {
                    ConveningOrderItem oldOrderItems = await this.orderItemRepository.FindAsync(x => x.Id == item.Id);
                    oldOrderItems.ReceivedQuantiy = item.ReceivedQuantiy;
                    var mapped = this.mapper.Map<List<ConveningOrderItemSurvey>>(item.SurveryModel);
                    await this.orderItemRepository.UpdateAsync(oldOrderItems, item.Id);
                    ConveningOrderItemSurveyModel.AddRange(mapped);
                }
                mappedMain.ConveningOrderItemSurvey = ConveningOrderItemSurveyModel;
                await this.repositoryMain.AddAsyn(mappedMain);



                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ConveningOrderSurveySalvageTempEntity>> AddEditSalvage(List<ConveningOrderSurveySalvageTempEntity> model, Guid conveningOrderId)
        {
            var list = await this.conveningOrderSurveySalvageTemp.FindAllAsync(x => x.ConveningOrderId == conveningOrderId);
            if (list != null && list.Count > 0)
            {
                await this.conveningOrderSurveySalvageTemp.DeleteRangeAsyn(list);
            }
            List<ConveningOrderSurveySalvageTemp> modelList = model.Select(x => new ConveningOrderSurveySalvageTemp { ConveningOrderId = x.ConveningOrderId, Auth = x.Auth, CreatedBy = x.CreatedBy, CreatedDate = x.CreatedDate, Date = x.Date, MaterialTypeId = x.MaterialTypeId, Remark = x.Remark, UpdatedBy = x.UpdatedBy, UpdatedDate = x.UpdatedDate, Weight = x.Weight }).ToList();

            await this.conveningOrderSurveySalvageTemp.AddRangeAsyn(modelList);
            return model;
        }

        public async Task<List<ConveningOrderSurveySalvageTempEntity>> GetSalvage(Guid conveningOrderId)
        {
            var list = await this.conveningOrderSurveySalvageTemp.FindAllAsync(x => x.ConveningOrderId == conveningOrderId);

            var materialList = await this.materialTypeRepository.GetAllAsync();

            List<ConveningOrderSurveySalvageTempEntity> modelList = materialList.Select(x => new ConveningOrderSurveySalvageTempEntity { MaterialTypeId = x.Id, MaterialTypeName = x.Name, ConveningOrderId = conveningOrderId }).ToList();
            modelList.ForEach(x => {

                var data = list != null && list.Any() ? list.Where(w => w.MaterialTypeId == x.MaterialTypeId && w.ConveningOrderId == conveningOrderId).FirstOrDefault() : null;
                if (data != null)
                {
                    x.Auth = data.Auth;
                    x.CreatedBy = data.CreatedBy;
                    x.CreatedDate = data.CreatedDate;
                    x.Date = data.Date;
                    x.Remark = data.Remark;
                    x.UpdatedBy = data.UpdatedBy;
                    x.UpdatedDate = data.UpdatedDate;
                    x.Weight = data.Weight;
                    x.Id = data.Id;
                }
            });

            return modelList;
        }
    }
}