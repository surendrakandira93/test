﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class LoanExtensionManager : ILoanExtensionManager
    {

        private IGenericRepository<ConveyNote> conveyNoteRepository;
        private IGenericRepository<ReleaseOrder> orderReleaseOrder;
        private IGenericRepository<LoanExtension> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<StoreStock> storeStockRepository;
        private IGenericRepository<StoreStockTransaction> transactionRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;

        public LoanExtensionManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<LoanExtension> repository, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<ConveyNote> conveyNoteRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransaction> transactionRepository, IGenericRepository<ReleaseOrder> orderReleaseOrder)
        {
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.conveyNoteRepository = conveyNoteRepository;
            this.storeStockRepository = storeStockRepository;
            this.transactionRepository = transactionRepository;
            this.mapper = mapper;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
            this.orderReleaseOrder = orderReleaseOrder;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isFinelReleaseOrder = await this.taskworkRepository.FindAllAsync(x => x.TaskId == (int)TaskTypeEnum.LoanExtension && x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId) != null && await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanExtension && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId) == null;

            DataTableResult response = new DataTableResult();

            IQueryable<LoanExtension> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.LoanExtensionDetail)
           .Include(m => m.LoanExtensionApproval).Include(m=>m.ReleaseOrder).Include(m=>m.LoanIssueVoucher)
           .Include(m => m.Store).Include(m => m.UnitFrom).Include(m=>m.UnitTo));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoanExtension)x;
                var fromApproveal = y.LoanExtensionApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var toApproveal = y.LoanExtensionApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = toApproveal != null && fromApproveal == null;
                requiredData.Add(new LoanExtensionGrid
                {
                    Id = y.Id,
                    DateFrom = y.DateFrom,
                    DateTo = y.DateTo,
                    LoanIssueVoucher = y.LoanIssueVoucher.VoucherNo,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    UnitFromName = y.UnitFrom.Name,
                    UnitToName = y.UnitTo.Name,
                    StoreName = y.Store.Name,
                    IsApproved = isApproved
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<ReleaseOrder> query = this.orderReleaseOrder.GetAllIncludingIQueryableAsyn(x => x.AuthorityLetter.Any(a=>a.ConveyNote.Any())&& x.ConveningOrder.Any(c => !c.LoanReceiptVoucher.Any()) && !x.LoanExtension.Any(),x=> x.Include(m => m.LoanIssueVoucher).Include(m => m.LoanRequest).Include(m => m.LoanRequest.AvailabilityCertIssue).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit).Include(m => m.Store));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    LoanRequestNo = y.LoanIssueVoucher.FirstOrDefault().VoucherNo,
                    ReleaseDate = y.ReleaseDate,
                    RequestFromDate= y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.FromDate,
                    RequestToDate= y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.ToDate,
                    UnitName = y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit.Name
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<LoanExtensionEntity> GetAsync(int id, short organizationId, short designationId)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.ReleaseOrder).Include(m => m.LoanExtensionDetail).Include(m => m.LoanIssueVoucher).Include("LoanExtensionDetail.ItemBasicCategory").Include("LoanExtensionDetail.Item").Include("LoanExtensionDetail.Item.ItemUom").Include("LoanExtensionDetail.ItemBasicCategory.BasicCategory").Include("LoanExtensionDetail.ItemEquipment").Include("LoanExtensionDetail.ItemEquipment.Equipment").Include("LoanExtensionDetail.GroupItem").Include("LoanExtensionDetail.ItemSetNumber").Include("LoanExtensionDetail.StockShed").Include(m=>m.Store));
            var response = this.mapper.Map<LoanExtensionEntity>(result);
            response.LoanExtensionDetail = new List<LoanExtensionDetailEntity>();
            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanExtension && x.FromOrganizationId == organizationId && x.FromDesignationId == designationId && x.ToOrganizationId != null && x.ToDesignationId != null);

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }
            else
            {
                response.ToDesignationId = null;
                response.ToOrganizationId = null;
            }


           
            response.Id = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.LoanIssueVoucherNo = result.LoanIssueVoucher.VoucherNo;
            response.ReleaseOrderId = result.ReleaseOrder.Id;
            response.LoanIssueVoucherId = result.LoanIssueVoucher.Id;
            response.StoreId = result.StoreId;
            response.UnitFromId = result.UnitFromId;
            response.UnitToId = result.UnitToId;
            response.StoreName = result.Store.Name;
            response.Authority = result.Authority;
            foreach (var item in result.LoanExtensionDetail)
            {
                response.LoanExtensionDetail.Add(new LoanExtensionDetailEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    ItemName = item.Item.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    ItemId = item.ItemId,
                    Quantity = item.Quantity,
                    LoanPeriodInMonth = item.LoanPeriodInMonth,
                    LoanExtensionId = item.LoanExtensionId,
                    GroupItemName=item.GroupItem.Name,
                    GroupItemId=item.GroupItemId,
                    ItemSetNumberId=item.ItemSetNumberId,
                    ItemSetNumberNo=item.ItemSetNumber.Name,
                    StockShedId=item.StockShedId,
                    StockShedNo=item.StockShed.Name,                   
                    Id = item.Id
                });
            }

            return response;
        }

        public async Task<LoanExtensionEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId)
        {
            var result = await this.orderReleaseOrder.GetIncludingByIdAsyn(x => x.Id == releaseOrderId && x.LoanIssueVoucher.Any() && x.ConveningOrder.Any(c => !c.LoanReceiptVoucher.Any()), x => x.Include(m => m.AuthorityLetter).Include(m => m.Store).Include(m => m.LoanIssueVoucher).Include(m => m.LoanRequest).Include(m => m.LoanRequest.AvailabilityCertIssue).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit));
            Guid authorityLetterId = result.AuthorityLetter.FirstOrDefault().Id;

            ICollection<ConveyNote> conveyNote = await this.conveyNoteRepository.GetIncludingFindByAsyn(x => x.AuthorityLetterId == authorityLetterId, x => x.Include(m => m.ConveyNoteDetail).Include("ConveyNoteDetail.ItemBasicCategory").Include("ConveyNoteDetail.Item").Include("ConveyNoteDetail.Item.ItemUom").Include("ConveyNoteDetail.ItemBasicCategory.BasicCategory").Include("ConveyNoteDetail.ItemEquipment").Include("ConveyNoteDetail.ItemEquipment.Equipment").Include("ConveyNoteDetail.ItemSetNumber").Include("ConveyNoteDetail.StockShed").Include("ConveyNoteDetail.GroupItem"));

            var response = new LoanExtensionEntity();
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrderNo;
            response.LoanIssueVoucherNo = result.LoanIssueVoucher.FirstOrDefault().VoucherNo;
            response.LoanIssueVoucherId = result.LoanIssueVoucher.FirstOrDefault().Id;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            response.UnitFromId = result.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.UnitId;
            foreach (ConveyNote conv in conveyNote)
            {
                foreach (var item in conv.ConveyNoteDetail)
                {
                    response.LoanExtensionDetail.Add(new LoanExtensionDetailEntity
                    {
                        ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                        ItemBasicCategoryId = item.ItemBasicCategoryId,
                        ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                        ItemEquipmentId = item.ItemEquipmentId,
                        Place = item.Item.ItemUom.DigitAfterDecimal,
                        ItemName = item.Item.Name,
                        ItemId = item.ItemId,
                        ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                        Quantity = item.Quantiy,
                        GroupItemId=item.GroupItemId,
                        GroupItemName=item.GroupItem.Name,
                        ItemSetNumberId=item.ItemSetNumberId,
                        ItemSetNumberNo=item.ItemSetNumber.Name,
                        StockShedId=item.StockShedId,
                        StockShedNo=item.StockShed.Name,
                        OutDate=item.CreatedDate

                    });
                }
            }
            

            return response;
        }

        public async Task<LoanExtensionEntity> InsertAsync(LoanExtensionEntity entity)
        {
            try
            {


                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanExtension && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<LoanExtension>(entity);
                if (workFlow != null)
                {
                    if ( workFlow.ToDesignationId.HasValue)
                    {
                        mapped.ToDesignationId = workFlow.ToDesignationId;
                        mapped.ToOrganizationId = workFlow.ToOrganizationId;
                    }
                    mapped.LoanExtensionApproval.Add(new LoanExtensionApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate

                    });
                }
                await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
                
            }
        }

        public async Task<LoanExtensionApprovedEntity> ApproveAsync(LoanExtensionApprovedEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.LoanExtensionDetail).Include(m => m.LoanExtensionApproval));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanExtension && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.LoanExtensionApproval.Add(new LoanExtensionApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    LoanExtensionId = oldResult.Id
                });

                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;

                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IsApproved = entity.IsApproved;
                }


                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
