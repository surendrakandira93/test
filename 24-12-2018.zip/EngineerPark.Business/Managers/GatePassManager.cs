﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.Business.Entities.GridResponse;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class GatePassManager: IGatePassManager
    {
        private IGenericRepository<GatePass> repository;
        private IGenericRepository<ConveyNote> conveyNoteRepository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IMapper mapper;

        public GatePassManager(IMapper mapper, IGenericRepository<GatePass> repository, IGenericRepository<ConveyNote> conveyNoteRepository, IGenericRepository<TaskWorkFlow> taskworkRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.conveyNoteRepository = conveyNoteRepository;
            this.taskworkRepository = taskworkRepository;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            // x.GatePassApproval.Where(a => (a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId) || (a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId)).Count() > 0,
            var query = this.repository.GetAllIncludingIQueryableAsyn(x=>x.StoreId==parameters.OrganizationId,x => x.Include(m => m.ConveyNote).Include(m => m.Store));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (GatePass)x;
                var fromApproveal = y.GatePassApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var toApproveal = y.GatePassApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = toApproveal != null && fromApproveal == null;

                requiredData.Add(new
                {
                    Id = y.Id,
                    StoreName = y.Store.Name,
                    GetePassNo = y.GatePassNo,
                    ConveyNoteNo = y.ConveyNote.NoteNo,
                    IssueDate = y.IssueDate,
                    IsApproved = isApproved,
                    ConveyNoteId=y.ConveyNoteId
                });
            }

            response.Data = requiredData;
            return response;
        }


        public async Task<DataTableResult> GetConveyNotePaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            var query = this.conveyNoteRepository.GetAllIncludingIQueryableAsyn(x =>x.GatePass.Count==0, x => x.Include(m => m.AuthorityLetter).Include(m => m.Store));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ConveyNote)x;
                requiredData.Add(new 
                {
                    Id = y.Id,
                    NoteNo = y.NoteNo,
                    IssueDate=y.IssueDate,
                    StoreName = y.Store.Name,
                    StoreId=y.StoreId,
                    LetterNo = y.AuthorityLetter.LetterNo,                    
                    ReleaseDate = y.AuthorityLetter.IssueDate,
                    Remark=y.Remark

                });
            }

            response.Data = requiredData;
            return response;
        }
        public async Task<GatePassEntity> GetAsync(Guid id, short organizationId, short designationId)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m => m.ConveyNote).Include(m => m.GatePassDetail));
            GatePassEntity response = this.mapper.Map<GatePassEntity>(result);
            return response;
        }

        public async Task<GatePassEntity> InsertAsync(GatePassEntity entity)
        {
            try
            {
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.GatePass && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<GatePass>(entity);
                if (workFlow != null)
                {
                    mapped.GatePassApproval.Add(new GatePassApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note = entity.Note

                    });
                }
                var result = await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GatePassEntity> ApproveAsync(GatePassEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.GatePassDetail));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.GatePass && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.GatePassApproval.Add(new GatePassApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    GatePassId = oldResult.Id,
                    Id = new Guid()
                });

                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}