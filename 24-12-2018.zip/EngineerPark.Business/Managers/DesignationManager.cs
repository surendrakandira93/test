﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Data.Entity;

    public class DesignationManager : IDesignationManager
    {
        private IGenericRepository<Designation> repository;
        private IMapper mapper;
        public DesignationManager(IMapper mapper, IGenericRepository<Designation> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<DesignationEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<DesignationEntity>>(result);
            return mapped;
        }

        public async Task<DesignationEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<DesignationEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<Designation>(parameters);
            predicate = predicate.Or(x => x.Organization.Name.Contains(parameters.Search.Value));
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.Organization));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (Designation)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    Description = y.Description,
                    OrganizationName = y.Organization.Name,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<DesignationEntity> InsertAsync(DesignationEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Designation>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<DesignationEntity>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<DesignationEntity> UpdateAsync(DesignationEntity entity)
        {
            var mapped = this.mapper.Map<Designation>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id,entity.RowVersion);

            return this.mapper.Map<DesignationEntity>(result);
        }
    }
}
