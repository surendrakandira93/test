﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Linq;
    using System.Data.Entity;
    using System.Collections;

    public class OrganizationManager : IOrganizationManager
    {
        private IGenericRepository<Organization> repository;
        private IMapper mapper;
        public OrganizationManager(IMapper mapper, IGenericRepository<Organization> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<OrganizationEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<OrganizationEntity>>(result);
            return mapped;
        }

        public async Task<OrganizationEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<OrganizationEntity>(result);
            return mapped;
        }

        public async Task<List<TreeEntity>> GetChildOrgAsync(int id)
        {
            List<TreeEntity> response = new List<TreeEntity>();

            var result = await this.repository.FindAllAsync(x => x.Id == id);
            if (result != null && result.Any())
            {
                foreach (var item in result)
                {
                    TreeEntity child = new TreeEntity();
                    child.id = item.Id;
                    child.text = item.Name;
                    child.organizationtypeid = item.OrganizationTypeId;
                    child.parent = "#";
                    child.li_attr = new { titleUrl = item.OrganizationTypeId.ToString() };
                    response.Add(child);
                    response.AddRange(await GetChildChild(item.Id));

                }
            }
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<Organization>(parameters);
            predicate = predicate.Or(x => x.OrganizationType.Name.Contains(parameters.Search.Value));
            predicate = predicate.Or(x => x.Parent.Name.Contains(parameters.Search.Value));

            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.OrganizationType).Include(m => m.Parent).Where(y => y.Parent.Name != null));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);

            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (Organization)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    ParentId = y.Parent.Name,
                    OrganizationTypeId = y.OrganizationType.Name,
                    Address = y.Address,
                    City = y.City,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;

        }

        public async Task<OrganizationEntity> InsertAsync(OrganizationEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Organization>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<OrganizationEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<OrganizationEntity> UpdateAsync(OrganizationEntity entity)
        {
            var mapped = this.mapper.Map<Organization>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<OrganizationEntity>(result);
        }

        private async Task<List<TreeEntity>> GetChildChild(int id)
        {
            List<TreeEntity> response = new List<TreeEntity>();

            var result = await this.repository.FindAllAsync(x => x.ParentId == id);

            if (result != null && result.Any())
            {
                foreach (var item in result)
                {
                    TreeEntity child = new TreeEntity();
                    child.id = item.Id;
                    child.text = item.Name;
                    child.organizationtypeid = item.OrganizationTypeId;
                    child.parent = item.ParentId.HasValue?item.ParentId.ToString():"#";
                    child.li_attr = new { titleUrl = item.OrganizationTypeId.ToString() };
                    response.Add(child);
                    response.AddRange(await GetChildChild(item.Id));

                }
            }
            return response;
        }
    }
}
