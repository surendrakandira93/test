﻿using System;
using AutoMapper;
using System.Linq;
using System.Threading.Tasks;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;
using EngineerPark.CrossCutting;
using System.Collections.Generic;
using EngineerPark.Business.Contracts;
using EngineerPark.Data.IRepositories;
using EngineerPark.Business.Entities.Reports;
using EngineerPark.Business.Entities.ViewReports;
using EngineerPark.Data;
using System.Data;
using System.Data.SqlClient;
using AutoMapper.Configuration;
using System.Data.Entity;

public class ReportsManager : IReportsManager
{
    private IGenericRepository<AuthorizedItemMSLView> MSLRepository;
    private IGenericRepository<ETSRStateView> ETSRRepository;
    private IGenericRepository<CategoryWiseView> CATRepository;
    private IGenericRepository<BasicCategoryWiseView> BasicCATRepository;
    private IGenericRepository<ETSRSummeryView> ETSRSummeryRepository;
    private IGenericRepository<BasicCategorySummeryView> BasicCategorySummeryRepository;
    private IGenericRepository<LoanStateView> LoanStateViewRepository;
    private readonly ApplicationDbContext context;
    private IGenericRepository<LoanDepositedStatusView> DepositeStatusReportViewRepository;
    private IGenericRepository<GroupItem> groupItemrepository;
    private IGenericRepository<StoreStock> storeStockrepository;
    private IGenericRepository<StoreStockItemAuthority> repository;
    private IGenericRepository<StoreStockTransaction> storeStockTransactionrepository;
    private IGenericRepository<StoreStockItemAuthority> storeStockItemAuthorityRepository;
    private readonly string Connectionstring;

    private IMapper mapper;
    private ICategoryManager CategoryManager;
    private IOrganizationManager OrganizationManager;
    private IBasicCategoryManager BasicCategoryManager;

    public ReportsManager(IMapper mapper, IGenericRepository<StoreStockItemAuthority> repository, IGenericRepository<GroupItem> groupItemrepository,
        IGenericRepository<StoreStock> storeStockrepository, IGenericRepository<StoreStockTransaction> storeStockTransactionrepository,
        IGenericRepository<StoreStockItemAuthority> storeStockItemAuthorityRepository, IGenericRepository<AuthorizedItemMSLView> MSLRepository,
        IGenericRepository<ETSRStateView> ETSRRepository, IGenericRepository<ETSRSummeryView> ETSRSummeryRepository,
        IGenericRepository<CategoryWiseView> CATRepository, IGenericRepository<BasicCategoryWiseView> BasicCATRepository, IBasicCategoryManager BasicCategoryManager,
        IGenericRepository<BasicCategorySummeryView> BasicCategorySummeryRepository, IGenericRepository<LoanStateView> LoanStateViewRepository, IGenericRepository<LoanDepositedStatusView> DepositeStatusReportViewRepository, ICategoryManager CategoryManager, IOrganizationManager OrganizationManager, ApplicationDbContext context)
    {
        this.mapper = mapper;
        this.repository = repository;
        this.MSLRepository = MSLRepository;
        this.groupItemrepository = groupItemrepository;
        this.storeStockrepository = storeStockrepository;
        this.storeStockTransactionrepository = storeStockTransactionrepository;
        this.storeStockItemAuthorityRepository = storeStockItemAuthorityRepository;
        this.ETSRRepository = ETSRRepository;
        this.ETSRSummeryRepository = ETSRSummeryRepository;
        this.BasicCategorySummeryRepository = BasicCategorySummeryRepository;
        this.LoanStateViewRepository = LoanStateViewRepository;
        this.CATRepository = CATRepository;
        this.BasicCATRepository = BasicCATRepository;
        this.DepositeStatusReportViewRepository = DepositeStatusReportViewRepository;
        this.CategoryManager = CategoryManager;
        this.OrganizationManager = OrganizationManager;
        this.BasicCategoryManager = BasicCategoryManager;
        this.context = context;
    }

    public async Task<IList<ETSRStateViewEntity>> GetEtsrStateAsync(short typeOfStoreId, short categoryId, short organizationId)
    {
        return await this.GetTypeOfStoreAsync(typeOfStoreId, categoryId, organizationId);
    }
    public async Task<IList<ETSRStateViewEntity>> GetIssueStatusAsync()
    {
        try
        {

            var groupIitems = await this.ETSRRepository.GetAllAsync();

            List<ETSRStateViewEntity> ModelList = new List<ETSRStateViewEntity>();
            int i = 1;
            foreach (var item in groupIitems.GroupBy(x => new { x.ItemName, x.AU, x.Id }).ToList())
            {

                ETSRStateViewEntity model = new ETSRStateViewEntity();
                model.RowNo = i;
                model.ItemName = item.Key.ItemName;
                model.AU = item.Key.AU;
                model.AuthQty = item.Sum(x => x.AuthQty);
                model.HeldQty = item.Sum(x => x.HeldQty);
                model.OnLoanQty = item.Sum(x => x.OnLoanQty);
                model.UnderRep = item.Sum(x => x.UnderRep);
                model.ComitOnGround = item.Sum(x => x.ComitOnGround);
                model.RelCollected = item.Sum(x => x.RelCollected);
                model.NetSerQty = item.Sum(x => x.NetSerQty);
                model.Remark = string.Empty;
                ModelList.Add(model);
                i++;
            }
            return ModelList;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }



    public async Task<IList<ETSRStateViewEntity>> GetTypeOfStoreAsync(short typeOfStoreId, short categoryId, short organizationId)
    {
        try
        {
            var Category = await CategoryManager.GetAsync(categoryId);
            var Organization = await OrganizationManager.GetAsync(organizationId);
            IQueryable<ETSRStateView> groupIitems;
            if (typeOfStoreId != 1000)
            {
                groupIitems = this.ETSRRepository.GetAllIncludingIQueryableAsyn(x => (typeOfStoreId == 0 ? x.TypeOfStoreId != 1 : x.TypeOfStoreId == typeOfStoreId) && x.CategoryId == categoryId && (organizationId == 0 ? true : x.StoreId == organizationId), x => x.Include(m => m.ItemUom));
            }
            else
            {
                groupIitems = this.ETSRRepository.GetAllIncludingIQueryableAsyn(x => x.CategoryId == categoryId && (organizationId == 0 ? true : x.StoreId == organizationId), x => x.Include(m => m.ItemUom));
            }
            List<ETSRStateViewEntity> ModelList = new List<ETSRStateViewEntity>();
            foreach (var item in groupIitems)
            {

                ETSRStateViewEntity model = new ETSRStateViewEntity();
                model.RowNo = item.RowNo;
                model.ItemName = item.ItemName;
                model.AU = item.AU;
                model.AuthQty = item.AuthQty;
                model.HeldQty = item.HeldQty;
                model.OnLoanQty = item.OnLoanQty;
                model.UnderRep = item.UnderRep;
                model.CategoryId = item.CategoryId;
                model.ComitOnGround = item.ComitOnGround;
                model.RelCollected = item.RelCollected;
                model.NetSerQty = item.NetSerQty;
                model.CategoryName = Category?.Name;
                model.OrganizationName = Organization?.Name;
                if (item.Remark != null)
                    model.Remark = item.Remark;
                ModelList.Add(model);
                //i++;
            }
            return ModelList;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }



    public async Task<IList<QuaterlyReportEntity>> GetQuaterlyDateWiseAsync(BaseFormDateWiseReportEntity entity)
    {
        var groupIitems = this.groupItemrepository.GetAllIncludingIQueryableAsyn(x => x.CategoryId != 0, x => x.Include(m => m.ItemUom));
        ////groupIitems = groupIitems.Where(y => y.CreatedDate >= entity.DateFrom && y.CreatedDate <= entity.DateTo);
        List<QuaterlyReportEntity> lst = new List<QuaterlyReportEntity>();
        if (groupIitems.Any() == false)
            return lst;
        int i = 1;
        foreach (var item in groupIitems)
        {
            var auth = await this.storeStockItemAuthorityRepository.FindAllAsync(x => x.GroupItemId == item.Id && x.StoreId == entity.StoreId);
            var store = this.storeStockrepository.GetAllIncludingIQueryableAsyn(x => x.GroupItemId == item.Id && (x.TransactionDate >= entity.DateFrom && x.TransactionDate <= entity.DateTo) && x.StoreId == entity.StoreId, x => x.Include(m => m.StoreStockTransaction).Include("StoreStockTransaction.StoreStockTransactionQuantity"));

            QuaterlyReportEntity lstItem = new QuaterlyReportEntity();
            lstItem.ItemName = item.Name;
            lstItem.Auth = auth.Sum(x => x.AuthorizedQuantiy);
            lstItem.AUName = item.ItemUom.Name;
            lstItem.Held = store.Where(y => y.TransactionTypeId == (int)TransactionTypeEnum.OpeningBalance).Sum(x => x.StoreStockTransaction.Sum(s => s.StoreStockTransactionQuantity.Where(w => w.ItemStatusId == (int)ItemStatusEnum.Serviceable || w.ItemStatusId == (int)ItemStatusEnum.Repairable).Sum(t => t.Quantiy)));
            lstItem.OnLoanQty = store.Where(y => y.TransactionTypeId == (int)TransactionTypeEnum.Issue).Sum(x => x.StoreStockTransaction.Sum(s => s.StoreStockTransactionQuantity.Where(q => q.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(y => y.Quantiy)));
            var deposit = store.Where(y => y.TransactionTypeId == (int)TransactionTypeEnum.Deposit).Sum(x => x.StoreStockTransaction.Sum(s => s.StoreStockTransactionQuantity.Where(q => q.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(y => y.Quantiy)));
            lstItem.OnLoanQty = lstItem.OnLoanQty - deposit;
            lstItem.UnderRepairQty = store.Where(y => y.TransactionTypeId == (int)TransactionTypeEnum.OpeningBalance).Sum(x => x.StoreStockTransaction.Sum(s => s.StoreStockTransactionQuantity.Where(w => w.ItemStatusId == (int)ItemStatusEnum.Repairable).Sum(t => t.Quantiy)));
            lstItem.NetServiceableQty = 0.0M;
            lstItem.CommittedOnGround = store.Where(y => y.TransactionTypeId == (int)TransactionTypeEnum.Block).Sum(x => x.StoreStockTransaction.Sum(s => s.StoreStockTransactionQuantity.Where(q => q.ItemStatusId == (int)ItemStatusEnum.Serviceable).Sum(y => y.Quantiy)));
            lstItem.RelCollected = 0.0M;
            lstItem.SRNo = i;
            lstItem.NetServiceableQty = lstItem.Held - (lstItem.OnLoanQty + lstItem.UnderRepairQty + lstItem.CommittedOnGround) + lstItem.RelCollected;
            lstItem.fromdate = Convert.ToDateTime(entity.DateFrom).ToShortDateString();
            lstItem.Todate = Convert.ToDateTime(entity.DateTo).ToShortDateString();
            lst.Add(lstItem);
            i++;
        }

        return lst;
    }

    public async Task<IList<AuthorizedItemMSLViewEntity>> GetAuthorizedItemMSLViewAsync()
    {
        try
        {
            List<AuthorizedItemMSLViewEntity> modelList = new List<AuthorizedItemMSLViewEntity>();
            var result = await this.MSLRepository.GetAllAsync();
            foreach (var item in result)
            {
                AuthorizedItemMSLViewEntity model = new AuthorizedItemMSLViewEntity();
                model.RowNo = item.RowNo;
                model.StoreStockItemAuthorityId = item.StoreStockItemAuthorityId;
                model.AuthorizedOrganiztionId = item.AuthorizedOrganiztionId;
                model.OrganizationName = item.OrganizationName;
                model.GroupItemId = item.GroupItemId;
                model.ItemName = item.ItemName;
                model.ItemId = item.ItemId;
                model.PartName = item.PartName;
                model.AuthQuantity = item.AuthQuantity;
                model.PartHeldQuantity = item.PartHeldQuantity;
                model.MinimumStockLevelPercent = item.MinimumStockLevelPercent;
                model.PartHeldInPercent = item.PartHeldInPercent;
                model.Criticality = item.Criticality;
                modelList.Add(model);
            }

            return modelList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public async Task<IList<ETSRSummeryViewEntity>> GetEtsrSummeryAsync()
    {
        try
        {
            List<ETSRSummeryViewEntity> modelList = new List<ETSRSummeryViewEntity>();
            var result = await this.ETSRSummeryRepository.GetAllAsync();
            foreach (var item in result)
            {
                ETSRSummeryViewEntity model = new ETSRSummeryViewEntity();
                model.Id = item.Id;
                model.Items = item.Items;
                //model.AU = item.AU;
                model.Held = item.Held;
                model.RepQty = item.RepQty;
                model.SerQty = item.SerQty;
                model.Salvage = item.Salvage;
                model.Remark = item.Remark;
                modelList.Add(model);
            }

            return modelList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public async Task<IList<CategoryWiseViewEntity>> GetCategoryWiseRptAsync(short categoryId)
    {
        try
        {
            var Category = await CategoryManager.GetAsync(categoryId);

            var groupIitems = this.CATRepository.GetAllIncludingIQueryableAsyn(x => x.CategoryId == categoryId, x => x.Include(m => m.ItemUom));
            List<CategoryWiseViewEntity> ModelList = new List<CategoryWiseViewEntity>();
            //int i = 1;
            foreach (var item in groupIitems)
            {
                CategoryWiseViewEntity model = new CategoryWiseViewEntity();
                model.RowNo = item.RowNo;
                model.ItemName = item.ItemName;
                model.AU = item.AU;
                model.AuthQty = item.AuthQty;
                model.HeldQty = item.HeldQty;
                model.OnLoanQty = item.OnLoanQty;
                model.UnderRep = item.UnderRep;
                model.CategoryId = item.CategoryId;
                model.ComitOnGround = item.ComitOnGround;
                model.RelCollected = item.RelCollected;
                model.NetSerQty = item.NetSerQty;
                model.CategoryName = Category.Name;
                // lstItem.OrganizationName = Organization.Name;
                if (item.Remark != null)
                    model.Remark = item.Remark;
                ModelList.Add(model);
                //i++;
            }
            return ModelList;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public async Task<IList<BasicCategoryWiseViewEntity>> GetBasicCategoryWiseRptAsync(short basiccategoryId)
    {
        try
        {
            var BasicCategory = await BasicCategoryManager.GetAsync(basiccategoryId);
            var groupIitems = this.BasicCATRepository.GetAll().Where(x => x.BasicCatId == basiccategoryId);
            List<BasicCategoryWiseViewEntity> ModelList = new List<BasicCategoryWiseViewEntity>();
            //int i = 1;
            foreach (var item in groupIitems)
            {
                BasicCategoryWiseViewEntity model = new BasicCategoryWiseViewEntity();
                model.RowNo = item.RowNo;
                model.ItemName = item.ItemName;
                model.AU = item.AU;
                model.AuthQty = item.AuthQty;
                model.HeldQty = item.HeldQty;
                model.OnLoanQty = item.OnLoanQty;
                model.UnderRep = item.UnderRep;
                model.BasicCatId = item.BasicCatId;
                model.ComitOnGround = item.ComitOnGround;
                model.RelCollected = item.RelCollected;
                model.NetSerQty = item.NetSerQty;
                model.BasicCategoryName = BasicCategory.Name;
                if (item.Remark != null)
                    model.Remark = item.Remark;
                ModelList.Add(model);
                //i++;
            }
            return ModelList;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public async Task<IList<BasicCategorySummeryViewEntity>> GetBasicCategorySummeryAsync()
    {
        try
        {
            List<BasicCategorySummeryViewEntity> modelList = new List<BasicCategorySummeryViewEntity>();
            var result = await this.BasicCategorySummeryRepository.GetAllAsync();
            foreach (var item in result)
            {
                BasicCategorySummeryViewEntity model = new BasicCategorySummeryViewEntity();
                model.Id = item.Id;
                model.Items = item.Items;
                model.Held = item.Held;
                model.RepQty = item.RepQty;
                model.SerQty = item.SerQty;
                model.Salvage = item.Salvage;
                model.Remark = item.Remark;
                modelList.Add(model);
            }

            return modelList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public async Task<IList<LoanStateViewEntity>> GetLoanStateAsync(short categoryId, short organizationId)
    {
        try
        {
            var Category = await CategoryManager.GetAsync(categoryId);
            var Organization = await OrganizationManager.GetAsync(organizationId);

            //var groupIitems = this.LoanStateViewRepository.GetAllIncludingIQueryableAsyn(x => x.ND_CategoryId == categoryId, x => x.Include(m => m.ItemUom));
            var groupIitems = await this.LoanStateViewRepository.FindByAsyn(x => x.ND_CategoryId == categoryId);
            List<LoanStateViewEntity> ModelList = new List<LoanStateViewEntity>();
            foreach (var item in groupIitems)
            {
                LoanStateViewEntity model = new LoanStateViewEntity();
                model.RowNo = item.RowNo;
                model.Numencluture = item.Numencluture;
                model.ND_AU = item.ND_AU;
                model.ND_CategoryId = item.ND_CategoryId;
                model.ND_BasiccatId = item.ND_BasiccatId;

                model.ND_Unit = item.ND_Unit;
                model.ND_Fmn = item.ND_Fmn;
                model.ND_LoanQty = item.ND_LoanQty;
                model.ND_Authority = item.ND_Authority;
                model.ND_Permt = item.ND_Permt;
                model.ND_Temp = item.ND_Temp;
                model.ND_LoanExpPeriod = item.ND_LoanExpPeriod;
                model.ND_PresentStatus = item.ND_PresentStatus;

                model.D_Unit = item.D_Unit;
                model.D_Fmn = item.D_Fmn;
                model.D_LoanQty = item.D_LoanQty;
                model.D_Authority = item.D_Authority;
                model.D_Permt = item.D_Permt;
                model.D_Temp = item.D_Temp;
                model.D_LoanExpPeriod = item.D_LoanExpPeriod;
                model.D_PresentStatus = item.D_PresentStatus;
                model.CategoryName = Category?.Name??string.Empty;
                model.OrganizationName = Organization?.Name??string.Empty;

                ModelList.Add(model);
            }
            return ModelList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public async Task<IList<DepositeStatusReportEntity>> GetDepositStatusAsync(short categoryId, short organizationId)
    {
        try
        {

            var Category = await CategoryManager.GetAsync(categoryId);
            //var modelList = await this.context.Set<DepositeStatusReportEDB>().FromSql($"DepositStatus {categoryId}, {(organizationId == 0 ? null : organizationId.ToString())}").ToListAsync();
            //var response = modelList.Select(x => new DepositeStatusReportEntity { AmountReqd = x.AmountReqd, ApproveDate = x.ApproveDate, AUName = x.AUName, Authority = x.Authority, UnitName = x.UnitName, ConveningOrderLetterDate = x.ConveningOrderLetterDate, ConveningOrderLettleNo = x.ConveningOrderLettleNo, Date = x.Date, ItemName = x.ItemName, Qty = x.Qty, Repairable = x.Repairable, RVNo = x.RVNo, Serviceable = x.Serviceable, CategoryName = Category.Name }).ToList();



            //return response;
            return new List<DepositeStatusReportEntity>();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataSet GetStateAsOnDate(short categoryId, short orginationId)
    {
        return SqlHelper.ExecuteDataset(this.Connectionstring,"StateAsOnDate", new SqlParameter("@Id", orginationId),new SqlParameter("@categoryId",categoryId));
    }

    public DataSet GetRP3(int? TypeofStoreId, short? categoryId, short? orginationId)
    {
        return SqlHelper.ExecuteDataset(this.Connectionstring, "RP3", new SqlParameter("@TypeofStoreId", TypeofStoreId), new SqlParameter("@categoryId", categoryId), new SqlParameter("@storeId", orginationId));
    }

    public DataSet GetRP4(int? TypeofStoreId, short? categoryId, short? orginationId)
    {
        return SqlHelper.ExecuteDataset(this.Connectionstring, "RP4", new SqlParameter("@TypeofStoreId", TypeofStoreId), new SqlParameter("@categoryId", categoryId), new SqlParameter("@storeId", orginationId));
    }


    public DataSet GetStateCustom(string col, string wh, string groupBy, string col1, string groupBy1)
    {
        DataSet ds= SqlHelper.ExecuteDataset(this.Connectionstring, "StateCustomSP", new SqlParameter("@column", col), new SqlParameter("@column1", col1), new SqlParameter("@where", wh), new SqlParameter("@groupBy", groupBy), new SqlParameter("@groupBy1", groupBy1));       
        
        return ds;
    }


    public DataSet LoanComparison(LoanComparisonReportEntity entity)
    {
        DataSet ds = SqlHelper.ExecuteDataset(this.Connectionstring, "LoanComparisonSP", new SqlParameter("@column", entity.column), new SqlParameter("@column1", entity.column1), new SqlParameter("@column2", entity.column2), new SqlParameter("@where", entity.where), new SqlParameter("@where2", entity.where2), new SqlParameter("@groupby", entity.groupby), new SqlParameter("@groupby2", entity.groupby2), new SqlParameter("@join", entity.join));

        return ds;
    }



    public DataSet InventoryComparison(InventoryComparisonReportEntity entity)
    {
        DataSet ds = SqlHelper.ExecuteDataset(this.Connectionstring, "InventoryComparisonSP", new SqlParameter("@column", entity.column), new SqlParameter("@column1", entity.column1), new SqlParameter("@where", entity.where), new SqlParameter("@groupBy", entity.groupby), new SqlParameter("@groupBy1", entity.groupby1));

        return ds;
    }

    
}




