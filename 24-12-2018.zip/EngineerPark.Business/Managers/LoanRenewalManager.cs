﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class LoanRenewalManager: ILoanRenewalManager
    {
        private IGenericRepository<ConveyNote> conveyNoteRepository;
        private IGenericRepository<ReleaseOrder> orderReleaseOrder;
        private IGenericRepository<LoanRenewal> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<StoreStock> storeStockRepository;
        private IGenericRepository<StoreStockTransaction> transactionRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;

        public LoanRenewalManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<LoanRenewal> repository, IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<ConveyNote> conveyNoteRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransaction> transactionRepository, IGenericRepository<ReleaseOrder> orderReleaseOrder)
        {
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.conveyNoteRepository = conveyNoteRepository;
            this.storeStockRepository = storeStockRepository;
            this.transactionRepository = transactionRepository;
            this.mapper = mapper;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
            this.orderReleaseOrder = orderReleaseOrder;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isFinelReleaseOrder = await this.taskworkRepository.FindAllAsync(x => x.TaskId == (int)TaskTypeEnum.LoanRenewal && x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId) != null && await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanRenewal && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId) == null;

            DataTableResult response = new DataTableResult();

            IQueryable<LoanRenewal> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.LoanRenewalDetail)
           .Include(m => m.LoanRenewalApproval).Include(m => m.LoanIssueVoucher).Include(m => m.ReleaseOrder)
           .Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoanRenewal)x;
                var fromApproveal = y.LoanRenewalApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var toApproveal = y.LoanRenewalApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = toApproveal != null && fromApproveal == null;
                requiredData.Add(new LoanRenewalGrid
                {
                    Id = y.Id,
                    DateFrom = y.DateFrom,
                    DateTo = y.DateTo,
                    LoanIssueVoucher = y.LoanIssueVoucher.VoucherNo,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    UnitName = y.Unit.Name,
                    StoreName = y.Store.Name,
                    IsApproved = isApproved
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<ReleaseOrder> query = this.orderReleaseOrder.GetAllIncludingIQueryableAsyn(x => x.AuthorityLetter.Any(a => a.ConveyNote.Any()) && x.ConveningOrder.Any(c => !c.LoanReceiptVoucher.Any()) && !x.LoanRenewal.Any(), x => x.Include(m => m.LoanIssueVoucher).Include(m => m.LoanRequest).Include(m => m.LoanRequest.AvailabilityCertIssue).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit).Include(m => m.Store));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    LoanRequestNo = y.LoanIssueVoucher.FirstOrDefault().VoucherNo,
                    ReleaseDate = y.ReleaseDate,
                    RequestFromDate = y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.FromDate,
                    RequestToDate = y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.ToDate,
                    UnitName = y.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit.Name
                });
            }
            response.Data = requiredData;
            return response;
        }

        public async Task<LoanRenewalEntity> GetAsync(int id, short organizationId, short designationId)
        {         

            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.ReleaseOrder).Include(m => m.LoanRenewalDetail).Include(m => m.LoanIssueVoucher).Include("LoanRenewalDetail.ItemBasicCategory").Include("LoanRenewalDetail.Item").Include("LoanRenewalDetail.Item.ItemUom").Include("LoanRenewalDetail.ItemBasicCategory.BasicCategory").Include("LoanRenewalDetail.ItemEquipment").Include("LoanRenewalDetail.ItemEquipment.Equipment").Include("LoanRenewalDetail.GroupItem").Include("LoanRenewalDetail.ItemSetNumber").Include("LoanRenewalDetail.StockShed"));

            var response = this.mapper.Map<LoanRenewalEntity>(result);
            response.LoanRenewalDetail = new List<LoanRenewalDetailEntity>();           

            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanRenewal && x.FromOrganizationId == organizationId && x.FromDesignationId == designationId && x.ToOrganizationId != null && x.ToDesignationId != null);

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }
            else
            {
                response.ToDesignationId = null;
                response.ToOrganizationId = null;
            }

            response.Id = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            response.LoanIssueVoucherNo = result.LoanIssueVoucher.VoucherNo;
            response.ReleaseOrderId = result.ReleaseOrder.Id;
            response.LoanIssueVoucherId = result.LoanIssueVoucher.Id;
            response.StoreId = result.StoreId;
            response.UnitId = result.UnitId;
            foreach (var item in result.LoanRenewalDetail)
            {
                response.LoanRenewalDetail.Add(new LoanRenewalDetailEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    ItemName = item.Item.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    ItemId = item.ItemId,
                    Quantity = item.Quantity,
                    LoanPeriodInMonth = item.LoanPeriodInMonth,
                    LoanRenewalId = item.LoanRenewalId,
                    GroupItemName = item.GroupItem.Name,
                    GroupItemId = item.GroupItemId,
                    ItemSetNumberId = item.ItemSetNumberId,
                    ItemSetNumberNo = item.ItemSetNumber.Name,
                    StockShedId = item.StockShedId,
                    StockShedNo = item.StockShed.Name,
                    Id = item.Id
                });
            }

            return response;
        }

        public async Task<LoanRenewalEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId)
        {
            var result = await this.orderReleaseOrder.GetIncludingByIdAsyn(x => x.Id == releaseOrderId && x.LoanIssueVoucher.Any() && x.ConveningOrder.Any(c => !c.LoanReceiptVoucher.Any()), x => x.Include(m => m.AuthorityLetter).Include(m => m.Store).Include(m => m.LoanIssueVoucher).Include(m => m.LoanRequest).Include(m => m.LoanRequest.AvailabilityCertIssue).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest).Include(m => m.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit));
            Guid authorityLetterId = result.AuthorityLetter.FirstOrDefault().Id;

            ICollection<ConveyNote> conveyNote = await this.conveyNoteRepository.GetIncludingFindByAsyn(x => x.AuthorityLetterId == authorityLetterId, x => x.Include(m => m.ConveyNoteDetail).Include("ConveyNoteDetail.ItemBasicCategory").Include("ConveyNoteDetail.Item").Include("ConveyNoteDetail.Item.ItemUom").Include("ConveyNoteDetail.ItemBasicCategory.BasicCategory").Include("ConveyNoteDetail.ItemEquipment").Include("ConveyNoteDetail.ItemEquipment.Equipment").Include("ConveyNoteDetail.ItemSetNumber").Include("ConveyNoteDetail.StockShed").Include("ConveyNoteDetail.GroupItem"));


            var response = new LoanRenewalEntity();
            response.UnitName = result.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.Unit.Name;
            response.ReleaseOrderId = result.Id;
            response.ReleaseOrderNo = result.ReleaseOrderNo;
            response.LoanIssueVoucherNo = result.LoanIssueVoucher.FirstOrDefault().VoucherNo;
            response.LoanIssueVoucherId = result.LoanIssueVoucher.FirstOrDefault().Id;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            response.UnitId= result.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.UnitId;
            response.LoanUnitId= result.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.UnitId;
            response.DateFrom = result.LoanRequest.AvailabilityCertIssue.AvailabilityCertReqest.ToDate;
            foreach (ConveyNote conv in conveyNote)
            {
                foreach (var item in conv.ConveyNoteDetail)
                {
                    response.LoanRenewalDetail.Add(new LoanRenewalDetailEntity
                    {
                        ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                        ItemBasicCategoryId = item.ItemBasicCategoryId,
                        ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                        ItemEquipmentId = item.ItemEquipmentId,
                        Place = item.Item.ItemUom.DigitAfterDecimal,
                        ItemName = item.Item.Name,
                        ItemId = item.ItemId,
                        ItemEquipmentTypeId = item.ItemEquipmentTypeId,
                        Quantity = item.Quantiy,
                        GroupItemId = item.GroupItemId,
                        GroupItemName = item.GroupItem.Name,
                        ItemSetNumberId = item.ItemSetNumberId,
                        ItemSetNumberNo = item.ItemSetNumber.Name,
                        StockShedId = item.StockShedId,
                        StockShedNo = item.StockShed.Name,
                        OutDate = item.CreatedDate

                    });
                }
            }


            return response;
        }

        public async Task<LoanRenewalEntity> InsertAsync(LoanRenewalEntity entity)
        {
            try
            {


                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanRenewal && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<LoanRenewal>(entity);
                mapped.UnitId = entity.LoanUnitId;
                if (workFlow != null)
                {
                    if (workFlow.ToDesignationId.HasValue)
                    {
                        mapped.ToDesignationId = workFlow.ToDesignationId;
                        mapped.ToOrganizationId = workFlow.ToOrganizationId;
                    }

                    mapped.LoanRenewalApproval.Add(new LoanRenewalApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note=""

                    });
                }
                await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<LoanRenewalApprovedEntity> ApproveAsync(LoanRenewalApprovedEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.LoanRenewalDetail).Include(m => m.LoanRenewalApproval));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.LoanRenewal && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.LoanRenewalApproval.Add(new LoanRenewalApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    LoanRenewalId = oldResult.Id
                });

                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;


                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IsApproved = entity.IsApproved;
                }

                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
