﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.Repositories;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;

    public class UnitStockManager: IUnitStockManager
    {
        private IGenericRepository<UnitStock> repository;
        private IMapper mapper;
        public UnitStockManager(IMapper mapper, IGenericRepository<UnitStock> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(Guid id)
        {
            try
            {
                var result = await this.repository.DeleteAsyn(id);
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<IList<UnitStockEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<UnitStockEntity>>(result);
            return mapped;
        }

        public async Task<UnitStockEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.UnitStockTransaction)); //await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<UnitStockEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<UnitStockEntity> InsertAsync(UnitStockEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<UnitStock>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<UnitStockEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<UnitStockEntity> UpdateAsync(UnitStockEntity entity)
        {

            var existingRecord = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.UnitStockTransaction));

            if (existingRecord != null)
            {
                var existingTransactions = existingRecord.UnitStockTransaction.Where(x => entity.UnitStockTransaction.Any(scdet => scdet.Id == x.Id)).ToList();
                var deletedTransactions = existingRecord.UnitStockTransaction.Where(x => !entity.UnitStockTransaction.Any(scdet => scdet.Id == x.Id)).ToList();

                if (entity.UnitStockTransaction.Any())
                {
                    var insertedTransactions = entity.UnitStockTransaction.Where(x => !existingRecord.UnitStockTransaction.Any(it => it.Id == x.Id)).ToList();
                    AddTransaction(insertedTransactions, existingRecord);
                }


                UpdateUnitstock(existingRecord, entity);

                UpdateTransaction(existingTransactions, entity);



                deletedTransactions.ForEach(x =>
                {
                    x.ObjectState = EntityState.Deleted;
                });
            }

            var result = await this.repository.UpdateAsync(existingRecord, existingRecord.Id, entity.RowVersion);

            return this.mapper.Map<UnitStockEntity>(result);
        }

        private void UpdateUnitstock(UnitStock existingRecord, UnitStockEntity entity)
        {
            existingRecord.IsStockOut = entity.IsStockOut;
            existingRecord.UnitId = entity.UnitId;
            existingRecord.TransactionDate = entity.TransactionDate;          
            existingRecord.TransactionTypeId = entity.TransactionTypeId;



        }

        private void UpdateTransaction(List<UnitStockTransaction> existingTransactions, UnitStockEntity entity)
        {
            if (existingTransactions != null)
            {


                existingTransactions.ForEach(transaction =>
                {
                    var UpdatedItemPart = entity.UnitStockTransaction.FirstOrDefault(x => x.Id == transaction.Id);

                    transaction.ObjectState = EntityState.Modified;
                    transaction.ItemId = UpdatedItemPart.ItemId;
                    transaction.LotNo = UpdatedItemPart.LotNo;
                    transaction.Mfgdate = UpdatedItemPart.Mfgdate;
                    transaction.Quantiy = UpdatedItemPart.Quantiy;
                    transaction.Remark = UpdatedItemPart.Remark;
                    transaction.SetNo = UpdatedItemPart.SetNo;                    
                    transaction.UnitStockId = UpdatedItemPart.UnitStockId;
                    transaction.UpdatedBy = UpdatedItemPart.UpdatedBy;
                    transaction.UpdatedDate = UpdatedItemPart.UpdatedDate;
                });
            }
        }

        private void AddTransaction(List<UnitStockTransactionEntity> insertedTransactions, UnitStock existingRecord)
        {
            if (insertedTransactions != null)
            {
                insertedTransactions.ForEach(x =>
                {
                    existingRecord.UnitStockTransaction.Add(new UnitStockTransaction()
                    {
                        ObjectState = EntityState.Added,
                        ItemId = x.ItemId,
                        LotNo = x.LotNo,
                        Mfgdate = x.Mfgdate,
                        Quantiy = x.Quantiy,
                        Remark = x.Remark,
                        SetNo = x.SetNo,                        
                        UnitStockId = x.UnitStockId,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        CreatedBy = x.UpdatedBy,
                        CreatedDate = x.CreatedDate,
                        ExpiryDate = x.ExpiryDate

                    });
                });
            }
        }
    }
}
