﻿using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.ViewReports;
using EngineerPark.Data;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using EngineerPark.Data.Models.ReportView;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class MaintenancePlanManager: IMaintenancePlanManager
    {
        private readonly ApplicationDbContext context;
        private IGenericRepository<Category> repositoryCategory;
        public MaintenancePlanManager(ApplicationDbContext context, IGenericRepository<Category> repositoryCategory)
        {
            this.context = context;
            this.repositoryCategory = repositoryCategory;
        }


        

    }
}
