﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.Business.Entities.GridResponse;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Data.Models;
    using System.Data.Entity;

    public class AuthorityLetterManager: IAuthorityLetterManager
    {
        private IGenericRepository<AuthorityLetter> repository; 
        private IGenericRepository<ReleaseOrder> releaseOrderRepository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;

        public AuthorityLetterManager(IMapper mapper, IOrganizationManager Organization, IUserManager Usermgr, IGenericRepository<AuthorityLetter> repository, IGenericRepository<ReleaseOrder> releaseOrderRepository, IGenericRepository<TaskWorkFlow> taskworkRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.releaseOrderRepository = releaseOrderRepository;
            this.taskworkRepository = taskworkRepository;
            this.Organization = Organization;
            this.Usermgr = Usermgr;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            //(x.UnitId>=parameters.OrganizationId || x.UnitId <= parameters.OrganizationId) &&
            // x =>x.AuthorityLetterApproval.Where(a => (a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId) || (a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId)).Count() > 0,
            var query = this.repository.GetAllIncludingIQueryableAsyn(x=>x.UnitId==parameters.OrganizationId,x => x.Include(m => m.ReleaseOrder).Include("ReleaseOrder.LoanRequest").Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AuthorityLetter)x;
                var fromApproveal = y.AuthorityLetterApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var toApproveal = y.AuthorityLetterApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = toApproveal != null && fromApproveal == null;

                requiredData.Add(new AuthorityLetterGrid
                {
                    Id = y.Id,
                    LoanRequestDate = y.ReleaseOrder.LoanRequest.RequestDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrder.ReleaseOrderNo,
                    LoanRequestNo = y.ReleaseOrder.LoanRequest.LoanRequestNo,
                    ReleaseDate = y.ReleaseOrder.ReleaseDate,
                    UnitName = y.Unit.Name,
                    LetterNo=y.LetterNo,
                    IssueDate=y.IssueDate,                    
                    IsApproved= isApproved
                });
            }

            response.Data = requiredData;
            return response;
        }


        public async Task<DataTableResult> GetLoanRequestPaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            var query = this.releaseOrderRepository.GetAllIncludingIQueryableAsyn(x => x.LoanRequest.UnitId == parameters.OrganizationId , x => x.Include(m => m.LoanRequest)
              .Include(m => m.AuthorityLetter).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;               
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    LoanRequestDate = y.LoanRequest.RequestDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    LoanRequestNo = y.LoanRequest.LoanRequestNo,
                    ReleaseDate = y.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsApproved=y.AuthorityLetter.Count==0
                });
            }

            response.Data = requiredData;
            return response;
        }
        public async Task<AuthorityLetterPrintEntity> GetAsyncForPrint(Guid id)
        {
            try
            {
                AuthorityLetterPrintEntity ALPE = new AuthorityLetterPrintEntity();
                var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m => m.ReleaseOrder).Include(m => m.AuthorityLetterVechileDetail));
                AuthorityLetterEntity response = this.mapper.Map<AuthorityLetterEntity>(result);
                ALPE.AuthorityLetter = response;
                ALPE.ReleaseOrder = this.mapper.Map<ReleaseOrderEntity>(result.ReleaseOrder);

                var FromOrg = await Organization.GetAsync(result.UnitId);
                var userReq = Usermgr.Get(result.CreatedBy);
                var ToOrg = await Organization.GetAsync(result.StoreId);

               
                ALPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(ToOrg);
                ALPE.OrganizationModelTo = this.mapper.Map<OrganizationEntity>(FromOrg);
                var user = Usermgr.Get(result.CreatedBy);
                ALPE.userDetail = this.mapper.Map<UserEntity>(user);
                return ALPE;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<AuthorityLetterEntity>GetAsync(Guid id, short organizationId, short designationId)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m => m.ReleaseOrder).Include(m => m.AuthorityLetterVechileDetail));
            AuthorityLetterEntity response = this.mapper.Map<AuthorityLetterEntity>(result);
            response.ReleaseOrderNo = result.ReleaseOrder.ReleaseOrderNo;
            return response;

        }

        public async Task<AuthorityLetterEntity> InsertAsync(AuthorityLetterEntity entity)
        {
            try
            {
               // var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskType.AuthorityLetterApproval && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<AuthorityLetter>(entity);
                mapped.Store = null;
                //mapped.AuthorityLetterApproval.Add(new AuthorityLetterApproval
                //{
                //    ApprovedDate = DateTime.Now,
                //    CreatedBy = entity.CreatedBy,
                //    CreatedDate = entity.CreatedDate,
                //    FromDesignationId = entity.DesignationId,
                //    FromOrganizationId = entity.UnitId,
                //    IsApproved = true,
                //    ToDesignationId = workFlow.ToDesignationId,
                //    ToOrganizationId = workFlow.ToOrganizationId,
                //    UpdatedBy = entity.UpdatedBy,
                //    UpdatedDate = entity.UpdatedDate,
                //    Note = entity.Note

                //});
                var result = await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<AuthorityLetterEntity> ApproveAsync(AuthorityLetterEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AuthorityLetterApproval).Include(m => m.AuthorityLetterVechileDetail));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.AuthorityLetterApproval && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.AuthorityLetterApproval.Add(new AuthorityLetterApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    AuthorityLetterId = oldResult.Id,
                    Id=new Guid()
                });

                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(Guid id, Guid releaseOrderId)
        {
            var record = await this.repository.FindAllAsync(x => x.ReleaseOrderId == releaseOrderId && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }       
    }
}