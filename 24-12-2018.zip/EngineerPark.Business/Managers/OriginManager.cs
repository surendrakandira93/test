﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;

    public class OriginManager : IOriginManager
    {

        private IGenericRepository<Origin> repository;
        private IMapper mapper;
        public OriginManager(IMapper mapper, IGenericRepository<Origin> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<OriginEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<OriginEntity>>(result);
            return mapped;
        }

        public async Task<OriginEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<OriginEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<OriginEntity> InsertAsync(OriginEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Origin>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<OriginEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }
        
        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<OriginEntity> UpdateAsync(OriginEntity entity)
        {
            var mapped = this.mapper.Map<Origin>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<OriginEntity>(result);
        }        
    }
}
