﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Data.Entity;
  
    public class ItemSetNumberManager : IItemSetNumberManager
    {
        private IGenericRepository<ItemSetNumber> repository;
        private IMapper mapper;
        public ItemSetNumberManager(IMapper mapper, IGenericRepository<ItemSetNumber> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<ItemSetNumberEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<ItemSetNumberEntity>>(result);
            return mapped;
        }

        public async Task<ItemSetNumberEntity> GetAsync(int id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<ItemSetNumberEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var predicate = CustomPredicate.BuildPredicate<ItemSetNumber>(parameters);
            predicate = predicate.Or(x => x.HeldForOrganization.Name.Contains(parameters.Search.Value));
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.HeldForOrganization));
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (ItemSetNumber)x;
                requiredData.Add(new
                {
                    Name = y.Name,
                    Description = y.Description,
                    OrganizationName = y.HeldForOrganization.Name,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<ItemSetNumberEntity> InsertAsync(ItemSetNumberEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<ItemSetNumber>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<ItemSetNumberEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, int id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<ItemSetNumberEntity> UpdateAsync(ItemSetNumberEntity entity)
        {
            var mapped = this.mapper.Map<ItemSetNumber>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id,entity.RowVersion);

            return this.mapper.Map<ItemSetNumberEntity>(result);
        }
    }
}
