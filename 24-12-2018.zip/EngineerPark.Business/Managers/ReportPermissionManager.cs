﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using EngineerPark.Data.Models;
using EngineerPark.Data.IRepositories;
using System.Linq;
using System.Data.Entity;

namespace EngineerPark.Business.Managers
{
    public class ReportPermissionManager : IReportPermissionManager
    {
        private IGenericRepository<Report> repository;
        private IGenericRepository<ReportPermission> repositoryReportPermission;
        private IGenericRepository<User> repositoryUser;
        private IMapper mapper;
        public ReportPermissionManager(IMapper mapper, IGenericRepository<Report> repository, IGenericRepository<ReportPermission> repositoryReportPermission, IGenericRepository<User> repositoryUser)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.repositoryReportPermission = repositoryReportPermission;
            this.repositoryUser = repositoryUser;
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<ReportEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<ReportEntity>>(result);
            return mapped;
        }

        public async Task<ReportEntity> GetAsync(int id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<ReportEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<DataTableResult> GetPaggedPermissionListAsync(DataTableParameter parameters,int id)
        {
            var predicate = CustomPredicate.BuildPredicate<ReportPermission>(parameters);
            predicate = predicate.Or(x => x.Role.Name.Contains(parameters.Search.Value));


            var query = this.repositoryReportPermission.GetAllIncludingIQueryableAsyn(x=>x.ReportId==id,x => x.Include(m => m.Role).Include(m=>m.ReportUserPermission));
            var list = query.ToList();
            var result = await CustomPredicate.BuildPredicate(query, parameters, predicate);
            var requiredData = new List<object>();
            result.Data.ForEach(x =>
            {
                var y = (ReportPermission)x;
                requiredData.Add(new
                {
                    Name = y.Role.Name,
                    PermissionCount = y.PermissionCount,
                    Count = y.ReportUserPermission.Count,
                    ReportId = y.ReportId,
                    Id = y.Id
                });
            });
            result.Data = requiredData;
            return result;
        }

        public async Task<ReportEntity> InsertAsync(ReportEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Report>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<ReportEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<ReportPermissionEntity> InsertPermissionAsync(ReportPermissionEntity entity)
        {
            try
            {
                var userlist = this.repositoryUser.FindAll(x => x.RoleId == entity.RoleId).ToList().Select(x => x.Id);
                var mapped = this.mapper.Map<ReportPermission>(entity);
                mapped.ReportUserPermission.Clear();
                foreach (var item in userlist)
                {
                    mapped.ReportUserPermission.Add(new ReportUserPermission { CreatedBy = entity.CreatedBy, CreatedDate = entity.CreatedDate, RowVersion = entity.RowVersion, UpdatedBy = entity.UpdatedBy, UpdatedDate = entity.UpdatedDate, UserId = item });

                }

                var result = await this.repositoryReportPermission.AddAsyn(mapped);

                return this.mapper.Map<ReportPermissionEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, int id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<ReportEntity> UpdateAsync(ReportEntity entity)
        {
            var mapped = this.mapper.Map<Report>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<ReportEntity>(result);
        }
    }
}
