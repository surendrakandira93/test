﻿using AutoMapper;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class MaintenanceManager : IMaintenanceManager
    {
        private IGenericRepository<GroupItem> repository;
        private readonly IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<Periodicity> repositoryPeriodicity;
        private IGenericRepository<CarePrice> repositoryCarePrice;
        private IGenericRepository<GroupItemBasicCategory> GroupitemBasicCategoryRepository;
        private IGenericRepository<GroupItemDetail> groupitemdetailrepository;
        private IGenericRepository<GroupItemBasicCategory> groupitembasicrepository;
        private readonly string Connectionstring;
        private IGenericRepository<Category> repositoryCategory;
        private IGenericRepository<MaintenancePlan> repositoryMaintenancePlan;
        private IGenericRepository<MaintenancePlanDetail> repositoryMaintenancePlanDetail;
        private IGenericRepository<MaintenancePlanDetailsGroupItem> repositoryMaintenancePlanDetailsGroupItem;
        private IGenericRepository<MaintenancePlanDetailsItem> repositoryMaintenancePlanDetailsItem;
        private IGenericRepository<MaintenanceSchedulePlan> repositoryMaintenanceSchedulePlan;
        private IGenericRepository<AnnualCpmbudget> repositoryAnnualCpmbudget;
        private IMapper mapper;

        public MaintenanceManager(IGenericRepository<Periodicity> repositoryPeriodicity, IGenericRepository<CarePrice> repositoryCarePrice, IMapper mapper, IGenericRepository<GroupItem> repository, IGenericRepository<GroupItemBasicCategory> groupitembasicrepository1, IGenericRepository<GroupItemBasicCategory> GroupitemBasicCategoryRepository, IGenericRepository<GroupItemDetail> groupitemdetailrepository,  IGenericRepository<Category> repositoryCategory, IGenericRepository<MaintenancePlan> repositoryMaintenancePlan, IGenericRepository<MaintenancePlanDetail> repositoryMaintenancePlanDetail, IGenericRepository<MaintenancePlanDetailsGroupItem> repositoryMaintenancePlanDetailsGroupItem, IGenericRepository<MaintenancePlanDetailsItem> repositoryMaintenancePlanDetailsItem, IGenericRepository<MaintenanceSchedulePlan> repositoryMaintenanceSchedulePlan, IGenericRepository<AnnualCpmbudget> repositoryAnnualCpmbudget, IGenericRepository<TaskWorkFlow> taskworkRepository)
        {
            this.repositoryPeriodicity = repositoryPeriodicity;
            this.repositoryCarePrice = repositoryCarePrice;
            this.mapper = mapper;
            this.repository = repository;
            this.groupitemdetailrepository = groupitemdetailrepository;
            this.GroupitemBasicCategoryRepository = GroupitemBasicCategoryRepository;
            this.groupitembasicrepository = groupitembasicrepository1;
            this.repositoryCategory = repositoryCategory;
            this.repositoryMaintenancePlan = repositoryMaintenancePlan;
            this.repositoryMaintenancePlanDetail = repositoryMaintenancePlanDetail;
            this.repositoryMaintenancePlanDetailsGroupItem = repositoryMaintenancePlanDetailsGroupItem;
            this.repositoryMaintenancePlanDetailsItem = repositoryMaintenancePlanDetailsItem;
            this.repositoryMaintenanceSchedulePlan = repositoryMaintenanceSchedulePlan;
            this.repositoryAnnualCpmbudget = repositoryAnnualCpmbudget;
            this.taskworkRepository = taskworkRepository;
        }


        public async Task<List<PeriodicityEntity>> GetPeriodicityAsync(Guid id)
        {
            var result = await this.groupitemdetailrepository.GetIncludingFindByAsyn(x => x.GroupItemId == id, x => x.Include(m => m.Item).Include(m => m.Item.ItemUom).Include(m => m.Item.Periodicity));
            List<PeriodicityEntity> list = result.Select(x => new PeriodicityEntity { AU = x.Item.ItemUom.Name, ItemId = x.ItemId, Periodicity1 = x.Item.Periodicity.FirstOrDefault()?.Periodicity1 ?? null, Id = x.Item.Periodicity.FirstOrDefault()?.Id ?? 0, ItemName = x.Item.Name, Qty = x.Quantity }).ToList();

            return list;
        }


        public async Task<List<CarePriceEntity>> GetCarePriceAsync(Guid id, int year)
        {
            var result = await this.groupitemdetailrepository.GetIncludingFindByAsyn(x => x.GroupItemId == id, x => x.Include(m => m.Item).Include(m => m.Item.ItemUom).Include(m => m.Item.CarePrice));
            List<CarePriceEntity> list = result.Select(x => new CarePriceEntity { AU = x.Item.ItemUom.Name, ItemId = x.ItemId, Cpmprice = x.Item.CarePrice.FirstOrDefault(f => f.Year == year)?.Cpmprice ?? null, Id = x.Item.CarePrice.FirstOrDefault(f => f.Year == year)?.Id ?? 0, ItemName = x.Item.Name, Year = year }).ToList();

            return list;
        }


        public async Task<List<PeriodicityEntity>> InsertPeriodicityAsync(List<PeriodicityEntity> entity)
        {
            try
            {
                foreach (var item in entity)
                {
                    if (item.Id > 0)
                    {
                        var periodicity = repositoryPeriodicity.Find(x => x.Id == item.Id);
                        periodicity.Periodicity1 = item.Periodicity1.Value;
                        periodicity.UpdatedBy = item.UpdatedBy;
                        periodicity.UpdatedDate = DateTime.Now;
                        await this.repositoryPeriodicity.UpdateAsync(periodicity, item.Id);


                    }
                    else
                    {
                        var perAdd = new Periodicity()
                        {
                            CreatedBy = item.CreatedBy,
                            ItemId = item.ItemId,
                            Periodicity1 = item.Periodicity1.Value,
                            UpdatedBy = item.UpdatedBy,
                            UpdatedDate = item.UpdatedDate
                        };
                        await this.repositoryPeriodicity.AddAsyn(perAdd);
                    }

                }
                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<List<CarePriceEntity>> InsertCarePriceAsync(List<CarePriceEntity> entity)
        {
            try
            {
                foreach (var item in entity)
                {
                    if (item.Id > 0)
                    {
                        var carePrice = repositoryCarePrice.Find(x => x.Id == item.Id);
                        carePrice.Cpmprice = item.Cpmprice.Value;
                        carePrice.Year = item.Year;
                        carePrice.UpdatedBy = item.UpdatedBy;
                        carePrice.UpdatedDate = DateTime.Now;
                        await this.repositoryCarePrice.UpdateAsync(carePrice, item.Id);


                    }
                    else
                    {
                        var carePrice = new CarePrice()
                        {
                            CreatedBy = item.CreatedBy,
                            ItemId = item.ItemId,
                            Cpmprice = item.Cpmprice.Value,
                            Year = item.Year,
                            UpdatedBy = item.UpdatedBy,
                            UpdatedDate = item.UpdatedDate
                        };
                        await this.repositoryCarePrice.AddAsyn(carePrice);
                    }

                }
                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }



        public async Task<MaintenancePlanGroupDetailsReponse> GetMaintenancePlanDetailsAsync(short categoryId, int year, short organizationId)
        {
            try
            {
                MaintenancePlanGroupDetailsReponse response = new MaintenancePlanGroupDetailsReponse();
                var category = await repositoryCategory.GetAsync(categoryId);
                response.Id = categoryId;
                response.Name = category.Name;
                response.Result = this.repository.GetAllIncludingIQueryableAsyn(x => x.CategoryId == categoryId, x => x.Include(m => m.GroupItemDetail)).Select(x => new MaintenancePlanGroupDetails { GroupItemId = x.Id, Name = x.Name, PartList = x.GroupItemDetail.Select(y => new GroupItemPartEntity { Id = y.ItemId, Quantity = float.Parse(y.Quantity.ToString()) }).ToList() }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MaintenancePlanResponseEntity> GetMaintenancePlanItemDetailsAsync(Guid groupId, int year, short organizationId, int planType)
        {
            try
            {
                MaintenancePlanResponseEntity response = new MaintenancePlanResponseEntity();
                var category = await repository.GetAsync(groupId);
                response.Id = groupId;
                response.Name = category.Name;
                var ds = SqlHelper.ExecuteDataset(this.Connectionstring, "GetMaintenancePlanDetails", new SqlParameter("@groupId", groupId), new SqlParameter("@StoreId", organizationId), new SqlParameter("@Year", year), new SqlParameter("@PlanType", planType));
                List<MaintenancePlanItemDetailsModel> result = new List<MaintenancePlanItemDetailsModel>();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        result.Add(new MaintenancePlanItemDetailsModel(row));

                    }
                }
                response.ItemList = result.Select(x => new MaintenancePlanDetailsEntity { Cost = x.Cost, DueFrom = x.DueFrom.ToString("dd/MM/yyyy"), ItemId = x.ItemId, ItemSetNumberId = x.ItemSetNumberId, Name = x.Name, Quantiy = x.Quantity, SetNo = x.SetNo, ShedNo = x.ShedNo, StockShedId = x.StockShedId, PerItemQuantity = x.PerItemQuantity }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MaintenancePlanEntity> InsertMaintenancePlanAsync(MaintenancePlanEntity entity)
        {
            MaintenancePlan dataEntity = await this.repositoryMaintenancePlan.GetIncludingByIdAsyn(x => x.StoreId == entity.StoreId && x.Year == entity.Year && !x.IsApproved && !x.IsVerified, x => x.Include(m => m.MaintenancePlanDetail).Include("MaintenancePlanDetail.Category").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem.MaintenancePlanDetailsItem"));

            if (entity.PlanType == 1 && dataEntity != null)
            {
                throw new Exception($"This plan already credted for this year({entity.Year})");
            }           

            if (dataEntity == null)
            {
                dataEntity = new MaintenancePlan();
                dataEntity.CreatedBy = entity.CreatedBy;
                dataEntity.CreatedDate = entity.CreatedDate;
                dataEntity.PlanType = entity.PlanType;
                dataEntity.Year = entity.Year;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;
            }
            else
            {
                dataEntity.PlanType = entity.PlanType;
                dataEntity.Year = entity.Year;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;

                foreach (var item in dataEntity.MaintenancePlanDetail.ToList())
                {

                    foreach (var group in item.MaintenancePlanDetailsGroupItem.ToList())
                    {
                        foreach (var items in group.MaintenancePlanDetailsItem.ToList())
                        {
                            await repositoryMaintenancePlanDetailsItem.DeleteAsyn(items.Id);
                        }


                        await repositoryMaintenancePlanDetailsGroupItem.DeleteAsyn(group.Id);
                    }

                    await repositoryMaintenancePlanDetail.DeleteAsyn(item.Id);

                }
            }

            var task = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.MaintenancePlan && x.FromOrganizationId == entity.StoreId && x.FromDesignationId == entity.DesignationId);
            if (task != null && task.ToDesignationId.HasValue)
            {
                dataEntity.ToDesignationId = task.ToDesignationId;
                dataEntity.ToOrganizationId = task.ToOrganizationId;
            }

            foreach (var item in entity.MaintenancePlanDetail)
            {
                MaintenancePlanDetail detail = new MaintenancePlanDetail();
                detail.MaintenancePlanId = dataEntity.Id;
                detail.Quantiy = item.Quantiy;
                detail.Amount = item.Amount;
                detail.CategoryId = item.CategoryId;
                detail.CreatedBy = item.CreatedBy;
                detail.CreatedDate = item.CreatedDate;
                detail.UpdatedBy = item.UpdatedBy;
                detail.UpdatedDate = item.UpdatedDate;
                item.MaintenancePlanDetailsGroupItem.ForEach(x =>
                {
                    detail.MaintenancePlanDetailsGroupItem.Add(new MaintenancePlanDetailsGroupItem
                    {
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        GroupItemId = x.GroupItemId,
                        UpdatedBy = x.UpdatedBy,
                        UpdatedDate = x.UpdatedDate,
                        Amount = x.Amount,
                        Quantiy = x.Quantiy,
                        MaintenancePlanDetailsItem = x.MaintenancePlanDetailsItem.Select(y => new MaintenancePlanDetailsItem
                        {
                            CreatedBy = y.CreatedBy,
                            CreatedDate = y.CreatedDate,
                            ItemId = y.ItemId,
                            ItemSetNumberId = y.ItemSetNumberId,
                            StockShedId = y.StockShedId,
                            UpdatedBy = y.UpdatedBy,
                            UpdatedDate = y.UpdatedDate,
                            Amount = y.Amount,
                            Quantiy = y.Quantiy
                        }).ToList()


                    });
                });

                if (dataEntity.Id > 0)
                {
                    await repositoryMaintenancePlanDetail.AddAsyn(detail);
                }
                else
                {
                    dataEntity.MaintenancePlanDetail.Add(detail);
                }
            }

            if (dataEntity.Id > 0)
            {
                await this.repositoryMaintenancePlan.UpdateAsync(dataEntity, dataEntity.Id);

            }
            else
            {
                await this.repositoryMaintenancePlan.AddAsyn(dataEntity);
            }

            return entity;
        }

        public async Task<MaintenancePlanResponseEntity> GetApprovedAsync(int id, short orgId, short desId)
        {

            MaintenancePlanResponseEntity response = new MaintenancePlanResponseEntity();
            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.MaintenancePlan && x.FromOrganizationId == orgId && x.FromDesignationId == desId && x.ToOrganizationId != null && x.ToDesignationId != null);

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }

            var result = await this.repositoryMaintenancePlan.GetIncludingByIdAsyn(x => x.Id == id && !x.IsApproved && !x.IsVerified, x => x.Include(m => m.MaintenancePlanDetail).Include("MaintenancePlanDetail.Category").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem.MaintenancePlanDetailsItem"));
            if (result != null)
            {
                response.Year = result.Year;
                response.MaintenancePlanId = result.Id;
                response.PlanType = result.PlanType;
                response.StoreId = result.StoreId;
                response.MaintenancePlanDetail = this.mapper.Map<List<MaintenancePlanDetailEntity>>(result.MaintenancePlanDetail);
                response.MaintenancePlanDetail.ForEach(x =>
                {
                    x.CategoryName = result.MaintenancePlanDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                });
            }

            return response;

        }

        public async Task<MaintenancePlanApprovedEntity> InsertApproveAsync(MaintenancePlanApprovedEntity entity)
        {
            try
            {
                bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.MaintenancePlan && x.FromOrganizationId == entity.OrgId && x.FromDesignationId == entity.DestId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

                var oldResult = await this.repositoryMaintenancePlan.GetIncludingByIdAsyn(x => x.Id == entity.MaintenancePlanId, x => x.Include(m => m.MaintenancePlanApproval));

                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;
                oldResult.MaintenancePlanApproval.Add(new MaintenancePlanApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DestId,
                    FromOrganizationId = entity.OrgId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    MaintenancePlanId = oldResult.Id
                });

                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IsApproved = entity.IsApproved;
                    oldResult.IsVerified = entity.IsApproved;
                }

                var result = await this.repositoryMaintenancePlan.UpdateAsync(oldResult, oldResult.Id);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<List<MasterDataEntity>> GetYearAsync(short organizationId, int planType)
        {
            var resulr = await this.repositoryMaintenancePlan.FindByAsyn(x => x.StoreId == organizationId && (planType == (int)PlanType.Amendment ? (!x.IsVerified && !x.IsApproved) : (x.IsApproved && x.IsVerified)));
            return resulr.Select(x => new MasterDataEntity { Name = x.Year.ToString(), Id = x.Year.ToString() }).Distinct().ToList();
        }

        public async Task<MaintenancePlanEntity> GetMaintenanceAsync(int year, short organizationId)
        {
            var response = new MaintenancePlanEntity();
            var result = await this.repositoryMaintenancePlan.GetIncludingByIdAsyn(x => x.StoreId == organizationId && x.Year == year && !x.IsApproved && !x.IsVerified, x => x.Include(m => m.MaintenancePlanDetail).Include("MaintenancePlanDetail.Category").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem").Include("MaintenancePlanDetail.MaintenancePlanDetailsGroupItem.MaintenancePlanDetailsItem"));
            if (result != null)
            {
                response = this.mapper.Map<MaintenancePlanEntity>(result);
                response.MaintenancePlanDetail.ForEach(x =>
                {
                    x.CategoryName = result.MaintenancePlanDetail.FirstOrDefault(a => a.CategoryId == x.CategoryId).Category.Name;
                });
            }
            else
            {
                response = new MaintenancePlanEntity();
            }

            return response;
        }


        public async Task<DataTableResult> GetMaintenancePaggedListAsync(DataTableParameter parameters)
        {
            
            DataTableResult response = new DataTableResult();
            IQueryable<MaintenancePlan> query = this.repositoryMaintenancePlan.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId || (x.ToOrganizationId==parameters.OrganizationId && x.ToDesignationId==parameters.DesignationId)||x.MaintenancePlanApproval.Any(a=>a.FromOrganizationId==parameters.OrganizationId && a.FromDesignationId==parameters.DesignationId), x => x.Include(m => m.Store).Include(m => m.MaintenancePlanApproval).Include(m=>m.MaintenancePlanDetail));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (MaintenancePlan)x;

                var fromWork = y.MaintenancePlanApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.MaintenancePlanApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.IsApproved;
                requiredData.Add(new MaintenancePlanGrid
                {
                    Id = y.Id,
                    StoreName = y.Store.Name,
                    Date = y.CreatedDate,
                    PlanType=Utilities.GetEnumDescription((PlanType)y.PlanType),
                    Year = y.Year,
                    Amount = y.MaintenancePlanDetail.Sum(s=>s.Amount),
                    IsApproved = y.MaintenancePlanApproval.Any(a => a.FromOrganizationId == parameters.OrganizationId && a.FromDesignationId == parameters.DesignationId) ||(y.IsApproved && y.ToOrganizationId == parameters.OrganizationId && y.ToDesignationId == parameters.DesignationId)|| y.StoreId==parameters.OrganizationId && y.IsApproved
                });
            }

            response.Data = requiredData;
            return response;
        }


        public async Task<List<AnnualBudgetReportEntity>> GetAnnualBudgetReportAsync(int year, short organizationId)
        {
            try
            {
                DateTime startDate = new DateTime(year, 4, 1);
                DateTime endDate = new DateTime(year + 1, 3, 31);

                var ds = SqlHelper.ExecuteDataset(this.Connectionstring, "AnnualBudgetReport", new SqlParameter("@storeId", organizationId), new SqlParameter("@year", year), new SqlParameter("@startDate", startDate), new SqlParameter("@endDate", endDate));
                List<AnnualBudgetReportEntity> result = new List<AnnualBudgetReportEntity>();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        result.Add(new AnnualBudgetReportEntity(row));

                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MaintenanceSchedulePlanEntity> GetAnnualBudgetGroupDetailsAsync(int id)
        {
            try
            {
                var plan = await repositoryMaintenanceSchedulePlan.GetIncludingByIdAsyn(x => x.MaintenancePlanDetailsId == id, x => x.Include(m => m.MaintenancePlanDetail).Include(m => m.MaintenancePlanDetail.Category));
                if (plan != null)
                {
                    MaintenanceSchedulePlanEntity response = new MaintenanceSchedulePlanEntity();
                    response.CPMQty = plan.Qtr1qty + plan.Qtr2qty + plan.Qtr3qty + plan.Qtr4qty;
                    response.Qtr1qty = plan.Qtr1qty;
                    response.Qtr2qty = plan.Qtr2qty;
                    response.Qtr3qty = plan.Qtr3qty;
                    response.Qtr4qty = plan.Qtr4qty;
                    response.GroupName = plan.MaintenancePlanDetail.Category.Name;
                    response.MaintenancePlanDetailsId = plan.MaintenancePlanDetailsId;
                    response.Id = plan.Id;
                    response.Contingency = plan.Contingency;
                    response.Cpmamount = plan.Cpmamount;
                    response.RepairAmount = plan.RepairAmount;
                    response.Remark = plan.Remark;
                    
                    return response;

                }
                else
                {
                    return await repositoryMaintenancePlanDetail.GetAllIncludingIQueryableAsyn(x => x.Id == id, x => x.Include(m => m.Category)).Select(x => new MaintenanceSchedulePlanEntity { CPMQty = x.Quantiy, GroupName = x.Category.Name, MaintenancePlanDetailsId = x.Id }).FirstOrDefaultAsync();
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MaintenanceSchedulePlanEntity> InsertMaintenanceSchedulePlanAsync(MaintenanceSchedulePlanEntity entity)
        {
            try
            {
                if (entity.Id > 0)
                {
                    MaintenanceSchedulePlan plan = await repositoryMaintenanceSchedulePlan.FindAsync(x => x.Id == entity.Id);
                    plan.Qtr1qty = entity.Qtr1qty;
                    plan.Qtr2qty = entity.Qtr2qty;
                    plan.Qtr3qty = entity.Qtr3qty;
                    plan.Qtr4qty = entity.Qtr4qty;
                    plan.MaintenancePlanDetailsId = entity.MaintenancePlanDetailsId;
                    plan.Contingency = entity.Contingency;
                    plan.Cpmamount = entity.Cpmamount;
                    plan.RepairAmount = entity.RepairAmount;
                    plan.Remark = entity.Remark;
                    plan.UpdatedBy = entity.UpdatedBy;
                    plan.UpdatedDate = DateTime.Now;
                    await this.repositoryMaintenanceSchedulePlan.UpdateAsync(plan, plan.Id);
                }
                else
                {
                    MaintenanceSchedulePlan plan = new MaintenanceSchedulePlan();
                    plan.Qtr1qty = entity.Qtr1qty;
                    plan.Qtr2qty = entity.Qtr2qty;
                    plan.Qtr3qty = entity.Qtr3qty;
                    plan.Qtr4qty = entity.Qtr4qty;
                    plan.MaintenancePlanDetailsId = entity.MaintenancePlanDetailsId;
                    plan.Contingency = entity.Contingency;
                    plan.Cpmamount = entity.Cpmamount;
                    plan.RepairAmount = entity.RepairAmount;
                    plan.Remark = entity.Remark;
                    plan.CreatedBy = entity.CreatedBy;
                    plan.CreatedDate = DateTime.Now;
                    plan.UpdatedBy = entity.UpdatedBy;
                    plan.UpdatedDate = DateTime.Now;
                    await this.repositoryMaintenanceSchedulePlan.AddAsyn(plan);
                }
                return entity;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<AnnualCPMBudgetEntity> InsertAnnualCpmbudgetAsync(AnnualCPMBudgetEntity entity)
        {
            AnnualCpmbudget dataEntity = await this.repositoryAnnualCpmbudget.FindAsync(x => x.StoreId == entity.StoreId && x.Year == entity.Year && !x.IsApproved && !x.IsVerified);

            if (dataEntity != null)
            {
                throw new Exception($"This Annual CPM Budget already credted for this year({entity.Year})");
            }

            if (dataEntity == null)
            {
                dataEntity = new AnnualCpmbudget();
                dataEntity.CreatedBy = entity.CreatedBy;
                dataEntity.CreatedDate = entity.CreatedDate;
                dataEntity.Year = entity.Year;
                dataEntity.Cpmamount = entity.Cpmamount;
                dataEntity.Contingency = entity.Contingency;
                dataEntity.RepairAmount = entity.RepairAmount;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;
            }
            else
            {
                dataEntity.Year = entity.Year;
                dataEntity.Cpmamount = entity.Cpmamount;
                dataEntity.Contingency = entity.Contingency;
                dataEntity.RepairAmount = entity.RepairAmount;
                dataEntity.StoreId = entity.StoreId;
                dataEntity.UpdatedBy = entity.UpdatedBy;
                dataEntity.UpdatedDate = entity.UpdatedDate;

            }

            if (dataEntity.Id > 0)
            {
                await this.repositoryAnnualCpmbudget.UpdateAsync(dataEntity, dataEntity.Id);

            }
            else
            {
                await this.repositoryAnnualCpmbudget.AddAsyn(dataEntity);
            }

            return entity;
        }


        public async Task<List<MasterDataEntity>> GetApprovedPlan()
        {
            var planList= await repositoryMaintenancePlan.FindAllAsync(x => x.IsApproved);
            return planList != null && planList.Any() ? planList.Select(x => new MasterDataEntity { Id = x.Id.ToString(), Name = $"{x.Year}-{Utilities.GetEnumDescription((PlanType)x.PlanType).ToString()}" }).ToList() : new List<MasterDataEntity>();
        }




    }
}
