﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Linq;

    public  class UnitOfMeasureManager: IUnitOfMeasureManager
    {
        private IGenericRepository<UnitOfMeasure> repository;
        private IMapper mapper;
        public UnitOfMeasureManager(IMapper mapper, IGenericRepository<UnitOfMeasure> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<UnitOfMeasureEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<UnitOfMeasureEntity>>(result);
            return mapped;
        }

        public async Task<UnitOfMeasureEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<UnitOfMeasureEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll().Where(x => x.UnitTypeId == 5);
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<UnitOfMeasureEntity> InsertAsync(UnitOfMeasureEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<UnitOfMeasure>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<UnitOfMeasureEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<UnitOfMeasureEntity> UpdateAsync(UnitOfMeasureEntity entity)
        {
            var mapped = this.mapper.Map<UnitOfMeasure>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id);

            return this.mapper.Map<UnitOfMeasureEntity>(result);
        }
    }
}