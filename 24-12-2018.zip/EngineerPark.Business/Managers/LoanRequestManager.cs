﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class LoanRequestManager : ILoanRequestManager
    {
        private IGenericRepository<AvailabilityCertIssue> issueRrepository;
        private IGenericRepository<AvailabilityCertIssueDetail> issueDetailRrepository;
        private IGenericRepository<LoanRequest> repository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<LoanRequestAssign> loanRequestAssignRepository;
        private IMapper mapper;
        private IOrganizationManager Organization;
        private IUserManager Usermgr;
        public LoanRequestManager(IMapper mapper, IOrganizationManager Organization, IUserManager user, IGenericRepository<AvailabilityCertIssue> issuRrepository, IGenericRepository<LoanRequest> repository,
            IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<AvailabilityCertIssueDetail> issueDetailRrepository, IGenericRepository<LoanRequestAssign> loanRequestAssignRepository)
        {
            this.mapper = mapper;
            this.issueRrepository = issuRrepository;
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.issueDetailRrepository = issueDetailRrepository;
            this.loanRequestAssignRepository = loanRequestAssignRepository;
            this.Organization = Organization;
            this.Usermgr = user;
        }
        public async Task<int> DeleteAsync(Guid id)
        {
            try
            {
                var result = await this.repository.DeleteAsyn(id);
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<LoanRequestEntity> GetByIssueIdAsync(Guid issueId)
        {
            var result = await this.issueRrepository.GetIncludingByIdAsyn(x => x.Id == issueId, x => x.Include(m => m.AvailabilityCertIssueDetail).Include(m => m.Store).Include(m => m.AvailabilityCertReqest).Include("AvailabilityCertIssueDetail.Item").Include
               ("AvailabilityCertIssueDetail.Item.ItemUom").Include("AvailabilityCertIssueDetail.ItemBasicCategory").Include("AvailabilityCertIssueDetail.ItemBasicCategory.BasicCategory").Include("AvailabilityCertIssueDetail.ItemEquipment").Include("AvailabilityCertIssueDetail.ItemEquipment.Equipment").Include("AvailabilityCertIssueDetail.ItemEquipmentType").Include("AvailabilityCertIssueDetail.ItemEquipmentType.EquipmentType"));
            var mapped = this.mapper.Map<AvailabilityCertIssueEntity>(result);
            var response = new LoanRequestEntity();
            response.AvailabilityCertIssueId = mapped.Id;
            response.AvailabilityCertRequestId = mapped.AvailabilityCertReqestId;
            response.RequestNo = result.AvailabilityCertReqest.RequestNo.ToString();
            response.IssuetNo = mapped.CertificateNo.ToString();
            response.StoreId = mapped.StoreId;
            response.StoreName = result.Store.Name;
            response.RequestDate = result.AvailabilityCertReqest.RequestDate;
            response.IssuetDate = mapped.IssueDate;
            
            foreach (var item in result.AvailabilityCertIssueDetail)
            {
                response.LoanRequestDetail.Add(new LoanRequestDetailEntity
                {
                    CategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    EquipmentName = item.ItemEquipment.Equipment.Name,
                    //EquipmentTypeName = item.ItemEquipmentType.EquipmentType.Name,
                    ItemName = item.Item.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    IssueQuantiy = item.AvailableQuantiy,
                    AvailabilityCertIssueDetailId = item.Id,
                    RequestQuantiy = item.RequestedQuantiy,
                    LoanPeriodInMonth= (result.AvailabilityCertReqest.ToDate - result.AvailabilityCertReqest.FromDate).Days
                });
            }

            return response;
        }

        public async Task<LoanRequestPrintEntity> GetAsyncForPrint(Guid id)
        {
            LoanRequestPrintEntity LRPE = new LoanRequestPrintEntity();
            //var LoanRequestResult = this.GetAsync(id);
            //LRPE.LoanRequestModel = this.mapper.Map<LoanRequestEntity>(LoanRequestResult.Result);
            


            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertIssue).Include(m => m.Store).Include("AvailabilityCertIssue.AvailabilityCertReqest").Include(m => m.LoanRequestAssign).Include("LoanRequestAssign.LoanRequestDetail"));
            var response = this.mapper.Map<LoanRequestEntity>(result);

            LRPE.AvailabilityCertIssueId = result.AvailabilityCertIssue.Id;
            LRPE.AvailabilityCertRequestId = result.AvailabilityCertIssue.AvailabilityCertReqestId;
            LRPE.AvailabilityCertIssueId = result.AvailabilityCertIssue.Id;
            LRPE.AvailabilityCertRequestId = result.AvailabilityCertIssue.AvailabilityCertReqestId;
            LRPE.RequestNo = result.AvailabilityCertIssue.AvailabilityCertReqest.RequestNo.ToString();
            LRPE.IssuetNo = result.AvailabilityCertIssue.CertificateNo.ToString();
            LRPE.StoreId = result.StoreId;
            LRPE.StoreName = result.Store.Name;
            LRPE.CreatedDate = result.CreatedDate;
            LRPE.LoanRequestNo = result.LoanRequestNo;
            var assignrequest = result.LoanRequestAssign.LastOrDefault();
            LRPE.Note = assignrequest.Note;



            foreach (var item in assignrequest.LoanRequestDetail)
            {
                var issueDetails = await this.issueDetailRrepository.GetIncludingByIdAsyn(x => x.Id == item.AvailabilityCertIssueDetailId, x => x.Include(m => m.ItemBasicCategory).Include(m => m.Item).Include(m => m.ItemBasicCategory.BasicCategory).Include(m => m.ItemEquipment).Include(m => m.ItemEquipment.Equipment));

                //response.LoanRequestDetail.Add(new LoanRequestDetailEntity
                //{
                //    CategoryName = issueDetails.ItemBasicCategory.BasicCategory.Name,
                //    EquipmentName = issueDetails.ItemEquipment.Equipment.Name,
                //    ItemName = issueDetails.Item.Name,
                //    IssueQuantiy = issueDetails.AvailableQuantiy,
                //    AvailabilityCertIssueDetailId = issueDetails.Id,
                //    RequestQuantiy = issueDetails.RequestedQuantiy,
                //    CreatedBy = item.CreatedBy,
                //    CreatedDate = item.CreatedDate,
                //    Id = item.Id,
                //    LoanPeriodInMonth = item.LoanPeriodInMonth,
                //    LoanReqestAssignId = item.LoanReqestAssignId,
                //    Quantiy = item.Quantiy,
                //    Reason = item.Reason,
                //    RowId = item.RowId,
                //    RowVersion = item.RowVersion
                //});

                LRPE.LoanRequestDetailPrint.Add(new LoanRequestDetailPrintEntity
                {
                    CategoryName = issueDetails.ItemBasicCategory.BasicCategory.Name,
                    EquipmentName = issueDetails.ItemEquipment.Equipment.Name,
                    ItemName = issueDetails.Item.Name,
                    IssueQuantiy = issueDetails.AvailableQuantiy,
                    AvailabilityCertIssueDetailId = issueDetails.Id,
                    RequestQuantiy = issueDetails.RequestedQuantiy,
                    //CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Id = item.Id,
                    LoanPerionFromTo = result.AvailabilityCertIssue.AvailabilityCertReqest.FromDate.ToShortDateString() + " TO " + result.AvailabilityCertIssue.AvailabilityCertReqest.ToDate.ToShortDateString(),
                    RequestedEP = result.AvailabilityCertIssue.AvailabilityCertReqest.RequestedStore.Name + "(" + result.AvailabilityCertIssue.AvailabilityCertReqest.RequestedStore.Address + ")",
                    LoanPerionMomthDays = this.NoofDays(result.AvailabilityCertIssue.AvailabilityCertReqest.FromDate, result.AvailabilityCertIssue.AvailabilityCertReqest.ToDate).ToString(), //item.LoanPeriodInMonth,
                    LoanReqestAssignId = item.LoanReqestAssignId,
                    Quantiy = item.Quantiy,
                    Reason = item.Reason,
                    RowId = item.RowId,

                   // RowVersion = item.RowVersion
                });


            }


             var user = Usermgr.Get(result.CreatedBy);
            //  LRPE.LoanRequestModel = this.mapper.Map<LoanRequestEntity>(response);
            var ToOrg = await Organization.GetAsync(user.OrganizationId);
            LRPE.userDetail = this.mapper.Map<UserEntity>(user);
            LRPE.OrganizationModelFrom = this.mapper.Map<OrganizationEntity>(ToOrg);
            return LRPE;
        }
        public double NoofDays(DateTime dtFrom,DateTime dtTo)
        {
            try
            {
                double diff = 0;
                if(dtFrom!=null && dtTo!=null)
                {
                    diff = (dtTo - dtFrom).TotalDays;
                }

                return diff;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public async Task<LoanRequestEntity> GetAsync(Guid id)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.AvailabilityCertIssue).Include(m => m.Store).Include("AvailabilityCertIssue.AvailabilityCertReqest").Include(m => m.LoanRequestAssign).Include("LoanRequestAssign.LoanRequestDetail"));
            var response = this.mapper.Map<LoanRequestEntity>(result);
            response.AvailabilityCertIssueId = result.AvailabilityCertIssue.Id;
            response.AvailabilityCertRequestId = result.AvailabilityCertIssue.AvailabilityCertReqestId;
            response.AvailabilityCertIssueId = result.AvailabilityCertIssue.Id;
            response.AvailabilityCertRequestId = result.AvailabilityCertIssue.AvailabilityCertReqestId;
            response.RequestNo = result.AvailabilityCertIssue.AvailabilityCertReqest.RequestNo.ToString();
            response.IssuetNo = result.AvailabilityCertIssue.CertificateNo.ToString();
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;


            var assignrequest = result.LoanRequestAssign.OrderBy(x=>x.RowId).LastOrDefault();
            response.Note = assignrequest.Note;
            var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromDesignationId == assignrequest.ToDesignationId.Value && x.FromOrganizationId == assignrequest.ToOrganizationId);
            response.FromDesignationId = workFlow.FromDesignationId;
            response.FromOrganizationId = workFlow.FromOrganizationId;
            response.ToDesignationId = workFlow.ToDesignationId;
            response.ToOrganizationId = workFlow.ToOrganizationId;



            foreach (var item in assignrequest.LoanRequestDetail)
            {
                var issueDetails = await this.issueDetailRrepository.GetIncludingByIdAsyn(x => x.Id == item.AvailabilityCertIssueDetailId, x => x.Include(m => m.ItemBasicCategory).Include(m => m.Item).Include(m => m.ItemBasicCategory.BasicCategory).Include(m => m.ItemEquipment).Include(m => m.ItemEquipment.Equipment));

                response.LoanRequestDetail.Add(new LoanRequestDetailEntity
                {
                    CategoryName = issueDetails.ItemBasicCategory.BasicCategory.Name,
                    EquipmentName = issueDetails.ItemEquipment.Equipment.Name,
                    ItemName = issueDetails.Item.Name,
                    IssueQuantiy = issueDetails.AvailableQuantiy,
                    AvailabilityCertIssueDetailId = issueDetails.Id,
                    RequestQuantiy = issueDetails.RequestedQuantiy,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Id = item.Id,
                    LoanPeriodInMonth = item.LoanPeriodInMonth,
                    LoanReqestAssignId = item.LoanReqestAssignId,
                    Quantiy = item.Quantiy,
                    Reason = item.Reason,
                    RowId = item.RowId,
                    RowVersion = item.RowVersion
                });
            }

            return response;
        }

        public async Task<DataTableResult> GetIssuePaggedListAsync(DataTableParameter parameters)
        {
            DataTableResult response = new DataTableResult();
            bool isfinalAvabApproveFrom = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Issue && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;
            bool isfinalAvabApproveTo = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Issue && x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

            var query = this.issueRrepository.GetAllIncludingIQueryableAsyn(x => x.AvailabilityCertReqest.UnitId == parameters.OrganizationId, x => x.Include(m => m.AvailabilityCertReqest).Include(m => m.Store).Include(m => m.Unit).Include(m => m.LoanRequest));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            response.Data.ForEach(x =>
            {
                var y = (AvailabilityCertIssue)x;
                var fromWork = y.AvailabilityCertIssueApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.AvailabilityCertIssueApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.AvailabilityCertIssueApproval.Count() == 0;
                requiredData.Add(new AvailabilityCertIssueGrid
                {
                    Id = y.Id,
                    IssueDate = y.IssueDate,
                    RequestDate = y.AvailabilityCertReqest.RequestDate,
                    StoreName = y.Store.Name,
                    UnitName = y.Unit.Name,
                    IssueNo = y.CertificateNo.ToString(),
                    RequestNo = y.AvailabilityCertReqest.RequestNo.ToString(),
                    Remark = y.Remark,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId),
                    IsApprove = y.IsIssued && y.LoanRequest.Count() == 0,// && isfinalAvabApproveFrom && isfinalAvabApproveTo,
                    IsReject = y.IsIssued
                });
            });
            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isReleaseOrder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;
            DataTableResult response = new DataTableResult();
            // x.UnitId >= parameters.OrganizationId &&
            var query = this.repository.GetAllIncludingIQueryableAsyn(x => x.LoanRequestAssign.Where(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId || a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId).Count() > 0 ||(x.Unit.OrganizationTypeId == (int)OrganizationEnum.EPBTI && x.ReleaseOrder.Count>0), x => x.Include(m => m.AvailabilityCertIssue)
              .Include(m => m.LoanRequestAssign).Include(m => m.ReleaseOrder)
              .Include("AvailabilityCertIssue.AvailabilityCertReqest").Include(m => m.Store).Include(m => m.Unit).Include(m => m.AssignedDesignation).Include(m => m.ApprovedDesignation));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (LoanRequest)x;
                var fromWork = y.LoanRequestAssign.LastOrDefault();
                bool isApproved = (fromWork.ToDesignationId == parameters.DesignationId && fromWork.ToOrganizationId == parameters.OrganizationId) && !(fromWork.FromDesignationId == parameters.DesignationId && fromWork.FromOrganizationId == parameters.OrganizationId) && y.ReleaseOrder.Count() == 0;
                requiredData.Add(new LoanRequestGrid
                {
                    Id = y.Id,
                    RequestDate = y.AvailabilityCertIssue.AvailabilityCertReqest.RequestDate,
                    StoreName = y.Store.Name,
                    RequestNo = y.AvailabilityCertIssue.AvailabilityCertReqest.RequestNo.ToString(),
                    LoanRequestNo = y.LoanRequestNo,
                    Remark = y.Remark,
                    LoanDate = y.RequestDate,
                    UnitName = y.Unit.Name,
                    Status = Utilities.GetEnumDescription((StatusEnum)y.StatusId),
                    IsApproved = y.IsApproved && isApproved,
                    IsReasenote = y.IsApproved && isReleaseOrder && y.ReleaseOrder.Count() == 0,
                    ReleaseOrderNo = y.ReleaseOrder.Count() > 0 ? y.ReleaseOrder.FirstOrDefault().ReleaseOrderNo : "Not Issued",
                    AssignedDesignation = y.AssignedDesignation.Name,
                    ApprovedDesignation = y.ApprovedDesignation.Name
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<LoanRequestEntity> InsertAsync(LoanRequestEntity entity)
        {
            try
            {
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<LoanRequest>(entity);
                mapped.AssignedDesignationId = workFlow.ToDesignationId.HasValue ? workFlow.ToDesignationId.Value : workFlow.FromDesignationId;
                mapped.ApprovedDesignationId = entity.DesignationId;
                mapped.LoanRequestAssign.Add(new LoanRequestAssign
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    LoanRequestDetail = this.mapper.Map<List<LoanRequestDetail>>(entity.LoanRequestDetail)

                });
                var result = await this.repository.AddAsyn(mapped);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<LoanRequestEntity> UpdateAsync(LoanRequestEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertIssue).Include(m => m.LoanRequestAssign).Include("LoanRequestAssign.LoanRequestDetail"));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                oldResult.Remark = entity.Remark;
                oldResult.StatusId = entity.StatusId;
                oldResult.IsActive = entity.IsActive;
                var oldAssignRequest = oldResult.LoanRequestAssign.FirstOrDefault();
                foreach (var item in oldResult.LoanRequestAssign)
                {
                    item.ToDesignationId = workFlow.ToDesignationId;
                    item.ToOrganizationId = workFlow.ToOrganizationId;
                    item.Note = entity.Note;
                    foreach (var details in item.LoanRequestDetail)
                    {
                        var loanrequestdetail = entity.LoanRequestDetail.FirstOrDefault(l => l.Id == details.Id && l.LoanReqestAssignId == item.Id);
                        details.Quantiy = loanrequestdetail.Quantiy;
                        details.Reason = loanrequestdetail.Reason;
                        details.LoanPeriodInMonth = loanrequestdetail.LoanPeriodInMonth;

                    }

                }

                var result = await this.repository.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);

                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<LoanRequestEntity> ApproveAsync(LoanRequestEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.AvailabilityCertIssue).Include(m => m.LoanRequestAssign).Include("LoanRequestAssign.LoanRequestDetail"));
                //var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                oldResult.Remark = entity.Remark;
                oldResult.StatusId = entity.StatusId;
                oldResult.IsApproved = entity.IsApproved;
                oldResult.IsActive = entity.IsActive;
                oldResult.ApprovedDesignationId = entity.DesignationId;
                oldResult.AssignedDesignationId = entity.ToDesignationId.HasValue ? entity.ToDesignationId.Value : entity.FromDesignationId.Value;
                var loanRequestAssign = new LoanRequestAssign
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = entity.IsActive.Value,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    LoanRequestId = oldResult.Id,
                    LoanRequestDetail = this.mapper.Map<List<LoanRequestDetail>>(entity.LoanRequestDetail)
                };

                var result = await this.loanRequestAssignRepository.AddAsyn(loanRequestAssign);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}