﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;
    using System.Data.Entity;
    using System.Linq;

    public class RoleManager : IRoleManager
    {
        private IGenericRepository<Role> repository;
        private IGenericRepository<Menu> menuRepository;
        private IGenericRepository<RoleMenu> rolemenurepository;
        private IGenericRepository<RoleMenuPermission> rolemenuPermissionRepository;
        private IMapper mapper;
        private IGenericRepository<Report> report;
        private IGenericRepository<ReportPermission> reportPermission;
        public RoleManager(IMapper mapper, IGenericRepository<RoleMenu> rolemenurepository, IGenericRepository<RoleMenuPermission> rolemenuPermissionRepository, IGenericRepository<Role> repository, IGenericRepository<Menu> menuRepository, IGenericRepository<Report> report, IGenericRepository<ReportPermission> reportPermission)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.menuRepository = menuRepository;
            this.rolemenurepository = rolemenurepository;
            this.rolemenuPermissionRepository = rolemenuPermissionRepository;
            this.report = report;
            this.reportPermission = reportPermission;
        }

        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<RoleEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<RoleEntity>>(result);
            return mapped;
        }

        public async Task<RoleEntity> GetAsync(short id)
        {
            RoleEntity response = new RoleEntity();
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.RoleMenu).Include("RoleMenu.RoleMenuPermission"));
            response.Id = result.Id;
            response.Name = result.Name;
            response.Description = result.Description;
            response.PermissionMask = result.PermissionMask;
            response.CreatedBy = result.CreatedBy;
            response.CreatedDate = result.CreatedDate;
            response.RoleMenu = await this.GetMenuById(result.RoleMenu);
            var allreport = await this.report.GetAllAsync();
            var allPermission = await this.reportPermission.FindAllAsync(x => x.RoleId == id);
            response.Report = allreport.Select(x => new ReportsEntity { Id = x.Id, Name = x.Name, SectioId = x.SectioId, Url = x.Url, IsApply = allPermission.Any(a => a.ReportId == x.Id) }).ToList();
            return response;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<RoleEntity> UpdateAsync(RoleEntity entity)
        {
            try
            {
                var updateResponse = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.RoleMenu).Include("RoleMenu.RoleMenuPermission").Include(m => m.ReportPermission));


                foreach (var item in updateResponse.RoleMenu.ToList())
                {
                    await this.rolemenuPermissionRepository.DeleteRangeAsyn(item.RoleMenuPermission.ToList());
                    await this.rolemenurepository.DeleteEntityAsyn(item);

                }

                foreach (var item in updateResponse.ReportPermission.ToList())
                {
                    await this.reportPermission.DeleteEntityAsyn(item);

                }

                updateResponse.RoleMenu = new List<RoleMenu>();
                updateResponse.Name = entity.Name;
                updateResponse.Description = entity.Description;
                updateResponse.PermissionMask = entity.PermissionMask;
                updateResponse.UpdatedBy = entity.UpdatedBy;
                updateResponse.UpdatedDate = entity.UpdatedDate;

                foreach (var item in entity.RoleMenu)
                {
                    RoleMenu roleMenu = new RoleMenu();
                    if (item.Menu != null && item.Menu.Count > 0)
                    {
                        foreach (var subItem in item.Menu.Where(x => x.IsApply))
                        {
                            roleMenu = new RoleMenu();
                            roleMenu.MenuId = subItem.Id;
                            roleMenu.CreatedBy = entity.CreatedBy;
                            roleMenu.CreatedDate = entity.CreatedDate;
                            roleMenu.UpdatedBy = entity.UpdatedBy;
                            roleMenu.UpdatedDate = entity.UpdatedDate;
                            roleMenu.RoleMenuPermission = new List<RoleMenuPermission>();
                            foreach (var permis in subItem.MenuPermiission.Where(x => x.IsApply))
                            {
                                roleMenu.RoleMenuPermission.Add(new RoleMenuPermission
                                {
                                    CreatedBy = entity.CreatedBy,
                                    CreatedDate = entity.CreatedDate,
                                    PermissionId = (byte)permis.Id,
                                    UpdatedBy = entity.UpdatedBy,
                                    UpdatedDate = entity.UpdatedDate
                                });

                            }

                            updateResponse.RoleMenu.Add(roleMenu);
                        }

                    }
                }

                updateResponse.ReportPermission = entity.Report.Select(x => new ReportPermission { ReportId = x.Id, RoleId = updateResponse.Id, CreatedBy = entity.CreatedBy, CreatedDate = entity.CreatedDate, UpdatedBy = entity.UpdatedBy, UpdatedDate = entity.UpdatedDate }).ToList();

                var result = await this.repository.UpdateAsync(updateResponse);

                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<RoleEntity> InsertAsync(RoleEntity entity)
        {
            try
            {


                Role insertObj = new Role();
                insertObj.Id = entity.Id;
                insertObj.Name = entity.Name;
                insertObj.Description = entity.Description;
                insertObj.PermissionMask = entity.PermissionMask;
                insertObj.CreatedBy = entity.CreatedBy;
                insertObj.CreatedDate = entity.CreatedDate;
                insertObj.UpdatedBy = entity.UpdatedBy;
                insertObj.UpdatedDate = entity.UpdatedDate;

                foreach (var item in entity.RoleMenu)
                {
                    RoleMenu roleMenu = new RoleMenu();
                    if (item.Menu != null && item.Menu.Count > 0)
                    {
                        foreach (var subItem in item.Menu.Where(x => x.IsApply))
                        {
                            roleMenu = new RoleMenu();
                            roleMenu.MenuId = subItem.Id;
                            roleMenu.CreatedBy = entity.CreatedBy;
                            roleMenu.CreatedDate = entity.CreatedDate;
                            roleMenu.UpdatedBy = entity.UpdatedBy;
                            roleMenu.UpdatedDate = entity.UpdatedDate;
                            roleMenu.RoleMenuPermission = new List<RoleMenuPermission>();
                            foreach (var permis in subItem.MenuPermiission.Where(x => x.IsApply))
                            {
                                roleMenu.RoleMenuPermission.Add(new RoleMenuPermission
                                {
                                    CreatedBy = entity.CreatedBy,
                                    CreatedDate = entity.CreatedDate,
                                    PermissionId = (byte)permis.Id,
                                    UpdatedBy = entity.UpdatedBy,
                                    UpdatedDate = entity.UpdatedDate
                                });

                            }

                            insertObj.RoleMenu.Add(roleMenu);
                        }

                    }
                }
                insertObj.ReportPermission = entity.Report.Select(x => new ReportPermission { ReportId = x.Id, RoleId = insertObj.Id, CreatedBy = entity.CreatedBy, CreatedDate = entity.CreatedDate, UpdatedBy = entity.UpdatedBy, UpdatedDate = entity.UpdatedDate }).ToList();

                var result = await this.repository.AddAsyn(insertObj);



                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<DisplayRoleMenuEntity>> GetMenuByRoleId(short roleId)
        {
            List<DisplayRoleMenuEntity> response = new List<DisplayRoleMenuEntity>();
            var roleMenus = await this.repository.GetIncludingFindByAsyn(x => x.Id == roleId, x => x.Include(m => m.RoleMenu).Include("RoleMenu.Menu").OrderBy(d => d.Id));
            List<int> menuids = new List<int>();
            foreach (var item in roleMenus.Select(x => x.RoleMenu))
            {
                menuids.AddRange(item.Select(c => c.MenuId).ToList());
            }
            try
            {
                var result = await this.menuRepository.GetIncludingFindByAsyn(x => x.ParentId == null, x => x.Include(m => m.InverseParent).Include("InverseParent.MenuPermission").OrderBy(d => d.Id));
                foreach (var menu in result)
                {
                    DisplayRoleMenuEntity rMenu = new DisplayRoleMenuEntity();
                    rMenu.Name = menu.DisplayName;
                    foreach (var cmenu in menu.InverseParent.OrderBy(d => d.Id))
                    {
                        if (menuids.Contains(cmenu.Id) || roleId == 1)
                        {
                            if (cmenu != null)
                            {
                                var permission = this.rolemenuPermissionRepository.FindAll(r => cmenu.RoleMenu.Select(x => x.Id).Contains(r.RoleMenuId)).ToList();
                                DisplayMenuEntity crmenu = new DisplayMenuEntity();
                                crmenu.Name = cmenu.DisplayName;
                                crmenu.Url = cmenu.PageUrl;
                                crmenu.PermissionId = permission.Select(x => x.PermissionId).ToList();
                                rMenu.menu.Add(crmenu);
                            }

                        }


                    }

                    response.Add(rMenu);

                }

            }
            catch (Exception ex)
            {

                throw;
            }



            return response;
        }

        public async Task<List<RoleParentMenuEntity>> GetMenu()
        {
            List<RoleParentMenuEntity> response = new List<RoleParentMenuEntity>();
            try
            {
                var result = await this.menuRepository.GetIncludingFindByAsyn(x => x.ParentId == null, x => x.Include(m => m.InverseParent).Include("InverseParent.MenuPermission").Include("InverseParent.MenuPermission.Permission"));
                foreach (var menu in result)
                {
                    RoleParentMenuEntity rMenu = new RoleParentMenuEntity();
                    rMenu.Id = menu.Id;
                    rMenu.Name = menu.DisplayName;

                    foreach (var cmenu in menu.InverseParent)
                    {
                        if (cmenu != null)
                        {
                            RoleMenuEntity crmenu = new RoleMenuEntity();
                            crmenu.Id = cmenu.Id;
                            crmenu.Name = cmenu.DisplayName;

                            if (cmenu.MenuPermission != null && cmenu.MenuPermission.Count > 0)
                            {

                                foreach (var item in cmenu.MenuPermission)
                                {
                                    if (item != null)
                                    {
                                        crmenu.MenuPermiission.Add(new RoleMenuPermiissionEntity
                                        {
                                            ParentId = cmenu.Id,
                                            Id = item.PermissionId,
                                            Name = item.Permission.Name

                                        });
                                    }
                                }

                                rMenu.Menu.Add(crmenu);
                            }


                        }


                    }

                    response.Add(rMenu);
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return response;

        }

        public async Task<List<ReportsEntity>> Report()
        {
            var allReport = await this.report.GetAllAsync();
            return allReport.Select(x => new ReportsEntity { Id = x.Id, Name = x.Name, SectioId = x.SectioId, Url = x.Url }).ToList();

        }

        private async Task<List<RoleParentMenuEntity>> GetMenuById(ICollection<RoleMenu> roleMenu)
        {
            List<RoleParentMenuEntity> response = new List<RoleParentMenuEntity>();

            var result = await this.menuRepository.GetIncludingFindByAsyn(x => x.ParentId == null, x => x.Include(m => m.InverseParent).Include("InverseParent.MenuPermission").Include("InverseParent.MenuPermission.Permission"));
            foreach (var menu in result)
            {
                RoleParentMenuEntity rMenu = new RoleParentMenuEntity();
                rMenu.Id = menu.Id;
                rMenu.Name = menu.DisplayName;

                foreach (var cmenu in menu.InverseParent)
                {
                    if (cmenu != null)
                    {
                        RoleMenuEntity crmenu = new RoleMenuEntity();
                        crmenu.Id = cmenu.Id;
                        crmenu.Name = cmenu.DisplayName;
                        crmenu.IsApply = roleMenu.Where(x => x.MenuId == cmenu.Id).Count() > 0;
                        if (cmenu.MenuPermission != null && cmenu.MenuPermission.Count > 0)
                        {

                            foreach (var item in cmenu.MenuPermission)
                            {
                                if (item != null)
                                {
                                    crmenu.MenuPermiission.Add(new RoleMenuPermiissionEntity
                                    {
                                        Id = item.PermissionId,
                                        ParentId = cmenu.Id,
                                        Name = item.Permission.Name,
                                        IsApply = roleMenu.Where(x => x.MenuId == cmenu.Id && x.RoleMenuPermission.Where(m => m.PermissionId == item.PermissionId).Count() > 0).Count() > 0

                                    });
                                }
                            }

                            rMenu.Menu.Add(crmenu);
                        }


                    }


                }

                response.Add(rMenu);
            }



            return response;
        }

    }
}
