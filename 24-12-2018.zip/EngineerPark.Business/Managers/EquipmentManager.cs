﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using EngineerPark.Data.IRepositories;

    public class EquipmentManager: IEquipmentManager
    {
        private IGenericRepository<Equipment> repository;
        private IMapper mapper;
        public EquipmentManager(IMapper mapper, IGenericRepository<Equipment> repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        public async Task<int> DeleteAsync(short id)
        {
            var result = await this.repository.DeleteAsyn(id);
            return result;
        }

        public async Task<IList<EquipmentEntity>> GetAllAsync()
        {
            var result = await this.repository.GetAllAsync();

            var mapped = this.mapper.Map<IList<EquipmentEntity>>(result);
            return mapped;
        }

        public async Task<EquipmentEntity> GetAsync(short id)
        {
            var result = await this.repository.GetAsync(id);
            var mapped = this.mapper.Map<EquipmentEntity>(result);
            return mapped;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            var query = this.repository.GetAll();
            var result = await CustomPredicate.BuildPredicate(query, parameters);
            return result;
        }

        public async Task<EquipmentEntity> InsertAsync(EquipmentEntity entity)
        {
            try
            {
                var mapped = this.mapper.Map<Equipment>(entity);

                var result = await this.repository.AddAsyn(mapped);

                return this.mapper.Map<EquipmentEntity>(result);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<bool> IsExistorNot(string name, short id)
        {
            var record = await this.repository.FindAllAsync(x => x.Name == name && x.Id != id);

            if (record != null && record.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<EquipmentEntity> UpdateAsync(EquipmentEntity entity)
        {
            var mapped = this.mapper.Map<Equipment>(entity);
            var result = await this.repository.UpdateAsync(mapped, entity.Id, entity.RowVersion);

            return this.mapper.Map<EquipmentEntity>(result);
        }
    }
}