﻿using AutoMapper;
using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.Business.Entities.GridResponse;
using EngineerPark.CrossCutting;
using EngineerPark.Data;
using EngineerPark.Data.IRepositories;
using EngineerPark.Data.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Managers
{
    public class AstbconveningOrderManagar : IAstbconveningOrderManagar
    {
        private readonly IGenericRepository<AstbconveningOrder> repository;
        private readonly IGenericRepository<TaskWorkFlow> taskworkRepository;
        private readonly IGenericRepository<Organization> organizationRepository;
        private readonly IGenericRepository<Astbstore> astbstoreRepository;
        private readonly IGenericRepository<Bdofficer> bdofficerRepository;
        private readonly IGenericRepository<StoreStock> storeStockRepository;
        private readonly IGenericRepository<StoreStockTransactionQuantity> storeStockQuantityRepository;
        private readonly ICategoryManager categoryManager;
        private readonly ApplicationDbContext context;
        private readonly IGenericRepository<ItemStatus> repositoryItemStatus;
        private readonly string Connectionstring;
        private IMapper mapper;
        private IGenericRepository<User> userRepository;
        private IGenericRepository<AstbsalvageTemp> astbsalvageTempRepository;
        private IGenericRepository<SalvageIn> salvageInRepository;
        private IGenericRepository<MaterialType> materialTypeRepository;

        public AstbconveningOrderManagar(IMapper mapper, IGenericRepository<AstbconveningOrder> repository, IGenericRepository<Organization> organizationRepository, IGenericRepository<TaskWorkFlow> taskworkRepository, ApplicationDbContext context, ICategoryManager categoryManager, IGenericRepository<ItemStatus> repositoryItemStatus, IGenericRepository<Astbstore> astbstoreRepository, IGenericRepository<StoreStock> storeStockRepository, IGenericRepository<StoreStockTransactionQuantity> storeStockQuantityRepository, IGenericRepository<User> userRepository, IGenericRepository<Bdofficer> bdofficerRepository, IGenericRepository<AstbsalvageTemp> astbsalvageTempRepository, IGenericRepository<SalvageIn> salvageInRepository, IGenericRepository<MaterialType> materialTypeRepository)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.organizationRepository = organizationRepository;
            this.categoryManager = categoryManager;
            this.context = context;
            this.repositoryItemStatus = repositoryItemStatus;
            this.astbstoreRepository = astbstoreRepository;
            this.storeStockRepository = storeStockRepository;
            this.storeStockQuantityRepository = storeStockQuantityRepository;
            this.userRepository = userRepository;
            this.bdofficerRepository = bdofficerRepository;
            this.astbsalvageTempRepository = astbsalvageTempRepository;
            this.salvageInRepository = salvageInRepository;
            this.materialTypeRepository = materialTypeRepository;
        }


        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            //bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ASTB && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

            //var isAccessAble = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ASTB && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId);
            //var currentOrg = await this.organizationRepository.FindAsync(x => x.Id == parameters.OrganizationId);

            DataTableResult response = new DataTableResult();
            IQueryable<AstbconveningOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.StoreId == parameters.OrganizationId || x.UnitId == parameters.OrganizationId, x => x.Include(m => m.Store).Include(m => m.Unit).Include(m => m.AstbconveningOrderApproval));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AstbconveningOrder)x;

                var fromWork = y.AstbconveningOrderApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.AstbconveningOrderApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.IsApproved;
                requiredData.Add(new AstbConveningOrderGrid
                {
                    Id = y.Id,
                    LetterNo = y.LetterNo,
                    StoreName = y.Store.Name,
                    Date = y.Date,
                    UnitName = y.Unit.Name,
                    approvedByStore = y.FileName != null && !y.IsApproved,
                    IsDbcomposition = !y.IsApproved && y.PresidingOfficerId == null,
                    IsApproved = y.IsApproved && y.ToOrganizationId == parameters.OrganizationId && y.ToDesignationId == parameters.DesignationId
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<AstbconveningOrderEntity> InsertAsync(AstbconveningOrderEntity entity)
        {
            try
            {
                if (entity.Id != Guid.Empty && entity.PresidingOfficerId != null)
                {
                    var data = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.Bdofficer));
                    data.PresidingOfficerId = entity.PresidingOfficerId;
                    data.IsApproved = false;
                    data.Bdofficer.ToList().ForEach(x =>
                    {
                        x.Name = entity.BdOfficer.FirstOrDefault(s => s.Id == x.Id).Name;
                    });
                    await this.repository.UpdateAsync(data, data.Id);
                }
                else
                if (entity.Id != Guid.Empty && entity.PresidingOfficerId == null)
                {
                    var data = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.Bdofficer));
                    data.Date = entity.Date;
                    data.Fyear = entity.Fyear;
                    data.IntercationDate = entity.IntercationDate;
                    data.LetterNo = entity.LetterNo;
                    data.Scope = entity.Scope;
                    data.StoreId = entity.StoreId;
                    data.UpdatedDate = DateTime.Now;
                    data.IsApproved = false;
                   
                   await this.bdofficerRepository.DeleteRangeAsyn(data.Bdofficer.ToList());
                    data.Bdofficer=new List<Bdofficer>();
                    entity.BdOfficer.ForEach(x =>
                    {
                        data.Bdofficer.Add(new Bdofficer { AstbconveningOrderId = entity.Id, DesignationId = x.DesignationId, CreatedBy = entity.CreatedBy, CreatedDate = DateTime.Now, MemberTypeId = x.MemberTypeId, OrganizationId = x.OrganizationId, Rank = x.Rank, Remark = x.Remark, UpdatedBy = entity.UpdatedBy, UpdatedDate = DateTime.Now });
                    });
                    await this.repository.UpdateAsync(data, data.Id);
                }
                else
                {
                    var list = this.repository.GetAll();
                    entity.FilioNo = list!=null&& list.Count()>0? list.Max(x => x.FilioNo) + 1:1;
                    var mapped = this.mapper.Map<AstbconveningOrder>(entity);
                    mapped.IsApproved = false;
                    var result = await this.repository.AddAsyn(mapped);
                }

                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<AstbconveningOrderEntity> GetAsync(Guid id)
        {

            var entity = await repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Bdofficer).Include(m => m.Store).Include(m => m.Unit).Include("Bdofficer.Organization").Include("Bdofficer.Designation"));
            var mapped = this.mapper.Map<AstbconveningOrderEntity>(entity);
            mapped.UnitName = entity.Unit.Name;
            mapped.StoreName = entity.Store.Name;
            mapped.BdOfficer = entity.Bdofficer.Select(x => new BdofficerEntity { AstbconveningOrderId = x.AstbconveningOrderId, Name = x.Name, MemberTypeId = x.MemberTypeId, Rank = x.Rank, DesignationName = x.Designation.Name, OrganizationName = x.Organization.Name, CreatedBy = x.CreatedBy, CreatedDate = x.CreatedDate, DesignationId = x.DesignationId, Id = x.Id, OrganizationId = x.OrganizationId, RowId = x.RowId, RowVersion = x.RowVersion, UpdatedBy = x.UpdatedBy, UpdatedDate = x.UpdatedDate}).ToList();

            mapped.BdOfficer.ForEach(x => {
                x.DesignationList.Add(new MasterDataEntity { Id = x.DesignationId.ToString(), Name = x.DesignationName });
            });
            return mapped;

        }

        public async Task<AstbApprovedEntity> ApproveAsync(AstbApprovedEntity entity)
        {
            try
            {
                bool isFinelConveorder = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ASTB && x.FromOrganizationId == entity.OrgId && x.FromDesignationId == entity.DestId && x.ToOrganizationId == null && x.ToDesignationId == null) != null;

                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.AstbconveningId, x => x.Include(m => m.AstbconveningOrderApproval));
                //var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ASTB && x.FromDesignationId == entity.DestId && x.FromOrganizationId == entity.OrgId);
                if (entity.IsApproved && !oldResult.IsApproved)
                {
                    oldResult.IsApproved = entity.IsApproved;
                    var poUser = userRepository.Get(oldResult.PresidingOfficerId);
                    poUser.ExpiryDate = DateTime.Now.AddDays(-1);
                    poUser.IsActive = false;
                    await this.userRepository.UpdateAsync(poUser, poUser.Id);
                }

                //if (workFlow != null)
                //{
                oldResult.ToDesignationId = entity.ToDesignationId;
                oldResult.ToOrganizationId = entity.ToOrganizationId;
                oldResult.AstbconveningOrderApproval.Add(new AstbconveningOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DestId,
                    FromOrganizationId = entity.OrgId,
                    IsApproved = entity.IsApproved,
                    ToDesignationId = entity.ToDesignationId,
                    ToOrganizationId = entity.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    AstbconveningOrderId = oldResult.Id
                });
                //}



                if (!entity.ToDesignationId.HasValue && !entity.ToOrganizationId.HasValue)
                {
                    oldResult.IssueDate = DateTime.Now;
                    var astbStore = await astbstoreRepository.GetIncludingFindByAsyn(x => x.AstbconveningOrderId == oldResult.Id, x => x.Include(m => m.AstbstoreDetail));
                    foreach (var item in astbStore.Where(x => x.AstbstoreDetail.Count > 0).ToList())
                    {
                        var store = await storeStockRepository.GetIncludingFindByAsyn(x => x.TransactionTypeId == 1 && x.GroupItemId == item.GroupItemId && x.StoreStockTransaction.Any(y => y.ItemId == item.ItemId && y.ItemSetNumberId == item.ItemSetNumberId), x => x.Include(m => m.StoreStockTransaction).Include("StoreStockTransaction.StoreStockTransactionQuantity"));

                        foreach (var stor in store.ToList())
                        {
                            foreach (var trans in stor.StoreStockTransaction.Where(y => y.ItemId == item.ItemId && y.ItemSetNumberId == item.ItemSetNumberId).ToList())
                            {
                                foreach (var ssqty in trans.StoreStockTransactionQuantity.ToList())
                                {
                                    if (item.GroupItemId == stor.GroupItemId && item.ItemId == trans.ItemId && item.StockShedId == trans.StockShedId && item.ItemSetNumberId == trans.ItemSetNumberId && item.AstbstoreDetail.Any(x => x.ItemStatusId == ssqty.ItemStatusId))
                                    {
                                        var updateQty = await this.storeStockQuantityRepository.FindAsync(x => x.Id == ssqty.Id);
                                        updateQty.Quantiy = item.AstbstoreDetail.FirstOrDefault(x => x.ItemStatusId == ssqty.ItemStatusId).Quantiy;
                                        await this.storeStockQuantityRepository.UpdateAsync(updateQty, updateQty.Id);
                                    }
                                    else
                                    {
                                        await this.storeStockQuantityRepository.DeleteAsyn(ssqty.Id);
                                    }
                                    foreach (var ins in item.AstbstoreDetail.Where(x => x.ItemStatusId != ssqty.ItemStatusId))
                                    {
                                        await this.storeStockQuantityRepository.AddAsyn(new StoreStockTransactionQuantity
                                        {
                                            CreatedBy = ssqty.CreatedBy,
                                            CreatedDate = ssqty.CreatedDate,
                                            ItemStatusId = ins.ItemStatusId,
                                            Quantiy = ins.Quantiy,
                                            StoreStockTransactionId = ssqty.StoreStockTransactionId,
                                            UpdatedBy = ssqty.UpdatedBy,
                                            UpdatedDate = ssqty.UpdatedDate
                                        });

                                    }


                                }
                            }

                        }



                    }

                    var list = await this.astbsalvageTempRepository.FindAllAsync(x => x.Astbid == oldResult.Id);
                    if (list != null && list.Count > 0)
                    {
                        List<SalvageIn> salvageInList = new List<SalvageIn>();
                        salvageInList = list.Select(x => new SalvageIn {MaterialTypeId=x.MaterialTypeId,OrganizationId=oldResult.StoreId,Auth=x.Auth,CreatedBy=oldResult.CreatedBy,StoreId=oldResult.StoreId=oldResult.StoreId,CreatedDate=DateTime.Now,Remark=x.Remark,Date=DateTime.Now,UpdatedBy=oldResult.UpdatedBy,UpdatedDate=DateTime.Now,Weight=x.Weight }).ToList();
                        await this.salvageInRepository.AddRangeAsyn(salvageInList);
                        await this.astbsalvageTempRepository.DeleteRangeAsyn(list);
                    }
                }
                var result = await this.repository.UpdateAsync(oldResult,oldResult.Id);
                return entity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<StockPrintEntity> StockPrint(short storeId, short categoryId)
        {
            var Category = await this.categoryManager.GetAsync(categoryId);
            var modelList = this.GetStock(storeId, categoryId); //await this.context.Set<SP_StockPrint>().FromSql($"StockPrint {storeId}, {categoryId}").ToListAsync();
            StockPrintEntity response = new StockPrintEntity();
            response.CategoryName = Category.Name;
            response.StoreData = modelList.Select(x => new StockDataEntity { Auth_Quantiy = x.Auth_Quantiy, DEP_Quantiy = x.DEP_Quantiy, GroupItemId = x.GroupItemId, GroupItemName = x.GroupItemName, heldQty = x.heldQty, ISS_Quantiy = x.ISS_Quantiy, ItemId = x.ItemId, ItemName = x.ItemName, OP_Quantiy = x.OP_Quantiy, AU = x.AU, ItemSetNumberId = x.ItemSetNumberId, Setnumber = x.Setnumber, StockShedId = x.StockShedId, StockShedName = x.StockShedName }).ToList();
            return response;
        }

        public async Task<DataTableResult> GetPaggedListForPOAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<AstbconveningOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.PresidingOfficerId == parameters.UserId && !x.IsApproved && x.FileName == null, x => x.Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AstbconveningOrder)x;
                requiredData.Add(new AstbConveningOrderGrid
                {
                    Id = y.Id,
                    LetterNo = y.LetterNo,
                    StoreName = y.Store.Name,
                    Date = y.Date,
                    UnitName = y.Unit.Name,
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<DataTableResult> GetPaggedListForAdemondAsync(DataTableParameter parameters)
        {

            DataTableResult response = new DataTableResult();
            IQueryable<AstbconveningOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => (x.StoreId == parameters.OrganizationId || x.UnitId == parameters.OrganizationId) && x.PresidingOfficerId==null, x => x.Include(m => m.Store).Include(m => m.Unit).Include(m => m.AstbconveningOrderApproval));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (AstbconveningOrder)x;

                var fromWork = y.AstbconveningOrderApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var towork = y.AstbconveningOrderApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = towork != null && fromWork == null && y.IsApproved;
                requiredData.Add(new AstbConveningOrderGrid
                {
                    Id = y.Id,
                    LetterNo = y.LetterNo,
                    StoreName = y.Store.Name,
                    Date = y.Date,
                    UnitName = y.Unit.Name,
                    approvedByStore = y.FileName != null && !y.IsApproved,
                    IsDbcomposition = !y.IsApproved && y.PresidingOfficerId == null,
                    IsApproved = y.IsApproved && y.ToOrganizationId == parameters.OrganizationId && y.ToDesignationId == parameters.DesignationId
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<Astbstoredetails> GetByIdAsync(Guid id)
        {
            var entity = await repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store));
            var response = new Astbstoredetails();
            response.LetterNo = entity.LetterNo;
            response.StoreId = entity.StoreId;
            response.StoreName = entity.Store.Name;
            response.AstbconveningId = entity.Id;
            return response;
        }

        public async Task<Astbstoredetails> GetByIdAsync(Guid id, short storeId, short categoryId)
        {
            var entity = await repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store));
            var response = new Astbstoredetails();
            response.LetterNo = entity.LetterNo;
            response.StoreName = entity.Store.Name;
            response.StoreId = entity.StoreId;
            response.AstbconveningId = entity.Id;
            var itemStatus = repositoryItemStatus.GetAll().Where(X => X.Id == 1 || X.Id == 2).Select(x => new AstbstoreDetailEntity { ItemStatusId = x.Id, Name = x.Name }).ToList();

            var modelList = this.GetStock(storeId, categoryId);//await this.context.Set<SP_StockPrint>().FromSql($"StockPrint {storeId}, {categoryId}").ToListAsync();

            response.Store = modelList.Select(x => new AstbstoreEntity { Auth_Quantiy = x.Auth_Quantiy, DEP_Quantiy = x.DEP_Quantiy, GroupItemId = x.GroupItemId, GroupItemName = x.GroupItemName, heldQty = x.heldQty, ISS_Quantiy = x.ISS_Quantiy, ItemId = x.ItemId, ItemName = x.ItemName, OP_Quantiy = x.OP_Quantiy, AU = x.AU, AstbconveningOrderId = entity.Id, AstbstoreDetail = itemStatus, ItemSetNumberId = x.ItemSetNumberId, Setnumber = x.Setnumber, StockShedId = x.StockShedId, StockShedName = x.StockShedName }).ToList();

            return response;
        }

        public async Task<Astbstoredetails> InsertstockAsync(Astbstoredetails entity)
        {
            try
            {
                if (entity.AstbconveningId != Guid.Empty)
                {
                    var data = await this.repository.FindAsync(x => x.Id == entity.AstbconveningId);
                    data.FileName = entity.FileName;
                    await this.repository.UpdateAsync(data, data.Id);
                }

                List<Astbstore> stockData = new List<Astbstore>();
                foreach (var item in entity.Store)
                {

                    var itemList = item.AstbstoreDetail.Where(x => x.Quantiy > 0).Select(x => new AstbstoreDetail { CreatedBy = x.CreatedBy, CreatedDate = x.CreatedDate, AstbstoreId = item.Id, ItemStatusId = x.ItemStatusId, Quantiy = x.Quantiy, UpdatedBy = x.UpdatedBy, UpdatedDate = x.UpdatedDate }).ToList();

                    stockData.Add(new Astbstore
                    {
                        CreatedBy = item.CreatedBy,
                        CreatedDate = item.CreatedDate,
                        GroupItemId = item.GroupItemId,
                        AstbconveningOrderId = entity.AstbconveningId,
                        ItemId = item.ItemId,
                        StockShedId = item.StockShedId,
                        ItemSetNumberId = item.ItemSetNumberId,
                        UpdatedBy = item.UpdatedBy,
                        UpdatedDate = item.UpdatedDate,
                        AstbstoreDetail = itemList

                    });

                }

                var result = await this.astbstoreRepository.AddRangeAsyn(stockData);
                return entity;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<Astbstoredetails> GetApprovedAsync(Guid id, short orgId, short desId)
        {
            var taskWorkflowAssign = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ASTB && x.FromOrganizationId == orgId && x.FromDesignationId == desId && x.ToOrganizationId != null && x.ToDesignationId != null);

            var entity = await repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Bdofficer).Include(m => m.Store));
            var response = new Astbstoredetails();
            response.LetterNo = entity.LetterNo;
            response.FileName = entity.FileName;
            response.StoreName = entity.Store.Name;
            response.StoreId = entity.StoreId;
            response.AstbconveningId = entity.Id;

            if (taskWorkflowAssign != null)
            {
                response.ToDesignationId = taskWorkflowAssign.ToDesignationId;
                response.ToOrganizationId = taskWorkflowAssign.ToOrganizationId;
            }

            var store = astbstoreRepository.GetAllIncludingIQueryableAsyn(x => x.AstbconveningOrderId == entity.Id, x => x.Include(m => m.GroupItem).Include(m => m.Item).Include("AstbstoreDetail.ItemStatus"));
            response.Store = store.Select(x => new AstbstoreEntity { GroupItemName = x.GroupItem.Name, ItemName = x.Item.Name, AstbstoreDetail = x.AstbstoreDetail.Select(y => new AstbstoreDetailEntity { Name = y.ItemStatus.Name, Quantiy = y.Quantiy }).ToList() }).ToList();

            return response;

        }

        public async Task<bool> UpdateBDOffers(short orgId, short destId)
        {
            try
            {
                var bdoffers = await this.bdofficerRepository.FindByAsyn(x => x.OrganizationId == orgId && x.DesignationId == destId && !x.IsView);
                if (bdoffers != null && bdoffers.Count() > 0)
                {
                    var first = bdoffers.FirstOrDefault();
                    first.IsView = true;
                    first.ViewDate = DateTime.Now;
                    await this.bdofficerRepository.UpdateAsync(first, first.Id);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


            return true;
        }

        public async Task<List<AstbsalvageTempEntity>> AddEditAstbSalvage(List<AstbsalvageTempEntity> model,Guid astbOrderId)
        {
            var list = await this.astbsalvageTempRepository.FindAllAsync(x => x.Astbid == astbOrderId);
            if(list!=null && list.Count > 0)
            {
             await   this.astbsalvageTempRepository.DeleteRangeAsyn(list);
            }
            List<AstbsalvageTemp> modelList = model.Select(x => new AstbsalvageTemp {Astbid=x.Astbid,Auth=x.Auth,CreatedBy=x.CreatedBy,CreatedDate=x.CreatedDate,Date=x.Date,MaterialTypeId=x.MaterialTypeId,Remark=x.Remark,UpdatedBy=x.UpdatedBy,UpdatedDate=x.UpdatedDate,Weight=x.Weight }).ToList();

            await this.astbsalvageTempRepository.AddRangeAsyn(modelList);
            return model;
        }

        public async Task<List<AstbsalvageTempEntity>> GetAstbSalvage(Guid astbOrderId)
        {
            var list = await this.astbsalvageTempRepository.FindAllAsync(x => x.Astbid == astbOrderId);

            var materialList =await this.materialTypeRepository.GetAllAsync();

            List<AstbsalvageTempEntity> modelList = materialList.Select(x => new AstbsalvageTempEntity { MaterialTypeId = x.Id, MaterialTypeName = x.Name ,Astbid=astbOrderId}).ToList();
            modelList.ForEach(x => {

                var data = list!=null && list.Any()?list.Where(w => w.MaterialTypeId == x.MaterialTypeId && w.Astbid == astbOrderId).FirstOrDefault():null;
                if (data != null)
                {
                    x.Auth = data.Auth;
                    x.CreatedBy = data.CreatedBy;
                    x.CreatedDate = data.CreatedDate;
                    x.Date = data.Date;
                    x.Remark = data.Remark;
                    x.UpdatedBy = data.UpdatedBy;
                    x.UpdatedDate = data.UpdatedDate;
                    x.Weight = data.Weight;
                    x.Id = data.Id;
                }
            });
            
            return modelList;
        }

        private List<SP_StockPrint> GetStock(short storeId, short categoryId)
        {
            short? catId = null;
            if (categoryId > 0)
            {
                catId = categoryId;
            }
            var response = new List<SP_StockPrint>();
            var ds = SqlHelper.ExecuteDataset(this.Connectionstring, "StockPrint", new SqlParameter("@StoreId", storeId), new SqlParameter("@categoryId", catId));

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    response.Add(new SP_StockPrint(row));

                }
            }
            return response;
        }




    }
}
