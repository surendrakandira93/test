﻿using EngineerPark.Business.Contracts;
using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using EngineerPark.Data;
using EngineerPark.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EngineerPark.Business.Managers
{
    public class DashboardManager : IDashboardManager
    {

        private IRepository<AvailabilityCertRequest> repositoryRequest;
        private IRepository<AvailabilityCertIssue> repositoryIssue;
        private IRepository<LoanRequest> repositoryLoanRequest;
        private IRepository<ReleaseOrder> repositoryReleaseOrder;
        private IRepository<AuthorityLetter> repositoryAuthorityLetter;
        private IRepository<ConveyNote> repositoryConveyNote;
        private IRepository<LoanIssueVoucher> repositoryLoanIssue;
        private IRepository<TaskWorkFlow> taskworkRepository;
        private IRepository<ConveningOrder> repositoryConveningOrder;
        private IRepository<ConveningOrderItemSurvey> repositoryConveningOrderItemSurvey;
        private IRepository<SenctionOrder> repositorySenctionOrder;
        private IRepository<AstbconveningOrder> repositoryAstbconveningOrder;
        private IRepository<MaintenancePlan> repositoryMaintenancePlan;
        private IRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan;
        private IRepository<JobOrder> repositoryJobOrder;
        private IRepository<LoanExtension> repositoryLoanExtension;
        private IRepository<LoanRenewal> repositoryLoanRenewal;
        public DashboardManager(IRepository<AvailabilityCertRequest> repositoryRequest, IRepository<AvailabilityCertIssue> repositoryIssue, IRepository<LoanRequest> repositoryLoanRequest, IRepository<ReleaseOrder> repositoryReleaseOrder, IRepository<ConveyNote> repositoryConveyNote, IRepository<LoanIssueVoucher> repositoryLoanIssue, IRepository<TaskWorkFlow> taskworkRepository, IRepository<AuthorityLetter> repositoryAuthorityLetter, IRepository<ConveningOrder> repositoryConveningOrder, IRepository<ConveningOrderItemSurvey> repositoryConveningOrderItemSurvey, IRepository<SenctionOrder> repositorySenctionOrder, IRepository<AstbconveningOrder> repositoryAstbconveningOrder, IRepository<MaintenancePlan> repositoryMaintenancePlan, IRepository<QuarterlyMaintenancePlan> repositoryQuarterlyMaintenancePlan, IRepository<JobOrder> repositoryJobOrder, IRepository<LoanExtension> repositoryLoanExtension, IRepository<LoanRenewal> repositoryLoanRenewal)
        {
            this.repositoryRequest = repositoryRequest;
            this.repositoryIssue = repositoryIssue;
            this.repositoryLoanRequest = repositoryLoanRequest;
            this.repositoryReleaseOrder = repositoryReleaseOrder;
            this.repositoryConveyNote = repositoryConveyNote;
            this.repositoryLoanIssue = repositoryLoanIssue;
            this.taskworkRepository = taskworkRepository;
            this.repositoryAuthorityLetter = repositoryAuthorityLetter;
            this.repositoryConveningOrder = repositoryConveningOrder;
            this.repositoryConveningOrderItemSurvey = repositoryConveningOrderItemSurvey;
            this.repositorySenctionOrder = repositorySenctionOrder;
            this.repositoryAstbconveningOrder = repositoryAstbconveningOrder;
            this.repositoryMaintenancePlan = repositoryMaintenancePlan;
            this.repositoryQuarterlyMaintenancePlan = repositoryQuarterlyMaintenancePlan;
            this.repositoryJobOrder = repositoryJobOrder;
            this.repositoryLoanExtension = repositoryLoanExtension;
            this.repositoryLoanRenewal = repositoryLoanRenewal;
        }

        public DashboardNotificationEntity Notification(NotificationMainEntity model)
        {
            DashboardNotificationEntity response = new DashboardNotificationEntity();
            foreach (var item in model.Methods)
            {
                var result = new NotificationDetailEntity();
                result.Heading = item.Heading;
                result.ModelId = Guid.NewGuid().ToString();
                result.ActionUrl = item.ActionUrl;
                result.ActionTitle = item.ActionTitle;
                result.ColumnName = item.ColumnName;
                result.ColorClass = item.ColorClass;
                switch (item.MethodName)
                {
                    case "availabilitycertissue":
                        result.Rows = this.GetCertIssue(model.OrganizationId);
                        break;
                    case "pendingloanrequest":
                        result.Rows = this.GetPendingLoanRequest(model.OrganizationId);
                        break;
                    case "approveloanrequest":

                        if (model.Methods.Any(x => x.MethodName == "requestreleaseorder"))
                        {
                            if (this.RequestReleaseOrder(model.OrganizationId, model.DesignationId).Count == 0)
                            {
                                result.Rows = this.GetApproveLoanRequest(model.OrganizationId, model.DesignationId);
                            }
                        }
                        else
                        {
                            result.Rows = this.GetApproveLoanRequest(model.OrganizationId, model.DesignationId);
                        }
                        break;
                    case "requestreleaseorder":
                        result.Rows = this.RequestReleaseOrder(model.OrganizationId, model.DesignationId);
                        break;
                    case "requestauthorityletter":
                        result.Rows = this.GetAuthorityLetter(model.OrganizationId);
                        break;
                    case "convoynoterequest":
                        result.Rows = this.GetConveyNote(model.OrganizationId);
                        break;
                    case "approveconveningorder":


                        if (model.Methods.Any(x => x.MethodName == "IssueConveningOrder"))
                        {
                            List<List<string>> conveing = this.GetIssueConveningOrder(model.OrganizationId, model.DesignationId);
                            if (conveing.Count() == 0)
                            {
                                result.Rows = this.GetApproveConveningOrder(model.OrganizationId, model.DesignationId);
                            }
                        }
                        else
                        {
                            result.Rows = this.GetApproveConveningOrder(model.OrganizationId, model.DesignationId);
                        }

                        break;

                    case "IssueConveningOrder":
                        List<List<string>> conveingss = this.GetApproveConveningOrder(model.OrganizationId, model.DesignationId);
                        result.Rows = this.GetIssueConveningOrder(model.OrganizationId, model.DesignationId);
                        break;

                    case "addmember":
                        result.Rows = this.GetAddMember(model.OrganizationId);
                        break;
                    case "sanctionorderrequest":
                        result.Rows = this.GetSenctionOrder(model.OrganizationId);
                        break;
                    case "loadtrolleyrequest":
                        result.Rows = this.GetLoadTrolleyRequest(model.OrganizationId);
                        break;
                    case "astbconveningorder":
                        result.Rows = this.GetAstbConveningOrder(model.OrganizationId);
                        break;
                    case "approveastbconveningorder":
                        result.Rows = this.GetApproveAstbConveningOrder(model.OrganizationId, model.DesignationId);
                        break;
                    case "abstconveningordercreate":
                        result.Rows = this.GetAstbConveningOrderCreate();
                        break;

                    case "astbconveningordermembernoti":
                        result.Rows = this.GetAstbConveningOrderMemberNoti(model.OrganizationId, model.DesignationId);
                        break;

                    case "maintenanceplanapprove":
                        result.Rows = this.GetMaintenancePlanApprove(model.OrganizationId, model.DesignationId);
                        break;

                    case "quarterlymaintenanceplanapprove":
                        result.Rows = this.GetQuarterlyMaintenancePlanApprove(model.OrganizationId, model.DesignationId);
                        break;

                    case "joborder":
                        result.Rows = this.GetJobOrderApprove(model.OrganizationId, model.DesignationId);
                        break;

                    case "loanrenewal":
                        result.Rows = this.LoanRenewalApprove(model.OrganizationId, model.DesignationId);
                        break;

                    case "loanextension":
                        
                        result.Rows = this.LoanExtensionApprove(model.OrganizationId, model.DesignationId);
                        break;
                }

                if (result != null && result.Rows != null && result.Rows.Count > 0)
                {
                    response.Result.Add(result);
                }


            }

            return response;
        }


        private List<List<string>> GetCertIssue(short organizationId)
        {
            return this.repositoryRequest.Query().Filter(x => x.AvailabilityCertIssue.Count == 0 && (x.RequestedStoreId == organizationId && x.IsApproved)).Include(x => x.Unit).Include(x => x.RequestedStore).Get().Select(x => new List<string>()
            {
                x.RequestNo,
                x.RequestDate.ToString(Constants.DATE_FORMAT),
                x.Unit.Name,
                x.RequestedStore.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetPendingLoanRequest(short organizationId)
        {
            return this.repositoryIssue.Query().Filter(x => x.LoanRequest.Count == 0 && x.AvailabilityCertReqest.UnitId == organizationId).Include(x => x.Store).Include(x => x.AvailabilityCertReqest).Get().Select(x => new List<string>()
            {
                x.CertificateNo,
                x.IssueDate.ToString(Constants.DATE_FORMAT),
                x.AvailabilityCertReqest.RequestNo,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();

        }

        //private List<List<string>> GetApproveLoanRequest(short organizationId, short designationId)
        //{
        //    //var counts = this.repositoryLoanRequest.Query().Filter(x => x.LoanRequestAssign.Where(a => a.FromDesignationId == designationId && a.FromOrganizationId == organizationId).Count() == 0 && x.LoanRequestAssign.Where(a => a.ToDesignationId == designationId && a.ToOrganizationId == organizationId).Count() > 0 && x.LoanRequestAssign.Where(a => a.ToOrganizationId == organizationId).Count() > 1 && x.IsApproved && x.ReleaseOrder.Count == 0).Include(x => x.Store).Include(x => x.ApprovedDesignation).Include(x => x.AvailabilityCertIssue).Include(x => x.AvailabilityCertIssue.LoanRequest).Get();
        //    if (true)
        //    {
        //        return this.repositoryLoanRequest.Query().Filter(x => x.LoanRequestAssign.Where(a => a.FromDesignationId == designationId && a.FromOrganizationId == organizationId).Count() == 0 && x.LoanRequestAssign.Where(a => a.ToDesignationId == designationId && a.ToOrganizationId == organizationId).Count() > 0 && x.IsApproved && x.ReleaseOrder.Count == 0 && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.Store).Include(x => x.ApprovedDesignation).Include(x => x.AvailabilityCertIssue).Include(x => x.AvailabilityCertIssue.LoanRequest).Get().Select(x => new List<string>()
        //    {
        //        x.RequestDate.ToString(Constants.DATE_FORMAT),
        //        x.LoanRequestNo,
        //        x.AvailabilityCertIssue.LoanRequest.FirstOrDefault().LoanRequestNo,
        //        x.Store.Name,
        //        x.ApprovedDesignation.Name,
        //        x.Id.ToString()
        //    }).ToList();
        //    }
        //    else
        //    {
        //        return new List<List<string>>();
        //    }

        //}


        private List<List<string>> GetApproveLoanRequest(short organizationId, short designationId)
        {
            //var counts = this.repositoryLoanRequest.Query().Filter(x => x.LoanRequestAssign.Where(a => a.FromDesignationId == designationId && a.FromOrganizationId == organizationId).Count() == 0 && x.LoanRequestAssign.Where(a => a.ToDesignationId == designationId && a.ToOrganizationId == organizationId).Count() > 0 && x.LoanRequestAssign.Where(a => a.ToOrganizationId == organizationId).Count() > 1 && x.IsApproved && x.ReleaseOrder.Count == 0).Include(x => x.Store).Include(x => x.ApprovedDesignation).Include(x => x.AvailabilityCertIssue).Include(x => x.AvailabilityCertIssue.LoanRequest).Get();

            return this.repositoryLoanRequest.Query().Filter(x => x.IsApproved && x.ReleaseOrder.Count == 0 && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.LoanRequestAssign).Include(x => x.Store).Include(x => x.ApprovedDesignation).Include(x => x.AvailabilityCertIssue).Include(x => x.AvailabilityCertIssue.LoanRequest).Get().Where(x => (x.LoanRequestAssign.LastOrDefault() != null && x.LoanRequestAssign.LastOrDefault().ToDesignationId.Value == designationId && x.LoanRequestAssign.LastOrDefault().ToOrganizationId.Value == organizationId) && !(x.LoanRequestAssign.LastOrDefault() != null && x.LoanRequestAssign.LastOrDefault().FromDesignationId == designationId && x.LoanRequestAssign.LastOrDefault().FromOrganizationId == organizationId)).Select(x => new List<string>()
            {
                x.RequestDate.ToString(Constants.DATE_FORMAT),
                x.LoanRequestNo,
                x.AvailabilityCertIssue.LoanRequest.FirstOrDefault().LoanRequestNo,
                x.Store.Name,
                x.ApprovedDesignation.Name,
                x.Id.ToString()
            }).ToList();


        }

        private List<List<string>> RequestReleaseOrder(short organizationId, short designationId)
        {
            var isFinal = taskworkRepository.Query().Filter(x => x.TaskId == (int)TaskTypeEnum.Approval && x.FromOrganizationId == organizationId && x.FromDesignationId == designationId && !x.ToDesignationId.HasValue && !x.ToDesignationId.HasValue).Get().Any();
            return this.repositoryLoanRequest.Query().Filter(x => x.LoanRequestAssign.Where(a => a.FromDesignationId == designationId && a.FromOrganizationId == organizationId).Count() == 0 && x.LoanRequestAssign.Where(a => a.ToDesignationId == designationId && a.ToOrganizationId == organizationId).Count() > 0 && isFinal && x.IsApproved && x.ReleaseOrder.Count == 0).Include(x => x.Store).Include(x => x.ApprovedDesignation).Include(x => x.AvailabilityCertIssue).Include(x => x.AvailabilityCertIssue.LoanRequest).Get().Select(x => new List<string>()
            {
                x.RequestDate.ToString(Constants.DATE_FORMAT),
                x.LoanRequestNo,
                x.AvailabilityCertIssue.LoanRequest.FirstOrDefault().LoanRequestNo,
                x.AvailabilityCertIssue.LoanRequest.FirstOrDefault().RequestDate.ToString("dd/MM/yyyy"),
                x.Store.Name,
                x.ApprovedDesignation.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetAuthorityLetter(short organizationId)
        {
            return this.repositoryReleaseOrder.Query().Filter(x => x.AuthorityLetter.Count == 0 && x.LoanRequest.UnitId == organizationId).Include(x => x.LoanRequest).Include(x => x.Store).Get().Select(x =>
            new List<string>()
            {
                x.ReleaseOrderNo,
                x.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.LoanRequest.LoanRequestNo,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetConveyNote(short organizationId)
        {
            return this.repositoryAuthorityLetter.Query().Filter(x => x.ConveyNote.Count == 0 && x.StoreId == organizationId).Include(x => x.ReleaseOrder).Include(x => x.ReleaseOrder.LoanRequest).Include(m => m.Store).Get().Select(x =>
                  new List<string>()
                  {
                x.ReleaseOrder.ReleaseOrderNo,
                x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.LoanRequest.LoanRequestNo,
                x.LetterNo,
                x.Store.Name,
                x.Id.ToString()
                  }).ToList();
        }

        private List<List<string>> GetApproveConveningOrder(short organizationId, short designationId)
        {
            // repositoryLoanExtension
            var convening=this.repositoryConveningOrder.Query().Filter(x=> x.IsApproved&& !x.LoadTrolley.Any() && x.ConveningOrderItemSurveyMain.Any() && x.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.ConveningOrderApproval).Include(x => x.ApprovedDesignation).Include(x => x.ReleaseOrder).Include(x => x.ApprovedDesignation).Include(x => x.Store).Get().Where(x => (repositoryLoanExtension.Query().Filter(a => a.ReleaseOrderId == x.ReleaseOrderId && a.UnitToId == organizationId).Get().Any())|| (!repositoryLoanExtension.Query().Filter(a => a.ReleaseOrderId == x.ReleaseOrderId && a.UnitFromId == organizationId).Get().Any() &&(x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.Value == designationId && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.Value == organizationId) && !(x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().FromDesignationId == designationId && x.ConveningOrderApproval.LastOrDefault().FromOrganizationId == organizationId))).Select(x => new List<string>()
            {
                x.ConveningOrderNo,
                x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.ReleaseOrderNo,
                x.ApprovedDesignation.Name,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
            return convening;

            //return this.repositoryConveningOrder.Query().Filter(x => x.IsApproved && x.ConveningOrderItemSurveyMain.Any() && x.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.ConveningOrderApproval).Include(x => x.ApprovedDesignation).Include(x => x.ReleaseOrder).Include(x => x.ApprovedDesignation).Include(x => x.Store).Get().Where(x => (x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.Value == designationId && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.Value == organizationId) && !(x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().FromDesignationId == designationId && x.ConveningOrderApproval.LastOrDefault().FromOrganizationId == organizationId)).Select(x => new List<string>()
            //{
            //    x.ConveningOrderNo,
            //    x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
            //    x.ReleaseOrder.ReleaseOrderNo,
            //    x.ApprovedDesignation.Name,
            //    x.Store.Name,
            //    x.Id.ToString()
            //}).ToList();

        }

        private List<List<string>> GetIssueConveningOrder(short organizationId, short designationId)
        {
            bool isFinelConveorder = this.taskworkRepository.Query().Filter(x => x.TaskId == (int)TaskTypeEnum.ConveningOrder && x.FromOrganizationId == organizationId && x.FromDesignationId == designationId && x.ToOrganizationId == null && x.ToDesignationId == null).Get().Count() > 0;

            return this.repositoryConveningOrder.Query().Filter(x => isFinelConveorder && x.IsApproved && x.ConveningOrderItemSurveyMain.Any() && x.ConveningOrderItemSurveyMain.FirstOrDefault().IsApproved && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.ReleaseOrder).Include(x => x.ApprovedDesignation).Include(x => x.Store).Get().Where(x => (x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToDesignationId.Value == designationId && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.HasValue && x.ConveningOrderApproval.LastOrDefault().ToOrganizationId.Value == organizationId) && !(x.ConveningOrderApproval.LastOrDefault() != null && x.ConveningOrderApproval.LastOrDefault().FromDesignationId == designationId && x.ConveningOrderApproval.LastOrDefault().FromOrganizationId == organizationId)).Select(x => new List<string>()
            {
                x.ConveningOrderNo,
                x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.ReleaseOrderNo,
                x.ApprovedDesignation.Name,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetAddMember(short organizationId)
        {
            return this.repositoryConveningOrder.Query().Filter(y => y.IsApproved && y.IssueDate != null && y.ConveningOrderMember.Count() == 0 && y.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.ReleaseOrder).Include(x => x.ApprovedDesignation).Include(x => x.Store).Get().Select(x =>
                  new List<string>()
                  {
                x.ConveningOrderNo,
                x.IssueDate.Value.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.ReleaseOrderNo,
                x.ApprovedDesignation.Name,
                x.Store.Name,
                x.Id.ToString()
                  }).ToList();
        }

        private List<List<string>> GetSenctionOrder(short organizationId)
        {
            return this.repositoryConveningOrder.Query().Filter(y => y.SenctionOrder == null).Include(x => x.ReleaseOrder).Get().Select(x => new List<string>()
            {
                x.ConveningOrderNo,
                x.IssueDate.Value.ToString(Constants.DATE_FORMAT),
                x.ReleaseOrder.ReleaseOrderNo,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetLoadTrolleyRequest(short organizationId)
        {
            return this.repositoryConveningOrder.Query().Filter(y => y.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI && y.SenctionOrder != null && y.LoadTrolley.Count == 0).Include(x => x.ReleaseOrder).Get().Select(x => new List<string>()
            {
                x.ConveningOrderNo,
                 x.ReleaseOrder.ReleaseOrderNo,
                x.ReleaseOrder.ReleaseDate.ToString(Constants.DATE_FORMAT),
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetAstbConveningOrder(short organizationId)
        {
            return this.repositoryAstbconveningOrder.Query().Filter(y => y.StoreId == organizationId && y.PresidingOfficerId == null).Include(x => x.Unit).Include(x => x.Store).Get().Select(x => new List<string>()
            {
                x.LetterNo,
                x.Date.ToString(Constants.DATE_FORMAT),
                x.Store.Name,
                x.Unit.Name,
                x.Id.ToString()
            }).ToList();
        }


        private List<List<string>> GetApproveAstbConveningOrder(short organizationId, short designationId)
        {

            return this.repositoryAstbconveningOrder.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.Store).Include(m => m.AstbconveningOrderApproval).Get().Select(x => new List<string>()
            { x.LetterNo,
                x.Date.ToString(Constants.DATE_FORMAT),               
                //x.AstbconveningOrderApproval.LastOrDefault().FromDesignation.Name,
                string.Empty,
                x.Store.Name,
                x.Id.ToString()
            }).ToList();
        }

        private List<List<string>> GetAstbConveningOrderCreate()
        {
            List<List<string>> response = new List<List<string>>();
            var currentDate = DateTime.Now;
            var notiDate = new DateTime(currentDate.Year, 06, 20);
            if (currentDate.Date > notiDate.Date)
            {
                var record = this.repositoryAstbconveningOrder.Query().Filter(y => y.Date.Date.Year == notiDate.Year).Get().Count();
                if (record == 0)
                {
                    response.Add(new List<string>()
            {
                $"Create ASTB Convening order  for {notiDate.Year} !",
                ""
            });
                }
            }

            return response;


        }



        private List<List<string>> GetAstbConveningOrderMemberNoti(short organizationId, short designationId)
        {
            return this.repositoryAstbconveningOrder.Query().Filter(x => x.Bdofficer.Any(y => y.OrganizationId == organizationId && y.DesignationId == designationId && !y.IsView)).Include(x => x.Store).Get().Select(x => new List<string>()
            { x.LetterNo,
                x.Date.ToString(Constants.DATE_FORMAT),
                x.Store.Name,
                x.Id.ToString()
            }).ToList();

        }


        private List<List<string>> GetMaintenancePlanApprove(short organizationId, short designationId)
        {


            return this.repositoryMaintenancePlan.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId && x.Store.OrganizationTypeId == (int)OrganizationEnum.EPBTI).Include(x => x.Store).Include(m => m.MaintenancePlanApproval).Include(m => m.MaintenancePlanDetail).Get().Select(x => new List<string>()
            {
                x.Store.Name,
                x.Year.ToString(),
                x.MaintenancePlanDetail.Sum(s=>s.Amount).ToString(),
                x.Id.ToString()
            }).ToList();


        }

        private List<List<string>> GetQuarterlyMaintenancePlanApprove(short organizationId, short designationId)
        {


            return this.repositoryQuarterlyMaintenancePlan.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId).Include(m => m.QuarterlyMaintenancePlanApproval).Include(m => m.Store).Include(m => m.MaintenancePlan).Include(m => m.QuarterlyMaintenancePlanDetail).Get().Select(x => new List<string>()
            {
                x.Store.Name,
                Utilities.GetEnumDescription((QuarterType)x.QuarterId),
                x.MaintenancePlan.Year.ToString(),
                x.QuarterlyMaintenancePlanDetail.Sum(s=>s.Amount).ToString(),
                x.Id.ToString()
            }).ToList();


        }

        private List<List<string>> GetJobOrderApprove(short organizationId, short designationId)
        {
            return this.repositoryJobOrder.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId).Include(m => m.JobOrderApproval).Include(m => m.Store).Include(m => m.JobOrderDetail).Get().Select(x => new List<string>()
            {
                x.Store.Name,
                Utilities.GetEnumDescription((JobOrderType)x.JobOrderTypeId),
                x.VenderName,
                x.FromDate.ToString("dd/MM/yyyy"),
                x.ToDate.ToString("dd/MM/yyyy"),
                x.Id.ToString()
            }).ToList();


        }

        private List<List<string>> LoanExtensionApprove(short organizationId, short designationId)
        {
            return this.repositoryLoanExtension.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId).Include(m => m.LoanExtensionDetail)
           .Include(m => m.LoanExtensionApproval).Include(m => m.ReleaseOrder).Include(m => m.LoanIssueVoucher)
           .Include(m => m.Store).Include(m => m.UnitFrom).Include(m => m.UnitTo).Get().Select(x => new List<string>()
            {
                x.ReleaseOrder.ReleaseOrderNo,
                x.LoanIssueVoucher.VoucherNo,
                x.UnitFrom.Name,
                x.UnitTo.Name,
                x.Store.Name,
                x.DateFrom.ToString("dd/MM/yyyy"),
                x.DateTo.ToString("dd/MM/yyyy"),
                x.Id.ToString()
            }).ToList();


        }



        private List<List<string>> LoanRenewalApprove(short organizationId, short designationId)
        {
            return this.repositoryLoanRenewal.Query().Filter(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId).Include(m => m.LoanRenewalDetail)
           .Include(m => m.LoanRenewalApproval).Include(m => m.LoanIssueVoucher).Include(m => m.ReleaseOrder)
           .Include(m => m.Store).Include(m => m.Unit).Get().Select(x => new List<string>()
            {
                x.ReleaseOrder.ReleaseOrderNo,
                x.LoanIssueVoucher.VoucherNo,
                x.Unit.Name,
                x.Store.Name,
                x.DateFrom.ToString("dd/MM/yyyy"),
                x.DateTo.ToString("dd/MM/yyyy"),
                x.Id.ToString()
            }).ToList();


        }
    }
}
