﻿namespace EngineerPark.Business.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using EngineerPark.Data.Models;
    using System.Data.Entity;
    using EngineerPark.Data.IRepositories;
    using EngineerPark.Business.Contracts;
    using EngineerPark.Business.Entities.GridResponse;

    public class ReleaseOrderManager : IReleaseOrderManager
    {
        private IGenericRepository<ReleaseOrder> repository;
        private IGenericRepository<LoanRequest> LoanRequestRepository;
        private IGenericRepository<LoanRequestDetail> LoanRequestdetailRepository;
        private IGenericRepository<TaskWorkFlow> taskworkRepository;
        private IGenericRepository<LoanRequestAssign> loanRequestAssignRepository;
        private IMapper mapper;
        private IGenericRepository<AvailabilityCertIssueDetail> issueDetailRrepository;
        public ReleaseOrderManager(IMapper mapper, IGenericRepository<ReleaseOrder> repository, IGenericRepository<LoanRequest> LoanRequestRepository, IGenericRepository<LoanRequestDetail> LoanRequestdetailRepository,
            IGenericRepository<TaskWorkFlow> taskworkRepository, IGenericRepository<LoanRequestAssign> loanRequestAssignRepository, IGenericRepository<AvailabilityCertIssueDetail> issueDetailRrepository)
        {
            this.mapper = mapper;
            this.LoanRequestRepository = LoanRequestRepository;
            this.repository = repository;
            this.taskworkRepository = taskworkRepository;
            this.LoanRequestdetailRepository = LoanRequestdetailRepository;
            this.loanRequestAssignRepository = loanRequestAssignRepository;
            this.issueDetailRrepository = issueDetailRrepository;
        }

        public async Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters)
        {
            bool isFinelReleaseOrder = await this.taskworkRepository.FindAllAsync(x => x.TaskId == (int)TaskTypeEnum.ReleaseOrder && x.ToOrganizationId == parameters.OrganizationId && x.ToDesignationId == parameters.DesignationId) != null && await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ReleaseOrder && x.FromOrganizationId == parameters.OrganizationId && x.FromDesignationId == parameters.DesignationId) == null;

            DataTableResult response = new DataTableResult();
            //x.UnitId <= parameters.OrganizationId &&
            // x.ReleaseOrderApproval.Where(a => (a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId) || (a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId)).Count() > 0,
            IQueryable<ReleaseOrder> query = this.repository.GetAllIncludingIQueryableAsyn(x => x.Include(m => m.ReleaseOrderDetail)
           .Include(m => m.ReleaseOrderApproval)
           .Include(m => m.LoanRequest).Include(m => m.Store).Include(m => m.Unit));
            response = await CustomPredicate.BuildPredicate(query, parameters);
            var requiredData = new List<object>();
            foreach (var x in response.Data)
            {
                var y = (ReleaseOrder)x;
                var fromApproveal = y.ReleaseOrderApproval.FirstOrDefault(a => a.FromDesignationId == parameters.DesignationId && a.FromOrganizationId == parameters.OrganizationId);
                var toApproveal = y.ReleaseOrderApproval.FirstOrDefault(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId);
                bool isApproved = toApproveal != null && fromApproveal == null;//?true: fromWork != null || towork != null;// y.LoanRequestAssign != null && y.LoanRequestAssign.Count > 0 && y.LoanRequestAssign.Where(a => a.ToDesignationId == parameters.DesignationId && a.ToOrganizationId == parameters.OrganizationId).Count() > 0;
                requiredData.Add(new ReleaseOrderGrid
                {
                    Id = y.Id,
                    LoanRequestDate = y.LoanRequest.RequestDate,
                    StoreName = y.Store.Name,
                    ReleaseOrderNo = y.ReleaseOrderNo,
                    LoanRequestNo = y.LoanRequest.LoanRequestNo,
                    ReleaseDate = y.ReleaseDate,
                    UnitName = y.Unit.Name,
                    IsApproved = isApproved
                });
            }

            response.Data = requiredData;
            return response;
        }

        public async Task<ReleaseOrderEntity> GetAsync(Guid id, short organizationId, short designationId)
        {
            var result = await this.repository.GetIncludingByIdAsyn(x => x.Id == id, x => x.Include(m => m.Store).Include(m => m.LoanRequest).Include("ReleaseOrderDetail.ItemBasicCategory").Include("ReleaseOrderDetail.Item").Include("ReleaseOrderDetail.Item.ItemUom").Include("ReleaseOrderDetail.ItemBasicCategory.BasicCategory").Include("ReleaseOrderDetail.ItemEquipment").Include("ReleaseOrderDetail.ItemEquipment.Equipment"));
            var response = new ReleaseOrderEntity();
            response.LoanRequestId = result.Id;
            response.LoanRequestNo = result.LoanRequest.LoanRequestNo;
            response.ReleaseOrderNo = result.ReleaseOrderNo;
            response.ReleaseDate = result.ReleaseDate;
            response.RequestDate = result.LoanRequest.RequestDate;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            foreach (var item in result.ReleaseOrderDetail)
            {
                response.ReleaseOrderDetail.Add(new ReleaseOrderDetailEntity
                {
                    ItemBasicCategoryName = item.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = item.ItemBasicCategoryId,
                    ItemEquipmentName = item.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = item.ItemEquipmentId,
                    ItemName = item.Item.Name,
                    Place = item.Item.ItemUom.DigitAfterDecimal,
                    ItemId = item.ItemId,
                    Quantiy = item.Quantiy,
                    LoanPeriodInMonth = item.LoanPeriodInMonth,
                    Reason = item.Reason,
                    ReleaseNote = item.ReleaseNote,
                    ReleaseOrderId = item.ReleaseOrderId,
                    LoanRequestDetailId = item.Id,
                    RequestQuantiy = item.Quantiy
                });
            }

            return response;
        }

        public async Task<ReleaseOrderEntity> GetByLoanIdAsync(Guid loanRequestId, short organizationId, short designationId)
        {
            var result = await this.LoanRequestRepository.GetIncludingByIdAsyn(x => x.Id == loanRequestId, x => x.Include(m => m.LoanRequestAssign).Include(m => m.Store).Include("LoanRequestAssign.LoanRequestDetail"));
            var response = new ReleaseOrderEntity();
            response.LoanRequestId = result.Id;
            response.LoanRequestNo = result.LoanRequestNo;
            response.StoreId = result.StoreId;
            response.StoreName = result.Store.Name;
            var assignrequest = result.LoanRequestAssign.LastOrDefault(x => x.ToDesignationId == designationId && x.ToOrganizationId == organizationId);

            foreach (var item in assignrequest.LoanRequestDetail)
            {
                var issueDetails = await this.issueDetailRrepository.GetIncludingByIdAsyn(x => x.Id == item.AvailabilityCertIssueDetailId, x => x.Include(m => m.ItemBasicCategory).Include(m => m.Item).Include(m => m.Item.ItemUom).Include(m => m.ItemBasicCategory.BasicCategory).Include(m => m.ItemEquipment).Include(m => m.ItemEquipment.Equipment).Include(m => m.ItemEquipmentType));

                response.ReleaseOrderDetail.Add(new ReleaseOrderDetailEntity
                {
                    ItemBasicCategoryName = issueDetails.ItemBasicCategory.BasicCategory.Name,
                    ItemBasicCategoryId = issueDetails.ItemBasicCategoryId,
                    ItemEquipmentName = issueDetails.ItemEquipment.Equipment.Name,
                    ItemEquipmentId = issueDetails.ItemEquipmentId,
                    Place = issueDetails.Item.ItemUom.DigitAfterDecimal,
                    ItemName = issueDetails.Item.Name,
                    ItemId = issueDetails.ItemId,
                    LoanRequestDetailId = item.Id,
                    RequestQuantiy = issueDetails.RequestedQuantiy,
                    Quantiy = item.Quantiy,
                    LoanPeriodInMonth = item.LoanPeriodInMonth
                });
            }

            return response;
        }

        public async Task<ReleaseOrderEntity> InsertAsync(ReleaseOrderEntity entity)
        {
            try
            {
                if (!entity.IsApproved)
                {
                    var oldResult = this.LoanRequestRepository.Find(x => x.Id == entity.LoanRequestId);
                    oldResult.StatusId = entity.StatusId;
                    oldResult.IsApproved = entity.IsApproved;
                    oldResult.IsActive = entity.IsApproved;
                    oldResult.ApprovedDesignationId = entity.DesignationId;
                    await this.LoanRequestRepository.UpdateAsync(oldResult, oldResult.Id, entity.RowVersion);
                    return entity;
                }

                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ReleaseOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);
                var mapped = this.mapper.Map<ReleaseOrder>(entity);
                if (workFlow != null)
                {
                    mapped.ReleaseOrderApproval.Add(new ReleaseOrderApproval
                    {
                        ApprovedDate = DateTime.Now,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        FromDesignationId = entity.DesignationId,
                        FromOrganizationId = entity.UnitId,
                        IsApproved = true,
                        ToDesignationId = workFlow.ToDesignationId,
                        ToOrganizationId = workFlow.ToOrganizationId,
                        UpdatedBy = entity.UpdatedBy,
                        UpdatedDate = entity.UpdatedDate,
                        Note = entity.Note

                    });
                }
                var result = await this.repository.AddAsyn(mapped);
                var loanResult = this.LoanRequestRepository.Find(x => x.Id == entity.LoanRequestId);
                loanResult.StatusId = (int)StatusEnum.IssuedReleaseOrder;                
                await this.LoanRequestRepository.UpdateAsync(loanResult, loanResult.Id, entity.RowVersion);
                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReleaseOrderEntity> ApproveAsync(ReleaseOrderEntity entity)
        {
            try
            {


                var oldResult = await this.repository.GetIncludingByIdAsyn(x => x.Id == entity.Id, x => x.Include(m => m.ReleaseOrderApproval).Include(m => m.ReleaseOrderDetail));
                var workFlow = await this.taskworkRepository.FindAsync(x => x.TaskId == (int)TaskTypeEnum.ReleaseOrder && x.FromDesignationId == entity.DesignationId && x.FromOrganizationId == entity.UnitId);

                oldResult.ReleaseOrderApproval.Add(new ReleaseOrderApproval
                {
                    ApprovedDate = DateTime.Now,
                    CreatedBy = entity.CreatedBy,
                    CreatedDate = entity.CreatedDate,
                    FromDesignationId = entity.DesignationId,
                    FromOrganizationId = entity.UnitId,
                    IsApproved = true,
                    ToDesignationId = workFlow.ToDesignationId,
                    ToOrganizationId = workFlow.ToOrganizationId,
                    UpdatedBy = entity.UpdatedBy,
                    UpdatedDate = entity.UpdatedDate,
                    Note = entity.Note,
                    ReleaseOrderId = oldResult.Id
                });

                var result = await this.repository.UpdateAsync(oldResult);
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}