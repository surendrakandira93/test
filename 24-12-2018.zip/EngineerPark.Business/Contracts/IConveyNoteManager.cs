﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IConveyNoteManager
    {
        Task<ConveyNoteEntity> GetAsync(Guid id);
        Task<ConveyNoteEntity> GetByIdAsync(Guid id);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<ConveyNoteEntity> InsertAsync(ConveyNoteEntity entity);
        Task<bool> IsExistorNot(Guid authorityLetterId, Guid authorityLetterVechileDetailId, Guid id);
        Task<dynamic> GetVechiList(Guid authorityLetterId);
        Task<dynamic> GetItemCategories(Guid itemId, Guid authorityLetterId);
        Task<DataTableResult> GetAuthorityLetterPaggedListAsync(DataTableParameter parameters);
        List<MasterDataEntity> GetGroupItems(Guid itemId);
        List<MasterDataEntity> GetStockShed(Guid itemId, Guid itemGroupId);
        Task<List<MasterDataEntity>> GetSetNo(Guid itemId, Guid itemGroupId, short stockShedId, short storeId, Guid authorityLetterId);

        Task<ConveyNoteModelPrintEntity> GetAsyncForPrint(Guid id);
    }
}
