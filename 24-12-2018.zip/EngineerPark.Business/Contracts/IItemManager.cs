﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IItemManager
    {
       
        Task<ItemEntity> InsertAsync(ItemEntity entity);
               
        Task<ItemEntity> UpdateAsync(ItemEntity entity);

        Task<IList<ItemEntity>> GetAllAsync();

        Task<IList<ItemEntity>> GetUOMListAsync();

        Task<IList<ItemDetailEntity>> GetItemChildListAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters, int? isMaster);
        
        Task<ItemDetailEntity> ItemDetailAsync(Guid id);

        Task<ItemEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);

        Task<bool> IsExistorNot(string name, Guid id);

    }
}
