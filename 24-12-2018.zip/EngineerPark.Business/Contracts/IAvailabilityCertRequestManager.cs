﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IAvailabilityCertRequestManager
    {
        Task<AvailabilityCertRequestEntity> InsertAsync(AvailabilityCertRequestEntity entity);


        Task<AvailabilityCertRequestEntity> UpdateAsync(AvailabilityCertRequestEntity entity);

        Task<IList<AvailabilityCertRequestEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<AvailabilityCertRequestEntity> GetAsync(Guid id);

        Task<AvailabilityCertRequestPrintEntity> GetAsyncForPrint(Guid id);

        Task<int> DeleteAsync(Guid id);
        
        List<MasterDataEntity> AvlbCertRequestGroupItemDetailList(Guid GID);

        Task<AvailabilityCertRequestEntity> ApproveAsync(AvailabilityCertRequestEntity entity);
    }
}
