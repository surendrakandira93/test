﻿namespace EngineerPark.Business.Contracts
{

    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IMaterialTypeManager
    {
        Task<MaterialTypeEntity> InsertAsync(MaterialTypeEntity entity);


        Task<MaterialTypeEntity> UpdateAsync(MaterialTypeEntity entity);


        Task<IList<MaterialTypeEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<MaterialTypeEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
