﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IItemSetNumberManager
    {
        
        Task<ItemSetNumberEntity> InsertAsync(ItemSetNumberEntity entity);

      
        Task<ItemSetNumberEntity> UpdateAsync(ItemSetNumberEntity entity);

       
        Task<IList<ItemSetNumberEntity>> GetAllAsync();

      
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

       
        Task<ItemSetNumberEntity> GetAsync(int id);

       
        Task<int> DeleteAsync(int id);

       
        Task<bool> IsExistorNot(string name, int id);
    }
}
