﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IStoreStockTransactionManager
    {
        Task<StoreStockTransactionEntity> InsertAsync(StoreStockTransactionEntity entity);

        Task<StoreStockTransactionEntity> UpdateAsync(StoreStockTransactionEntity entity);

        Task<IList<StoreStockTransactionEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<StoreStockTransactionEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);

    }
}
