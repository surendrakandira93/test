﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IEquipmentManager
    {
        Task<EquipmentEntity> InsertAsync(EquipmentEntity entity);


        Task<EquipmentEntity> UpdateAsync(EquipmentEntity entity);


        Task<IList<EquipmentEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<EquipmentEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
