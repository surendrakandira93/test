﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ILoadTrolleyManager
    {
        Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<ConveningOrderEntity> GetAsync(Guid id);
        Task<LoadTrolleyEntity> InsertAsync(LoadTrolleyEntity entity);
        List<MasterDataEntity> GetStockShed(Guid itemId, Guid itemGroupId);
        List<MasterDataEntity> GetSetNo(Guid itemId, Guid itemGroupId, short stockShedId);

        Task<LoadTrollyPrintEntity> GetAsyncForPrint(Guid id);
    }
}
