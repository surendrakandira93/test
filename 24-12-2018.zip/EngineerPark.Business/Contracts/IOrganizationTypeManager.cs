﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
   public interface IOrganizationTypeManager
    {
        /// <summary>
        /// Inserts the asynchronous.
        /// </summary>
        /// <param name="entity">The designation entity.</param>
        /// <returns>Designation Id</returns>
        Task<OrganizationTypeEntity> InsertAsync(OrganizationTypeEntity entity);

        /// <summary>
        /// Updates the asynchronous.
        /// </summary>
        /// <param name="entity">The designation entity.</param>
        /// <returns>true or false</returns>
        Task<OrganizationTypeEntity> UpdateAsync(OrganizationTypeEntity entity);

        /// <summary>
        /// Gets all asynchronous.
        /// </summary>
        /// <returns>List Designation Detail Entity</returns>
        Task<IList<OrganizationTypeEntity>> GetAllAsync();

        /// <summary>
        /// Gets the pagged list asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns>GetPaggedListAsync</returns>
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        /// <summary>
        /// Gets the asynchronous.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Designation Detail Entity</returns>
        Task<OrganizationTypeEntity> GetAsync(byte id);

        /// <summary>
        /// Deletes the asynchronous.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>true or false</returns>
        Task<int> DeleteAsync(byte id);

        /// <summary>
        /// Determines whether [is existor not] [the specified name].
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>IsExistorNot</returns>
        Task<bool> IsExistorNot(string name, byte id);
    }
}
