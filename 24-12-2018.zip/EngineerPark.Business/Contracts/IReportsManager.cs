﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using EngineerPark.Business.Entities.Reports;
using EngineerPark.Business.Entities.ViewReports;

namespace EngineerPark.Business.Contracts
{

    public interface IReportsManager
    {
        Task<IList<LoanStateViewEntity>> GetLoanStateAsync(short categoryId, short orginationId); 

        Task<IList<DepositeStatusReportEntity>> GetDepositStatusAsync(short categoryId, short orginationId); 

        Task<IList<ETSRStateViewEntity>> GetEtsrStateAsync(short typeOfStoreId, short categoryId, short orginationId);

        Task<IList<QuaterlyReportEntity>> GetQuaterlyDateWiseAsync(BaseFormDateWiseReportEntity entity);

        Task<IList<AuthorizedItemMSLViewEntity>> GetAuthorizedItemMSLViewAsync();

        Task<IList<ETSRSummeryViewEntity>> GetEtsrSummeryAsync();

        Task<IList<CategoryWiseViewEntity>> GetCategoryWiseRptAsync(short categoryId);

        Task<IList<BasicCategoryWiseViewEntity>> GetBasicCategoryWiseRptAsync(short categoryId);

        Task<IList<BasicCategorySummeryViewEntity>> GetBasicCategorySummeryAsync();

        Task<IList<ETSRStateViewEntity>> GetIssueStatusAsync();

        DataSet GetStateAsOnDate(short categoryId, short orginationId);

        DataSet GetRP3(int? TypeofStoreId, short? categoryId, short? orginationId);

        DataSet GetRP4(int? TypeofStoreId, short? categoryId, short? orginationId);

        DataSet GetStateCustom(string col, string wh, string groupBy, string col1, string groupBy1);

        DataSet LoanComparison(LoanComparisonReportEntity entity);

        DataSet InventoryComparison(InventoryComparisonReportEntity entity);

    }
}
