﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
namespace EngineerPark.Business.Contracts
{
  public  interface IJobOrderManager 
    {
        Task<JobOrderDetailsReponse> GetJobOrderDetailsAsync(short categoryId, int quarterlyMaintenancePlanId, short organizationId);
        Task<JobOrderResponseEntity> GetJobOrderItemDetailsAsync(short materialTypeId, int quarterlyMaintenancePlanId, short organizationId,short categoryId);
        Task<JobOrderEntity> InsertJobOrderAsync(JobOrderEntity entity);
        Task<JobOrderResponseEntity> GetApprovedAsync(int id, short orgId, short desId);
        Task<JobOrderApprovalEntity> InsertApproveAsync(JobOrderApprovalEntity entity);
        Task<JobOrderEntity> GetJobOrderAsync(int id, short organizationId);
        Task<DataTableResult> GetJobOrderPaggedListAsync(DataTableParameter parameters);
        Task<JobOrderActionEntity> InsertActionAsync(JobOrderActionEntity entity);
        Task<JobOrderResponseEntity> GetActionAsync(int id);
    }
}
