﻿//namespace EngineerPark.Business.Contracts
//{
//    using System;
//    using System.Collections.Generic;
//    using System.Threading.Tasks;
//    using EngineerPark.Business.Entities;
//    using EngineerPark.CrossCutting;
//    public interface IGroupItemDetailManager
//    {
//        Task<GroupItemDetailEntity> InsertAsync(GroupItemDetailEntity entity);
        
//        Task<GroupItemDetailEntity> UpdateAsync(GroupItemDetailEntity entity);
        
//        Task<IList<GroupItemDetailEntity>> GetAllAsync();
        
//        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        
//        Task<GroupItemDetailEntity> GetAsync(Guid id);
        
//        Task<int> DeleteAsync(Guid id);
        
        
//    }
//}
