﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public  interface IEquipmentTypeManager
    {
        Task<EquipmentTypeEntity> InsertAsync(EquipmentTypeEntity entity);


        Task<EquipmentTypeEntity> UpdateAsync(EquipmentTypeEntity entity);


        Task<IList<EquipmentTypeEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<EquipmentTypeEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
