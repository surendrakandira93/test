﻿
namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface ICategoryManager
    {

        Task<CategoryEntity> InsertAsync(CategoryEntity entity);


        Task<CategoryEntity> UpdateAsync(CategoryEntity entity);


        Task<IList<CategoryEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<CategoryEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
