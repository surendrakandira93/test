﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface IReportPermissionManager
    {
        Task<ReportEntity> InsertAsync(ReportEntity entity);


        Task<ReportEntity> UpdateAsync(ReportEntity entity);


        Task<IList<ReportEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<DataTableResult> GetPaggedPermissionListAsync(DataTableParameter parameters, int id);


        Task<ReportEntity> GetAsync(int id);


        Task<int> DeleteAsync(int id);

        Task<ReportPermissionEntity> InsertPermissionAsync(ReportPermissionEntity entity);


        Task<bool> IsExistorNot(string name, int id);
    }
}
