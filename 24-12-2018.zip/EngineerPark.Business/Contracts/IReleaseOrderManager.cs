﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Threading.Tasks;

    public  interface IReleaseOrderManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<ReleaseOrderEntity> GetAsync(Guid loanRequestId, short organizationId, short designationId);
        Task<ReleaseOrderEntity> GetByLoanIdAsync(Guid loanRequestId, short organizationId, short designationId);
        Task<ReleaseOrderEntity> InsertAsync(ReleaseOrderEntity entity);
        Task<ReleaseOrderEntity> ApproveAsync(ReleaseOrderEntity entity);
    }
}
