﻿namespace EngineerPark.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;

    public interface ITaskWorkFlowManager
    {
        Task<List<TaskWorkFlowEntity>> InsertAsync(TaskWorkFlowResponseEntity entities);

        Task<List<TaskWorkFlowEntity>> UpdateAsync(List<TaskWorkFlowEntity> entities);        

        Task<TaskWorkFlowResponseEntity> GetAsync(short fromOrganizationId,short id);

    }
}