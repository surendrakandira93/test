﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface ILoanReceiptVoucherManager
    {
        Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<LoanReceiptVoucherEntity> GetAsync(Guid id);
        Task<LoanReceiptVoucherEntity> InsertAsync(LoanReceiptVoucherEntity entity);
        Task<LoanReceiptVoucherPrintEntity> GetAsyncForPrint(Guid id);
    }
}
