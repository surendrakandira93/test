﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
  public  interface ILoanRequestManager
    {
        Task<int> DeleteAsync(Guid id);
        Task<LoanRequestEntity> GetByIssueIdAsync(Guid issueId);
        Task<LoanRequestEntity> GetAsync(Guid issueId);
        Task<DataTableResult> GetIssuePaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<LoanRequestEntity> InsertAsync(LoanRequestEntity entity);

        Task<LoanRequestPrintEntity> GetAsyncForPrint(Guid id);

        Task<LoanRequestEntity> UpdateAsync(LoanRequestEntity entity);
        Task<LoanRequestEntity> ApproveAsync(LoanRequestEntity entity);
    }
}
