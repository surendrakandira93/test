﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface ILoanRenewalManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters);
        Task<LoanRenewalEntity> GetAsync(int id, short organizationId, short designationId);
        Task<LoanRenewalEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId);
        Task<LoanRenewalEntity> InsertAsync(LoanRenewalEntity entity);
        Task<LoanRenewalApprovedEntity> ApproveAsync(LoanRenewalApprovedEntity entity);
    }
}
