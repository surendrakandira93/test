﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

  public  interface IStatusManager
    {
        Task<StatusEntity> InsertAsync(StatusEntity entity);


        Task<StatusEntity> UpdateAsync(StatusEntity entity);


        Task<IList<StatusEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<StatusEntity> GetAsync(byte id);


        Task<int> DeleteAsync(byte id);


        Task<bool> IsExistorNot(string name, byte id);
    }
}
