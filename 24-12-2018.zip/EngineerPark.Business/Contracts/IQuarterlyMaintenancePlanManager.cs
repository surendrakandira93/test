﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface IQuarterlyMaintenancePlanManager
    {
        Task<QuarterlyMaintenancePlanGroupDetailsReponse> GetMaintenancePlanDetailsAsync(short categoryId, int maintenancePlanId, short organizationId);
        Task<QuarterlyMaintenancePlanResponseEntity> GetMaintenancePlanItemDetailsAsync(short materialTypeId, int maintenancePlanId, short organizationId, int quarter,int categoryId);
        Task<QuarterlyMaintenancePlanEntity> InsertMaintenancePlanAsync(QuarterlyMaintenancePlanEntity entity);
        Task<QuarterlyMaintenancePlanResponseEntity> GetApprovedAsync(int id, short orgId, short desId);
        Task<QuarterlyMaintenancePlanApprovalEntity> InsertApproveAsync(QuarterlyMaintenancePlanApprovalEntity entity);
        Task<QuarterlyMaintenancePlanEntity> GetMaintenanceAsync(int maintenancePlanId, int quarterType, short organizationId);
        Task<DataTableResult> GetMaintenancePaggedListAsync(DataTableParameter parameters);

        Task<List<MasterDataEntity>> GetApprovedPlan(int maintenancePlanId);
    }
}
