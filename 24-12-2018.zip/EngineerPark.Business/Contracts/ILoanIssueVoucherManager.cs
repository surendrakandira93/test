﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface ILoanIssueVoucherManager
    {
        Task<DataTableResult> GetReleaseOrderPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<LoanIssueVoucherEntity> GetAsync(Guid id);
        Task<LoanIssueVoucherEntity> InsertAsync(LoanIssueVoucherEntity entity);
        Task<LoanIssueVoucherPrintEntity> GetAsyncForPrint(Guid id);
        Task<LoanIssueVoucherEntity> GetByIdAsync(Guid id);
    }
}
