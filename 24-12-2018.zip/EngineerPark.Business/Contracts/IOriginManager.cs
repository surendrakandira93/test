﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IOriginManager
    {

        Task<OriginEntity> InsertAsync(OriginEntity entity);


        Task<OriginEntity> UpdateAsync(OriginEntity entity);


        Task<IList<OriginEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<OriginEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
