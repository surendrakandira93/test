﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business
{
    public interface IMaintenanceManager
    {
        Task<List<PeriodicityEntity>> GetPeriodicityAsync(Guid id);
        Task<List<CarePriceEntity>> GetCarePriceAsync(Guid id, int year);
        Task<List<PeriodicityEntity>> InsertPeriodicityAsync(List<PeriodicityEntity> entity);
        Task<List<CarePriceEntity>> InsertCarePriceAsync(List<CarePriceEntity> entity);
        Task<MaintenancePlanGroupDetailsReponse> GetMaintenancePlanDetailsAsync(short categoryId, int year, short organizationId);
        Task<MaintenancePlanResponseEntity> GetMaintenancePlanItemDetailsAsync(Guid groupId, int year, short organizationId,int planType);
        Task<MaintenancePlanEntity> InsertMaintenancePlanAsync(MaintenancePlanEntity entity);
        Task<List<MasterDataEntity>> GetYearAsync(short organizationId, int planType);
        Task<MaintenancePlanEntity> GetMaintenanceAsync(int year, short organizationId);
        Task<List<AnnualBudgetReportEntity>> GetAnnualBudgetReportAsync(int year, short organizationId);
        Task<MaintenanceSchedulePlanEntity> GetAnnualBudgetGroupDetailsAsync(int id);
        Task<MaintenanceSchedulePlanEntity> InsertMaintenanceSchedulePlanAsync(MaintenanceSchedulePlanEntity entity);
        Task<AnnualCPMBudgetEntity> InsertAnnualCpmbudgetAsync(AnnualCPMBudgetEntity entity);
        Task<DataTableResult> GetMaintenancePaggedListAsync(DataTableParameter parameters);


        Task<MaintenancePlanResponseEntity> GetApprovedAsync(int id, short orgId, short desId);
        Task<MaintenancePlanApprovedEntity> InsertApproveAsync(MaintenancePlanApprovedEntity entity);

        Task<List<MasterDataEntity>> GetApprovedPlan();
    }
}
