﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IDepartmentManager
    {

        Task<DepartmentEntity> InsertAsync(DepartmentEntity entity);


        Task<DepartmentEntity> UpdateAsync(DepartmentEntity entity);


        Task<IList<DepartmentEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<DepartmentEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
