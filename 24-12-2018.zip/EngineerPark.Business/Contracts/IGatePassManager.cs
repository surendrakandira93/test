﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Threading.Tasks;

    public interface IGatePassManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetConveyNotePaggedListAsync(DataTableParameter parameters);
        Task<GatePassEntity> GetAsync(Guid id, short organizationId, short designationId);
        Task<GatePassEntity> InsertAsync(GatePassEntity entity);
        Task<GatePassEntity> ApproveAsync(GatePassEntity entity);
    }
}
