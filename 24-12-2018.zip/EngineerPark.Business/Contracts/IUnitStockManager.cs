﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IUnitStockManager
    {
        Task<UnitStockEntity> InsertAsync(UnitStockEntity entity);


        Task<UnitStockEntity> UpdateAsync(UnitStockEntity entity);

        Task<IList<UnitStockEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<UnitStockEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);
    }
}
