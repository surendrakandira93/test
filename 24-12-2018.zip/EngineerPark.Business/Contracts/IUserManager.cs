﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
   public interface IUserManager
    {
        Task<bool> InsertAsync(UserEntity entity);

        Task<UserEntity> UpdateAsync(UserEntity entity);

        Task<IList<UserEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        UserEntity Get(Guid id);

        Task<int> DeleteAsync(Guid id);

        Task<bool> IsExistorNot(string name, Guid id);

        Task<Tuple<Guid, bool>> LoginAsync(Loginentity entity);

        Task<(List<DisplayRoleMenuEntity> menu, UserEntity user, List<ReportsEntity> report)> UserByUserNameAsync(string userName);

        List<MasterDataEntity> GetPoTypeUser(short orgId);

        Task<Guid> LogOutHistoryAsync(Guid userId, string ip);

        Task<Guid> LoginHistoryAsync(Guid userId, string ip);

        Task<UserMacList> GetUsetMacAddressList(Guid userId);

        Task<bool> InsertMacAddressAsync(UserMacEntity entity);

        Task<UserMacEntity> UpdateMacAddressAsync(UserMacEntity entity);

        Task<int> DeleteMacAddressAsync(int id);
    }
}
