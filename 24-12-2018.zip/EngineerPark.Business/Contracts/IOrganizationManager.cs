﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IOrganizationManager
    {
        Task<OrganizationEntity> InsertAsync(OrganizationEntity entity);


        Task<OrganizationEntity> UpdateAsync(OrganizationEntity entity);


        Task<IList<OrganizationEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<OrganizationEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);

        Task<List<TreeEntity>> GetChildOrgAsync(int id);
    }
}
