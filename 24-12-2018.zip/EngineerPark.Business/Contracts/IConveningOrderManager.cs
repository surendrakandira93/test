﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;


    public interface IConveningOrderManager
    {
        Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<ConveningOrderEntity> GetAsync(Guid id);
        Task<ConveningOrderEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId, short organizationId, short designationId);
        Task<ConveningOrderEntity> InsertAsync(ConveningOrderEntity entity);
        Task<ConveningOrderEntity> ApproveAsync(ConveningOrderEntity entity);
        Task<bool> SaveOrderMember(ConveningOrderMainMember entity);

    }
}
