﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Threading.Tasks;

    public interface ISenctionOrderManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters);
        Task<ConveningOrderEntity> GetAsync(Guid id);
        Task<SenctionOrderEntity> InsertAsync(SenctionOrderEntity entity);
        Task<SenctionOrderEntity> ApproveAsync(SenctionOrderEntity entity);
    }
}
