﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
   public interface IAuthorityLetterManager
    {
        Task<bool> IsExistorNot(Guid id, Guid releaseOrderId);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetLoanRequestPaggedListAsync(DataTableParameter parameters);
        Task<AuthorityLetterEntity> InsertAsync(AuthorityLetterEntity entity);
        Task<AuthorityLetterEntity> GetAsync(Guid id, short organizationId, short designationId);
        Task<AuthorityLetterEntity> ApproveAsync(AuthorityLetterEntity entity);
        Task<AuthorityLetterPrintEntity> GetAsyncForPrint(Guid id);
    }
}
