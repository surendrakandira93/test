﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IStoreStockTransactionSetNoManager
    {
        Task<StoreStockTransactionSetNoEntity> InsertAsync(StoreStockTransactionSetNoEntity entity);

        Task<StoreStockTransactionSetNoEntity> UpdateAsync(StoreStockTransactionSetNoEntity entity);

        Task<IList<StoreStockTransactionSetNoEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<StoreStockTransactionSetNoEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);

    }
}
