﻿using EngineerPark.Business.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
  public interface IMasterDataManager
    {
        Task<List<MasterDataEntity>> States();
        Task<List<MasterDataEntity>> OrganizationType();
        Task<List<MasterDataEntity>> Organization();
        Task<List<MasterDataEntity>> OrganizationEP();
        Task<List<MasterDataEntity>> OrganizationUnit();
        Task<List<MasterDataEntity>> OrganizationAuthFor();
        Task<List<MasterDataEntity>> Category();
        Task<List<MasterDataEntity>> UnitOfMeasure();
        Task<List<MasterDataEntity>> MaterialType();
        Task<List<MasterDataEntity>> Items(short? categoryId, int? isMaster);
        Task<List<MasterDataEntity>> TransactionType();
        Task<List<MasterDataEntity>> BasicCategory();
        Task<List<MasterDataEntity>> Equipment();
        Task<List<MasterDataEntity>> EquipmentType();
        Task<List<MasterDataEntity>> ItemStatus();
        Task<List<MasterDataEntity>> Origin();
        Task<List<MasterDataEntity>> ShedType();
        Task<List<MasterDataEntity>> StockShed();
        Task<List<MasterDataEntity>> Level();
        Task<List<MasterDataEntity>> GroupItem();
        Task<List<MasterDataEntity>> GroupItemCatIdWise(short? categoryId);
        Task<List<MasterDataEntity>> Role();
        Task<List<MasterDataEntity>> Designation(short? orgId);
        Task<List<MasterDataEntity>> Department();
        Task<List<MasterDataEntity>> TaskList();
        Task<List<MasterDataEntity>> ItemSetNoList();


    }
}
