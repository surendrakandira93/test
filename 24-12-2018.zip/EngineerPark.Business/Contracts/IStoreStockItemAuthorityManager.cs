﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public   interface IStoreStockItemAuthorityManager
    {
        Task<List<StoreStockItemAuthorityEntity>> InsertAsync(List<StoreStockItemAuthorityEntity> entity);
        
        Task<StoreStockItemAuthorityEntity> UpdateAsync(StoreStockItemAuthorityEntity entity);
        
        Task<IList<StoreStockItemAuthorityEntity>> GetAllAsync();
        
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<StoreStockItemAuthorityEntity> GetAsyncDetail(Guid id);


        Task<StoreStockItemAuthorityEntity> GetAsync(Guid id);
        
        Task<int> DeleteAsync(Guid id);
                
        Task<IList<MasterDataEntity>> GetSSIAAuthForAsync();

        Task<IList<MasterDataEntity>> GetSSIABasicCatAsync();

        Task<IList<MasterDataEntity>> GetSSIAGroupItemAsync();

    }
}
