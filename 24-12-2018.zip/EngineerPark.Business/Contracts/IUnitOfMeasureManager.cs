﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IUnitOfMeasureManager
    {


        Task<UnitOfMeasureEntity> InsertAsync(UnitOfMeasureEntity entity);


        Task<UnitOfMeasureEntity> UpdateAsync(UnitOfMeasureEntity entity);


        Task<IList<UnitOfMeasureEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<UnitOfMeasureEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}

