﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public  interface IStoreStockManager
    {
        Task<StoreStockEntity> InsertAsync(StoreStockEntity entity);
        
        Task<StoreStockEntity> UpdateAsync(StoreStockEntity entity);

        Task<List<StoreStockEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<StoreStockEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);

        //Task<IList<MasterDataEntity>> StoreStockGroupItemList();

        List<MasterDataEntity> StoreStockGroupItemDetailList(Guid GID);

        //Task<IList<MasterDataEntity>> StoreStockOrganizationHeldByList(Guid GID);

    }
}
