﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IStockShedManager
    {

        Task<StockShedEntity> InsertAsync(StockShedEntity entity);


        Task<StockShedEntity> UpdateAsync(StockShedEntity entity);


        Task<IList<StockShedEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<StockShedEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
