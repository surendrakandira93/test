﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface ISalvageManager
    {
        Task<DataTableResult> GetPaggedInListAsync(DataTableParameter parameters);
        Task<DataTableResult> GetPaggedOutListAsync(DataTableParameter parameters);
        Task<SalvageInEntity> InsertInAsync(SalvageInEntity entity);
        Task<SalvageOutEntity> InsertOutAsync(SalvageOutEntity entity);
        Task<SalvageInEntity> GetInAsync(int id);
        Task<SalvageOutEntity> GetOutAsync(int id);
        Task<double> GetAvailableQty(short storeId, short materialTypeId);
    }
}
