﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IDesignationManager
    {
        
        Task<DesignationEntity> InsertAsync(DesignationEntity entity);

      
        Task<DesignationEntity> UpdateAsync(DesignationEntity entity);

       
        Task<IList<DesignationEntity>> GetAllAsync();

      
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

       
        Task<DesignationEntity> GetAsync(short id);

       
        Task<int> DeleteAsync(short id);

       
        Task<bool> IsExistorNot(string name, short id);
    }
}
