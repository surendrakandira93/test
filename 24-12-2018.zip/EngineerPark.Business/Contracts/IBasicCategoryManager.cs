﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IBasicCategoryManager
    {
        Task<BasicCategoryEntity> InsertAsync(BasicCategoryEntity entity);


        Task<BasicCategoryEntity> UpdateAsync(BasicCategoryEntity entity);


        Task<IList<BasicCategoryEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<BasicCategoryEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);
    }
}
