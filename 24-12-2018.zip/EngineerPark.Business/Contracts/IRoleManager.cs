﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IRoleManager
    {
        Task<RoleEntity> InsertAsync(RoleEntity entity);


        Task<RoleEntity> UpdateAsync(RoleEntity entity);


        Task<IList<RoleEntity>> GetAllAsync();


        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);


        Task<RoleEntity> GetAsync(short id);


        Task<int> DeleteAsync(short id);


        Task<bool> IsExistorNot(string name, short id);

        Task<List<RoleParentMenuEntity>> GetMenu();

        Task<List<ReportsEntity>> Report();

        Task<List<DisplayRoleMenuEntity>> GetMenuByRoleId(short roleId);
    }
}
