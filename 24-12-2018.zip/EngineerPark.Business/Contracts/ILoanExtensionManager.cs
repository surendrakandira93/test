﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
    public interface ILoanExtensionManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<DataTableResult> GetPaggedReleaseOrderListAsync(DataTableParameter parameters);

        Task<LoanExtensionEntity> GetAsync(int id, short organizationId, short designationId);

        Task<LoanExtensionEntity> GetByReleaseOrderIdAsync(Guid releaseOrderId);

        Task<LoanExtensionEntity> InsertAsync(LoanExtensionEntity entity);

        Task<LoanExtensionApprovedEntity> ApproveAsync(LoanExtensionApprovedEntity entity);
    }
}
