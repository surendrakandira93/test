﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;

    public interface IStoreStockTransactionQuantityManager
    {
        Task<StoreStockTransactionQuantityEntity> InsertAsync(StoreStockTransactionQuantityEntity entity);

        Task<StoreStockTransactionQuantityEntity> UpdateAsync(StoreStockTransactionQuantityEntity entity);

        Task<IList<StoreStockTransactionQuantityEntity>> GetAllAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<StoreStockTransactionQuantityEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);

    }
}
