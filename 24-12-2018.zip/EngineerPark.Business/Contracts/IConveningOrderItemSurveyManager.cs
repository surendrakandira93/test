﻿namespace EngineerPark.Business.Contracts
{
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;

    public interface IConveningOrderItemSurveyManager
    {
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<ConveningOrderSurveyEntity> GetAsync(Guid id);
        Task<ConveningOrderSurveyEntity> GetByConveningOrderIdAsync(Guid conveningOrderId);
        Task<bool> InsertAsync(ConveningOrderItemSurveyMainEntity entity);
        Task<ConveningOrderItemSurveyPrintEntity> GetAsyncForPrint(Guid id);
        Task<DataTableResult> GetConveningOrderPaggedListAsync(DataTableParameter parameters);
        Task<List<ConveningOrderSurveySalvageTempEntity>> AddEditSalvage(List<ConveningOrderSurveySalvageTempEntity> model, Guid conveningOrderId);
        Task<List<ConveningOrderSurveySalvageTempEntity>> GetSalvage(Guid conveningOrderId);
    }
}
