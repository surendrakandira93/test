﻿namespace EngineerPark.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EngineerPark.Business.Entities;
    using EngineerPark.CrossCutting;
    public interface IGroupItemManager
    {

        Task<GroupItemEntity> InsertAsync(GroupItemEntity entity);
        
        Task<GroupItemEntity> UpdateAsync(GroupItemEntity entity);
        
        Task<IList<GroupItemEntity>> GetAllAsync();

        Task<IList<GroupItemDetlEntity>> GetGroupItemChildListAsync();

        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);

        Task<GroupItemEntity> GroupItemDetailAsync(Guid id);

        Task<GroupItemEntity> GetAsync(Guid id);

        Task<int> DeleteAsync(Guid id);
        
        Task<bool> IsExistorNot(string name, Guid id);


        Task<IList<GroupItemMslEntity>> GroupItemsbyCatagoryAsync(short catId);
        Task<GroupItemEntity> UpdateMslAsync(GroupItemMslModelEntity entityMsl);
        Task<List<GroupItemDto>> GetitemDetails(Guid groupId);


    }
}
