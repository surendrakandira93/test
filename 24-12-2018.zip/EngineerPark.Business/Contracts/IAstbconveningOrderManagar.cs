﻿using EngineerPark.Business.Entities;
using EngineerPark.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EngineerPark.Business.Contracts
{
   public interface IAstbconveningOrderManagar
    {
        Task<AstbconveningOrderEntity> InsertAsync(AstbconveningOrderEntity entity);
        Task<AstbApprovedEntity> ApproveAsync(AstbApprovedEntity entity);
        Task<AstbconveningOrderEntity> GetAsync(Guid id);
        Task<DataTableResult> GetPaggedListAsync(DataTableParameter parameters);
        Task<StockPrintEntity> StockPrint(short storeId, short categoryId);
        Task<DataTableResult> GetPaggedListForPOAsync(DataTableParameter parameters);
        Task<Astbstoredetails> GetByIdAsync(Guid id);
        Task<Astbstoredetails> GetByIdAsync(Guid id, short storeId, short categoryId);
        Task<Astbstoredetails> InsertstockAsync(Astbstoredetails entity);
        Task<Astbstoredetails> GetApprovedAsync(Guid id, short orgId, short desId);
        Task<bool> UpdateBDOffers(short orgId, short destId);
        Task<DataTableResult> GetPaggedListForAdemondAsync(DataTableParameter parameters);
        Task<List<AstbsalvageTempEntity>> AddEditAstbSalvage(List<AstbsalvageTempEntity> model, Guid astbOrderId);
        Task<List<AstbsalvageTempEntity>> GetAstbSalvage(Guid astbOrderId);
    }
}
