﻿using EngineerPark.Business.Entities;

namespace EngineerPark.Business.Contracts
{
    public interface IDashboardManager
    {
        DashboardNotificationEntity Notification(NotificationMainEntity model);
    }
}
