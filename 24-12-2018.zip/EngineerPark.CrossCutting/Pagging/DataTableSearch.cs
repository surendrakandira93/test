﻿namespace EngineerPark.CrossCutting
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class DataTableSearch
    {

        public string Value { get; set; }

        public bool Regex { get; set; }
    }
}
