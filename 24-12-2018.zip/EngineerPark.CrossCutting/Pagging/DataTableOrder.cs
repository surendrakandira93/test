﻿namespace EngineerPark.CrossCutting
{
    using System;
    using System.Collections.Generic;
    using System.Text;

   
    public class DataTableOrder
    {
       
        public int Column { get; set; }

       
        public string Dir { get; set; }
    }
}
