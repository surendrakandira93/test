﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.CrossCutting
{
    public class Constants
    {
        /// <summary>
        /// The tm cors policy
        /// </summary>
        public const string ApplicationCorsPolicy = "EngineerParkPolicy";
        public const string ApplicationVersion = "1.0";
        public const string ETAG_HEADER = "ETag";
        public const string MATCH_HEADER = "If-Match";
        public const string DATE_FORMAT = "dd/MM/yyyy";
        ////public const Guid UserId = new Guid("72ec1842-c0d8-4802-a9da-74860bede084");
    }
}
