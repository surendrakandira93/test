﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineerPark.CrossCutting.Extensions
{
    public static class StringExtension
    {
        
            public static string RemoveQuotes(this string value)
            {
                if (string.IsNullOrEmpty(value)) return "";
                return value.Replace("\"", "");
            }

            //public static string RemoveQuotes(this string value)
            //{
            //    if (string.IsNullOrEmpty(value)) return "";
            //    return value.ToString().Replace("\"", "");
            //}
        
    }
}
