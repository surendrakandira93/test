﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace EngineerPark.CrossCutting
{
    public enum TaskTypeEnum
    {
        Request = 1,                    //Avlb Cert Request
        Issue = 2,                      //Avlb Cert Issue
        Approval = 3,                   //Loan Request
        ReleaseOrder = 4,               //Release Order
        AuthorityLetterApproval = 5,    //Authority Letter Approval
        ConveyNote =6,                  //Convey Note
        GatePass = 7,                   //Gate Pass
        ConveningOrder = 8,             //Convening Order
        SenctionOrder = 9    ,          //Senction Order
        ASTB = 10 ,                     // ASTB Convenning order
        MaintenancePlan=11,             // Maintenance Plan
        QuarterlyMaintenancePlan = 12,  //QuarterlyMaintenanceSchedule
        JobOrder = 13,                  //JobOrder
        LoanExtension= 14,              //LoanExtension
        LoanRenewal=15                  //LoanRenewal

    }

    public enum TransactionTypeEnum
    {
        OpeningBalance=1,
        Issue=2,
        Deposit=3,
        Block=4,
        JobOrderOut = 5,
        JobOrderIn = 6
    }

    public enum ItemStatusEnum
    {
        Serviceable=1,
        Repairable=2,
        OnLoan=3,
        Salvage=4
    }

    public enum StatusEnum
    {
        [Description("Pending")]
        Pending = 1,
        [Description("In Approval Process")]
        InApprovalProcess = 2,
        [Description("Rejected")]
        Rejected = 3,
        [Description("Approved")]
        Approved = 4,
        [Description("Issued Release Order")]
        IssuedReleaseOrder = 5,
        [Description("Loan Recived")]
        LoanRecived = 6,
        [Description("Request For Convening Order")]
        RequestForConveningOrder = 7,
        [Description("Issued Convening Order")]
        IssuedConveningOrder = 8,
        [Description("Conditioning Board")]
        ConditioningBoard = 9,
        [Description("Survey Done")]
        SurveyDone = 10,
        [Description("Issued Senction Order")]
        IssuedSenctionOrder = 11,
        [Description("Load Trolly")]
        LoadTrolly = 12,
        [Description("Loan Deposit")]
        Loandeposit = 13
    }

    public enum OrganizationEnum
    {
        Admin=1,
        EPBTI=7
    }

    public enum RoleTypeEnum
    {
        Admin = 1
    }


    public enum PlanType
    {
        Fresh = 1,
        Amendment = 2,
        Supplementary = 3
    }

    public enum QuarterType
    {

        [Description("I Quarter")]
        Quarter1 = 1,
        [Description("II Quarter")]
        Quarter2 = 2,
        [Description("III Quarter")]
        Quarter3 = 3,
        [Description("IV Quarter")]
        Quarter4 = 4

    }

    public enum JobOrderType
    {
        Vender = 1,
        Troops = 2
    }

    public enum JobOrderStatus
    {
        Complete = 1,
        Cancel = 2
    }
}
