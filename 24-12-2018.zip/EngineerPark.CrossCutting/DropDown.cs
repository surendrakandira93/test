﻿namespace EngineerPark.CrossCutting
{
    using Newtonsoft.Json;

    /// <summary>
    /// Dropdown
    /// </summary>
    public class Dropdown
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        [JsonProperty(PropertyName = "text")]
        public string Name { get; set; }

        /////// <summary>
        /////// Gets or sets the addtional property.
        /////// </summary>
        /////// <value>
        /////// The addtional property.
        /////// </value>
        ////[JsonProperty(PropertyName = "text")]
        ////public string AdditionalProperty { get; set; }
    }
}
